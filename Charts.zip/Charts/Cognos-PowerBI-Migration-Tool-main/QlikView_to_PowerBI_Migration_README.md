# QlikView to Power BI Migration — ReportBridge

End-to-end guide to the `qlik_engine` migration tool: what it does, how
the pipeline is structured, how to run it locally, what you get out of
it, and exactly what does and doesn't convert automatically today.

## Agenda

1. [What this tool does](#1-what-this-tool-does)
2. [How it works — the two-stage pipeline](#2-how-it-works--the-two-stage-pipeline)
3. [Requirements](#3-requirements)
4. [Folder structure](#4-folder-structure)
5. [How to run it](#5-how-to-run-it)
6. [What gets generated](#6-what-gets-generated)
7. [Migration coverage — what converts, what doesn't](#7-migration-coverage--what-converts-what-doesnt)
8. [Migration coverage — by report and model complexity](#8-migration-coverage--by-report-and-model-complexity)
9. [Where to look when something looks wrong](#9-where-to-look-when-something-looks-wrong)
10. [Known limitations](#10-known-limitations)
11. [Initializing via the unified launcher (`report_migration_tool.py`)](#11-initializing-via-the-unified-launcher-report_migration_toolpy)

---

## 1. What this tool does

ReportBridge converts a **QlikView (.qvw) desktop application** into a
**Power BI Project (.pbip)** that opens directly in Power BI Desktop —
without hand-rebuilding the data model, relationships, DAX measures,
Power Query, or report visuals from scratch.

Input is a QlikView PRJ export folder (QlikView → Settings → User
Preferences → Design → *Generate Project Folder*, saved alongside the
`.qvw`): `LoadScript.txt`, `AllProperties.xml`, `DocInternals.xml` /
`DocProperties.xml`, and one XML file per sheet and per sheet object.

Output is a `.pbip` folder: a TMDL semantic model (tables, columns,
measures, relationships, M-query partitions), a PBIR report definition
(one JSON file per page/visual), a starter DAX measures script, a
relationships report, and a migration-notes file naming every object
that needs manual review — nothing is silently dropped.

## 2. How it works — the two-stage pipeline

```
qlik_source/<App>-PRJ/          Stage 1: extraction            Stage 2: migration
  LoadScript.txt          ──┐                              ┌──  PowerBIScript/PBIP/<App>/
  AllProperties.xml         │   qlik_metadata_extractor      │      <App>.pbip
  DocInternals.xml          ├──►  (main.py)              ────┼──►  <App>.Report/...
  SH01.xml, LB01.xml, ...    │                                │      <App>.SemanticModel/...
  CH01.xml, SB01.xml, ...  ──┘                              ──┘   PowerBIScript/DAX, MQueries, Relationships
                             │                                │
                             ▼                                ▼
                    Qlik_Script_MetaData/*.json      MigrationEngine
                    Qlik_Visual_MetaData/*.json      (python -m MigrationEngine)
```

- **Stage 1 — `qlik_metadata_extractor`** parses the raw QlikView PRJ
  XML into two structured JSON repositories: the load script/table
  model (`Qlik_Script_MetaData/<App>.json`) and every sheet's visual
  objects — listboxes, multiboxes, charts, statistics boxes, textboxes
  (`Qlik_Visual_MetaData/<App>_visual_metadata.json`).
- **Stage 2 — `MigrationEngine`** reads only those two JSON
  repositories (it never touches QlikView XML directly) and generates
  the actual `.pbip` project: M queries, DAX measures, relationships,
  TMDL tables, and report-page visual JSON.

Because the two stages only talk to each other through those JSON
files, you can re-run Stage 2 as many times as you like (e.g. after a
code fix) without re-extracting from QlikView, as long as the JSON is
already there.

## 3. Requirements

- **Python 3.8+ — that's it.** Every module in both
  `qlik_metadata_extractor` and `MigrationEngine` uses only the
  standard library (`xml.etree.ElementTree`, `json`, `re`, `csv`,
  `pathlib`, `dataclasses`, `uuid`, ...). No `pip install` step, no
  `requirements.txt` entries for this tool.
- **Power BI Desktop** (any recent version) to open the generated
  `.pbip` and let it validate/refresh the model.

## 4. Folder structure

```
qlik_engine/
├── main.py                        <- Stage 1 entry point (extraction)
├── Qlik_input_files/               <- default input folder for main.py
├── Qlik_scripts/                   <- Stage 1 output: raw LoadScript.txt copies, one .txt per app
├── Qlik_Script_MetaData/           <- Stage 1 output: load-script + table + sheet-object JSON
├── Qlik_Visual_MetaData/           <- Stage 1 output: per-sheet visual JSON (charts, filters, ...)
├── qlik_metadata_extractor/         <- Stage 1 package (PRJ XML parsers)
│   ├── config.py                    <- input/output paths for Stage 1
│   ├── controllers/extraction_controller.py
│   └── prj/                         <- one parser class per QlikView object type
│       └── chart_object_parser.py     (ChartParser, StatisticsBoxParser, ...)
├── MigrationEngine/                 <- Stage 2 package (JSON -> .pbip)
│   ├── config.py                    <- input/output paths for Stage 2
│   ├── metadata_parser.py           <- loads Qlik_Script_MetaData JSON
│   ├── visual_metadata_loader.py    <- loads Qlik_Visual_MetaData JSON
│   ├── m_query_generator.py         <- LOAD script -> Power Query M
│   ├── dax_generator.py             <- chart/statistics/colour expressions -> DAX measures
│   ├── relationship_generator.py    <- table relationships + cardinality
│   ├── report_visual_generator.py   <- sheet objects -> Power BI visual JSON
│   └── pbip_generator.py            <- writes the .pbip/.Report/.SemanticModel scaffold
└── PowerBIScript/                   <- Stage 2 output (see §6)
```

## 5. How to run it

Both commands are run from inside `qlik_engine/`.

**Stage 1 — extract QlikView PRJ export(s) into JSON:**

```bash
cd qlik_engine
python main.py "/path/to/qlik_source"
```

`input_path` can be a single `.qvw`, a single `<Name>-PRJ` folder, or a
folder containing several `-PRJ` folders (each gets processed
independently) — it defaults to `Qlik_input_files/` if you omit it.
This writes/refreshes `Qlik_scripts/`, `Qlik_Script_MetaData/`, and
`Qlik_Visual_MetaData/`.

**Stage 2 — turn that JSON into a Power BI Project:**

```bash
cd qlik_engine
python -m MigrationEngine
```

This reads every JSON file already sitting in `Qlik_Script_MetaData/`
and `Qlik_Visual_MetaData/` and (re)writes `PowerBIScript/` from
scratch. Run this again any time after a code change or a re-run of
Stage 1 — it's safe to delete `PowerBIScript/` first if you want a
guaranteed-clean rebuild:

```bash
rm -rf PowerBIScript
python -m MigrationEngine
```

**Open the result:**

```
PowerBIScript/PBIP/<App>/<App>.pbip
```

Double-click the `.pbip` in Power BI Desktop. Let Desktop validate and
refresh the model on first open — that's the point of shipping a
`.pbip` rather than a `.pbix`: Desktop's own TMDL/PBIR validation is
the last, most authoritative check this tool can't run for you.

## 6. What gets generated

```
PowerBIScript/
├── PBIP/<App>/
│   ├── <App>.pbip                              <- open this in Power BI Desktop
│   ├── <App>_visuals_migration_notes.md         <- every sheet object that needs manual review, by name
│   ├── README_MIGRATION.md                      <- short per-app "what this is" note
│   ├── <App>.SemanticModel/definition/
│   │   ├── model.tmdl, database.tmdl, relationships.tmdl
│   │   └── tables/<Table>.tmdl                  <- columns, measures, M-query partition (or a calculated
│   │                                                Metric/Value table for a multi-statistic box, see §7)
│   └── <App>.Report/definition/pages/<Sheet>/
│       └── visuals/<ObjectId>/visual.json        <- one folder per migrated chart/filter/card/table
├── DAX/<App>_Measures.dax                       <- readable script mirroring every measure embedded above
├── MQueries/<Table>_<App>.pq                    <- readable script mirroring every M partition embedded above
└── Relationships/<App>_relationships.md          <- every inferred/explicit relationship and why
```

The `DAX/` and `MQueries/` files aren't loaded by Power BI — they're
a human-readable copy of exactly what got embedded in the TMDL, useful
for review without opening Desktop.

## 7. Migration coverage — what converts, what doesn't

| | ✔ Fully Migrated | ⚠ Partially Migrated | ✘ Not Migrated |
|---|---|---|---|
| **Load Script**<br>(`LoadScript.txt`) | LOAD/SELECT, joins, RESIDENT derivation chains → a Power Query M partition per table | `ApplyMap()` lookups — mapping table's first two columns used as key/value positionally; verify column order | `IterNo()` / `Exists()` / `Peek()` — WHILE-loop counters and cross-table existence checks have no M equivalent; left as a flagged placeholder |
| **Relationships & Joins** | Explicit shared-key joins and QlikView's own DocInternals field lineage → `relationships.tmdl` with cardinality | Composite-key joins — first key pair is used; remaining key columns logged as a warning | Section Access / document security — no automatic Power BI RLS equivalent; needs manual design |
| **Filter Objects**<br>(Listbox / Multibox) | Single-field filters → Power BI slicer, with the original Qlik caption preserved as the title | Multi-field multibox — only the first bound field is migrated to a slicer; remaining fields flagged to add manually | Current Selections box — Power BI's built-in Filter pane already covers this role; skipped by design, not by gap |
| **Charts**<br>(GraphProperties) | Bar / Line / Pie / Scatter — Sum/Avg/Min/Max/Count/Count(Distinct) measures bound with the matching aggregation function | Pivot-table-mode charts — migrated as a Power BI matrix/table visual; multi-field colour-by-expression needs a manual check | Radar / Gauge / Block charts — no direct Power BI equivalent; falls back to a plain table so the data still lands on the page |
| **Statistics / Table / Selection Boxes** | Row Count sanity measures — one `COUNTROWS()` per migrated table. **Statistics box with exactly one displayed statistic** → a Power BI **Card**, bound to one real DAX measure | **Statistics box with more than one displayed statistic** → a Power BI **Table**, bound to a generated Metric/Value calculated table (one row per statistic, original order and labels preserved) | Table Box (Detail Grid) — its column list isn't extracted from QlikView's table-box XML yet; not migrated in this version |
| **Field Data Types** | A field tagged `$integer`/`$numeric`/`$date`/... in QlikView's own DocInternals → the matching Power BI dataType (`int64`/`double`/`dateTime`/...) | No type tag, but the field's own Qlik expression shape (e.g. a date function) gives a best-effort inferred type instead | No type signal at all — QlikView has no schema-level type declaration to read; a field's type only exists implicitly in its values. Defaults to Text/String; set the real type manually |

**Also fully automated**, regardless of category above:

- DAX: Sum / Avg / Min / Max / Count
- DAX: Count(Distinct ...)
- Conditional formatting → DAX colour measure
- Chart & slicer captions preserved
- Sheet → report page mapping
- Auto flow/grid layout (no overlaps)
- Migration-notes file (every skip logged by name)
- Locale-aware number/date format comments
- Qlik SET/LET variables → commented DAX candidates
- Power Query M partition per table
- Naming-convention hierarchy detection
- Field-lineage-based table resolution

### A note on the Statistics box (Card vs. Table)

QlikView's Statistics box doesn't store its selected statistics as
expression text the way a chart does — it stores a `MemberMask` bit
flag plus a `Labels` override array. This tool decodes that mask
against six confirmed bit positions (Numeric count, Total count, Sum,
Average, Min, Max — QlikView's own default set for a new Statistics
box) and converts accordingly:

- **Exactly one displayed statistic** → a Card bound to one real DAX
  measure, e.g. `'SB02 Average' = AVERAGE(Statistics[Goals per Match])`.
- **More than one** → a Table bound to a small generated calculated
  table, e.g.:
  ```
  UNION(
      ROW("Metric", "Numeric count", "Value", COUNT(Statistics[GOALS])),
      ROW("Metric", "Total count", "Value", COUNTA(Statistics[GOALS])),
      ROW("Metric", "Sum", "Value", SUM(Statistics[GOALS])),
      ROW("Metric", "AvgGoals", "Value", AVERAGE(Statistics[GOALS])),
      ROW("Metric", "Min", "Value", MIN(Statistics[GOALS])),
      ROW("Metric", "Max", "Value", MAX(Statistics[GOALS]))
  )
  ```
  ("AvgGoals" there is a real label override the box's original author
  set on the Average row — preserved, not the generic default.)
- Any other statistic (Null count, Std dev, Skewness, Kurtosis, Only
  value, Median, Fractile) has a real but *unconfirmed* bit position,
  so it's named in the migration-notes file instead of guessed at.

## 8. Migration coverage — by report and model complexity

Automation percentage by sheet and load-script complexity, observed
across the sample QlikView apps migrated in this workspace:

| Report-wise | Description | Migration % |
|---|---|---:|
| **Simple Reports** | Standard listbox/multibox filters, plain bar/line/pie charts, simple Sum/Count measures over a single load-script table each. Fully automated end-to-end, including slicer captions and chart titles. | ~90% |
| **Intermediate Reports** | Adds statistics boxes, a detail table box, multi-field multiboxes, and cross-table relationships resolved through a shared Year/date key. Filters and charts migrate; statistics and table boxes need manual follow-up. | ~55% |
| **Complex Reports** | Dominated by nested `if()`/set-analysis chart expressions, calc-condition-gated measures, multi-field concatenated text objects. Core visuals auto-generate; expression placeholders are flagged for manual DAX. | ~50% |

| Model-wise | Description | Migration % |
|---|---|---:|
| **Simple Model** | Single-layer LOAD/SELECT straight from Excel/CSV/QVD, direct field mapping, relationships detected explicitly or by naming convention. Tables, relationships, and Row Count measures all auto-generate cleanly. | ~90% |
| **Intermediate Model** | Adds `ApplyMap()` lookups and RESIDENT-table derivation chains. The engine reconstructs the real upstream source instead of an empty scaffold, but positional mapping-table columns need a quick manual check. | ~70% |
| **Complex Model** | Uses `WildMatch()` pattern rules, custom `Interval()` formats, `IterNo()` WHILE-loop counters, and `Exists()` cross-table checks. Core tables still generate; these specific expressions are left as flagged placeholders. | ~50% |

## 9. Where to look when something looks wrong

1. **`<App>_visuals_migration_notes.md`** (next to the `.pbip`) — the
   first stop. Every sheet object that wasn't fully converted is
   listed here by object ID and reason, e.g.:
   ```
   - [SH01] TB01: category 'table_box' not migrated (unsupported)
   - [SH01] CS01: category 'current_selection_box' skipped by design
   ```
2. **`PowerBIScript/Relationships/<App>_relationships.md`** — every
   relationship the engine inferred or read explicitly, and which
   resolution strategy produced it.
3. **`PowerBIScript/DAX/<App>_Measures.dax`** — a readable copy of
   every measure embedded in the TMDL tables, for review without
   opening Desktop.
4. **Power BI Desktop itself**, on first open — it will validate the
   TMDL/PBIR and flag anything structurally wrong (see §11 for a real
   example of this working as intended).

## 10. Known limitations

- **Table Box (Detail Grid)** — not migrated; its column list isn't
  extracted from QlikView's table-box XML yet.
- **Section Access / document security** — no automatic Power BI
  row-level-security equivalent; needs manual design.
- **Set-analysis and multi-field chart expressions** — bound as a raw
  column and flagged, not re-derived, since getting these wrong would
  silently show the wrong number.
- **QlikView macros/VBScript** — out of scope; Power BI has no
  equivalent execution model.
- Statistics functions outside the six confirmed `MemberMask` bits
  (Null count, Std dev, Skewness, Kurtosis, Only value, Median,
  Fractile) are named in the notes file, not converted.

None of the above fail silently — every one of them is named, by
object ID, in that app's `_visuals_migration_notes.md`.

## 11. Initializing via the unified launcher (`report_migration_tool.py`)

Sections 5–6 above run the QlikView engine directly with its own two
CLI commands. `report_migration_tool.py`, at the repo root, is the
product's actual entry point: a single browser-based launcher that
wraps the Tableau, Cognos, Qlik, and Crystal Reports engines behind
one server and one login-protected UI, so a user never has to run
either of `main.py` / `python -m MigrationEngine` by hand.

It must be run from the repo root, next to its sibling engine scripts
and UI files it loads at import/serve time:

```
report_migration_tool.py
qlik_pbi_server.py          <- the Qlik engine this launcher loads
cognos_pbi_server.py
tableau_pbi_server.py
Landing.html                 <- login page
Index.html                   <- main app UI
```

**Start it:**

```bash
python report_migration_tool.py
# or on a different port:
python report_migration_tool.py --port 8500
```

On startup it auto-creates the `qlik_source/` and `qlik_target/`
folders (alongside `source/`, `target/`, `cognos_source/`,
`cognos_target/`, `input/`, `output/`) next to the script if they
don't already exist, and prints a status banner confirming which
engines loaded:

```
╔══════════════════════════════════════════════════════════╗
║         Report Migration Tool  →  Power BI               ║
╠══════════════════════════════════════════════════════════╣
║  URL      : http://localhost:8500                        ║
║  Qlik     : ✓ Ready                                       ║
╚══════════════════════════════════════════════════════════╝
```

**Use it:** open `http://localhost:<port>` in a browser, log in
(default credentials `admin` / `admin123`), pick the Qlik engine in
the app UI, and point it at a source folder (containing `.qvw` files
with their `-PRJ` export alongside them) and a target/output folder.
From there you can either:

- **Watch a folder** — starts a background worker that automatically
  runs the full pipeline on anything dropped into the source folder, or
- **Convert one file/path** — runs the full pipeline synchronously on
  a single `.qvw` or `-PRJ` folder and returns the result immediately.

Either way, this calls `qlik_pbi_server.run_qlik_to_powerbi()` under
the hood, which runs Stage 1 (extraction) and then automatically feeds
its own output straight into Stage 2 (migration) as one call — the
same two stages from §2, just triggered together instead of as two
separate manual commands.

**Qlik-only, without the full unified UI:**

```bash
python qlik_pbi_server.py --source ./qlik_source --target ./qlik_target
```

This is the same single-call pipeline `report_migration_tool.py` uses
for the Qlik engine, runnable on its own for local testing.
