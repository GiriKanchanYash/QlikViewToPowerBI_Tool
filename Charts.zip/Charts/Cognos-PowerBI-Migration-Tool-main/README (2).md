# ReportBridge — IBM Cognos On-Premise to Microsoft Power BI Migration Tool

> **Production-grade, browser-driven migration engine** that converts IBM Cognos Analytics
> on-premise assets into fully functional Power BI Projects (`.pbip`) — automatically,
> with no manual report rebuilding.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [File Structure](#3-file-structure)
4. [Features](#4-features)
5. [Supported Input Formats](#5-supported-input-formats)
6. [Migration Coverage](#6-migration-coverage)
7. [Prerequisites](#7-prerequisites)
8. [Installation](#8-installation)
9. [Running the Server](#9-running-the-server)
10. [Usage — Step by Step](#10-usage--step-by-step)
11. [API Endpoints](#11-api-endpoints)
12. [Output Structure](#12-output-structure)
13. [Migration Modes](#13-migration-modes)
14. [Source Folder Layouts](#14-source-folder-layouts)
15. [Current Limitations](#15-current-limitations)
16. [Troubleshooting](#16-troubleshooting)
17. [Future Enhancements](#17-future-enhancements)
18. [License](#18-license)
19. [Contributors](#19-contributors)

---

## 1. Project Overview

### What is ReportBridge?

ReportBridge is a unified, multi-engine report migration platform that converts
legacy BI reporting assets into Microsoft Power BI. The IBM Cognos engine
(`cognos_pbi_server.py`) is the newest addition alongside the existing Tableau
and Crystal Reports engines.

It is operated entirely through a browser UI served locally at
`http://localhost:8500`. You point it at a folder of Cognos exports, select
**Cognos Reporting** as the engine, click **Start**, and it streams live
progress back to your browser while writing a complete, validated Power BI
Project to your target folder.

### Business Objective

Enterprise organisations migrating away from IBM Cognos Analytics face two hard
problems: **volume** (hundreds of report specifications, multiple Framework
Manager packages) and **expression depth** (Cognos SQL-flavoured macros,
CASE expressions, date arithmetic, aggregation rules). ReportBridge solves
both:

- Processes every supported file type in a watched source folder **automatically**,
  without per-file intervention.
- Translates Cognos expressions to **syntactically valid DAX**, with commented
  placeholders and a migration document for anything that cannot be fully
  automated.
- Produces a **complete, validated Power BI Project** (`.pbip`) that opens
  directly in Power BI Desktop — no intermediate API, no Azure setup, no
  manual file editing.

### How the Migration Works

```
IBM Cognos Source Asset
(XML / ZIP / MHT / HTML / JSON)
          │
          ▼
  Artifact Type Detection
  ┌────────────────────────────────────────┐
  │  Root element sniffed:                 │
  │  <project>  →  Framework Manager Model │
  │  <report>   →  Report Specification    │
  └────────────────────────────────────────┘
          │
    ┌─────┴──────────────────────┐
    │                            │
    ▼                            ▼
  FM Model Parser         Report Parser
  (model.xml)             (.xml/.spec/.report
                           .zip/.mht/.html/.json)
    │                            │
    └──────────┬─────────────────┘
               │  Merged automatically when both arrive together
               ▼
  Semantic Model Builder
  (Query Subjects → PBI Tables,
   Relationships, Cardinality, Hierarchies,
   DAX Measures, Calculated Columns)
               │
               ▼
  TMDL + PBIR Writer
  (database.tmdl, model.tmdl,
   tables/*.tmdl, relationships.tmdl,
   pages/*/page.json, visuals/*/visual.json,
   data_sources/*.csv)
               │
               ▼
  Power BI Project (.pbip) Folder
  └─ Open in Power BI Desktop
     File → Save As → .pbix
```

---

## 2. Architecture

The application is a three-layer Python HTTP server — no framework, no
external web dependencies.

```
report_migration_tool.py          Unified HTTP server (port 8500)
│                                 Routes requests to the correct engine.
│                                 Serves Landing.html (login) and Index.html (app).
│                                 Manages sessions, SSE fan-out, engine status.
│
├── tableau_pbi_server.py         Tableau (.twb/.twbx) → Power BI engine
│   (reference architecture)      Provides shared utilities reused by Cognos engine:
│                                 _guid, _safe_pbi_name, _unique_name, _jmin/_jstr,
│                                 _pbi_m_type, _m_sample_value, _pbix_via_desktop/api
│
├── cognos_pbi_server.py          IBM Cognos → Power BI engine (this project)
│   (8 400+ lines)                Parsing, DAX conversion, TMDL/PBIR generation,
│                                 SSE broadcast, folder watcher, migration docs
│
└── crystal_pbi_generator.py      Crystal Reports (.rpt) → Power BI engine
    (sibling, not modified)
```

### SSE Event Bus

All three engines share one unified Server-Sent Events stream. The router
monkey-patches each engine's `broadcast()` function so that `log`, `status`,
`job_update`, `cognos_detect`, and `progress` events from any engine reach
every connected browser client in real time over the same `/events` endpoint.

### Session Management

`Landing.html` provides a login form. Credentials are validated server-side
against a configurable dictionary in `report_migration_tool.py`. A UUID
session cookie is issued on success. All routes except `/`, `/api/login`, and
static assets require a valid session.

Default credentials: `admin` / `admin123` — change
`_VALID_CREDENTIALS` in `report_migration_tool.py` before production use.

---

## 3. File Structure

```
ReportBridge/
│
├── report_migration_tool.py       Unified HTTP server — start this
├── cognos_pbi_server.py           IBM Cognos → Power BI engine
├── tableau_pbi_server.py          Tableau → Power BI engine (sibling)
├── crystal_pbi_generator.py       Crystal Reports → Power BI engine (sibling)
│
├── Landing.html                   Login page (React, three themes)
├── Index.html                     Migration workspace UI (React + SSE)
├── logo.svg                       Brand logo served as a static asset
│
├── cognos_source/                 Default source folder (auto-created)
├── cognos_target/                 Default target folder (auto-created)
├── source/                        Default Tableau source folder
├── target/                        Default Tableau target folder
├── input/                         Default Crystal input folder
└── output/                        Default Crystal output folder
```

After a successful Cognos migration, the target folder contains:

```
<target>/
│
├── <ReportName>.pbip              Root PBIP file — open this in Power BI Desktop
│
├── <ReportName>.SemanticModel/
│   ├── .platform
│   └── definition/
│       ├── database.tmdl          Compatibility level (1600) declaration
│       ├── model.tmdl             Culture, annotations, table references
│       ├── relationships.tmdl     All join relationships with cardinality
│       ├── cultures/
│       │   └── en-US.tmdl
│       └── tables/
│           ├── Sales.tmdl         Columns, measures, calculated columns, M partition
│           └── ...
│
├── <ReportName>.Report/
│   ├── .platform
│   ├── definition.pbir            Report → SemanticModel reference
│   └── definition/
│       ├── report.json            Theme, settings
│       ├── version.json
│       └── pages/
│           └── <page-guid>/
│               ├── page.json
│               └── visuals/
│                   └── <visual-guid>/
│                       └── visual.json
│
├── data_sources/
│   └── <TableName>.csv            Materialized CSV backing each table
│
└── <ReportName>_migration.docx    Migration documentation (requires python-docx)
```

---

## 4. Features

All features listed below are implemented in `cognos_pbi_server.py`.

### Parsing

| Feature | Details |
|---|---|
| **Namespace-agnostic XML parsing** | Every tag is matched by its local name only (`_local(tag)` helper strips the namespace URI). Tolerant of all Cognos schema versions (10.x, 11.x, Cognos Analytics). |
| **Framework Manager model parser** | Parses `<project>` root XML across Physical, Business, and Presentation layers. Resolves Presentation Layer `<folder>`/`<item>` references back to Business Layer query subjects, so the friendly display names report authors use resolve correctly. |
| **Report specification parser** | Parses `<report>` root XML. Extracts queries, data items, filters, sort lists, layout pages, and visual objects. Handles every Cognos version's schema variation. |
| **Artifact type auto-detection** | Sniffs the root element before routing to the correct parser — `<project>` → FM model, `<report>` → report spec. A Framework Manager model and a report specification sharing the same `.xml` extension are never confused. |
| **Paired FM + Report migration** | When a Framework Manager model (`model.xml`) and a report specification arrive in the same source folder together, the engine automatically merges them into one Power BI Project. Each report specification is paired with the FM model; the semantic model is built once and shared. |
| **Nested project folder detection** | Detects the IBM Cognos Analytics On-Premise project layout (`model/model.xml`, `content_store/report.xml`, `sample_data/*.csv`) anywhere under the watched folder and processes it as one unit. |
| **ZIP package extraction** | Extracts and parses all XML members inside a Cognos ZIP package. Non-XML members (images, binary blobs) are intentionally skipped. |
| **MHT / MHTML rendered export** | MIME decodes quoted-printable and base64 content, extracts HTML tables row by row, and converts them to populated Power BI tables. |
| **HTML rendered export** | Parses `<table>` elements from rendered HTML exports and converts each to a Power BI table visual with actual embedded data rows. |
| **JSON data module** | Parses the Cognos Analytics JSON data module format into the same normalized internal dict as XML — every downstream stage is format-agnostic. |
| **Static table extraction** | `<table>` layout elements with no query binding (hand-built static grids, common in Cognos demo/sample reports) are extracted row-by-row from `<staticValue>` cells and converted to populated Power BI table visuals. Layout-wrapper tables (flagged `isPageLayoutTable`, or containing nested report objects) are correctly excluded. |
| **IBM vizControl chart parsing** | Resolves the `<vizControl>` → `<vcDataSet>` → `<reportDataStore>` → query chain and extracts `vcSlotDsColumn` field references, so IBM's modern chart format produces correct visual field bindings. |
| **Report CSS color palette** | Reads `background-color` / `color` CSS declarations from `<style><CSS>` elements and carries them through to the Power BI theme, giving different Cognos reports visually distinct themes. |
| **Aggregate normalization** | Treats `aggregate="none"` as a real, meaningful value (not an omission). The entire normalisation passes through `_normalize_aggregate()` so `none`/`automatic`/`calculated` never becomes a measure by accident. |

### Query and Data Model

| Feature | Details |
|---|---|
| **Query discovery** | Extracts every `<query>` with its `<dataItem>` children: name, expression, aggregate rule, sort list, and data type. |
| **Query subject discovery** | Parses every `<querySubject>` in the FM model with its `<queryItem>` children, including objectID cross-references for Presentation Layer resolution. |
| **Multi-table query splitting** | When a single Cognos query flattens multiple source tables together, `_split_one_query()` separates them into individual logical tables using source-table inference from field expressions. Shared dimension tables across queries are merged globally (pass 2) before naming, so a shared lookup never becomes two separate copies. |
| **Relationship discovery** | Supports five resolution strategies in `_fm_parse_relationship()`: (1) classic `<left>/<right>` + `<expression>` bracket chain; (2) objectID-based endpoints (`<refObjectID>/<refQueryItem>`); (3) `<determinant>Table.Column</determinant>` pairs; (4) `<join>` wrapping `<leftColumn>/<rightColumn>` or `<foreignKey>/<primaryKey>`; (5) `<relationshipRef name="..."/>` resolved via a named-relationship map. |
| **Cardinality detection** | Resolves through: explicit `<cardinality>` tag → FK/PK naming convention → `mincard`/`maxcard` attributes → determinant-uniqueness inference. Normalizes `from-One/to-Many` to `from-Many/to-One` (Power BI Desktop rejects the former). Invalid relationships are logged and skipped, never written broken. |
| **Schema-qualified table names** | `_fm_parse_dotted_ref()` uses the known-tables set to prefer the longest dot-prefix matching a real query subject name, so `dbo.Sales.CustomerID` resolves as table=`dbo.Sales`, column=`CustomerID` — not the naive last-segment split. |
| **Inferred relationships** | When no explicit joins exist, relationships are inferred from: (a) promoted foreign-key columns detected during query splitting, (b) shared column names across tables, (c) key-naming-convention patterns (`<TableName>ID/Key/Code`). |
| **Cycle detection and breaking** | After relationship inference, `_find_one_relationship_cycle()` detects cycles and removes the weakest edge (the inferred relationship with the lowest confidence) to prevent Power BI "circular dependency" errors. |
| **Duplicate relationship filtering** | De-duplicates on `(fromTable, fromColumn, toTable, toColumn)` before writing. |
| **Hierarchy detection** | Uses explicit FM `<hierarchy>/<navigationPath>` elements first; falls back to naming-convention inference (Year/Quarter/Month/Day, Category/Subcategory/Product, Country/State/City, etc.) when no explicit hierarchy is declared. |
| **Geo data categories** | Assigns Power BI `dataCategory` values (City, StateOrProvince, Country, PostalCode, Latitude, Longitude) to columns matching geographic hint patterns via whole-word token matching — `Country` matches, `CountryCode` does not accidentally match `count`. |

### DAX Conversion

| Feature | Details |
|---|---|
| **Aggregate rule mapping** | `total` → `SUM`, `average` → `AVERAGE`, `maximum` → `MAX`, `minimum` → `MIN`, `count` → `COUNT`, `count-distinct` → `DISTINCTCOUNT`, `running-total` → `CALCULATE(SUM(...), FILTER(...))`, `rank` → `RANKX`, `moving-average` → `AVERAGEX`. |
| **Field reference conversion** | Converts `[Namespace].[Query].[Item]`, `[Query].[Item]`, and bare `[Item]` bracket references to `'TableName'[Item]` (column) or `[MeasureName]` (measure, never table-qualified). |
| **CASE / nested CASE** | Recursive conversion of `CASE WHEN ... THEN ... ELSE ... END` to `SWITCH(TRUE(), ...)`. Handles arbitrarily nested CASE inside WHEN/THEN/ELSE branches via a bracket-depth counter — not a regex that would mismatch on the inner `END`. |
| **IF / COALESCE / IFNULL** | Converted to `IF(...)` and `COALESCE(...)` DAX equivalents. |
| **Date functions** | `_add_days`, `_add_months`, `_add_years`, `_days_between`, `_first_of_month`, `_last_of_month`, `_make_timestamp`, `extract(day/month/year/hour/minute)`, `current_date`, `current_timestamp` → DAX `DATEADD`, `DATEDIFF`, `STARTOFMONTH`, `ENDOFMONTH`, `DATE`, `NOW`, `TODAY`. |
| **String functions** | `substring` → `MID`, `_length` → `LEN`, `trim`/`ltrim`/`rtrim` → `TRIM`, `uppercase`/`lowercase` → `UPPER`/`LOWER`, `cast` → `FORMAT`/`INT`/`VALUE`. |
| **Date literal disambiguation** | The M-query date literal builder `_m_literal()` disambiguates DD-MM-YYYY vs MM-DD-YYYY by checking which segment is > 12; defaults to day-first (the convention in real Cognos en-GB exports) when ambiguous. Validates the resolved date with `datetime.date()` and returns `null` for impossible dates. |
| **Commented placeholder fallback** | Any expression that cannot be confidently translated is written as `// COGNOS: <original expression>` in the TMDL file and recorded in the migration documentation. It is never silently dropped. |

### Semantic Model Generation

| Feature | Details |
|---|---|
| **TMDL writer** | Produces `database.tmdl` (compatibility level 1600), `model.tmdl` (culture, annotations), `tables/<name>.tmdl` (one per table), `relationships.tmdl`, and `cultures/en-US.tmdl`. All formatting rules match Power BI Desktop's internal output exactly. |
| **Column data type mapping** | Cognos types (`integer`, `decimal`, `double`, `date`, `datetime`, `boolean`, `varchar`) → PBI `int64`, `double`, `dateTime`, `boolean`, `string`. Unknown types default to `string`. |
| **Measure generation** | Data items with aggregate rules → TMDL `measure` with converted DAX, format string, and display folder. |
| **Calculated column generation** | Data items with expressions and no aggregate rule → TMDL `calculatedColumn` with converted DAX. |
| **Power Query (M) partitions** | Three partition strategies: (1) **CSV-backed** — exact extracted rows written to `data_sources/<Table>.csv`, M query uses `Csv.Document(File.Contents(...))` matching Power BI Desktop's own CSV import output; (2) **Excel-backed** — when a matching `.xlsx` file is found in the source data folder; (3) **Synthetic stub** — typed `#table(...)` literal with representative sample values, clearly commented for replacement. |
| **CSV materialization** | `_materialize_table_csv()` always writes a real external CSV for every table so Power BI Desktop populates "Data Source Settings" — a `#table()` literal-only model always shows that dialog empty by design. |
| **Unique name enforcement** | `_unique_name()` ensures no two tables, columns, or measures in the same scope share a name, appending `_2`, `_3`, … as needed. |
| **PBI_SourceType annotation** | Every generated table is annotated `PBI_SourceType = Cognos` for lineage tracking. |
| **Migration documentation** | Generates a Word `.docx` (via `python-docx`, auto-installed) listing every converted table, measure, calculated column, relationship, expression translation, and item flagged for manual review. |

### Report / Visual Generation

| Feature | Details |
|---|---|
| **PBIR writer** | Produces `definition.pbir`, `.platform`, `definition/report.json`, `definition/version.json`, `definition/pages/<guid>/page.json`, `definition/pages/<guid>/visuals/<guid>/visual.json`, and `StaticResources/SharedResources/BaseThemes/CY26SU05.json`. |
| **Table / List visual** | Cognos `<list>` → Power BI `tableEx` with full column field binding. |
| **Crosstab / Matrix visual** | Cognos `<crosstab>` → Power BI `pivotTable` (Matrix) with row edge → rows, column edge → columns, measures → values. |
| **Chart visuals** | `<chart>` and `<vizControl>` → Power BI chart. Mapped visual types: `column`, `bar`, `line`, `pie`, `area`, `scatter`, `waterfall`, `funnel`, `treemap`, `donut`, `gauge`, `filledMap`, `map`, `ribbon`. |
| **Visual field binding validation** | Each visual's field references are checked against the actual tables/columns/measures in the model before writing. A visual with an unresolvable reference is logged and omitted rather than written with a null binding. |
| **Visual-level filters** | `<detailFilter>` / `<filter>` elements on layout objects are parsed and written as Power BI visual-level filter JSON. |
| **Report-level filters** | Query-level `<detailFilters>` are written as report-level PBI filter JSON. |
| **Page layout** | Each Cognos `<page>` becomes one PBIR page. Visuals are placed in a three-column grid (400 × 280 px per cell, 20 px gap). |

### Live Operation

| Feature | Details |
|---|---|
| **Folder watcher** | `conversion_worker()` polls the source folder every 2 seconds. Each file is processed exactly once (keyed by `name:mtime`). New files dropped mid-run are picked up automatically. |
| **SSE event bus** | `broadcast()` pushes `log`, `status`, `job_update`, `cognos_detect`, `progress`, `completed`, and `error` events. Mirrors the Tableau engine's interface exactly so the unified router wires both engines identically. |
| **Per-file job tracking** | `conversion_state["jobs"]` records status, message, start time, and finish time for every file. Surfaced in the Migration Jobs panel. |
| **`python-docx` auto-install** | If `python-docx` is not present, the engine installs it silently via `pip` at startup. Falls back gracefully if the install fails — the migration continues without the `.docx` output. |
| **PBIX conversion** | Optionally converts the generated `.pbit` to `.pbix` via Power BI Desktop automation or the Power BI REST API. Helpers are imported from `tableau_pbi_server.py`. |
| **Standalone CLI mode** | Can be run directly for local testing: `python cognos_pbi_server.py --source ./cognos_source --target ./cognos_target`. |

---

## 5. Supported Input Formats

| Extension | Format | Notes |
|---|---|---|
| `.xml` | Cognos report spec or FM model | Auto-detected by root element |
| `.spec` | Cognos report specification | Treated as XML |
| `.report` | Cognos report specification | Treated as XML |
| `.zip` | Cognos package export | All XML members extracted and parsed |
| `.mht` / `.mhtml` | Rendered report (MIME) | Quoted-printable and base64 decoded |
| `.html` / `.htm` | Rendered report | HTML table extraction |
| `.json` | Cognos Analytics data module | Parsed into the same normalized dict |

---

## 6. Migration Coverage

### Report-Wise

| Report Category | Description | Automation % |
|---|---|---|
| **Simple** | Plain list/table reports, direct query-to-table mapping, standard joins, no calculated fields, no CASE logic  |
| **Intermediate** | Crosstab/matrix, chart visuals, basic DAX measures (SUM/AVERAGE/COUNT), report-level filters, standard 2-layer FM |
| **Complex** | Nested CASE/IF, composite-key joins, IBM vizControl charts, multi-layer FM (Physical + Business + Presentation), prompts, conditional formatting, drill-through |

### Model-Wise

| Model Component | Description | Automation % |
|---|---|---|
| **Simple Model** | Single-namespace FM, direct physical-to-business mapping, standard 1:N joins |
| **Intermediate Model** | Two-layer FM, basic calculated query items, standard relationships, naming-convention hierarchies |
| **Complex Model** | Three-layer FM, nested CASE, composite-key joins, many-to-many, RLS ACLs, role-playing dimensions  |

### Component Coverage

| Component | Status | Notes |
|---|---|---|
| Framework Manager model | ✔ Full | Physical + Business + Presentation layers |
| Report specification XML | ✔ Full | All Cognos versions |
| ZIP package export | ✔ Full | All XML members |
| MHT / HTML rendered export | ✔ Full | Row-by-row extraction |
| JSON data module | ✔ Full | Cognos Analytics format |
| Queries and data items | ✔ Full | Selection, aggregate, sort, data type |
| Relationships and joins | ✔ Full | Five resolution strategies |
| Cardinality detection | ✔ Full | Explicit → FK/PK → maxcard → inferred |
| Hierarchy detection | ✔ Full | Explicit FM + naming-convention fallback |
| DAX CASE / nested CASE | ✔ Full | Recursive → `SWITCH(TRUE(), ...)` |
| DAX date functions | ✔ Full | `_add_days`, `_add_months`, `extract`, etc. |
| DAX string functions | ✔ Full | `substring`, `trim`, `uppercase`, `cast` |
| Measures | ✔ Full | Aggregate rules → TMDL measure + DAX |
| Calculated columns | ✔ Full | Non-aggregate expressions → TMDL calcCol |
| Table / List visuals | ✔ Full | `<list>` → `tableEx` |
| Crosstab visuals | ✔ Full | `<crosstab>` → Matrix |
| Chart visuals (14 types) | ✔ Full | Column, Bar, Line, Pie, Map, Scatter, … |
| IBM vizControl charts | ✔ Full | `vcDataSet` → `vcSlotDsColumn` resolved |
| Static table extraction | ✔ Full | Hand-built grids → populated PBI tables |
| Report-level filters | ✔ Full | `detailFilter` → PBI filter JSON |
| Visual-level filters | ✔ Full | Per-visual filter → PBI visual filter |
| Power Query (M) partitions | ✔ Full | CSV-backed, Excel-backed, or typed stub |
| PBIP output | ✔ Full | Opens directly in Power BI Desktop |
| Migration documentation | ✔ Full | Word `.docx` with every object + warning |
| Prompts / parameters | ⚠ Partial | Names and types extracted; no slicer/What-If auto-generated |
| Conditional formatting | ⚠ Partial | CSS palette → PBI theme; per-cell rules not converted |
| Drill-through links | ⚠ Partial | Hierarchy levels generated; cross-report links not written |
| Composite-key joins | ⚠ Partial | First key pair used; remaining keys logged |
| Report bursting / scheduling | ✘ Not supported | No Power BI equivalent |
| Row-level security (ACLs) | ✘ Not supported | Flagged in migration docs for manual planning |
| Macros / JavaScript | ✘ Not supported | No Power BI equivalent |

---

## 7. Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Python | 3.8 or later | Only the standard library is required for the core pipeline |
| `python-docx` | Any recent | **Auto-installed** at startup. Required for migration documentation only |
| Power BI Desktop | June 2024 or later | Required to open the generated `.pbip` folder |
| IBM Cognos source assets | 10.x, 11.x, Analytics | Framework Manager XML, report spec XML, ZIP, MHT, HTML, or JSON |
| `tableau_pbi_server.py` | Same directory | Sibling engine. Provides shared helpers. Loads automatically; falls back gracefully if absent |

No `pip install` step is needed before first run. `python-docx` is the only
auto-installed dependency.

---

## 8. Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-org/reportbridge.git
cd reportbridge

# 2. (Optional) Create a virtual environment
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

# 3. No pip install required for the core engine.
#    To pre-install the documentation dependency manually:
pip install python-docx

# 4. Confirm all engine files are in the same folder:
#    report_migration_tool.py
#    cognos_pbi_server.py
#    tableau_pbi_server.py      (provides shared helpers)
#    crystal_pbi_generator.py   (optional, for Crystal Reports)
#    Landing.html
#    Index.html
#    logo.svg
```

---

## 9. Running the Server

```bash
# Default port 8500
python report_migration_tool.py

# Custom port
python report_migration_tool.py --port 9000

# With Crystal Reports assembly path
python report_migration_tool.py --crystal-assembly-path "C:\path\to\CrystalDecisions"
```

On startup, the console prints:

```
╔══════════════════════════════════════════════════════════╗
║         Report Migration Tool  →  Power BI               ║
╠══════════════════════════════════════════════════════════╣
║  URL      : http://localhost:8500                        ║
║  Tableau  : ✓ Ready                                      ║
║  Crystal  : ✓ Ready (SDK: runtimes)                      ║
║  Cognos   : ✓ Ready                                      ║
╚══════════════════════════════════════════════════════════╝
```

Open `http://localhost:8500` in your browser.

### Standalone CLI (Cognos engine only, for local testing)

```bash
python cognos_pbi_server.py --source ./cognos_source --target ./cognos_target
python cognos_pbi_server.py --source ./cognos_source --target ./cognos_target --embed-sample-data
python cognos_pbi_server.py --source ./cognos_source --target ./cognos_target \
    --source-data-folder ./live_data --mode analyze_migrate
```

| CLI flag | Default | Description |
|---|---|---|
| `--source` | `./cognos_source` | Watched input folder |
| `--target` | `./cognos_target` | Output folder |
| `--mode` | `analyze_migrate` | `migrate`, `analyze`, or `analyze_migrate` |
| `--embed-sample-data` | off | Embed sample rows directly in M queries |
| `--source-data-folder` | none | Folder of CSV/Excel files used as live data source |

---

## 10. Usage — Step by Step

### Step 1 — Log in

Navigate to `http://localhost:8500`. Enter your credentials (default:
`admin` / `admin123`) and click **Enter migration workspace**.

### Step 2 — Select the Cognos engine

In the **Migration Command Center** panel, select **Cognos Reporting** from
the Engine dropdown.

### Step 3 — Set source and target folders

| Field | What to enter |
|---|---|
| **Input Folder** | Full absolute path to your Cognos asset folder or a single file. Examples: `D:\exports\`, `D:\exports\model.xml`, `D:\exports\report.zip` |
| **Output Folder** | Full absolute path to the output folder. Created automatically if absent. Example: `D:\pbi_output` |

Use the **Folder** / **File** picker buttons to browse instead of typing.

> **Tip:** Use the full absolute path. Relative paths are resolved against the
> server script's own directory.

### Step 4 — Choose the migration mode

Check or uncheck **Analyze** and **Convert**:

| Analyze | Convert | Mode | Output |
|---|---|---|---|
| ✔ | ✔ | `analyze_migrate` | Migration docs + `.pbip` folder (default) |
| ✔ | ✗ | `analyze` | Migration documentation `.docx` only |
| ✗ | ✔ | `migrate` | `.pbip` folder only |

### Step 5 — Start the migration

Click **Start Process**. The Operations Log streams live events:

```
[INFO]  Detected project folder layout: model.xml + 3 report file(s)
[INFO]  Detected Artifact: Framework Manager Model + Report Specification
[INFO]  Loading Framework Manager Model...
[INFO]  Parsing Physical Layer query subjects...
[INFO]  Parsing Business Layer relationships...
[INFO]  Presentation Layer resolved: 42 item references
[INFO]  Building Power BI semantic model...
[INFO]  Hierarchy detected: Calendar Hierarchy on 'OrderDate'
[INFO]  Writing TMDL semantic model...
[INFO]  Writing PBIR report pages...
[INFO]  Materializing data_sources/Sales.csv
[INFO]  Migration complete → D:\pbi_output\SalesReport.pbip
```

### Step 6 — Review the output

Open the target folder. Check:

- `<Name>_migration.docx` — full list of converted objects, DAX translations,
  and every item flagged for manual review.
- The Operations Log in the browser — warnings for untranslatable expressions,
  unresolved joins, and skipped visuals.

### Step 7 — Open in Power BI Desktop

1. Power BI Desktop → **File → Open → Power BI Projects**
2. Browse to the target folder and select `<Name>.pbip`
3. Connect data when prompted (or use the materialized CSVs in `data_sources/`)
4. **File → Save As → Power BI File (`.pbix`)**

---

## 11. API Endpoints

All endpoints are served by `report_migration_tool.py` on port 8500.

### GET Endpoints

| Endpoint | Auth | Description |
|---|---|---|
| `GET /` | No | Login page (Landing.html) |
| `GET /app` | Session cookie | Migration workspace (Index.html) |
| `GET /api/session` | No | Returns `{"authenticated": true/false}` |
| `GET /events` | Session | SSE stream — `log`, `status`, `job_update`, `progress`, `cognos_detect` |
| `GET /engines` | Session | Engine load status: `{"tableau":bool, "cognos":bool, "crystal":bool, ...}` |
| `GET /state` | Session | Tableau engine `conversion_state` |
| `GET /cognos/state` | Session | Cognos engine `conversion_state` |

### POST Endpoints — Cognos

| Endpoint | Payload | Description |
|---|---|---|
| `POST /cognos/start` | `{source, target, mode, embed_sample_data, source_data_folder, ...pbix_params}` | Start a Cognos migration run (folder watcher) |
| `POST /cognos/stop` | `{}` | Stop the running watcher |
| `POST /cognos/convert_one` | `{file, target, mode, embed_sample_data}` | Convert a single file immediately |
| `POST /cognos/scan_repository` | `{source}` | Scan the source folder and return a file inventory without converting |
| `POST /cognos/clear` | `{}` | Clear `conversion_state.jobs` |

### POST Endpoints — Tableau

| Endpoint | Description |
|---|---|
| `POST /start` | Start a Tableau migration run |
| `POST /stop` | Stop the Tableau watcher |
| `POST /convert_one` | Convert a single `.twb`/`.twbx` file |
| `POST /clear` | Clear Tableau job state |
| `POST /convert_to_pbix` | Convert a `.pbit` to `.pbix` via Desktop or API |

### POST Endpoints — Crystal Reports

| Endpoint | Description |
|---|---|
| `POST /crystal/start` | Start a Crystal Reports conversion run |
| `POST /crystal/set_assembly_path` | Set `CRYSTAL_ASSEMBLY_PATH` at runtime |
| `POST /crystal/*` | Proxied to the Crystal WSGI app |

### POST Endpoints — Auth

| Endpoint | Payload | Description |
|---|---|---|
| `POST /api/login` | `{username, password}` | Validates credentials, issues session cookie |

---

## 12. Output Structure

```
<target>/
├── <Name>.pbip                          Open this in Power BI Desktop
│
├── <Name>.SemanticModel/
│   ├── .platform                        Fabric platform metadata (JSON)
│   └── definition/
│       ├── database.tmdl                compatibilityLevel: 1600
│       ├── model.tmdl                   culture: en-US + annotations
│       ├── relationships.tmdl           All joins with fromCardinality/toCardinality
│       ├── cultures/en-US.tmdl
│       └── tables/
│           └── <TableName>.tmdl         columns + measures + calculatedColumns +
│                                        partition (CSV-backed or synthetic M query)
│
├── <Name>.Report/
│   ├── .platform                        Fabric platform metadata (JSON)
│   ├── definition.pbir                  {"datasetReference": {"byPath": ...}}
│   └── definition/
│       ├── report.json                  Theme (CY26SU05) + resource packages
│       ├── version.json                 PBIR format version
│       └── pages/
│           └── <page-guid>/
│               ├── page.json            Page dimensions + display name
│               └── visuals/
│                   └── <vis-guid>/
│                       └── visual.json  visualType + field bindings + filters
│
├── data_sources/
│   └── <TableName>.csv                  Materialized CSV (one per table)
│
└── <Name>_migration.docx               Migration documentation
```

---

## 13. Migration Modes

The `mode` parameter controls what the engine does with each file:

| Mode | What happens |
|---|---|
| `migrate` | Parses the source file and writes the Power BI Project (`.pbip`) to the target folder. No documentation output. |
| `analyze` | Parses the source file and writes the migration documentation (`.docx`) only. No `.pbip` output. |
| `analyze_migrate` | Does both: writes the `.pbip` folder **and** the migration documentation `.docx`. This is the default. |

---

## 14. Source Folder Layouts

The engine supports three source folder shapes and auto-detects all of them:

**Layout 1 — Flat folder (all files at root level)**
```
cognos_source/
├── model.xml           → detected as Framework Manager model
└── report.xml          → detected as report specification, paired with model.xml
```

**Layout 2 — Nested project folder (IBM Cognos On-Premise export)**
```
cognos_source/
├── model/
│   └── model.xml
├── content_store/
│   └── report.xml
└── sample_data/
    ├── Sales.csv
    └── Customers.csv
```

**Layout 3 — Mixed single files**
```
cognos_source/
├── report1.xml         → processed independently
├── report2.zip         → ZIP members extracted and processed
└── rendered.mht        → MIME-decoded HTML table extraction
```

When a Framework Manager model and one or more report specifications are both
present (layouts 1 and 2), the engine processes them as one paired migration:
the semantic model is built from the FM model and merged with each report
specification into one Power BI Project per report.

---

## 15. Current Limitations

The following limitations are based on the actual implementation:

- **Prompts / parameters not converted to slicers.** Prompt names and types
  are extracted and logged. No DAX What-If parameter table or slicer visual
  is generated. Each prompt must be recreated manually.

- **Per-cell conditional formatting not migrated.** CSS color palettes from
  the report's `<style>` block populate the Power BI theme. Individual
  cell-level Cognos conditional formatting rules are not converted.

- **Drill-through page links not migrated.** Hierarchy levels are generated
  in the semantic model. Cross-report drill-through links are not written into
  the PBIR output.

- **Composite-key joins partially resolved.** When a relationship has more
  than one `<determinant>` pair, only the first key pair is used. The
  remaining key columns are logged as a warning.

- **Row-level security not migrated.** Cognos ACLs do not map 1:1 to Power BI
  Row-Level Security roles. Flagged in migration documentation for manual
  planning.

- **Macros and embedded JavaScript not converted.** No Power BI equivalent
  exists.

- **Untranslatable DAX expressions emit commented placeholders.** Any Cognos
  expression the converter cannot translate is written as
  `// COGNOS: <original>` in the TMDL file. These must be completed manually.

- **Session credentials are in plain text.** `_VALID_CREDENTIALS` in
  `report_migration_tool.py` stores passwords as plain strings. Replace with
  a proper credential store before production use.

---

## 16. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `✗ Cognos engine failed to load` at startup | Syntax or import error in `cognos_pbi_server.py` | Check the traceback printed below the message |
| `✗ Tableau engine failed to load` at startup | `tableau_pbi_server.py` missing or broken | Cognos engine falls back to built-in stubs — migration still works |
| Browser redirects to `/` on `/app` | No valid session cookie | Log in at `http://localhost:8500` |
| "Source not found" in the log | Relative path given — server resolved it against its own directory | Use the full absolute path, e.g. `D:\Reports\model.xml` |
| Empty `.pbip` with no tables | Source file had no parseable `<query>` or `<querySubject>` elements | Check the source XML — ensure it is a real Cognos report spec or FM model, not a Cognos Studios export in an unsupported format |
| `python-docx not found — installing…` | First run on a machine without `python-docx` | Normal — install proceeds automatically. If it fails, run `pip install python-docx` manually |
| Power BI Desktop shows "Data Source Settings" as empty | Tables backed by synthetic `#table()` stubs instead of real CSV files | Use `--source-data-folder` to point the engine at your real data files, or replace the M partition manually |

---

## 17. Future Enhancements

- **AI-assisted formula translation** — route untranslatable Cognos expressions
  to an LLM pass for candidate DAX generation and human review.
- **Prompt-to-slicer migration** — auto-generate a What-If parameter table and
  slicer visual for each extracted Cognos prompt.
- **Extended visual type mapping** — Cognos bullet charts, gauge arrays,
  microcharts, and combination charts that do not map to a single Power BI
  visual type.
- **Drill-through page links** — write PBIR drill-through references that
  reconstruct Cognos cross-report navigation.
- **RLS scaffolding** — generate a starter Power BI RLS role definition from
  Cognos ACL exports, flagging rows requiring human decision.
- **Parallel file processing** — process multiple source files concurrently
  for large source folders.
- **Incremental re-processing** — skip files whose `mtime` has not changed
  since the last run.
- **TMDL round-trip validation** — serialize → deserialize → compare to catch
  formatting edge cases before writing.

---

## 18. License

MIT License

Copyright © Yash Technologies

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

---

## 19. Contributors

| Field | Value |
|---|---|
| **Project name** | ReportBridge — IBM Cognos On-Premise to Microsoft Power BI Migration Tool |
| **Version** | 1.0.0 |
| **Author** | Yash Technologies |
| **Primary engine** | `cognos_pbi_server.py` (8 400+ lines) |
| **Server / router** | `report_migration_tool.py` |
| **UI** | `Landing.html` (login · React · three themes) · `Index.html` (migration workspace · React · SSE) |
| **Sibling engines** | `tableau_pbi_server.py` · `crystal_pbi_generator.py` |
| **Shared utilities** | `_guid`, `_safe_pbi_name`, `_unique_name`, `_jmin`, `_pbi_m_type`, `_m_sample_value`, `_pbix_via_desktop`, `_pbix_via_api` — imported from `tableau_pbi_server.py` |
