# Running the Cognos → Power BI Converter Locally

## 1. Requirements

- Python 3.8+ — that's it. Both scripts only use the standard library
  (`csv`, `os`, `re`, `xml.etree.ElementTree`, `json`), so there's no
  `pip install` step.

## 2. Folder structure (must match exactly)

The scripts use fixed relative paths, so "auto-pickup" only works if
your files sit in these exact locations:

```
poc2/
├── repository/
│   ├── model_xml/
│   │   └── model.xml          <- real Framework Manager model export goes here (optional entry point)
│   ├── sample_data/            <- flattened CSVs (generated from model.xml, or placed here directly)
│   └── content_store/          <- Stage B input: data source connections, security, schedules, etc.
├── cognos_reports/              <- your real Cognos report XML files go here
├── converter/
│   ├── cognos_dax_mapping.py
│   ├── parse_model_xml.py       <- Stage A, step 1: model.xml -> flattened CSVs
│   ├── parse_repo.py            <- Stage A, step 2: CSVs -> semantic model
│   ├── convert_report.py        <- Stage A, step 3: report XML -> Power BI reports
│   ├── run_conversion.py        <- Stage A orchestrator: runs the 3 steps above in one command
│   └── gap_analysis.py          <- Stage B: produces GAP_REPORT.md (not auto-converted, by design)
└── output_powerbi/               <- created automatically, don't touch by hand
```

Always run the scripts **from inside `converter/`** — that's what the
`../repository/...` and `../cognos_reports` relative paths assume.

## 3. Run sequence

**Stage A — Conversion (model + reports).** This is fully automated
and is what produces your Power BI semantic model and report
definitions.

```bash
cd poc2/converter
python3 run_conversion.py          # runs all 3 steps below in order automatically
```

`run_conversion.py` is the single entry point and internally runs:

```bash
python3 parse_model_xml.py ../repository/model_xml/model.xml   # 1. real FM XML -> flattened CSVs
python3 parse_repo.py                                          # 2. CSVs -> Power BI semantic model
python3 convert_report.py                                      # 3. report XML -> Power BI reports
```

Use `python3 run_conversion.py --skip-model-xml` if you already have
flattened CSVs in `repository/sample_data/` and don't need step 1.

**Stage B — Gap analysis (everything conversion intentionally skips).**
Run this *after* Stage A, once you're ready to plan the parts that
need a human decision rather than a script:

```bash
python3 gap_analysis.py
```

This reads `repository/content_store/*.csv` (data source connections,
security/ACLs, schedules, distribution lists/bursting, drill-through,
audit/usage) and writes `output_powerbi/GAP_REPORT.md` — a checklist,
not a conversion. Nothing here gets auto-converted, on purpose: Cognos
security and bursting in particular don't map 1:1 onto Power BI's
model, so every row is flagged for a person to decide, not a script to
guess at.

**Note:** `parse_model_xml.py` overwrites the CSVs in
`repository/sample_data/` every time it runs, so treat `model.xml` (or
your real FM export) as the source of truth, not the CSVs — don't
hand-edit the CSVs if you're re-running from XML.

```bash
python3 convert_report.py my_report.xml
```

Run `parse_repo.py` before `convert_report.py` — the report converter
assumes the Measures/tables it references already exist in the model.

## 4. What your real repository export needs to look like

`parse_repo.py` expects these exact CSV filenames and column headers in
`repository/sample_data/`. If your actual Cognos export (Content Store
query, Framework Manager XML parsed to CSV, etc.) uses different column
names, either rename the columns to match this contract, or share a
sample row with me and I'll adjust the parser to your real schema
instead of the other way around.

| File | Required columns |
|---|---|
| `FM_PACKAGE.csv` | `PACKAGE_ID, PACKAGE_NAME, DATASOURCE_ID` |
| `FM_QUERY_SUBJECT.csv` | `QS_ID, PACKAGE_ID, QS_NAME, SOURCE_TABLE, QS_TYPE` |
| `FM_QUERY_ITEM.csv` | `QI_ID, QS_ID, QI_NAME, DATA_TYPE, USAGE, AGGREGATE_RULE, EXPRESSION` |
| `FM_RELATIONSHIP.csv` | `REL_ID, LEFT_QS_ID, RIGHT_QS_ID, LEFT_CARDINALITY, RIGHT_CARDINALITY, JOIN_EXPRESSION, ROLE_PLAYING_AS` (last column optional) |
| `FM_CALCULATION.csv` | `CALC_ID, PACKAGE_ID, CALC_NAME, CALC_EXPRESSION, FOLDER` (`DEPENDS_ON_CALC` optional) |
| `FM_FILTER.csv` | `FILTER_ID, PACKAGE_ID, FILTER_NAME, FILTER_EXPRESSION` (`IS_PROMPTED` optional) |
| `FM_DETERMINANT.csv` | optional — `DET_ID, QS_ID, DET_NAME, KEY_ITEMS, GROUP_BY_KEY` |
| `CM_OBJECTS.csv`, `CM_REPORT.csv` | used for reference/lineage only — not required for the model to build |

`DATA_TYPE` values recognized: `integer`, `decimal`, `string`, `date`
(anything else defaults to `string` — extend `DATATYPE_MAP` in
`cognos_dax_mapping.py` if your export uses different type names).

`USAGE` values recognized: `identifier`, `attribute`, `fact`.

## 5. What your real report exports need to look like

`convert_report.py` walks the XML tree for `<list>`, `<crosstab>`, and
`<chart>` elements (namespace-agnostic — it strips the namespace before
comparing tags), so it's tolerant of the exact Cognos Report Spec
schema version. Just drop the `.xml` files as exported from Content
Manager / the Cognos SDK straight into `cognos_reports/` — no renaming
needed.

## 6. Where to look after running

- `output_powerbi/CONVERSION_STATUS.md` — **check this first.** It's a
  flat list of everything converted, marked `OK` or `NEEDS REVIEW`,
  with the original Cognos expression next to each. This is the queue
  a human (or an LLM pass) should work through before anything ships.
- `output_powerbi/SalesModel.SemanticModel/definition/` — the TMDL
  semantic model (tables, measures, relationships).
- `output_powerbi/<ReportName>.Report/definition/` — one folder per
  converted report, with `report.json` and a `visual.json` per visual.

## 7. Getting this into actual Power BI Desktop

One honest gap: this POC generates the *definition* files (TMDL/PBIR),
not a complete `.pbip` project shell (which also needs a `.pbip` file,
`.platform` files, and a few metadata files Power BI Desktop writes
itself). The fastest path today:

1. In Power BI Desktop, create a new blank **Power BI Project** (File →
   Save as → Power BI Project (.pbip)) — this generates the shell/
   metadata files.
2. Replace its `<Name>.SemanticModel/definition/` and
   `<Name>.Report/definition/` folders with the ones this converter
   generated.
3. Reopen the `.pbip` in Power BI Desktop.

If you'd rather I script step 1 as well (generating a full valid
`.pbip` shell), let me know and I'll add it — it just needs a real
Power BI Desktop-created example to copy the exact metadata schema
from, since that part isn't publicly documented in full.
