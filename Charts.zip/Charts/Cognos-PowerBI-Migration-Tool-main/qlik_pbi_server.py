#!/usr/bin/env python3
"""
QlikView -> Power BI Migration Server
======================================
Single-call orchestration wrapper around the existing, unmodified
QlikView conversion logic (the "finalcodde" reference implementation),
which is vendored unchanged under ``qlik_engine/``:

    qlik_engine/qlik_metadata_extractor/   <- Step 1: QlikView metadata extraction
    qlik_engine/MigrationEngine/           <- Step 2: Power BI migration engine

Architecture note
------------------
This module is a sibling engine to ``tableau_pbi_server.py`` and
``cognos_pbi_server.py`` and is loaded in-process by
``report_migration_tool.py`` exactly the way those engines are — as an
importable module exposing ``conversion_state``, ``broadcast()``,
``log()``, ``conversion_worker()`` and ``process_file()``. The unified
router monkey-patches ``broadcast`` the same way it does for Cognos/
Tableau so that Qlik log/job/status events reach the same SSE stream
used by the rest of the application.

Previously, converting a QlikView app required two manual, separate
commands run from inside ``qlik_metadata_extractor/``:

    py main.py                 # Step 1 - metadata extraction
    py -m MigrationEngine       # Step 2 - Power BI migration

This module preserves that extraction and migration logic completely
unchanged (it only *imports* ``ExtractionController`` and
``run_migration`` — none of their code is duplicated or reimplemented)
and wraps both stages behind a single call:

    run_qlik_to_powerbi(input_path)

which runs extraction, then automatically feeds its output into the
migration engine, and returns one status object describing the whole
pipeline. If extraction fails, migration is never started.

Usage (standalone, for local testing only — normally loaded by
report_migration_tool.py):
    python qlik_pbi_server.py --source ./qlik_source --target ./qlik_target
"""

import json
import logging
import queue
import shutil
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# Make the vendored, unmodified extraction + migration packages importable.
# qlik_engine/ contains the two packages exactly as delivered in
# "finalcodde.zip" (qlik_metadata_extractor/ and MigrationEngine/), which
# both resolve their own working folders relative to their own location, so
# they continue to work unchanged regardless of where this server runs from.
# ─────────────────────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent.resolve()
_QLIK_ENGINE_DIR = _HERE / "qlik_engine"
import sys
if str(_QLIK_ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(_QLIK_ENGINE_DIR))


def _diagnose_missing_engine() -> str:
    """
    Builds a precise, actionable message when qlik_engine/ (or one of its
    two required subpackages) isn't where this file expects it — almost
    always caused by an incomplete zip extraction (Windows' built-in
    "Extract All" sometimes silently drops deeply-nested files/folders)
    rather than a real code problem.
    """
    lines = [
        f"Expected the Qlik engine at: {_QLIK_ENGINE_DIR}",
        f"This file's own folder ({_HERE}) contains:",
    ]
    try:
        entries = sorted(p.name + ("/" if p.is_dir() else "") for p in _HERE.iterdir())
        lines.append("  " + ", ".join(entries))
    except Exception as exc:
        lines.append(f"  <could not list folder: {exc}>")

    if not _QLIK_ENGINE_DIR.exists():
        lines.append(
            "\nqlik_engine/ itself is missing. Re-extract the zip you were given — "
            "qlik_engine/ must sit directly next to qlik_pbi_server.py and "
            "report_migration_tool.py. On Windows, right-click the .zip and use "
            "'Extract All'; if that still drops files, use 7-Zip or WinRAR instead "
            "(Windows' built-in extractor sometimes silently skips deeply-nested "
            "files) and extract to a short path like C:\\ReportBridge\\ rather than "
            "a long nested Downloads path."
        )
    else:
        for sub in ("qlik_metadata_extractor", "MigrationEngine"):
            sub_dir = _QLIK_ENGINE_DIR / sub
            if not sub_dir.exists():
                lines.append(f"\nqlik_engine/{sub}/ is missing — re-extract the zip; "
                             f"this subfolder was not copied over.")
            elif not any(sub_dir.rglob("*.py")):
                lines.append(f"\nqlik_engine/{sub}/ exists but contains no .py files — "
                             f"the extraction was incomplete; re-extract the zip.")
    return "\n".join(lines)


try:
    from qlik_metadata_extractor.config import Config as _ExtractConfig
    from qlik_metadata_extractor.controllers.extraction_controller import ExtractionController
    from qlik_metadata_extractor.prj import PRJNotFoundError
except ModuleNotFoundError as _exc:
    raise ModuleNotFoundError(
        f"{_exc}\n\n{_diagnose_missing_engine()}"
    ) from _exc

try:
    from MigrationEngine import run_migration
    from MigrationEngine.config import MigrationConfig
except ModuleNotFoundError as _exc:
    raise ModuleNotFoundError(
        f"{_exc}\n\n{_diagnose_missing_engine()}"
    ) from _exc


# ─────────────────────────────────────────────────────────────────────────────
# Global event bus — mirrors tableau_pbi_server.py / cognos_pbi_server.py
# exactly, so the unified router in report_migration_tool.py can wire this
# engine in the same way.
# ─────────────────────────────────────────────────────────────────────────────
_clients: list = []
_clients_lock = threading.Lock()

# ─────────────────────────────────────────────────────────────────────────────
# CRITICAL: the vendored extraction + migration engine is NOT safe to run
# concurrently. Extraction always writes into shared, fixed folders
# (Qlik_scripts/, Qlik_Script_MetaData/, Qlik_Visual_MetaData/), and
# MigrationEngine.run_migration() processes EVERY metadata JSON file it
# finds there in one pass (it has no concept of "just this app"). If two
# QlikView inputs are converted at the same time (e.g. the folder watcher
# finds several files at once and spawns a thread per file, matching the
# Tableau/Cognos pattern), both threads' migration passes end up reading
# and writing the very same generated files simultaneously, producing
# race-condition errors like "No PBIP report scaffold found" or Windows
# file-in-use errors during the output copy.
#
# This lock forces every full pipeline run (extraction + migration + copy)
# to execute one at a time, process-wide. Concurrent requests simply queue
# up and run in turn instead of corrupting each other's output.
# ─────────────────────────────────────────────────────────────────────────────
_pipeline_lock = threading.Lock()

conversion_state = {
    "running": False,
    "source": "",
    "target": "",
    "jobs": {},          # input path (str) -> {status, message, started, finished, output_dir}
}


def broadcast(event: str, data: dict):
    """Push an SSE event to all connected browser clients."""
    payload = f"event: {event}\ndata: {json.dumps(data)}\n\n"
    with _clients_lock:
        dead = []
        for q in _clients:
            try:
                q.put_nowait(payload)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _clients.remove(q)


def log(level: str, message: str, filename: str = ""):
    ts = datetime.now().strftime("%H:%M:%S")
    broadcast("log", {"ts": ts, "level": level, "message": message, "file": filename})
    print(f"[{ts}] [{level.upper():5s}] {('[' + filename + '] ') if filename else ''}{message}",
          flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Supported QlikView inputs. Extraction is PRJ-only (see
# qlik_metadata_extractor/main.py): a ".qvw" is really just a naming handle
# used to locate its sibling "<name>-PRJ" folder, which can also be pointed
# to directly.
# ─────────────────────────────────────────────────────────────────────────────
SUPPORTED_EXTENSIONS = (".qvw",)


class QlikMigrationError(Exception):
    """Raised when either pipeline stage fails; carries which stage failed."""

    def __init__(self, stage: str, message: str):
        super().__init__(message)
        self.stage = stage
        self.message = message


# ─────────────────────────────────────────────────────────────────────────────
# THE single call: QlikView input -> extraction -> migration -> Power BI
# output, in one function, with one return value describing the whole run.
# ─────────────────────────────────────────────────────────────────────────────
def run_qlik_to_powerbi(input_path,
                         output_dir: Optional[str] = None,
                         build_pbip: bool = True,
                         build_report_visuals: bool = True) -> dict:
    """
    Run the complete QlikView -> Power BI conversion in one call:

        QlikView Input (.qvw / PRJ folder)
                v
        Step 1: QlikView Metadata Extraction   (ExtractionController.run)
                v
        Generated Metadata / Scripts / Visual Metadata
                v
        Step 2: Power BI Migration Engine      (MigrationEngine.run_migration)
                v
        M Queries + DAX + Relationships + PBIP + Report Visuals
                v
        Final Power BI Report

    This is a thin orchestrator: it does not re-implement any parsing or
    generation logic. ``ExtractionController`` and ``run_migration`` are
    used exactly as they exist in the reference implementation.

    Parameters
    ----------
    input_path:
        A .qvw file, a "<name>-PRJ" folder, or a folder containing any mix
        of these (same contract as qlik_metadata_extractor/main.py).
    output_dir:
        Optional folder to copy the final Power BI output (PowerBIScript/)
        into once migration succeeds. If omitted, the output stays at its
        default location under qlik_engine/PowerBIScript/.
    build_pbip / build_report_visuals:
        Forwarded to MigrationEngine.run_migration (see its docstring).

    Returns
    -------
    dict with keys:
        ok                : bool   - True only if BOTH stages succeeded
        stage_failed       : str | None  - "extraction" | "migration" | None
        error              : str | None
        extraction_results : list[[str, str]]  - (script_txt, metadata_json) pairs
        output_dir         : str | None  - final Power BI output location
        started_at / finished_at : ISO timestamps

    Concurrency
    -----------
    This function acquires ``_pipeline_lock`` and blocks until any other
    in-progress QlikView conversion (from a concurrent request or from the
    folder watcher spawning multiple files at once) has finished — see the
    comment on ``_pipeline_lock`` above for why that's required. If another
    run is already in progress, the job is marked "queued" in
    ``conversion_state`` (and a log line is emitted) so the UI shows why
    nothing appears to be happening yet, rather than looking stuck.
    """
    job_key = str(input_path)
    if _pipeline_lock.locked():
        conversion_state["jobs"][job_key] = {
            "status": "queued", "stage": "waiting",
            "message": "Waiting for another QlikView conversion to finish "
                       "(the migration engine processes one app at a time)...",
            "started": datetime.now().isoformat(), "finished": None,
        }
        broadcast("state", conversion_state)
        log("info", f"Queued (another QlikView conversion is in progress): {input_path}")

    with _pipeline_lock:
        return _run_qlik_to_powerbi_locked(job_key, input_path, output_dir,
                                            build_pbip, build_report_visuals)


def _run_qlik_to_powerbi_locked(job_key: str, input_path,
                                 output_dir: Optional[str],
                                 build_pbip: bool,
                                 build_report_visuals: bool) -> dict:
    """The actual pipeline body. Only ever runs while _pipeline_lock is held."""
    started_at = datetime.now().isoformat()
    conversion_state["jobs"][job_key] = {
        "status": "running", "stage": "extraction",
        "message": "Starting QlikView extraction...",
        "started": started_at, "finished": None,
    }
    broadcast("state", conversion_state)

    result = {
        "ok": False,
        "stage_failed": None,
        "error": None,
        "extraction_results": [],
        "output_dir": None,
        "started_at": started_at,
        "finished_at": None,
    }

    # ── Stage 1: QlikView metadata extraction ───────────────────────────────
    log("info", f"Starting QlikView extraction for: {input_path}")
    try:
        controller = ExtractionController()
        extraction_results = controller.run(input_path)
        result["extraction_results"] = [
            [str(txt_path), str(json_path)] for txt_path, json_path in extraction_results
        ]
        log("info", f"Extraction completed: {len(extraction_results)} app(s) processed.")
    except FileNotFoundError as exc:
        result["stage_failed"] = "extraction"
        result["error"] = str(exc)
        log("error", f"Extraction failed (input not found): {exc}")
        _finish_job(job_key, result, ok=False)
        return result
    except PRJNotFoundError as exc:
        result["stage_failed"] = "extraction"
        result["error"] = str(exc)
        log("error", f"Extraction failed (PRJ folder missing): {exc}")
        _finish_job(job_key, result, ok=False)
        return result
    except Exception as exc:  # noqa: BLE001 - never let extraction errors reach migration
        result["stage_failed"] = "extraction"
        result["error"] = f"Unexpected extraction error: {exc}"
        log("error", f"Extraction failed unexpectedly: {exc}\n{traceback.format_exc()}")
        _finish_job(job_key, result, ok=False)
        return result

    # Extraction succeeded -> migration is only ever started from this point.
    conversion_state["jobs"][job_key].update(
        stage="migration", message="Extraction complete. Starting Power BI migration...")
    broadcast("state", conversion_state)

    # ── Stage 2: Power BI migration ─────────────────────────────────────────
    log("info", "Starting Power BI migration engine...")
    try:
        run_migration(build_pbip=build_pbip, build_report_visuals=build_report_visuals)
    except Exception as exc:  # noqa: BLE001
        result["stage_failed"] = "migration"
        result["error"] = f"Migration failed: {exc}"
        log("error", f"Migration failed: {exc}\n{traceback.format_exc()}")
        _finish_job(job_key, result, ok=False)
        return result

    final_output_dir = MigrationConfig.POWERBI_OUTPUT_DIR

    # Optionally copy the generated Power BI output to a caller-specified
    # target folder (keeps this engine consistent with Cognos/Tableau, which
    # both accept an explicit target directory). Retries briefly on Windows
    # file-in-use errors (e.g. antivirus scanning a just-written file) --
    # the _pipeline_lock above already rules out our own code being the
    # cause, so a short retry is the appropriate fix for what's left.
    if output_dir:
        dest = Path(output_dir).expanduser().resolve()
        last_exc = None
        for attempt in range(3):
            try:
                dest.mkdir(parents=True, exist_ok=True)
                shutil.copytree(final_output_dir, dest, dirs_exist_ok=True)
                final_output_dir = dest
                log("info", f"Copied Power BI output to requested target: {dest}")
                last_exc = None
                break
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
        if last_exc is not None:
            log("warn", f"Migration succeeded, but copying output to '{output_dir}' failed "
                        f"after retries: {last_exc}")

    result["ok"] = True
    result["output_dir"] = str(final_output_dir)
    log("info", f"QlikView -> Power BI conversion completed successfully. Output: {final_output_dir}")
    _finish_job(job_key, result, ok=True)
    return result


def _finish_job(job_key: str, result: dict, ok: bool) -> None:
    result["finished_at"] = datetime.now().isoformat()
    job = conversion_state["jobs"].get(job_key, {})
    job.update(
        status="success" if ok else "error",
        stage=result.get("stage_failed") or "done",
        message=result.get("error") or f"Output: {result.get('output_dir')}",
        finished=result["finished_at"],
        output_dir=result.get("output_dir"),
    )
    conversion_state["jobs"][job_key] = job
    broadcast("qlik_result", result)
    broadcast("state", conversion_state)


# ─────────────────────────────────────────────────────────────────────────────
# process_file / conversion_worker — kept for parity with the Tableau/Cognos
# engine contract (folder watcher + single-file convert used by the unified
# router and UI), delegating to the single call above for every file.
# ─────────────────────────────────────────────────────────────────────────────
def process_file(qlik_path: Path, target_dir: Path, *_ignored, **_ignored_kw) -> dict:
    """
    Route one QlikView input (.qvw file or "-PRJ" folder) through the full
    extraction + migration pipeline via run_qlik_to_powerbi, writing the
    final Power BI output into target_dir.
    """
    return run_qlik_to_powerbi(str(qlik_path), output_dir=str(target_dir))


def _is_new_qlik_input(path: Path) -> bool:
    if path.is_file() and path.suffix.lower() == ".qvw":
        return True
    if path.is_dir() and path.name.lower().endswith("-prj"):
        return True
    return False


def conversion_worker(source_dir: str, target_dir: str, *_ignored, **_ignored_kw) -> None:
    """
    Watches source_dir for new .qvw files / "<name>-PRJ" folders and runs
    the full single-call pipeline for each one, mirroring the watcher
    pattern used by cognos_pbi_server.conversion_worker /
    tableau_pbi_server.conversion_worker so the same UI/SSE flow works for
    Qlik conversions.
    """
    src = Path(source_dir).resolve()
    tgt = Path(target_dir).resolve()
    tgt.mkdir(parents=True, exist_ok=True)
    seen: set = set()

    log("info", f"Watching {src}  ->  {tgt}")
    broadcast("status", {"running": True, "source": str(src), "target": str(tgt)})

    while conversion_state["running"]:
        try:
            candidates = [p for p in src.iterdir() if _is_new_qlik_input(p)]
            for p in candidates:
                key = f"{p.resolve()}:{p.stat().st_mtime}"
                if key in seen:
                    continue
                seen.add(key)
                log("info", f"Detected new QlikView input: {p.name}")
                threading.Thread(target=process_file, args=(p, tgt), daemon=True).start()
        except Exception as exc:  # noqa: BLE001
            log("error", f"Watcher error: {exc}")
        time.sleep(2)

    broadcast("status", {"running": False})
    log("info", "Watcher stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# Standalone CLI entry point (for local testing only — normally this module
# is imported in-process by report_migration_tool.py, exactly like the
# Cognos/Tableau engines).
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    import os

    parser = argparse.ArgumentParser(
        description="QlikView -> Power BI Migration Engine (standalone single-call test mode)")
    parser.add_argument("--source", default=str(_ExtractConfig.INPUT_DIR),
                        help="A .qvw file, a '-PRJ' folder, or a folder containing either.")
    parser.add_argument("--target", default=str(MigrationConfig.POWERBI_OUTPUT_DIR),
                        help="Folder to copy the final Power BI output into.")
    args = parser.parse_args()

    os.makedirs(args.source, exist_ok=True)
    os.makedirs(args.target, exist_ok=True)
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    print(f"[qlik] Running single-call QlikView -> Power BI conversion for {args.source}")
    outcome = run_qlik_to_powerbi(args.source, output_dir=args.target)
    print(json.dumps(outcome, indent=2))
    sys.exit(0 if outcome["ok"] else 1)
