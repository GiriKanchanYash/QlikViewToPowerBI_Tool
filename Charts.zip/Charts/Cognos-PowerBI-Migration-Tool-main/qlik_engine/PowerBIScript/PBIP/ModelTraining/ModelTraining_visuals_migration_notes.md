# Visual migration notes for ModelTraining

Every visual in the metadata repository was migrated with no warnings.
