# ModelTraining - migrated scaffold

Generated from Qlik metadata for `ModelTraining.qvw`.

This is a starting point, not a finished report: it carries over tables, M sources, inferred relationships and basic row-count measures. Report visuals/layout have no Qlik equivalent in the extracted metadata and are not included. Open the .pbip in Power BI Desktop and let it validate the semantic model, then build the report canvas from there.
