# Visual migration notes for WorldCup Analysis

- [SH01] CS01: category 'current_selection_box' skipped by design
- [SH01] TX70: text expression '=[Home Team Name]&'    '&[Home Team Initials]' combines multiple fields/functions and wasn't fully re-derived - bound to 'Home Team Name' alone as a placeholder; replace with the real calculated column or DAX measure
- [SH01] TX60: text expression '=[Away Team Name]&'    '&[Away Team Initials]' combines multiple fields/functions and wasn't fully re-derived - bound to 'Away Team Name' alone as a placeholder; replace with the real calculated column or DAX measure
- [SH01] TX30: text expression '=if(len([Away Team Name])='0','-',[Away Team Goals])' combines multiple fields/functions and wasn't fully re-derived - bound to 'Away Team Name' alone as a placeholder; replace with the real calculated column or DAX measure
- [SH01] TX29: text expression '=if([Away Team Name]='','-',
if([Home Team Goals] = '',0,[Home Team Goals]))' combines multiple fields/functions and wasn't fully re-derived - bound to 'Away Team Name' alone as a placeholder; replace with the real calculated column or DAX measure
- [SH01] LA04: category 'layout' skipped by design
- [SH01] LA03: category 'layout' skipped by design
- [SH01] LA02: category 'layout' skipped by design
- [SH01] LA05: category 'layout' skipped by design
