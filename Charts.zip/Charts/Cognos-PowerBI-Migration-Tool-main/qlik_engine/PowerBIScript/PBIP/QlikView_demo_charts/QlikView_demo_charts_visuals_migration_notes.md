# Visual migration notes for QlikView_demo_charts

- [SH01] TB01: category 'table_box' not migrated (unsupported)
- [SH01] CS01: category 'current_selection_box' skipped by design
