# Candidate Power BI relationships for: WorldCup Analysis.qvw

QlikView associates tables implicitly on same-named fields. 
Power BI needs each relationship created explicitly (Model view 
-> Manage relationships), so review every row below before 
building the model - cardinality and cross-filter direction are 
best guesses, not guarantees.

| From table | To table | On field | Suggested cardinality | Status | Risk |
|---|---|---|---|---|---|
| Match-Wise Data | Player Data | MatchID-RoundID-KEY | 1:* (verify) | Active | - |
| Match-Wise Data | Statistics | Year | 1:* (verify) | Active | - |
| Match-Wise Data | Tp4 | Year | 1:* (verify) | Active | - |
| Match-Wise Data | WorldCup Summary | Year | 1:* (verify) | Active | - |
| Statistics | Tp4 | Year | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| Statistics | WorldCup Summary | Year | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| Tp4 | WorldCup Summary | Year | 1:* (verify) | SKIPPED (would create ambiguous path) | - |

3 candidate relationship(s) above were left out of the .tmdl model because the two tables were already connected through another relationship - adding them too would create multiple paths between the same tables, which Power BI rejects as "ambiguous paths" on load (QlikView's associative model allows this; Power BI's tabular engine doesn't). If you need one of these specifically, remove/redirect the conflicting relationship in Power BI Desktop first.
