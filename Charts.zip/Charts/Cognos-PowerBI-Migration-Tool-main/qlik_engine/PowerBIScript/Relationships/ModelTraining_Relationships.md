# Candidate Power BI relationships for: ModelTraining.qvw

QlikView associates tables implicitly on same-named fields. 
Power BI needs each relationship created explicitly (Model view 
-> Manage relationships), so review every row below before 
building the model - cardinality and cross-filter direction are 
best guesses, not guarantees.

| From table | To table | On field | Suggested cardinality | Status | Risk |
|---|---|---|---|---|---|
| Map_MovementType | StockMovements | MovementCode | 1:* (verify) | Active | SYNTHETIC KEY RISK - review before modeling |
| Map_MovementType | StockMovements | MovementDesc | 1:* (verify) | SKIPPED (would create ambiguous path) | SYNTHETIC KEY RISK - review before modeling |
| Products | PurchaseOrders | SupplierID | 1:* (verify) | Active | - |
| Products | Suppliers | SupplierID | 1:* (verify) | Active | - |
| PurchaseOrders | Suppliers | SupplierID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| ProductWarehouse | Products | ProductID | 1:* (verify) | Active | - |
| ProductWarehouse | PurchaseOrderLines | ProductID | 1:* (verify) | Active | - |
| ProductWarehouse | QA_OrphanProductsInMovements | ProductID | 1:* (verify) | Active | - |
| ProductWarehouse | SalesSummaryByProductMonth | ProductID | 1:* (verify) | Active | - |
| Products | PurchaseOrderLines | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| Products | QA_OrphanProductsInMovements | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| Products | SalesSummaryByProductMonth | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| PurchaseOrderLines | QA_OrphanProductsInMovements | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| PurchaseOrderLines | SalesSummaryByProductMonth | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| QA_OrphanProductsInMovements | SalesSummaryByProductMonth | ProductID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| ProductWarehouse | PurchaseOrders | WarehouseID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| ProductWarehouse | Warehouses | WarehouseID | 1:* (verify) | Active | - |
| PurchaseOrders | Warehouses | WarehouseID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| Customers | SalesOrders | CustomerID | 1:* (verify) | Active | - |
| EmployeeDirectorFlag | SalesOrders | EmployeeID | 1:* (verify) | Active | - |
| PurchaseOrderDailyAge | PurchaseOrderLines | PurchaseOrderID | 1:* (verify) | Active | - |
| PurchaseOrderDailyAge | PurchaseOrders | PurchaseOrderID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| PurchaseOrderLines | PurchaseOrders | PurchaseOrderID | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| SalesOrderLines | SalesOrders | SalesOrderID | 1:* (verify) | Active | - |
| StockMovementExceptions | StockMovements | MovementID | 1:* (verify) | Active | - |
| InventorySnapshot | ProductWarehouse | ProductWarehouseKey | 1:* (verify) | Active | - |
| InventorySnapshot | SalesOrderLines | ProductWarehouseKey | 1:* (verify) | Active | - |
| InventorySnapshot | StockMovements | ProductWarehouseKey | 1:* (verify) | Active | - |
| ProductWarehouse | SalesOrderLines | ProductWarehouseKey | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| ProductWarehouse | StockMovements | ProductWarehouseKey | 1:* (verify) | SKIPPED (would create ambiguous path) | - |
| SalesOrderLines | StockMovements | ProductWarehouseKey | 1:* (verify) | SKIPPED (would create ambiguous path) | - |

15 candidate relationship(s) above were left out of the .tmdl model because the two tables were already connected through another relationship - adding them too would create multiple paths between the same tables, which Power BI rejects as "ambiguous paths" on load (QlikView's associative model allows this; Power BI's tabular engine doesn't). If you need one of these specifically, remove/redirect the conflicting relationship in Power BI Desktop first.

2 relationship(s) above involve tables that the Qlik script parser flagged as sharing multiple fields (QlikView synthetic-key territory). In Power BI this usually means: pick a single real key column, or build a proper bridge/dimension table instead of relating on every shared field.
