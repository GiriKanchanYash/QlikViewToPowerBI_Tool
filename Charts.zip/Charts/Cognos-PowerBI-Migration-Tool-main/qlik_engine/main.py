"""
main.py
-------
CLI entry point for the Qlik Metadata Extractor tool.

Extraction is PRJ-only: each .qvw must have its "<name>-PRJ" project
folder saved alongside it (QlikView -> Settings -> User Preferences ->
Design -> "Generate Project Folder"). No QlikView Desktop/COM
automation is used or required.

Usage:
    cd qlik_metadata_extractor
    python main.py "C:/Users/kanchan.giri/Downloads/.../WorldCup Analysis.qvw"

Outputs (named after the source .qvw file):
    qlik_metadata_extractor/output/scripts/WorldCup Analysis.txt   <- raw load script
    qlik_metadata_extractor/output/metadata/WorldCup Analysis.json <- parsed structured metadata

Project layout:
    qlik_metadata_extractor/
        main.py                     <- this file (run it from here)
        qlik_metadata_extractor/    <- the package (models/services/views/controllers)
"""
import sys
import logging
import argparse

from qlik_metadata_extractor.config import Config
from qlik_metadata_extractor.controllers.extraction_controller import ExtractionController
from qlik_metadata_extractor.prj import PRJNotFoundError


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract and parse one or more QlikView (.qvw) files into .txt and .json outputs."
    )
    parser.add_argument(
        "input_path",
        nargs="?",
        default=str(Config.INPUT_DIR),
        help="Path to a .qvw file or a folder containing .qvw files. Defaults to Qlik_input_files."
    )
    return parser.parse_args()


def main() -> int:
    configure_logging()
    logger = logging.getLogger("qlik_metadata_extractor.main")
    args = parse_args()

    try:
        controller = ExtractionController()
        controller.run(args.input_path)
        return 0
    except FileNotFoundError as exc:
        logger.error(str(exc))
        return 1
    except PRJNotFoundError as exc:
        logger.error(str(exc))
        return 2
    except Exception as exc:  # noqa: BLE001 - top-level CLI safety net
        logger.exception(f"Unexpected error: {exc}")
        return 3


if __name__ == "__main__":
    sys.exit(main())
