"""
models/metadata_model.py
------------------------
The "Model" layer: a typed data structure that mirrors the canonical
JSON schema used for parsed QlikView script metadata. Keeping this as
a dataclass (rather than a raw dict) gives type-checking, IDE support,
and a single source of truth for the schema shape.
"""
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Dict, Any


@dataclass
class ScriptMetadata:
    script_name: str
    variables: List[Dict[str, Any]] = field(default_factory=list)
    tabs: List[Dict[str, Any]] = field(default_factory=list)
    tables: List[Dict[str, Any]] = field(default_factory=list)
    joins: List[Dict[str, Any]] = field(default_factory=list)
    concatenations: List[Dict[str, Any]] = field(default_factory=list)
    mapping_tables: List[Dict[str, Any]] = field(default_factory=list)
    resident_loads: List[Dict[str, Any]] = field(default_factory=list)
    preceding_loads: List[Dict[str, Any]] = field(default_factory=list)
    qvd_sources: List[Dict[str, Any]] = field(default_factory=list)
    csv_sources: List[Dict[str, Any]] = field(default_factory=list)
    excel_sources: List[Dict[str, Any]] = field(default_factory=list)
    sql_sources: List[Dict[str, Any]] = field(default_factory=list)
    fixed_width_sources: List[Dict[str, Any]] = field(default_factory=list)
    xml_sources: List[Dict[str, Any]] = field(default_factory=list)
    inline_tables: List[Dict[str, Any]] = field(default_factory=list)
    fields: List[str] = field(default_factory=list)
    derived_fields: List[Dict[str, Any]] = field(default_factory=list)
    keys: List[str] = field(default_factory=list)
    synthetic_keys: List[Dict[str, Any]] = field(default_factory=list)
    lineage: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    # --- Fields below are populated by the PRJ extraction path
    # (qlik_metadata_extractor.prj), which is the only extraction path
    # in this build. ---
    document_properties: Dict[str, Any] = field(default_factory=dict)
    sheets: List[Dict[str, Any]] = field(default_factory=list)
    charts: List[Dict[str, Any]] = field(default_factory=list)
    objects: List[Dict[str, Any]] = field(default_factory=list)
    extraction_source: str = "PRJ"
    prj_dir: str = ""

    @classmethod
    def from_template(cls, template_path: Path, script_name: str) -> "ScriptMetadata":
        """Load the blank schema template and stamp in the script name."""
        with open(template_path, "r", encoding="utf-8") as f:
            template = json.load(f)
        template["script_name"] = script_name
        return cls(**template)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 4) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)