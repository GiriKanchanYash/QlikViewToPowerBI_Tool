"""
services/script_parser_service.py
----------------------------------
Parses raw QlikView load-script text into the structured metadata schema
defined in models/metadata_model.py.

This is a heuristic, regex-based parser. QlikView's script syntax is
free-form (not a strict grammar), so this targets the patterns that show
up in real-world scripts: SET/LET variables, ///$tab markers, TableName:
LOAD/SELECT/MAPPING LOAD blocks, JOIN/CONCATENATE, RESIDENT loads,
preceding (nested) loads, and FROM clauses pointing at qvd/csv/txt/xlsx
files or SQL sources.

Anything that cannot be confidently classified is recorded in
`warnings` rather than silently dropped or guessed at.
"""
import re
import logging
from pathlib import Path
from typing import List, Dict, Any, Tuple

from qlik_metadata_extractor.models.metadata_model import ScriptMetadata

logger = logging.getLogger(__name__)


class ScriptParserService:

    TAB_RE = re.compile(r"^\s*///\$tab\s+(.+?)\s*$", re.MULTILINE)
    VAR_RE = re.compile(r"^\s*(SET|LET)\s+([A-Za-z0-9_.]+)\s*=\s*(.+?);", re.MULTILINE | re.IGNORECASE)
    TABLE_HEADER_RE = re.compile(
        r"(?:^|\n)\s*\[?([A-Za-z0-9_ \-\.]+?)\]?\s*:\s*\n\s*(?:NOCONCATENATE\s+)?(MAPPING\s+)?(LOAD|SELECT)\b",
        re.IGNORECASE
    )
    JOIN_RE = re.compile(
        r"\b(LEFT|RIGHT|INNER|OUTER)?\s*(JOIN|KEEP)\s*(?:\(\s*\[?([A-Za-z0-9_ \-\.]+)\]?\s*\))?",
        re.IGNORECASE
    )
    CONCAT_RE = re.compile(r"\bCONCATENATE\s*(?:\(\s*\[?([A-Za-z0-9_ \-\.]+)\]?\s*\))?", re.IGNORECASE)
    RESIDENT_RE = re.compile(r"\bRESIDENT\s+\[?([A-Za-z0-9_ \-\.]+)\]?", re.IGNORECASE)
    DROP_TABLE_RE = re.compile(r"^\s*DROP\s+TABLES?\s+(.+)$", re.IGNORECASE | re.DOTALL)
    FROM_FILE_BRACKET_RE = re.compile(r"\bFROM\s+\[([^\]]+)\]", re.IGNORECASE)
    FROM_FILE_PLAIN_RE = re.compile(r"\bFROM\s+([^\s\(;]+)", re.IGNORECASE)
    SQL_SELECT_RE = re.compile(r"\bSQL\s+SELECT\b", re.IGNORECASE)
    CONNECT_RE = re.compile(r"\bCONNECT\s+TO\b", re.IGNORECASE)
    FORMAT_SPEC_RE = re.compile(r"\(([^)]+)\)\s*$")
    TABLE_IS_RE = re.compile(r"\btable\s+is\s+\[?([^\],]+?)\]?\s*$", re.IGNORECASE)
    LOAD_KEYWORD_RE = re.compile(r"\bLOAD\b", re.IGNORECASE)
    SELECT_KEYWORD_RE = re.compile(r"\bSELECT\b", re.IGNORECASE)
    # DOTALL: an expression can legitimately span multiple lines (e.g. a
    # nested If(...) formatted across several lines before its `AS alias`),
    # and without DOTALL `.` never matches the embedded newlines, so the
    # whole thing silently fails to split into expression + alias.
    AS_ALIAS_RE = re.compile(r"(.+?)\s+AS\s+\[?([A-Za-z0-9_ \-\.]+?)\]?\s*$", re.IGNORECASE | re.DOTALL)
    VAR_REF_RE = re.compile(r"\$\(([A-Za-z0-9_.]+)\)")
    FROM_OR_RESIDENT_RE = re.compile(r"\b(FROM|RESIDENT)\b", re.IGNORECASE)
    BARE_LOAD_OR_SELECT_RE = re.compile(r"^\s*(LOAD|SELECT)\b", re.IGNORECASE)
    DISTINCT_LOAD_RE = re.compile(r"^\s*DISTINCT\b\s*", re.IGNORECASE)
    INLINE_RE = re.compile(r"\bINLINE\s*\[(.*?)\]", re.IGNORECASE | re.DOTALL)
    WHERE_CLAUSE_RE = re.compile(
        r"\bWHERE\s+(.+?)\s*(?=\bGROUP\s+BY\b|\bORDER\s+BY\b|$)", re.IGNORECASE | re.DOTALL
    )
    GROUP_BY_CLAUSE_RE = re.compile(
        r"\bGROUP\s+BY\s+(.+?)\s*(?=\bORDER\s+BY\b|$)", re.IGNORECASE | re.DOTALL
    )
    ORDER_BY_CLAUSE_RE = re.compile(r"\bORDER\s+BY\s+(.+?)\s*$", re.IGNORECASE | re.DOTALL)
    FIXED_WIDTH_FIELD_RE = re.compile(
        r"@\s*(\d+)\s*:\s*(\d+)\s+AS\s+\[?([A-Za-z0-9_ \-\.]+?)\]?\s*$", re.IGNORECASE
    )

    def __init__(self, script_name: str, template_path: Path):
        self.script_name = script_name
        self.template_path = template_path

    def parse(self, raw_script: str) -> ScriptMetadata:
        metadata = ScriptMetadata.from_template(self.template_path, self.script_name)

        if not raw_script or not raw_script.strip():
            metadata.warnings.append("Script content is empty.")
            return metadata

        # QlikView commonly writes LoadScript.txt with a leading UTF-8 BOM
        # (U+FEFF). It isn't whitespace as far as `\s` is concerned, so if
        # left in place it silently breaks the very first line of the
        # script (typically the first ///$tab marker or a SET/LET
        # statement). Strip it defensively regardless of how the caller
        # read the file.
        raw_script = raw_script.lstrip("\ufeff")

        self._parse_tabs(raw_script, metadata)
        self._parse_variables(raw_script, metadata)
        expanded_script = self._expand_variables(raw_script, metadata)

        statements = self._split_statements(expanded_script)
        table_field_map: Dict[str, List[str]] = {}

        i, n = 0, len(statements)
        while i < n:
            stmt = statements[i]

            # DROP TABLE(S) removes the named table(s) from the data
            # model entirely. Must be handled before anything else below,
            # since a common Qlik pattern is: DROP a table, then LOAD a
            # brand-new table under the *same* name a few lines later
            # (e.g. CROSSTABLE unpivot -> RESIDENT reshape -> RESIDENT
            # reshape final). Without clearing table_field_map/metadata
            # here, that reused name keeps accumulating fields from every
            # earlier (already-dropped) incarnation, and _derive_keys()
            # ends up treating long-gone fields as still belonging to the
            # table -- producing relationship candidates that reference
            # columns the final, written table never actually has.
            drop_match = self.DROP_TABLE_RE.match(stmt)
            if drop_match:
                self._drop_tables(drop_match.group(1), table_field_map, metadata)
                i += 1
                continue

            header_match = self.TABLE_HEADER_RE.search(stmt)
            starts_chain = (
                header_match is not None
                and not self.FROM_OR_RESIDENT_RE.search(stmt)
                and i + 1 < n
                and bool(self.BARE_LOAD_OR_SELECT_RE.match(statements[i + 1]))
                and not self.TABLE_HEADER_RE.search(statements[i + 1])
            )
            if starts_chain:
                chain_statements = [stmt]
                j = i + 1
                while (
                    j < n
                    and self.BARE_LOAD_OR_SELECT_RE.match(statements[j])
                    and not self.TABLE_HEADER_RE.search(statements[j])
                ):
                    chain_statements.append(statements[j])
                    j += 1
                    if self.FROM_OR_RESIDENT_RE.search(chain_statements[-1]):
                        break
                self._parse_load_chain(header_match, chain_statements, metadata, table_field_map)
                i = j
                continue
            self._parse_statement(stmt, metadata, table_field_map)
            i += 1

        self._derive_keys(table_field_map, metadata)
        return metadata

    # ---------------- Tabs ----------------
    def _parse_tabs(self, raw_script: str, metadata: ScriptMetadata) -> None:
        for match in self.TAB_RE.finditer(raw_script):
            metadata.tabs.append({"name": match.group(1).strip()})
        if not metadata.tabs:
            metadata.tabs.append({"name": "Main"})

    # ---------------- Variables ----------------
    def _parse_variables(self, raw_script: str, metadata: ScriptMetadata) -> None:
        for match in self.VAR_RE.finditer(raw_script):
            var_type, name, value = match.groups()
            metadata.variables.append({
                "name": name.strip(),
                "value": value.strip().strip("'\""),
                "type": var_type.upper()
            })

    def _substitute_vars(
        self, text: str, resolved: Dict[str, str], max_passes: int = 10
    ) -> Tuple[str, set]:
        """
        Replaces every $(VarName) in `text` with its resolved value,
        re-scanning up to `max_passes` times so a variable whose own value
        contains another $(...) reference still resolves (e.g. vDataPath
        built from vRoot). Any $(...) with no matching variable is left
        untouched and reported back in the returned set so the caller can
        warn about it once, generically, without guessing at a value.
        """
        unresolved: set = set()
        for _ in range(max_passes):
            changed = False

            def _repl(m: "re.Match[str]") -> str:
                nonlocal changed
                name = m.group(1)
                if name in resolved:
                    changed = True
                    return resolved[name]
                unresolved.add(name)
                return m.group(0)

            new_text = self.VAR_REF_RE.sub(_repl, text)
            if new_text == text:
                break
            text = new_text
        return text, unresolved

    def _expand_variables(self, raw_script: str, metadata: ScriptMetadata) -> str:
        """
        Resolves every SET/LET variable's own value first (so later
        variables can reference earlier ones), then expands every
        $(VarName) occurrence across the whole script -- most importantly
        inside FROM clauses, e.g. FROM [$(vDataPath)Products.xlsx].
        """
        resolved: Dict[str, str] = {}
        for v in metadata.variables:
            expanded_value, _ = self._substitute_vars(v["value"], resolved)
            resolved[v["name"]] = expanded_value
            v["resolved_value"] = expanded_value

        expanded_script, unresolved = self._substitute_vars(raw_script, resolved)
        if unresolved:
            metadata.warnings.append(
                "Unresolved $(...) variable reference(s) left as-is (no "
                "matching SET/LET found): " + ", ".join(sorted(unresolved))
            )
        return expanded_script

    # ---------------- Statement splitting ----------------
    @staticmethod
    def _strip_trailing_comment(line: str) -> str:
        """
        Truncates a line at a trailing `// comment` (Qlik's line-comment
        marker), if one is present outside of a quoted string literal or
        a bracketed [...] identifier/path (Qlik connection strings like
        `[lib://Data/Customers.qvd]` legitimately contain "//" and must
        not be mistaken for a comment) -- e.g.
        `WHILE ... <= 120;   // safety cap at 120 days` becomes
        `WHILE ... <= 120;   `. Without this, a trailing comment with no
        semicolon of its own gets glued onto the *next* statement by
        _split_statements' plain split(";"), which can corrupt that next
        statement's own leading keyword match (e.g. DROP_TABLE_RE's
        `^\\s*DROP` anchor no longer matches because the line now starts
        with comment text instead) and silently make it disappear from
        parsing entirely.
        """
        in_string = False
        bracket_depth = 0
        i, n = 0, len(line)
        while i < n:
            ch = line[i]
            if in_string:
                if ch == "'":
                    if i + 1 < n and line[i + 1] == "'":
                        i += 2
                        continue
                    in_string = False
                i += 1
                continue
            if ch == "'":
                in_string = True
                i += 1
                continue
            if ch == "[":
                bracket_depth += 1
                i += 1
                continue
            if ch == "]":
                bracket_depth = max(0, bracket_depth - 1)
                i += 1
                continue
            if bracket_depth == 0 and ch == "/" and i + 1 < n and line[i + 1] == "/":
                return line[:i]
            i += 1
        return line

    def _split_statements(self, raw_script: str) -> List[str]:
        """
        Splits the script into individual statements on ';'.
        Full-line comments (// ...) and ///$tab markers are stripped
        first since they are handled separately; trailing same-line
        comments are truncated too (see _strip_trailing_comment). This
        is a pragmatic approach: it does not fully respect semicolons
        embedded inside quoted string literals, which is rare within
        LOAD/table statements.
        """
        cleaned_lines = []
        for line in raw_script.splitlines():
            stripped = line.strip()
            if stripped.startswith("///$tab"):
                continue
            if stripped.startswith("//"):
                continue
            cleaned_lines.append(self._strip_trailing_comment(line))
        cleaned = "\n".join(cleaned_lines)

        statements = []
        for part in cleaned.split(";"):
            part = part.strip()
            if part and part.lower() != "exit script":
                statements.append(part)
        return statements

    # ---------------- Per-statement parsing ----------------
    def _parse_load_chain(
        self,
        header_match: "re.Match[str]",
        chain_statements: List[str],
        metadata: ScriptMetadata,
        table_field_map: Dict[str, List[str]],
    ) -> None:
        """
        Handles QlikView PRECEDING LOAD: a table defined as a stack of
        LOAD/SELECT statements where only the bottom-most one carries a
        FROM/RESIDENT source, e.g.:

            Products:
            LOAD ..., If(MarginPct >= 0.4, ...) as MarginTier ;
            LOAD ..., Num(UnitCost,'#,##0.00') as UnitCost FROM [...];

        Each statement is its own pipeline stage; the bottom (last
        encountered) statement is the innermost/source stage, the top
        (header) statement is the outermost/final stage whose field list
        is what the table actually exposes. Generic over any number of
        stacked stages and any table/field names.
        """
        table_name = header_match.group(1).strip()
        is_mapping = bool(header_match.group(2))

        stages: List[Dict[str, Any]] = []

        first_fields, first_derived, first_fixed, first_distinct = self._extract_fields(
            chain_statements[0], header_match.end(), table_name
        )
        stages.append({
            "fields": first_fields, "derived": first_derived,
            "fixed_width": first_fixed, "is_distinct": first_distinct,
            "raw": chain_statements[0],
        })

        for stmt in chain_statements[1:]:
            kw_match = self.LOAD_KEYWORD_RE.search(stmt) or self.SELECT_KEYWORD_RE.search(stmt)
            start_pos = kw_match.end() if kw_match else 0
            fields, derived, fixed_width, is_distinct = self._extract_fields(stmt, start_pos, table_name)
            stages.append({
                "fields": fields, "derived": derived,
                "fixed_width": fixed_width, "is_distinct": is_distinct,
                "raw": stmt,
            })

        # Resolve any `LOAD *` wildcard stage: against the stage beneath
        # it in the pipeline, or (for the innermost stage) against its
        # RESIDENT source table's already-known field list.
        for idx in range(len(stages) - 1, -1, -1):
            if stages[idx]["fields"] != ["*"]:
                continue
            if idx == len(stages) - 1:
                resident_here = self.RESIDENT_RE.search(stages[idx]["raw"])
                source_table = resident_here.group(1).strip() if resident_here else None
                stages[idx]["fields"] = self._resolve_wildcard_fields(
                    source_table, table_field_map, metadata, table_name
                )
            else:
                stages[idx]["fields"] = list(stages[idx + 1]["fields"])

        outermost, innermost = stages[0], stages[-1]
        src_stmt = innermost["raw"]

        from_match = self.FROM_FILE_BRACKET_RE.search(src_stmt) or self.FROM_FILE_PLAIN_RE.search(src_stmt)
        if from_match:
            self._register_source(src_stmt, table_name, from_match.group(1).strip(), metadata)
        resident_match = self.RESIDENT_RE.search(src_stmt)
        if resident_match:
            inner_clauses = self._extract_load_clauses(src_stmt)
            metadata.resident_loads.append({
                "new_table": table_name,
                "source_table": resident_match.group(1).strip(),
                "where": inner_clauses["where"],
                "group_by": inner_clauses["group_by"],
                "order_by": inner_clauses["order_by"],
                "is_distinct": innermost["is_distinct"],
            })
        if not from_match and not resident_match:
            metadata.warnings.append(
                f"Preceding-load chain for table '{table_name}' has no "
                f"FROM/RESIDENT source in its innermost LOAD; the migration "
                f"engine cannot point it at real data automatically."
            )

        metadata.tables.append({
            "name": table_name,
            "fields": outermost["fields"],
            "is_mapping": is_mapping,
            "is_distinct": outermost["is_distinct"],
        })
        table_field_map.setdefault(table_name, [])
        table_field_map[table_name].extend(outermost["fields"])
        for f in outermost["fields"]:
            if f not in metadata.fields:
                metadata.fields.append(f)

        # innermost-first order, so a later (outer) alias of the same name
        # correctly overrides an earlier (inner) one in flat per-table
        # alias-map consumers that don't distinguish stages.
        ordered_stages = list(reversed(stages))
        for stage in ordered_stages:
            metadata.derived_fields.extend(
                {"table": table_name, "expression": d["expression"], "alias": d["alias"]}
                for d in stage["derived"]
            )

        metadata.preceding_loads.append({
            "table": table_name,
            "load_count": len(stages),
            "stages": [
                {"fields": s["fields"], "derived": s["derived"]}
                for s in ordered_stages
            ],
        })

    def _resolve_wildcard_fields(
        self,
        resident_source: "str | None",
        table_field_map: Dict[str, List[str]],
        metadata: ScriptMetadata,
        table_name: str,
    ) -> List[str]:
        """`LOAD *` copies every field from the RESIDENT source table."""
        if resident_source and resident_source in table_field_map:
            return list(table_field_map[resident_source])
        metadata.warnings.append(
            f"Table '{table_name}' uses LOAD * but its source fields could "
            f"not be resolved automatically; downstream columns will be "
            f"incomplete."
        )
        return []

    def _parse_statement(
        self,
        stmt: str,
        metadata: ScriptMetadata,
        table_field_map: Dict[str, List[str]]
    ) -> None:
        header_match = self.TABLE_HEADER_RE.search(stmt)
        table_name = header_match.group(1).strip() if header_match else None
        is_mapping = bool(header_match.group(2)) if header_match else False

        if is_mapping and table_name:
            metadata.mapping_tables.append({
                "name": table_name,
                "statement_preview": stmt[:200]
            })

        # Joins / Keeps. Qlik always joins/keeps on every field the two
        # tables have in common (there's no explicit ON clause like SQL),
        # so the M generator needs this statement's own field list (to
        # know exactly which *new* columns a JOIN contributes) and its
        # RESIDENT source (what's being merged in) captured together in
        # one place, rather than trying to correlate separately-recorded
        # facts after the fact.
        join_match = self.JOIN_RE.search(stmt)
        if join_match:
            modifier = join_match.group(1).upper() if join_match.group(1) else None
            kind = join_match.group(2).upper()
            target_table = join_match.group(3)
            if not target_table and metadata.tables:
                # Bare `JOIN`/`KEEP` with no explicit "(TableName)" means
                # "the most recently defined table" per Qlik semantics.
                target_table = metadata.tables[-1]["name"]
            join_resident_match = self.RESIDENT_RE.search(stmt)
            source_table = join_resident_match.group(1).strip() if join_resident_match else None
            join_fields: List[str] = []
            load_kw_match = self.LOAD_KEYWORD_RE.search(stmt)
            if load_kw_match:
                raw_join_fields, _, _, _ = self._extract_fields(
                    stmt, load_kw_match.end(), target_table or f"{kind} target"
                )
                if raw_join_fields == ["*"] and source_table:
                    raw_join_fields = self._resolve_wildcard_fields(
                        source_table, table_field_map, metadata, target_table or f"{kind} target"
                    )
                join_fields = [f for f in raw_join_fields if f != "*"]
            metadata.joins.append({
                "kind": kind,                    # "JOIN" or "KEEP"
                "modifier": modifier,             # "LEFT"/"RIGHT"/"INNER"/"OUTER"/None
                "target_table": target_table,     # the table being joined/kept into
                "source_table": source_table,     # what's being merged in/matched against
                "fields": join_fields,            # this join statement's own field list
            })

        # Concatenations
        for cm in self.CONCAT_RE.finditer(stmt):
            metadata.concatenations.append({
                "target_table": cm.group(1),
                "in_table": table_name
            })

        # Resident loads -- also capture WHERE/DISTINCT/GROUP BY/ORDER BY,
        # which only ever apply to a LOAD that has some source (RESIDENT
        # here; a FROM-sourced LOAD can carry them too, handled below).
        clauses = self._extract_load_clauses(stmt)
        for rm in self.RESIDENT_RE.finditer(stmt):
            metadata.resident_loads.append({
                "new_table": table_name,
                "source_table": rm.group(1).strip(),
                "where": clauses["where"],
                "group_by": clauses["group_by"],
                "order_by": clauses["order_by"],
            })

        # Preceding (nested) load detection: more than one LOAD keyword
        # in a single statement implies a preceding load chain.
        load_positions = [m.start() for m in self.LOAD_KEYWORD_RE.finditer(stmt)]
        if len(load_positions) > 1 and table_name:
            metadata.preceding_loads.append({
                "table": table_name,
                "load_count": len(load_positions)
            })

        # SQL sources
        if (self.SQL_SELECT_RE.search(stmt) or self.CONNECT_RE.search(stmt)) and table_name:
            metadata.sql_sources.append({
                "table": table_name,
                "statement_preview": stmt[:200]
            })

        # FROM clause -> classify source type
        from_match = self.FROM_FILE_BRACKET_RE.search(stmt) or self.FROM_FILE_PLAIN_RE.search(stmt)
        if from_match and table_name:
            self._register_source(stmt, table_name, from_match.group(1).strip(), metadata)

        # Register table + its fields
        if table_name and header_match:
            fields, derived, fixed_width, is_distinct = self._extract_fields(
                stmt, header_match.end(), table_name
            )

            inline_match = self.INLINE_RE.search(stmt)
            if inline_match:
                inline_data = self._extract_inline_table(stmt, table_name, fields)
                metadata.inline_tables.append(inline_data)
                fields = inline_data["fields"]
                metadata.lineage.append({
                    "table": table_name, "source": "INLINE", "source_type": "INLINE"
                })
            elif fields == ["*"]:
                resident_here = self.RESIDENT_RE.search(stmt)
                source_table = resident_here.group(1).strip() if resident_here else None
                fields = self._resolve_wildcard_fields(source_table, table_field_map, metadata, table_name)

            metadata.tables.append({
                "name": table_name,
                "fields": fields,
                "is_mapping": is_mapping,
                "is_distinct": is_distinct,
            })
            table_field_map.setdefault(table_name, [])
            table_field_map[table_name].extend(fields)
            for f in fields:
                if f not in metadata.fields:
                    metadata.fields.append(f)
            metadata.derived_fields.extend(derived)
            if fixed_width:
                # _register_source already appended a {"table","path"}
                # entry for this table above (from the "fix" format
                # spec) -- attach the field specs to that same entry
                # rather than creating a duplicate.
                target = next(
                    (e for e in reversed(metadata.fixed_width_sources) if e.get("table") == table_name),
                    None,
                )
                if target is not None:
                    target["fields"] = fixed_width
                else:
                    metadata.fixed_width_sources.append({
                        "table": table_name,
                        "path": from_match.group(1).strip() if from_match else "",
                        "fields": fixed_width,
                    })
            # Every resident_loads entry created above for this table
            # (there's normally exactly one) also needs is_distinct.
            for rl in metadata.resident_loads:
                if rl["new_table"] == table_name and "is_distinct" not in rl:
                    rl["is_distinct"] = is_distinct

        if not header_match and self.LOAD_KEYWORD_RE.search(stmt) and not self.RESIDENT_RE.search(stmt):
            # A LOAD statement we could not attribute to a named table.
            metadata.warnings.append(
                f"Could not determine table name for statement: {stmt[:80]}..."
            )

    def _register_source(self, stmt: str, table_name: str, source_path: str, metadata: ScriptMetadata) -> None:
        lower_path = source_path.lower()
        fmt_match = self.FORMAT_SPEC_RE.search(stmt)
        fmt_spec_raw = fmt_match.group(1) if fmt_match else ""
        fmt_spec = fmt_spec_raw.lower()
        # The format spec's first token (txt/qvd/ooxml/biff/fix/xmlsimple/...)
        # is the authoritative file-type indicator when present -- checked
        # before falling back to guessing from the file extension, since an
        # extension like a fixed-width file literally named "*.txt" would
        # otherwise be misclassified as a plain delimited CSV/TXT source.
        first_token = fmt_spec.split(",")[0].strip() if fmt_spec else ""

        source_entry = {"table": table_name, "path": source_path}
        source_type = "UNKNOWN"

        if first_token == "fix":
            metadata.fixed_width_sources.append(source_entry)
            source_type = "FIXEDWIDTH"
        elif lower_path.endswith(".qvd") or first_token == "qvd":
            metadata.qvd_sources.append(source_entry)
            source_type = "QVD"
        elif first_token == "xmlsimple" or lower_path.endswith(".xml"):
            node_match = self.TABLE_IS_RE.search(fmt_spec_raw)
            if node_match:
                source_entry["node_path"] = node_match.group(1).strip()
            else:
                metadata.warnings.append(
                    f"No 'Table is <NodePath>' clause found for XML table "
                    f"'{table_name}'; the migration engine cannot tell which "
                    f"repeating XML node to flatten into rows."
                )
            metadata.xml_sources.append(source_entry)
            source_type = "XML"
        elif lower_path.endswith(".xlsx") or lower_path.endswith(".xls") or first_token in ("ooxml", "biff"):
            sheet_match = self.TABLE_IS_RE.search(fmt_spec_raw)
            if sheet_match:
                source_entry["sheet_name"] = sheet_match.group(1).strip()
            else:
                metadata.warnings.append(
                    f"No 'table is <SheetName>' clause found for Excel table "
                    f"'{table_name}'; falling back to the Qlik table name as "
                    f"the worksheet name, which may not match the actual "
                    f"sheet in {source_path}."
                )
            metadata.excel_sources.append(source_entry)
            source_type = "EXCEL"
        elif lower_path.endswith(".csv") or lower_path.endswith(".txt") or first_token == "txt":
            metadata.csv_sources.append(source_entry)
            source_type = "CSV/TXT"
        else:
            metadata.warnings.append(
                f"Unclassified source type for table '{table_name}': {source_path}"
            )

        metadata.lineage.append({
            "table": table_name,
            "source": source_path,
            "source_type": source_type
        })

    def _extract_fields(
        self, stmt: str, start_pos: int, table_name: str
    ) -> Tuple[List[str], List[Dict[str, str]], List[Dict[str, Any]], bool]:
        """
        Pulls the field list out of a LOAD/SELECT block, i.e. everything
        between the LOAD/SELECT keyword and the following FROM/RESIDENT/
        INLINE keyword, splitting on top-level commas (ignoring commas
        nested inside brackets or parentheses, e.g. inside expressions).

        Returns (fields, derived_expr_fields, fixed_width_fields, is_distinct).
        A bare `LOAD *` wildcard is returned as fields == ["*"] -- the
        caller resolves it against the referenced RESIDENT table's own
        field list, since this method has no knowledge of other tables.
        """
        remainder = stmt[start_pos:]

        is_distinct = bool(self.DISTINCT_LOAD_RE.match(remainder))
        if is_distinct:
            remainder = self.DISTINCT_LOAD_RE.sub("", remainder, count=1)

        cut_match = re.search(r"\b(FROM|RESIDENT|INLINE|AUTOGENERATE)\b", remainder, re.IGNORECASE)
        field_block = remainder[:cut_match.start()] if cut_match else remainder

        if field_block.strip() == "*":
            return ["*"], [], [], is_distinct

        parts = self._split_top_level(field_block, ",")
        fields: List[str] = []
        derived: List[Dict[str, str]] = []
        fixed_width: List[Dict[str, Any]] = []

        for part in parts:
            part = part.strip().rstrip(",").strip()
            if not part:
                continue
            fixed_match = self.FIXED_WIDTH_FIELD_RE.match(part)
            if fixed_match:
                start_char, end_char, alias = fixed_match.groups()
                clean_alias = alias.strip().strip("[]")
                fields.append(clean_alias)
                fixed_width.append({
                    "alias": clean_alias,
                    "start": int(start_char),
                    "end": int(end_char),
                })
                continue
            alias_match = self.AS_ALIAS_RE.match(part)
            if alias_match:
                expr, alias = alias_match.groups()
                clean_alias = alias.strip().strip("[]")
                fields.append(clean_alias)
                derived.append({"table": table_name, "expression": expr.strip(), "alias": clean_alias})
            else:
                fields.append(part.strip("[]"))
        return fields, derived, fixed_width, is_distinct

    def _extract_load_clauses(self, stmt: str) -> Dict[str, Any]:
        """
        Pulls WHERE / GROUP BY / ORDER BY off the tail of a LOAD
        statement (they always follow the FROM/RESIDENT source clause).
        Generic over any field/table names or condition text.
        """
        clauses: Dict[str, Any] = {"where": None, "group_by": [], "order_by": []}

        where_match = self.WHERE_CLAUSE_RE.search(stmt)
        if where_match:
            clauses["where"] = where_match.group(1).strip()

        group_match = self.GROUP_BY_CLAUSE_RE.search(stmt)
        if group_match:
            clauses["group_by"] = [
                f.strip().strip("[]")
                for f in self._split_top_level(group_match.group(1), ",")
                if f.strip()
            ]

        order_match = self.ORDER_BY_CLAUSE_RE.search(stmt)
        if order_match:
            order_items = []
            for part in self._split_top_level(order_match.group(1), ","):
                part = part.strip()
                if not part:
                    continue
                direction = "ASC"
                if re.search(r"\bDESC\b", part, re.IGNORECASE):
                    direction = "DESC"
                field_name = re.sub(r"\b(ASC|DESC)\b", "", part, flags=re.IGNORECASE).strip().strip("[]")
                order_items.append({"field": field_name, "direction": direction})
            clauses["order_by"] = order_items

        return clauses

    def _extract_inline_table(self, stmt: str, table_name: str, declared_fields: List[str]) -> Dict[str, Any]:
        """
        Parses a QlikView INLINE LOAD's embedded data block into a real
        header + rows structure so the M generator can build an actual
        `#table(...)` with the literal data, instead of losing it.
        `LOAD * INLINE [...]` uses the inline block's own header row for
        field names; `LOAD field1, field2 INLINE [...]` keeps the
        explicitly declared field list.
        """
        inline_match = self.INLINE_RE.search(stmt)
        if not inline_match:
            return {}

        raw_lines = [ln.strip() for ln in inline_match.group(1).splitlines()]
        raw_lines = [ln for ln in raw_lines if ln]
        if not raw_lines:
            return {"table": table_name, "fields": declared_fields, "rows": []}

        def _split_row(line: str) -> List[str]:
            return [cell.strip() for cell in self._split_top_level(line, ",")]

        if declared_fields == ["*"] or not declared_fields:
            header = _split_row(raw_lines[0])
            data_lines = raw_lines[1:]
        else:
            header = declared_fields
            data_lines = raw_lines

        rows = [_split_row(line) for line in data_lines]
        return {"table": table_name, "fields": header, "rows": rows}

    @staticmethod
    def _split_top_level(text: str, sep: str) -> List[str]:
        """Splits `text` on `sep`, ignoring occurrences nested inside () or []."""
        parts = []
        depth = 0
        current = ""
        for ch in text:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth = max(0, depth - 1)
            if ch == sep and depth == 0:
                parts.append(current)
                current = ""
            else:
                current += ch
        if current.strip():
            parts.append(current)
        return parts

    # ---------------- DROP TABLE handling ----------------
    def _drop_tables(
        self, names_blob: str, table_field_map: Dict[str, List[str]], metadata: ScriptMetadata
    ) -> None:
        """
        Removes each dropped table name from `table_field_map` and from
        `metadata.tables`, so a later reload of the same name starts with
        a clean field list instead of inheriting fields from the
        now-gone table. See the comment at the DROP TABLE call site in
        `parse()` for why this matters.
        """
        for raw_name in self._split_top_level(names_blob, ","):
            name = raw_name.strip().rstrip(";").strip().strip("[]").strip()
            if not name:
                continue
            table_field_map.pop(name, None)
            metadata.tables[:] = [t for t in metadata.tables if t.get("name") != name]

    # ---------------- Keys / synthetic keys ----------------
    def _derive_keys(self, table_field_map: Dict[str, List[str]], metadata: ScriptMetadata) -> None:
        field_to_tables: Dict[str, List[str]] = {}
        for table, fields in table_field_map.items():
            for f in set(fields):
                field_to_tables.setdefault(f, []).append(table)

        for field_name, tables in field_to_tables.items():
            if len(tables) > 1 and field_name not in metadata.keys:
                metadata.keys.append(field_name)
            if len(tables) > 2:
                # 3+ tables sharing one field is a "hub" pattern: a naive
                # relationship-inference step that relates every pair of
                # tables sharing this field will build a fully-connected
                # graph, which Power BI rejects on load as "ambiguous
                # paths" (it only allows one active filter path between
                # any two tables, unlike QlikView's associative model).
                # The correct model is a star -- one dimension/hub table
                # related to each of the others -- not a mesh. Flagging it
                # here so anyone consuming this JSON (human or generator)
                # knows not to blindly wire up every pair.
                metadata.warnings.append(
                    f"Field '{field_name}' is shared by {len(tables)} tables "
                    f"({', '.join(sorted(tables))}) - this is a hub/star-schema "
                    f"key, not a simple 1:1 relationship. Relate each table to a "
                    f"single hub table (or a dedicated dimension table) rather "
                    f"than creating a direct relationship between every pair, "
                    f"or Power BI will reject the model with an 'ambiguous "
                    f"paths' error."
                )

        # Synthetic-key heuristic: two tables sharing 2+ fields will
        # trigger a synthetic key/table in QlikView's data model.
        table_names = list(table_field_map.keys())
        for i in range(len(table_names)):
            for j in range(i + 1, len(table_names)):
                t1, t2 = table_names[i], table_names[j]
                common = set(table_field_map[t1]) & set(table_field_map[t2])
                if len(common) >= 2:
                    metadata.synthetic_keys.append({
                        "tables": [t1, t2],
                        "common_fields": sorted(common)
                    })
                    metadata.warnings.append(
                        f"Potential synthetic key risk between '{t1}' and '{t2}' "
                        f"(shared fields: {', '.join(sorted(common))})."
                    )