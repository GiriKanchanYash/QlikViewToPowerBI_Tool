"""
controllers/extraction_controller.py
--------------------------------------
Orchestrates the end-to-end flow. Extraction is PRJ-only:

    find "<name>-PRJ" folder -> PRJMetadataService -> write outputs

If no PRJ folder exists next to a .qvw, extraction fails fast with a
clear message telling the user to enable QlikView's "Generate Project
Folder" setting and re-save. There is no QlikView Desktop/COM fallback
in this build.

This is the "controller" that wires Model, Views/Templates, and Services
together; it contains no parsing/XML logic of its own - that all lives
in `qlik_metadata_extractor.prj`.
"""
import logging
from pathlib import Path
from typing import List, Tuple

from qlik_metadata_extractor.config import Config
from qlik_metadata_extractor.views.file_writer_view import FileWriterView
from qlik_metadata_extractor.prj import PRJMetadataService, PRJNotFoundError

logger = logging.getLogger(__name__)


class ExtractionController:

    def __init__(self, config: Config = Config, prefer_prj: bool = True):
        """
        prefer_prj: try the PRJ folder for every input (default True).
                    This is currently the only supported extraction path;
                    the flag is kept so callers can still express intent
                    explicitly, but setting it False will simply cause
                    every input to raise PRJNotFoundError.
        """
        self.config = config
        self.config.ensure_dirs()
        self.prefer_prj = prefer_prj
        self.writer = FileWriterView(
            txt_output_dir=self.config.TXT_OUTPUT_DIR,
            json_output_dir=self.config.JSON_OUTPUT_DIR,
            visual_metadata_output_dir=getattr(self.config, "VISUAL_METADATA_OUTPUT_DIR", None),
        )
        self.prj_service = PRJMetadataService(template_path=self.config.TEMPLATE_PATH)

    @staticmethod
    def _collect_input_files(input_path: str | Path) -> List[Path]:
        """
        Resolves `input_path` into a list of "qvw paths" to process.
        These don't need to actually exist as files on disk anymore -
        PRJ-only extraction never opens the .qvw itself, it only needs
        the sibling "<name>-PRJ" folder. A .qvw path here is really just
        a naming handle: it tells us what to call the output files and
        where to look for "<name>-PRJ" next to it.

        Accepts, in any combination:
          - a real .qvw file
          - a "<name>-PRJ" folder directly
          - a folder containing any mix of .qvw files and/or
            "<name>-PRJ" folders (searched recursively)
        """
        path = Path(input_path).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Input path not found: {path}")

        if path.is_dir() and path.name.lower().endswith("-prj"):
            return [path.with_name(f"{path.name[:-len('-PRJ')]}.qvw")]

        if path.is_file():
            if path.suffix.lower() != ".qvw":
                raise FileNotFoundError(f"Only .qvw files are supported: {path}")
            return [path]

        if path.is_dir():
            qvw_files = list(path.rglob("*.qvw"))
            known_stems = {f.stem for f in qvw_files}

            # Every "<name>-PRJ" folder without a sibling .qvw becomes a
            # virtual input in its own right, named after the folder.
            # Matched case-insensitively since QlikView/Windows folder
            # names aren't guaranteed to use "-PRJ" verbatim.
            for entry in path.rglob("*"):
                if not entry.is_dir() or not entry.name.lower().endswith("-prj"):
                    continue
                base_name = entry.name[:-len("-PRJ")]
                if base_name in known_stems:
                    continue
                qvw_files.append(entry.with_name(f"{base_name}.qvw"))
                known_stems.add(base_name)

            if not qvw_files:
                raise FileNotFoundError(
                    f"No .qvw files or '-PRJ' project folders found in: {path}"
                )
            return sorted(qvw_files)

        raise FileNotFoundError(f"Unsupported input path: {path}")

    def run(self, input_path: str | Path) -> List[Tuple[Path, Path]]:
        """
        Runs the full extraction pipeline for a single .qvw file or all
        .qvw files inside a folder.
        Returns a list of (txt_output_path, json_output_path) tuples.
        """
        input_files = self._collect_input_files(input_path)
        results: List[Tuple[Path, Path]] = []

        for qvw_path in input_files:
            logger.info(f"Starting extraction for: {qvw_path}")
            txt_path, json_path = self._extract_one(qvw_path)
            logger.info("Extraction completed successfully.")
            logger.info(f"  - Script (.txt): {txt_path}")
            logger.info(f"  - Metadata (.json): {json_path}")
            results.append((txt_path, json_path))

        return results

    # ------------------------------------------------------------------
    def _extract_one(self, qvw_path: Path) -> Tuple[Path, Path]:
        prj_dir = self.prj_service.find_prj_dir(qvw_path) if self.prefer_prj else None

        if prj_dir is None:
            raise PRJNotFoundError(
                f"No '-PRJ' folder found for '{qvw_path.name}'. Enable "
                f"Settings -> User Preferences -> Design -> "
                f"'Generate Project Folder' in QlikView, re-save the "
                f"document, and re-run."
            )

        logger.info(f"Found PRJ project folder ({prj_dir.name}); using PRJ extraction.")
        return self._extract_from_prj(qvw_path, prj_dir)

    def _extract_from_prj(self, qvw_path: Path, prj_dir: Path) -> Tuple[Path, Path]:
        metadata = self.prj_service.extract(qvw_path, prj_dir=prj_dir)

        # Keep writing the .txt sidecar for backward compatibility with
        # anything downstream that expects one, sourced from the PRJ's
        # own LoadScript.txt.
        load_script_file = prj_dir / "LoadScript.txt"
        raw_script = load_script_file.read_text(encoding="utf-8-sig", errors="replace") \
            if load_script_file.exists() else ""
        txt_path = self.writer.write_script_txt(qvw_path, raw_script)
        json_path = self.writer.write_metadata_json(qvw_path, metadata)
        self.writer.write_visual_metadata(qvw_path, metadata)
        return txt_path, json_path
