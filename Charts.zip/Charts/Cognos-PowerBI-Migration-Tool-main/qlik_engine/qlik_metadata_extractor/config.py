"""
config.py
---------
Central configuration for the Qlik Metadata Extractor tool.
Keeps all paths and tunable settings in one place instead of
scattering hard-coded strings across modules.
"""
from pathlib import Path


class Config:
    # Base project directory (workspace root)
    BASE_DIR = Path(__file__).resolve().parent.parent

    # Input and output locations
    INPUT_DIR = BASE_DIR / "Qlik_input_files"
    SCRIPT_OUTPUT_DIR = BASE_DIR / "Qlik_scripts"
    METADATA_OUTPUT_DIR = BASE_DIR / "Qlik_Script_MetaData"
    VISUAL_METADATA_OUTPUT_DIR = BASE_DIR / "Qlik_Visual_MetaData"

    # Backward-compatible aliases for existing code
    TXT_OUTPUT_DIR = SCRIPT_OUTPUT_DIR
    JSON_OUTPUT_DIR = METADATA_OUTPUT_DIR

    # Template used as the canonical metadata schema
    TEMPLATE_PATH = BASE_DIR / "qlik_metadata_extractor" / "templates" / "metadata_template.json"

    @classmethod
    def ensure_dirs(cls) -> None:
        cls.SCRIPT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        cls.METADATA_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        cls.VISUAL_METADATA_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (cls.VISUAL_METADATA_OUTPUT_DIR / "csv").mkdir(parents=True, exist_ok=True)
