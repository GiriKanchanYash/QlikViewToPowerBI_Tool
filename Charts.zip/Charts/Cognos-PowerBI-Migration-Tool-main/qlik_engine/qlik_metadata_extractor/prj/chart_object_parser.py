"""
prj/chart_object_parser.py
-----------------------------
Parsers for individual sheet-object PRJ files: charts (CH*.xml),
text boxes (TX*.xml), buttons (MB*.xml), list boxes (LB*.xml), and
current-selection boxes (CS*.xml).

`SheetObjectParser` extracts everything that is common to *every*
sheet object (id, type, caption, position, formatting, conditions,
actions, hyperlinks, print/export settings). `ChartParser` extends it
with the chart-specific structure the migration brief calls out:
dimensions, measures/expressions, set analysis, sorting, ranking
(Top/Bottom N), legend, axis settings, trend/reference lines,
conditional and colour formatting, and tooltip expressions.

Every lookup is dynamic (tag-name based, not a fixed XPath) so that
version differences in QlikView's chart XML degrade to an empty field
rather than an exception. Anything not explicitly modelled is still
captured in `raw`, satisfying "everything available inside the XML"
without hardcoding every possible node up front.
"""
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from .base_prj_parser import BasePRJParser
from .xml_utils import (
    find_first, find_all, direct_children, find_text, text_of, attrs_of,
    coerce_number, local_tag,
)

logger = logging.getLogger(__name__)

# Contains a colon-terminated 'field={...}' set-analysis pattern.
_SET_ANALYSIS_MARKER = "{"


class SheetObjectParser(BasePRJParser):
    """Fields common to every sheet object, regardless of object type."""

    #: overridden by subclasses ("chart", "textbox", "button", ...)
    object_type_label = "object"

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        return {
            "object_id": self.get_object_id(root),
            "object_type": self._resolve_subtype(root),
            "category": self.object_type_label,
            "caption": self.get_caption(root),
            "text_content": self.get_expression_text(find_first(root, "Text")),
            "color_expr": self._color_expr(root),
            "description": find_text(root, "Comment", "Description", "Tooltip"),
            "position": self.get_position(root),
            "number_format": self.get_number_format(root),
            "show_condition": self.get_show_condition(root),
            "calc_condition": self.get_calc_condition(root),
            "alternate_state": find_text(root, "AlternateState", "StateName"),
            "background": self._background(root),
            "borders": self._borders(root),
            "fonts": self._fonts(root),
            "data_labels": self._data_labels(root),
            "actions": self._actions(root),
            "hyperlinks": self._hyperlinks(root),
            "export_settings": self._export_settings(root),
            "print_settings": self._print_settings(root),
            "comments": find_text(root, "Comment", "Comments"),
        }

    @staticmethod
    def _color_expr(root: ET.Element) -> str:
        """
        The ColorExpr that actually drives an object's displayed
        text/value color lives under a <TextColor> container -
        QlikView's standard name for that property - alongside a
        dozen other <ColorExpr> placeholders on background/border/
        selection colors that are almost always empty. Taking the
        first ColorExpr in document order (as a naive recursive search
        would) reliably grabs one of those empty ones instead, so this
        looks inside <TextColor> first and only falls back to
        scanning every ColorExpr in the object for one that actually
        has content.
        """
        text_color = find_first(root, "TextColor")
        if text_color is not None:
            expr = BasePRJParser.get_expression_text(find_first(text_color, "ColorExpr"))
            if expr:
                return expr
        for node in find_all(root, "ColorExpr"):
            expr = BasePRJParser.get_expression_text(node)
            if expr:
                return expr
        return ""

    # ------------------------------------------------------------------
    @staticmethod
    def _resolve_subtype(root: ET.Element) -> str:
        for tag in ("SubType", "ObjectType", "ChartType", "Type"):
            for node in direct_children(root, tag):
                if text_of(node):
                    return text_of(node)
        # Fall back to the root tag itself, e.g. <Chart> -> "Chart".
        return local_tag(root)

    @staticmethod
    def _background(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "BackgroundColor", "Background")
        if node is None:
            return {}
        return {"color": text_of(find_first(node, "Color")) or text_of(node)}

    @staticmethod
    def _borders(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "Border", "Borders")
        if node is None:
            return {}
        return {local_tag(c): text_of(c) for c in node if text_of(c)}

    @staticmethod
    def _fonts(root: ET.Element) -> List[Dict[str, Any]]:
        fonts = []
        for node in find_all(root, "Font"):
            font = {k: v for k, v in attrs_of(node).items()}
            for tag in ("Name", "Size", "Bold", "Italic", "Underline"):
                v = find_text(node, tag)
                if v:
                    font[tag.lower()] = v
            if font:
                fonts.append(font)
        return fonts

    @classmethod
    def _actions(cls, root: ET.Element) -> List[Dict[str, Any]]:
        actions = []
        for action_node in find_all(root, "Action"):
            actions.append({
                "trigger": find_text(action_node, "Event", "Trigger"),
                "type": find_text(action_node, "ActionType", "Command"),
                "definition": cls.get_expression_text(find_first(action_node, "Parameter", "Definition")),
            })
        return actions

    @staticmethod
    def _hyperlinks(root: ET.Element) -> List[Dict[str, str]]:
        links = []
        for node in find_all(root, "Hyperlink", "URL"):
            url = text_of(node) or find_text(node, "Address", "v")
            if url:
                links.append({"url": url})
        return links

    @staticmethod
    def _export_settings(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "ExportSettings", "Export")
        if node is None:
            return {}
        return {local_tag(c): text_of(c) for c in node if text_of(c)}

    @staticmethod
    def _print_settings(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "PrintSettings", "Print")
        if node is None:
            return {}
        return {local_tag(c): text_of(c) for c in node if text_of(c)}

    @staticmethod
    def _data_labels(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "DataLabels", "ValueLabels", "ShowLabels")
        if node is None:
            return {}
        return {
            "visible": SheetObjectParser.get_bool(node, "Show", "Visible", default=True),
            "position": find_text(node, "Position", "LabelPosition"),
        }


class ChartParser(SheetObjectParser):
    """CH*.xml -> full chart metadata."""

    object_type_label = "chart"

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        base = super().parse_element(root)
        base.update({
            "chart_type": find_text(root, "ChartType", "SubType", "GraphMode") or base["object_type"],
            "dimensions": self._dimensions(root),
            "measures": self._measures(root),
            "referenced_fields": self._referenced_fields(root),
            "referenced_variables": self._referenced_variables(root),
            "set_analysis": self._set_analysis_expressions(root),
            "current_selections": self._current_selections(root),
            "sort_expressions": self._sort_expressions(root),
            "ranking": self._ranking(root),
            "legend": self._legend(root),
            "axis_settings": self._axis_settings(root),
            "reference_lines": self._simple_list(root, "ReferenceLine"),
            "trend_lines": self._simple_list(root, "TrendLine"),
            "conditional_formatting": self._conditional_formatting(root),
            "tooltip_expressions": self._expr_list(root, "ToolTip", "Tooltip"),
            "color_expressions": self._expr_list(root, "ColorExpression", "ColorFormula"),
            "raw": self.collect_raw(root, max_depth=8),
        })
        return base

    # ------------------------------------------------------------------
    @classmethod
    def _dimensions(cls, root: ET.Element) -> List[Dict[str, Any]]:
        dims = []
        for dim_node in find_all(root, "Dimension", "DimInfo", "ChartDimensionDataDef"):
            # Real QlikView exports name the field (or group) inside a
            # nested PseudoDef/<n|Name> container; the flat Field/
            # FieldName tags only appear in older/other export flavours.
            pseudo_node = find_first(dim_node, "PseudoDef")
            field_name = (
                (cls.get_caption(pseudo_node) if pseudo_node is not None else "")
                or find_text(dim_node, "Field", "FieldName")
                or cls.get_expression_text(find_first(dim_node, "Definition"))
            )
            if not field_name:
                continue
            dims.append({
                "field": field_name,
                "label": find_text(dim_node, "Label", "Title") or field_name,
                "number_format": cls.get_number_format(dim_node),
                "sort_criteria": cls._sort_criteria(dim_node),
                # Populated later by PRJMetadataService once document-wide
                # drill-down/cyclic groups are known; a chart's own XML
                # only names the field, not the group it belongs to.
                "group_ref": None,
                "dimension_limits": cls._dimension_limits(dim_node),
                "top_n": cls._rank_value(dim_node, "ShowTop", "TopN"),
                "bottom_n": cls._rank_value(dim_node, "ShowBottom", "BottomN"),
            })
        return dims

    @classmethod
    def _measures(cls, root: ET.Element) -> List[Dict[str, Any]]:
        # Real QlikView exports carry one MainExpressionData per
        # measure, nesting both the formula/sort/cycle-group data
        # (Data/ExpressionData) and the label/format/visibility data
        # (Data/ExpressionVisual) together - no fragile positional
        # zipping needed. Older/other export flavours (and this repo's
        # own test fixture) use a flatter <Expression> list instead.
        main_defs = find_all(root, "MainExpressionData")
        if main_defs:
            return [m for m in (cls._measure_from_main_def(d) for d in main_defs) if m]
        return [m for m in (cls._measure_from_flat_node(n) for n in find_all(root, "Expression", "MeasureInfo")) if m]

    @classmethod
    def _measure_from_main_def(cls, main_node: ET.Element) -> Optional[Dict[str, Any]]:
        data_node = find_first(main_node, "Data") or main_node
        expr_data = find_first(data_node, "ExpressionData")
        expr_visual = find_first(data_node, "ExpressionVisual")

        definition = cls.get_expression_text(find_first(expr_data, "Definition")) if expr_data is not None else ""
        if not definition:
            return None

        label = cls.get_expression_text(find_first(expr_visual, "Label")) if expr_visual is not None else ""
        invisible = cls.get_bool(expr_visual, "Invisible", default=False) if expr_visual is not None else False
        show_condition = cls.get_expression_text(find_first(expr_data, "Show")) if expr_data is not None else ""
        cycle_group_index = find_text(expr_data, "CycleGroup") if expr_data is not None else ""
        enable_condition = find_first(data_node, "EnableCondition")
        calc_condition = find_text(enable_condition, "Expression") if enable_condition is not None else ""

        return {
            "label": label,
            "expression": definition,
            "is_set_analysis": _SET_ANALYSIS_MARKER in definition,
            "visible": not invisible,
            "number_format": cls.get_number_format(expr_visual) if expr_visual is not None else {},
            "color": cls._measure_color(expr_visual) if expr_visual is not None else {},
            "sort_criteria": cls._sort_criteria(expr_data) if expr_data is not None else {},
            "show_condition": show_condition,
            "calc_condition": calc_condition,
            # -1 means "not part of a cyclic group"; any other value is
            # an index into the document-wide cyclic-group list rather
            # than a name, so it's surfaced as-is rather than resolved.
            "cycle_group_index": coerce_number(cycle_group_index) if cycle_group_index else None,
        }

    @classmethod
    def _measure_from_flat_node(cls, expr_node: ET.Element) -> Optional[Dict[str, Any]]:
        definition = cls.get_expression_text(find_first(expr_node, "Definition")) \
            or cls.get_expression_text(expr_node)
        if not definition:
            return None
        return {
            "label": find_text(expr_node, "Label") or "",
            "expression": definition,
            "is_set_analysis": _SET_ANALYSIS_MARKER in definition,
            "visible": cls.get_bool(expr_node, "Visible", default=True),
            "number_format": cls.get_number_format(expr_node),
            "color": cls._measure_color(expr_node),
            "sort_criteria": {},
            "show_condition": "",
            "calc_condition": "",
            "cycle_group_index": None,
        }

    @classmethod
    def _measure_color(cls, node: ET.Element) -> Dict[str, Any]:
        # Only a color node that's a *direct* child of the measure's own
        # visual def counts as "the measure's color" - a deep/recursive
        # search would also match unrelated nested colors (e.g. the
        # low/high value-cue colors under VisualCues).
        color_node = next(iter(direct_children(node, "Color", "BarColor")), None)
        if color_node is None:
            return {}
        hex_color = cls.get_rgb_color(color_node)
        return {"color": hex_color} if hex_color else {}

    @staticmethod
    def _referenced_fields(root: ET.Element) -> List[str]:
        fields = []
        for node in find_all(root, "Field", "FieldName"):
            value = text_of(node)
            if value and value not in fields:
                fields.append(value)
        return fields

    @staticmethod
    def _referenced_variables(root: ET.Element) -> List[str]:
        variables = []
        # Variables surface inside expressions as $(varname); a light,
        # dependency-free scan of every expression's text catches this
        # without needing a full QlikView expression grammar.
        var_re = re.compile(r"\$\(([A-Za-z0-9_.]+)\)")
        for node in find_all(root, "Definition", "v"):
            text = text_of(node)
            for match in var_re.finditer(text):
                name = match.group(1)
                if name not in variables:
                    variables.append(name)
        return variables

    @classmethod
    def _set_analysis_expressions(cls, root: ET.Element) -> List[str]:
        found = []
        for node in find_all(root, "Definition"):
            text = cls.get_expression_text(node)
            if _SET_ANALYSIS_MARKER in text and text not in found:
                found.append(text)
        return found

    @staticmethod
    def _current_selections(root: ET.Element) -> List[Dict[str, str]]:
        selections = []
        for node in find_all(root, "SelectInfo", "CurrentSelection"):
            field = find_text(node, "Field", "FieldName")
            value = find_text(node, "Value", "SelectedValues")
            if field:
                selections.append({"field": field, "value": value})
        return selections

    @classmethod
    def _sort_expressions(cls, root: ET.Element) -> List[str]:
        exprs = []
        for node in find_all(root, "SortByExpression", "SortCriteria"):
            text = cls.get_expression_text(node)
            if text and text not in exprs:
                exprs.append(text)
        return exprs

    @staticmethod
    def _ranking(root: ET.Element) -> Dict[str, Any]:
        return {
            "top_n": find_text(root, "TopN", "ShowTop"),
            "bottom_n": find_text(root, "BottomN", "ShowBottom"),
        }

    @staticmethod
    def _rank_value(node: ET.Element, *tag_candidates: str) -> str:
        return find_text(node, *tag_candidates)

    @staticmethod
    def _dimension_limits(node: ET.Element) -> Dict[str, str]:
        limits_node = find_first(node, "DimensionLimits", "OtherTotalMode")
        if limits_node is None:
            return {}
        return {local_tag(c): text_of(c) for c in limits_node if text_of(c)}

    @staticmethod
    def _sort_criteria(node: ET.Element) -> Dict[str, Any]:
        sort_node = find_first(node, "SortCriteria", "SortBy")
        if sort_node is None:
            return {}
        return {local_tag(c): text_of(c) for c in sort_node if text_of(c)}

    @staticmethod
    def _legend(root: ET.Element) -> Dict[str, Any]:
        node = find_first(root, "Legend")
        if node is None:
            return {}
        return {
            "visible": SheetObjectParser.get_bool(node, "Show", "Visible", default=True),
            "position": find_text(node, "Position"),
        }

    @staticmethod
    def _axis_settings(root: ET.Element) -> Dict[str, Any]:
        axes = {}
        for axis_tag in ("XAxis", "YAxis", "LeftAxis", "RightAxis", "AxisData"):
            node = find_first(root, axis_tag)
            if node is not None:
                axes[axis_tag] = {local_tag(c): text_of(c) for c in node if text_of(c)}
        return axes

    @classmethod
    def _simple_list(cls, root: ET.Element, tag: str) -> List[Dict[str, Any]]:
        items = []
        for node in find_all(root, tag):
            items.append({
                "expression": cls.get_expression_text(find_first(node, "Definition")) or text_of(node),
                "label": find_text(node, "Label"),
            })
        return items

    @classmethod
    def _expr_list(cls, root: ET.Element, *tag_candidates: str) -> List[str]:
        exprs = []
        for node in find_all(root, *tag_candidates):
            text = cls.get_expression_text(node)
            if text and text not in exprs:
                exprs.append(text)
        return exprs

    @staticmethod
    def _conditional_formatting(root: ET.Element) -> List[Dict[str, str]]:
        rules = []
        for node in find_all(root, "TextFormat", "ConditionalColoring"):
            rules.append({
                "condition": text_of(find_first(node, "Definition")) or text_of(node),
                "color": find_text(node, "Color"),
            })
        return rules


class ListBoxParser(SheetObjectParser):
    """LB*.xml -> list box / drop-down filter metadata.

    A list box's on-screen caption is a free-text display label (e.g.
    "Select Year") the report author can set independently of the
    field the box actually filters, and it lives in a different place
    (the Frame's title) than the real binding. The field a list box
    (or the drop-down single-line style of the same object type)
    actually filters is only recorded in its own <Def> block, so it's
    read from there explicitly rather than assumed to equal the
    caption - the assumption a generic caption-based fallback would be
    stuck making, and which breaks for any filter whose display label
    differs from its bound field name.
    """

    object_type_label = "listbox"

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        base = super().parse_element(root)
        base["field"] = self._bound_field(root)
        return base

    @staticmethod
    def _bound_field(root: ET.Element) -> str:
        def_node = find_first(root, "Def")
        if def_node is None:
            return ""
        # QlikView spells the field name inside <Def> as a short <n>
        # tag (the same convention get_caption() already accounts for
        # elsewhere in the schema); "Name"/"Field"/"FieldName" are
        # tried too in case another export flavour spells it out.
        return find_text(def_node, "n", "Name", "Field", "FieldName")


class MultiBoxParser(SheetObjectParser):
    """MB*.xml -> MultiBoxProperties: a filter box that stacks one or
    more field-bound list boxes into a single object (e.g. QlikView's
    "TEAM"/"STAGE" style compact filter widgets). Despite the name, it
    has nothing to do with a clickable button - each stacked field is
    recorded as its own <MultiBoxMemberAttributes> entry (with the
    field itself inside a nested <FieldDef>), independent of whatever
    display label the member was given, the same caption-vs-binding
    distinction ListBoxParser accounts for on a plain list box.
    """

    object_type_label = "multibox"

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        base = super().parse_element(root)
        fields = self._bound_fields(root)
        base["fields"] = fields
        base["field"] = fields[0] if fields else ""
        return base

    @staticmethod
    def _bound_fields(root: ET.Element) -> List[str]:
        fields: List[str] = []
        for member in find_all(root, "MultiBoxMemberAttributes"):
            field_def = find_first(member, "FieldDef")
            if field_def is None:
                continue
            field = find_text(field_def, "n", "Name", "Field", "FieldName")
            if field:
                fields.append(field)
        return fields


class StatisticsBoxParser(ChartParser):
    """StatisticsBoxProperties -> a field-level statistics summary box
    (one or more of Sum/Average/Min/Max/Count/... computed on a
    field, with no dimension to break it down by - QlikView's
    "Statistics box" object).

    Unlike a real chart, a Statistics box does NOT store its selected
    statistics as Expression/MainExpressionData measure text - real
    QlikView PRJ exports carry them as a <MemberMask> bit flag plus one
    <StatisticsBoxRow>/<Labels><String> pair per displayed row, with no
    expression string at all (confirmed against a real QlikView 12
    Statistics Box Properties export). ChartParser's `_measures()`
    therefore always returns empty here, which is why every Statistics
    box used to come back with "no statistics/expressions found".

    Only 6 of QlikView's ~15 statistic functions have a MemberMask bit
    position confirmed against real exported data (see
    `_STAT_BIT_FUNCTIONS`) - the QlikView 12 "Statistics Box
    Properties" dialog's default new-object set, and the only bits
    this repo has seen in an actual export: Numeric count(0), Total
    count(1), Sum(2), Average(3), Min(7), Max(10). Any other bit
    (Null/Text/Missing count, Std dev, Skewness, Kurtosis, Only value,
    Median, Fractile) is real but its exact bit position isn't
    confirmed, so it's surfaced as an unrecognised-statistic entry
    instead of guessed at.
    """

    object_type_label = "statistics"

    #: bit position -> QlikView statistic name, confirmed against a real
    #: exported Statistics Box (see class docstring). Ascending bit order
    #: matches both the box's own Rows/StatisticsBoxRow order and its
    #: Labels/String override order.
    _STAT_BIT_FUNCTIONS = {
        0: "Numeric count",
        1: "Total count",
        2: "Sum",
        3: "Average",
        7: "Min",
        10: "Max",
    }
    #: QlikView statistic name -> DAX aggregation function. "Total count"
    #: (count of every non-null value regardless of type) maps to COUNTA
    #: rather than COUNT so it stays distinct from "Numeric count" (which
    #: only counts values QlikView treats as numbers) instead of both
    #: silently collapsing onto the same number.
    _STAT_FUNCTION_DAX = {
        "Numeric count": "COUNT",
        "Total count": "COUNTA",
        "Sum": "SUM",
        "Average": "AVERAGE",
        "Min": "MIN",
        "Max": "MAX",
    }

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        base = super().parse_element(root)

        field_def = find_first(root, "FieldDef")
        field = find_text(field_def, "n", "Name", "Field", "FieldName") if field_def is not None else ""
        base["field"] = field

        # The box's own <Title><v>...</v></Title> is the display title a
        # person gave it (e.g. "AvgGoals") - distinct from the bound
        # field name above. The shared get_caption() helper searches for
        # several candidate tag names in plain document order and, for
        # this object type, reaches the FieldDef's own <Name> before it
        # reaches <Title> - so the caption it already set is corrected
        # here rather than widening that shared helper (used by every
        # other object type) for this one type's quirk.
        title_node = find_first(root, "Title")
        title = self.get_expression_text(title_node) if title_node is not None else ""
        if title:
            base["caption"] = title

        base["measures"] = self._statistics_functions(root, field)
        return base

    @classmethod
    def _statistics_functions(cls, root: ET.Element, field: str) -> List[Dict[str, Any]]:
        mask_text = find_text(root, "MemberMask")
        try:
            mask = int(mask_text) if mask_text else 0
        except ValueError:
            mask = 0

        label_overrides: List[str] = []
        labels_node = find_first(root, "Labels")
        if labels_node is not None:
            label_overrides = [text_of(s) for s in find_all(labels_node, "String")]

        displayed_bits = sorted(bit for bit in cls._STAT_BIT_FUNCTIONS if mask & (1 << bit))
        measures: List[Dict[str, Any]] = []
        for i, bit in enumerate(displayed_bits):
            function = cls._STAT_BIT_FUNCTIONS[bit]
            override = label_overrides[i] if i < len(label_overrides) else ""
            measures.append({
                "field": field,
                "function": function,
                "dax_func": cls._STAT_FUNCTION_DAX.get(function),
                "label": override or function,
                "expression": f"{function}({field})",
                "bit": bit,
            })

        # Any set bit outside the confirmed table is a real QlikView
        # statistic (Null/Text/Missing count, Std dev, Skewness,
        # Kurtosis, Only value, Median, Fractile) this parser can't yet
        # name with confidence - flagged as its own entry (function=None)
        # so report_visual_generator can note it by name instead of the
        # box silently ending up with fewer rows than it really has.
        unknown_bits = [
            bit for bit in range(0, max(mask.bit_length(), 1))
            if (mask & (1 << bit)) and bit not in cls._STAT_BIT_FUNCTIONS
        ]
        if unknown_bits:
            measures.append({
                "field": field,
                "function": None,
                "dax_func": None,
                "label": f"Unrecognised statistic (MemberMask bit {', '.join(map(str, unknown_bits))})",
                "expression": "",
                "bit": None,
            })
        return measures


class GenericObjectParser(SheetObjectParser):
    """
    Fallback for object types that don't need a specialised subclass
    (text boxes, buttons, current-selection boxes, sliders).
    Still returns every common field plus a full raw dump so nothing
    is lost even without type-specific extraction.
    """

    def __init__(self, object_type_label: str = "object"):
        self.object_type_label = object_type_label

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        base = super().parse_element(root)
        base["raw"] = self.collect_raw(root, max_depth=6)
        return base
