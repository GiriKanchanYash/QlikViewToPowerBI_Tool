"""
prj/load_script_parser.py
----------------------------
Reads LoadScript.txt directly from the PRJ folder - no COM, no
QlikView Desktop - and hands it to the *existing*
ScriptParserService unchanged, so every table/join/QVD/variable rule
already tested there keeps working exactly as before. This is the
one deliberate exception to "every PRJ file gets its own parser
class": the load script's *content* is plain QlikView script syntax,
identical whether it came from COM or from disk, so re-parsing it
with new code would just duplicate ScriptParserService for no
benefit.
"""
import logging
from pathlib import Path
from typing import Optional

from qlik_metadata_extractor.models.metadata_model import ScriptMetadata
from qlik_metadata_extractor.services.script_parser_service import ScriptParserService

logger = logging.getLogger(__name__)


class LoadScriptParser:
    """Loads LoadScript.txt from a PRJ folder and parses it via ScriptParserService."""

    def __init__(self, template_path: Path):
        self.template_path = template_path

    def parse(self, load_script_path: Optional[Path], script_name: str) -> ScriptMetadata:
        if load_script_path is None or not Path(load_script_path).exists():
            logger.warning(
                f"LoadScript.txt not found in PRJ folder for '{script_name}'. "
                f"Data-model metadata (tables/joins/sources) will be empty; "
                f"fall back to the QVW/COM path if this information is required."
            )
            metadata = ScriptMetadata.from_template(self.template_path, script_name)
            metadata.warnings.append(
                "LoadScript.txt was not present in the PRJ folder; "
                "no load-script metadata could be extracted from PRJ."
            )
            return metadata

        raw_script = Path(load_script_path).read_text(encoding="utf-8-sig", errors="replace")
        parser = ScriptParserService(script_name=script_name, template_path=self.template_path)
        return parser.parse(raw_script)
