"""
prj/prj_metadata_service.py
------------------------------
The orchestrator for the new PRJ-first metadata pipeline:

    PRJ folder -> PRJLocator.classify()
               -> LoadScriptParser (reuses ScriptParserService)
               -> DocumentParser, VariableParser
               -> SheetParser (per SH*.xml)
               -> ChartParser / GenericObjectParser (per object file)
               -> TableParser (cross-reference enrichment)
               -> one normalized metadata dict, superset of the
                  existing ScriptMetadata schema.

This is the only class ExtractionController needs to know about for
the PRJ path; everything else in this package is an implementation
detail behind it.
"""
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from qlik_metadata_extractor.models.metadata_model import ScriptMetadata

from .prj_locator import PRJLocator, PRJNotFoundError, KNOWN_OBJECT_PREFIXES
from .document_parser import DocumentParser
from .variable_parser import VariableParser
from .sheet_parser import SheetParser
from .chart_object_parser import (
    ChartParser, GenericObjectParser, ListBoxParser, MultiBoxParser, StatisticsBoxParser,
)
from .load_script_parser import LoadScriptParser
from .table_parser import TableParser
from .validation import validate_metadata
from .visual_metadata_service import VisualMetadataService

logger = logging.getLogger(__name__)

# Which parser class handles which two-letter object-file prefix.
# CH (chart), LB (list box / drop-down filter), and MB (multibox
# filter) get specialised parsers; everything else known falls back
# to the generic one with a readable category label. Any prefix NOT
# in this map (a version-specific object type we've never seen) still
# gets parsed generically rather than skipped - see `_parser_for_prefix`.
_OBJECT_PARSER_MAP = {
    "CH": lambda: ChartParser(),
    "LB": lambda: ListBoxParser(),
    "MB": lambda: MultiBoxParser(),
    "SH": None,  # sheets are handled separately by SheetParser
}

# Some object types are reliably identified by their own declared type
# (the XML root tag / <SubType>, already captured as `object_type` by
# every parser via SheetObjectParser._resolve_subtype) even when the
# two-letter *file-name* prefix a given QlikView export used for that
# object doesn't match this repo's assumed prefix above (prefixes vary
# slightly by QlikView version/export flavour). For these known object
# types, `_reclassify_by_declared_type` re-parses the file with the
# dedicated, richer parser instead of leaving it on whatever generic/
# wrong-guess parser the prefix alone selected - purely a safety net;
# when the prefix guess was already correct this is a no-op.
_CONTENT_OVERRIDE_PARSERS = {
    "MultiBoxProperties": lambda: MultiBoxParser(),
    "StatisticsBoxProperties": lambda: StatisticsBoxParser(),
}


class PRJMetadataService:
    """Extracts full metadata for one QlikView app from its PRJ folder."""

    def __init__(self, template_path: Path):
        self.template_path = Path(template_path)
        self.locator = PRJLocator()
        self.document_parser = DocumentParser()
        self.variable_parser = VariableParser()
        self.sheet_parser = SheetParser()
        self.load_script_parser = LoadScriptParser(self.template_path)

    # ------------------------------------------------------------------
    def find_prj_dir(self, qvw_path: Path) -> Optional[Path]:
        return self.locator.find_for_qvw(qvw_path)

    def extract(self, qvw_path: Path, prj_dir: Optional[Path] = None) -> Dict[str, Any]:
        """
        Builds the full normalized metadata dict for `qvw_path` using its
        PRJ folder. Raises PRJNotFoundError if no PRJ folder can be
        located and none was explicitly supplied - callers (the
        controller) decide whether to fall back to COM extraction at
        that point.
        """
        qvw_path = Path(qvw_path)
        prj_dir = prj_dir or self.find_prj_dir(qvw_path)
        if prj_dir is None:
            raise PRJNotFoundError(
                f"No '-PRJ' folder found next to '{qvw_path}'. Enable "
                f"Settings -> User Preferences -> Design -> "
                f"'Generate Project Folder' in QlikView and re-save the "
                f"document to produce one."
            )

        logger.info(f"Extracting metadata from PRJ folder: {prj_dir}")
        contents = self.locator.classify(prj_dir)

        # 1) Load script -> reuse the existing, already-tested parser.
        script_metadata: ScriptMetadata = self.load_script_parser.parse(
            contents.load_script, qvw_path.name
        )
        metadata = script_metadata.to_dict()

        # 2) Document-level properties.
        doc_props = self.document_parser.parse(
            doc_properties_path=contents.document_files.get("document_properties"),
            project_path=contents.document_files.get("project"),
            all_properties_path=contents.document_files.get("all_properties"),
            top_layout_path=contents.document_files.get("top_layout"),
            doc_internals_path=contents.document_files.get("doc_internals"),
        )
        metadata["document_properties"] = doc_props
        if not doc_props.get("title"):
            doc_props["title"] = qvw_path.stem
        if doc_props.get("tabs") and not metadata.get("tabs"):
            metadata["tabs"] = doc_props["tabs"]

        # 3) Variables: merge PRJ-level variables (DocProperties /
        # QlikViewProject / dedicated Variables.xml) with whatever the
        # load script already declared, de-duplicated by name.
        variable_sources = [
            contents.document_files.get("document_properties"),
            contents.document_files.get("project"),
            contents.document_files.get("variables"),
        ]
        prj_variables = self.variable_parser.parse_files([p for p in variable_sources if p])
        metadata["variables"] = self._merge_variables(metadata.get("variables", []), prj_variables)

        # 4) Sheets.
        sheet_files = contents.objects_of("SH")
        metadata["sheets"] = self.sheet_parser.parse_all(sheet_files)

        # 5) Every other sheet object (charts + generic objects).
        charts = []
        objects = []
        for prefix, files in contents.object_files.items():
            if prefix == "SH":
                continue
            parser = self._parser_for_prefix(prefix)
            for path in files:
                parsed = parser.parse_file(path)
                parsed = self._reclassify_by_declared_type(parsed, path)
                if parsed.get("category") == "chart":
                    charts.append(parsed)
                else:
                    objects.append(parsed)
        metadata["charts"] = charts
        metadata["objects"] = objects

        # 6) Attach each object to its parent sheet. Real QlikView PRJ
        # exports carry the sheet->object relationship (and each
        # object's position/Z-order) only in QlikViewProject.xml, not
        # inside the sheet's own XML, so that placement map takes
        # priority; SheetParser's own object_ids list is only a
        # fallback for exports that do embed it there.
        self._link_objects_to_sheets(
            metadata["sheets"], charts + objects,
            doc_props.get("sheet_object_placements", {}),
        )

        # 7) Cross-reference table fields with report usage.
        metadata["tables"] = TableParser.enrich_tables_with_usage(
            metadata.get("tables", []), charts
        )

        # 7b) Attach engine-authoritative lineage/classification from
        # DocInternals.xml (field -> source table(s), synthetic/key/
        # system field flags). This is a cross-check on top of the
        # LoadScript-derived table/field parsing, not a replacement.
        metadata["tables"] = TableParser.enrich_tables_with_lineage(
            metadata["tables"],
            doc_props.get("field_lineage", {}),
            synthetic_fields=doc_props.get("synthetic_fields"),
            key_fields=doc_props.get("key_fields"),
            system_fields=doc_props.get("system_fields"),
        )

        # 8) Consolidate everything above into the visual metadata
        # repository (report -> sheets -> visuals, groups, variable
        # usage) that the report-generation phase will consume, and
        # that a user can review/edit before Power BI visuals are
        # actually generated from it.
        visual_output = VisualMetadataService.build(metadata)
        metadata["visual_metadata"] = visual_output["visual_metadata"]
        metadata["visual_metadata_tables"] = visual_output["visual_metadata_tables"]

        metadata["extraction_source"] = "PRJ"
        metadata["prj_dir"] = str(prj_dir)
        if contents.unclassified_files:
            metadata.setdefault("warnings", []).append(
                f"{len(contents.unclassified_files)} file(s) in the PRJ folder "
                f"did not match a known object pattern and were not parsed: "
                f"{[f.name for f in contents.unclassified_files]}"
            )

        # 9) Validation pass over the finished unified model - surfaces
        # completeness/consistency gaps (missing lineage, unplaced
        # objects, chart-less expressions, etc.) before this feeds the
        # Power BI migration engine.
        validation_findings = validate_metadata(metadata)
        metadata["validation"] = validation_findings
        if validation_findings:
            metadata.setdefault("warnings", []).extend(validation_findings)

        return metadata

    # ------------------------------------------------------------------
    @staticmethod
    def _parser_for_prefix(prefix: str):
        if prefix == "CH":
            return ChartParser()
        if prefix == "LB":
            return ListBoxParser()
        if prefix == "MB":
            return MultiBoxParser()
        label = KNOWN_OBJECT_PREFIXES.get(prefix, f"object_{prefix.lower()}")
        return GenericObjectParser(object_type_label=label)

    @staticmethod
    def _reclassify_by_declared_type(parsed: Dict[str, Any], path: Path) -> Dict[str, Any]:
        """
        Safety net for `_parser_for_prefix`'s file-prefix guess: if the
        object's own declared type (already captured as `object_type`,
        read from its XML root tag/<SubType> regardless of which parser
        ran) is one of the well-known types in `_CONTENT_OVERRIDE_PARSERS`
        but the prefix-based parser didn't already produce the matching
        category, re-parse the same file with the dedicated parser so
        extraction ends up keyed on the object's real type rather than a
        naming guess. A no-op (single dict lookup, no re-parse) whenever
        the prefix guess was already correct.
        """
        object_type = parsed.get("object_type")
        expected_category = {
            "MultiBoxProperties": "multibox",
            "StatisticsBoxProperties": "statistics",
        }.get(object_type)
        if not expected_category or parsed.get("category") == expected_category:
            return parsed
        override = _CONTENT_OVERRIDE_PARSERS.get(object_type)
        if not override:
            return parsed
        try:
            return override().parse_file(path)
        except Exception as exc:  # noqa: BLE001 - fall back to the original parse rather than losing the object
            logger.warning(
                f"Reclassifying '{path.name}' as {object_type} failed ({exc}); "
                f"keeping its original '{parsed.get('category')}' category."
            )
            return parsed

    @staticmethod
    def _merge_variables(script_vars, prj_vars):
        merged = list(script_vars or [])
        existing_names = {v.get("name") for v in merged}
        for var in prj_vars:
            if var["name"] not in existing_names:
                merged.append(var)
                existing_names.add(var["name"])
        return merged

    @staticmethod
    def _link_objects_to_sheets(sheets, all_objects, placements) -> None:
        by_id = {obj.get("object_id"): obj for obj in all_objects if obj.get("object_id")}
        placements = placements or {}

        for sheet in sheets:
            placement_entries = placements.get(sheet.get("sheet_id"), [])
            object_ids = [p["object_id"] for p in placement_entries] or sheet.get("object_ids", [])
            if object_ids and object_ids != sheet.get("object_ids"):
                sheet["object_ids"] = object_ids

            # Position/Z-order for a real object's on-sheet placement
            # lives only in QlikViewProject.xml's per-sheet placement
            # list - the object's own XML can contain unrelated
            # internal <Position>/<Rect> blocks (e.g. a chart's Title
            # or Legend docking box) that get_position() may pick up
            # first during its recursive search. QlikViewProject.xml
            # is therefore authoritative and always overrides whatever
            # (possibly wrong) position the object's own file yielded,
            # rather than only backfilling when it's empty.
            for entry in placement_entries:
                obj = by_id.get(entry.get("object_id"))
                if obj is not None and entry.get("position"):
                    obj["position"] = entry["position"]

            sheet["objects"] = [by_id[oid] for oid in object_ids if oid in by_id]