"""
qlik_metadata_extractor/prj
----------------------------
PRJ-folder-based metadata extraction.

This package is the replacement metadata *source* for the existing
extraction pipeline. It never touches the QlikView COM API and does
not require QlikView Desktop to be installed. It reads the XML/TXT
files QlikView writes into ``<AppName>-PRJ`` when
"Generate Project Folder" is enabled, and turns them into the exact
same ``ScriptMetadata`` shape the rest of the app (FileWriterView,
MigrationEngine) already knows how to consume - extended with new,
purely-additive fields (`sheets`, `charts`, `objects`,
`document_properties`) that did not exist when the only source was
the load script.

Entry point: :class:`PRJMetadataService`.
"""
from .prj_metadata_service import PRJMetadataService
from .prj_locator import PRJLocator, PRJNotFoundError

__all__ = ["PRJMetadataService", "PRJLocator", "PRJNotFoundError"]
