"""
prj/xml_utils.py
-----------------
Generic, dynamic XML helpers shared by every PRJ parser.

Design rule (per the migration brief): "Do not hardcode XML nodes."
Every function here walks whatever tree it is given and works purely
off tag names / structure it discovers at runtime, so a QlikView
version that adds, removes, or renames a handful of nodes degrades
gracefully instead of throwing a KeyError. Callers ask "does this
subtree have anything that looks like X" using `find_first`/`find_all`
(substring / case-insensitive tag matching) rather than an exact,
version-specific XPath.
"""
import logging
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


def load_xml(path: Path) -> Optional[ET.Element]:
    """
    Parses an XML file and returns its root element, or None if the
    file is missing/unreadable/malformed. A single bad file should
    never abort extraction of everything else in the PRJ folder.
    """
    path = Path(path)
    try:
        tree = ET.parse(path)
        return tree.getroot()
    except FileNotFoundError:
        logger.warning(f"PRJ file not found: {path}")
    except ET.ParseError as exc:
        logger.warning(f"Could not parse XML in {path}: {exc}")
    return None


def local_tag(element: ET.Element) -> str:
    """Tag name with any XML namespace prefix stripped, e.g. '{ns}Foo' -> 'Foo'."""
    tag = element.tag
    return tag.split("}", 1)[1] if "}" in tag else tag


def find_first(element: ET.Element, *tag_candidates: str) -> Optional[ET.Element]:
    """
    Depth-first search for the first descendant (or self) whose local
    tag name case-insensitively matches any of `tag_candidates`.
    Does not assume a fixed depth or parent path.
    """
    if element is None:
        return None
    wanted = {t.lower() for t in tag_candidates}
    for node in element.iter():
        if local_tag(node).lower() in wanted:
            return node
    return None

def find_all(element: ET.Element, *tag_candidates: str) -> List[ET.Element]:
    """Every descendant (or self) matching any of `tag_candidates` (case-insensitive)."""
    if element is None:
        return []
    wanted = {t.lower() for t in tag_candidates}
    return [node for node in element.iter() if local_tag(node).lower() in wanted]


def direct_children(element: ET.Element, *tag_candidates: str) -> List[ET.Element]:
    """Only immediate children matching any of `tag_candidates` (not the whole subtree)."""
    if element is None:
        return []
    wanted = {t.lower() for t in tag_candidates}
    return [child for child in element if local_tag(child).lower() in wanted]


def text_of(element: Optional[ET.Element], default: str = "") -> str:
    """Trimmed text content of an element, or `default` if None/empty."""
    if element is None or element.text is None:
        return default
    return element.text.strip()


def find_text(element: ET.Element, *tag_candidates: str, default: str = "") -> str:
    """Convenience: find_first(...) + text_of(...) in one call."""
    return text_of(find_first(element, *tag_candidates), default)


def attrs_of(element: Optional[ET.Element]) -> Dict[str, str]:
    return dict(element.attrib) if element is not None else {}


def element_to_dict(element: Optional[ET.Element], max_depth: int = 12) -> Union[Dict[str, Any], str, None]:
    """
    Fully-generic, lossless XML -> dict/list conversion. Used as a
    fallback so that *every* piece of information in a PRJ XML file is
    reachable in the normalized metadata even if no specialised parser
    field claims it explicitly (the brief asks for "everything
    available inside the XML").

    Rules:
      - An element with only text and no children/attrs -> that text (str).
      - Attributes are captured under an "@attrs" key.
      - Repeated child tags become a list under that tag name.
      - A single occurrence of a child tag becomes a dict value.
      - Recursion is capped by `max_depth` as a safety net against
        pathological/cyclical-looking structures.
    """
    if element is None:
        return None
    if max_depth <= 0:
        return text_of(element) or None

    children = list(element)
    attrs = attrs_of(element)
    text = text_of(element)

    if not children and not attrs:
        return text or None

    result: Dict[str, Any] = {}
    if attrs:
        result["@attrs"] = attrs
    if text:
        result["#text"] = text

    grouped: Dict[str, List[ET.Element]] = {}
    for child in children:
        grouped.setdefault(local_tag(child), []).append(child)

    for tag, nodes in grouped.items():
        values = [element_to_dict(n, max_depth - 1) for n in nodes]
        result[tag] = values[0] if len(values) == 1 else values

    return result


def coerce_number(value: str) -> Union[int, float, str]:
    """Best-effort numeric coercion; returns the original string if it isn't numeric."""
    try:
        if "." in value or "e" in value.lower():
            return float(value)
        return int(value)
    except (TypeError, ValueError):
        return value


def coerce_bool_like(value: str) -> Union[bool, str]:
    """Maps QlikView's common boolean text spellings; leaves anything else untouched."""
    if value is None:
        return value
    lowered = value.strip().lower()
    if lowered in ("true", "-1", "1"):
        return True
    if lowered in ("false", "0"):
        return False
    return value
