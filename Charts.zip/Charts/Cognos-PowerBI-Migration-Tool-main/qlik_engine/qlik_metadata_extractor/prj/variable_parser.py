"""
prj/variable_parser.py
------------------------
Extracts document ("global") variables wherever they appear in the
PRJ folder. QlikView typically writes them as repeated <Variable>
blocks inside DocProperties.xml, QlikViewProject.xml, or a dedicated
Variables.xml depending on version - this parser looks for the
<Variable> tag dynamically across whichever document-level files it
is given, rather than assuming one specific source file.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List
import xml.etree.ElementTree as ET

from .base_prj_parser import BasePRJParser
from .xml_utils import load_xml, find_all, find_first, find_text, text_of

logger = logging.getLogger(__name__)


class VariableParser(BasePRJParser):
    """Parses <Variable> nodes into normalized variable dicts."""

    def parse_files(self, paths: List[Path]) -> List[Dict[str, Any]]:
        variables: List[Dict[str, Any]] = []
        seen_names = set()
        for path in paths:
            if path is None:
                continue
            root = load_xml(path)
            if root is None:
                continue
            for var_node in find_all(root, "Variable"):
                var = self._parse_variable(var_node, Path(path).name)
                if var["name"] and var["name"] not in seen_names:
                    seen_names.add(var["name"])
                    variables.append(var)
        return variables

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        raise NotImplementedError(
            "VariableParser is driven through parse_files(paths), not the "
            "single-file parse_file()/parse_element() entry point, since "
            "document variables can be spread across several PRJ files."
        )

    @staticmethod
    def _parse_variable(node: ET.Element, source_file: str) -> Dict[str, Any]:
        name = find_text(node, "Name")
        definition_node = find_first(node, "Definition")
        definition = ""
        if definition_node is not None:
            v_node = find_first(definition_node, "v")
            definition = text_of(v_node) if v_node is not None else text_of(definition_node)
        comment = find_text(node, "Comment")
        return {
            "name": name,
            "definition": definition,
            "comment": comment,
            "is_config_variable": name.startswith("_") if name else False,
            "source_file": source_file,
        }
