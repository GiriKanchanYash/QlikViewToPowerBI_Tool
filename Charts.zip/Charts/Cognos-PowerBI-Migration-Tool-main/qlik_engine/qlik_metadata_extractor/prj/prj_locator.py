"""
prj/prj_locator.py
-------------------
Finds and classifies the contents of a QlikView "-PRJ" project folder.

QlikView writes this folder next to the .qvw when
Settings -> User Preferences -> Design -> "Generate Project Folder"
is enabled at save time:

    MyApp.qvw
    MyApp-PRJ/
        LoadScript.txt
        DocProperties.xml
        AllProperties.xml
        QlikViewProject.xml
        TopLayout.xml
        SH01.xml, SH02.xml, ...      <- Sheets
        CH01.xml, CH02.xml, ...      <- Charts
        LB01.xml, ...                <- List boxes
        TX01.xml, ...                <- Text objects
        MB01.xml, ...                <- Buttons
        CS01.xml, ...                <- Current selection boxes
        SB01.xml, ...                <- Slider/Calendar objects
        ... (naming varies slightly by QlikView version)

Nothing here hardcodes what is *inside* those files -- this module's
only job is to find the folder and bucket the files by the two-letter
prefix QlikView uses for the object type, so each specialised parser
only ever sees the files it owns.
"""
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# Two-letter object-file prefixes QlikView is known to emit into a PRJ
# folder, mapped to a human-readable object type. This list is used
# only to *label* files for convenience/logging - the parsers below do
# not rely on this mapping to decide whether a file is understandable
# (that decision is dynamic, based on XML content), so an unrecognised
# or version-specific prefix degrades gracefully to "OBJECT" rather
# than being skipped.
KNOWN_OBJECT_PREFIXES: Dict[str, str] = {
    "CH": "chart",
    "SH": "sheet",
    "LB": "listbox",
    "TX": "textbox",
    "MB": "multibox",  # MultiBoxProperties: a filter box bound to one or more fields, not a button
    "CS": "current_selection_box",
    "SB": "slider_or_calendar",
    "TB": "table_box",
    "IB": "input_box",
    "BM": "bookmark",
    "LA": "layout",
}

# Files whose names are fixed (not <PREFIX><NN>.xml) and carry
# document-wide (not per-object) information.
DOCUMENT_LEVEL_FILES = {
    "docproperties.xml": "document_properties",
    "allproperties.xml": "all_properties",
    "qlikviewproject.xml": "project",
    "toplayout.xml": "top_layout",
    "variables.xml": "variables",
    # DocInternals.xml carries the document's *internal* metadata: the
    # authoritative field->source-table lineage (FieldSrcTables), field
    # classification tags ($key/$synthetic/$hidden/$system/etc via
    # FieldTags), and the internal data-model (table viewer) layout.
    # It was previously left unclassified (and therefore silently
    # skipped) because it isn't a <PREFIX><NN>.xml object file and had
    # no entry here.
    "docinternals.xml": "doc_internals",
}

_OBJECT_FILE_RE = re.compile(r"^([A-Za-z]{2})(\d+)\.xml$", re.IGNORECASE)


class PRJNotFoundError(Exception):
    """Raised when no PRJ project folder can be located for a given QVW."""


@dataclass
class PRJContents:
    """Classified inventory of a single PRJ folder."""
    prj_dir: Path
    load_script: Optional[Path] = None
    document_files: Dict[str, Path] = field(default_factory=dict)
    object_files: Dict[str, List[Path]] = field(default_factory=dict)  # prefix -> files
    unclassified_files: List[Path] = field(default_factory=list)

    def objects_of(self, *prefixes: str) -> List[Path]:
        """All object files for one or more two-letter prefixes (e.g. 'CH')."""
        out: List[Path] = []
        for p in prefixes:
            out.extend(self.object_files.get(p.upper(), []))
        return sorted(out)

    def all_object_files(self) -> List[Path]:
        out: List[Path] = []
        for files in self.object_files.values():
            out.extend(files)
        return sorted(out)


class PRJLocator:
    """Locates a QlikView PRJ folder and classifies what is inside it."""

    def find_for_qvw(self, qvw_path: Path) -> Optional[Path]:
        """
        Returns the '<name>-PRJ' folder that QlikView would have created
        beside `qvw_path`, or None if it doesn't exist. Never raises -
        callers decide whether a missing PRJ folder is fatal.
        """
        qvw_path = Path(qvw_path)
        candidate = qvw_path.with_name(f"{qvw_path.stem}-PRJ")
        if candidate.is_dir():
            return candidate

        # Some QlikView versions/exports lower-case the suffix or use a
        # space instead of a hyphen; do a tolerant case-insensitive scan
        # of the parent directory as a fallback before giving up.
        parent = qvw_path.parent
        if not parent.is_dir():
            return None
        target_name = f"{qvw_path.stem}-prj".lower()
        for entry in parent.iterdir():
            if entry.is_dir() and entry.name.lower().replace(" ", "-") == target_name:
                return entry
        return None

    def classify(self, prj_dir: Path) -> PRJContents:
        """Scans a PRJ folder and buckets every file by known type."""
        prj_dir = Path(prj_dir)
        contents = PRJContents(prj_dir=prj_dir)

        for entry in sorted(prj_dir.iterdir()):
            if not entry.is_file():
                continue
            name_lower = entry.name.lower()

            if name_lower == "loadscript.txt":
                contents.load_script = entry
                continue

            if name_lower in DOCUMENT_LEVEL_FILES:
                contents.document_files[DOCUMENT_LEVEL_FILES[name_lower]] = entry
                continue

            match = _OBJECT_FILE_RE.match(entry.name)
            if match:
                prefix = match.group(1).upper()
                contents.object_files.setdefault(prefix, []).append(entry)
                continue

            contents.unclassified_files.append(entry)

        if not contents.load_script:
            logger.warning(f"No LoadScript.txt found in PRJ folder: {prj_dir}")

        return contents
