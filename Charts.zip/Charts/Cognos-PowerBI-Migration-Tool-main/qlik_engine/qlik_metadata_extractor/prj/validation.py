"""
prj/validation.py
-------------------
A validation pass over the fully-built unified metadata dict, run as
the last step of PRJMetadataService.extract(). This does not change
what was extracted; it only inspects the finished model and reports
gaps that would otherwise silently degrade the downstream Power BI
migration (missing lineage, orphaned objects, unresolved expressions,
etc.), the same way ``metadata["warnings"]`` already flags star-schema
risks - this generalizes that pattern to the rest of the model.

Every check is best-effort and defensive: a malformed/missing section
of the metadata produces a validation message, never an exception, so
validation itself can never abort extraction.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def validate_metadata(metadata: Dict[str, Any]) -> List[str]:
    """Returns a list of human-readable validation findings (may be empty)."""
    findings: List[str] = []

    findings.extend(_check_document_properties(metadata))
    findings.extend(_check_sheets_and_objects(metadata))
    findings.extend(_check_tables_and_lineage(metadata))
    findings.extend(_check_charts(metadata))

    return findings


def _check_document_properties(metadata: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    doc_props = metadata.get("document_properties") or {}
    if not doc_props.get("title"):
        out.append("No document title was found in DocProperties.xml (falling back to the .qvw file name).")
    if not doc_props.get("source_files"):
        out.append(
            "No document-level PRJ files (DocProperties/AllProperties/TopLayout/"
            "QlikViewProject/DocInternals) were found or parsed - document-wide "
            "settings, locale, styling, and field lineage will all be empty."
        )
    if not doc_props.get("field_lineage"):
        out.append(
            "DocInternals.xml produced no field->table lineage; table "
            "relationships will rely solely on LoadScript field-name matching, "
            "which cannot distinguish a real relationship from an accidental "
            "field-name collision."
        )
    if not doc_props.get("locale"):
        out.append(
            "No locale/regional formatting (decimal separator, date format, etc.) "
            "was found; generated DAX/M number and date formats will use "
            "generic defaults instead of matching the source document."
        )
    return out


def _check_sheets_and_objects(metadata: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    sheets = metadata.get("sheets") or []
    if not sheets:
        out.append("No sheets (SH*.xml) were parsed - the Power BI report will have no pages.")

    all_objects = (metadata.get("charts") or []) + (metadata.get("objects") or [])
    placed_ids = {oid for sheet in sheets for oid in (sheet.get("object_ids") or [])}
    for obj in all_objects:
        oid = obj.get("object_id")
        if oid and oid not in placed_ids:
            out.append(
                f"Object '{oid}' was parsed but is not placed on any sheet "
                f"(missing from every sheet's object_ids / QlikViewProject.xml "
                f"placement map) - it will not appear in the generated report."
            )
        if oid and not (obj.get("position") or {}):
            out.append(f"Object '{oid}' has no resolved position/size - layout reconstruction will use a default placement.")

    for sheet in sheets:
        if not sheet.get("caption"):
            out.append(f"Sheet '{sheet.get('sheet_id')}' has no caption/title - the generated Power BI page name will fall back to its internal ID.")

    return out


def _check_tables_and_lineage(metadata: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    tables = metadata.get("tables") or []
    if not tables:
        out.append("No tables were parsed from the load script - the semantic model will be empty.")

    for table in tables:
        name = table.get("name", "<unnamed>")
        if not table.get("fields"):
            out.append(f"Table '{name}' has no fields - it will be dropped from the semantic model.")
        conflicts = table.get("lineage_conflicts") or []
        if conflicts:
            out.append(
                f"Table '{name}': field(s) {conflicts} are declared under this table "
                f"in the load script but DocInternals.xml's engine-computed lineage "
                f"attributes them to a different table - review before generating "
                f"the semantic model, since this usually means a QVD/resident-load "
                f"table alias."
            )
    return out


def _check_charts(metadata: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    for chart in metadata.get("charts") or []:
        cid = chart.get("object_id", "<unknown>")
        if not chart.get("dimensions") and not chart.get("measures"):
            out.append(f"Chart '{cid}' has no dimensions or measures - it will be skipped during Power BI visual generation.")
        for measure in chart.get("measures") or []:
            expr = measure.get("expression") or measure.get("definition")
            if not expr:
                out.append(f"Chart '{cid}': a measure has no resolvable expression - the equivalent DAX measure cannot be generated.")
    return out
