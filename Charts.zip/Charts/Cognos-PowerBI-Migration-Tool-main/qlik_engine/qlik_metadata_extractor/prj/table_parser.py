"""
prj/table_parser.py
----------------------
Table-level enrichment that is only possible once both the load
script (tables/fields, from ScriptParserService) *and* the report
objects (charts/sheets, from ChartParser/SheetParser) have been
parsed: which fields are actually referenced by which sheet objects.

This is additive information that plain load-script parsing can
never produce (the script doesn't know what's on a sheet), so it
earns its own class per the "TableParser" item in the requested
architecture, rather than duplicating what ScriptParserService
already does for table/join/source extraction.
"""
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class TableParser:
    """Builds a field -> [chart/object ids] usage map and flags unused fields."""

    @staticmethod
    def build_field_usage(tables: List[Dict[str, Any]], charts: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        usage: Dict[str, List[str]] = {}
        for chart in charts:
            chart_id = chart.get("object_id", "")
            for field in chart.get("referenced_fields", []):
                usage.setdefault(field, [])
                if chart_id and chart_id not in usage[field]:
                    usage[field].append(chart_id)
            for dim in chart.get("dimensions", []):
                field = dim.get("field")
                if field:
                    usage.setdefault(field, [])
                    if chart_id and chart_id not in usage[field]:
                        usage[field].append(chart_id)
        return usage

    @classmethod
    def enrich_tables_with_usage(
        cls, tables: List[Dict[str, Any]], charts: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        usage = cls.build_field_usage(tables, charts)
        enriched = []
        for table in tables:
            fields = table.get("fields", []) or []
            used_fields = [f for f in fields if usage.get(f)]
            enriched.append({
                **table,
                "used_in_objects": {f: usage[f] for f in used_fields},
                "unused_fields": [f for f in fields if f not in used_fields],
            })
        return enriched

    @staticmethod
    def enrich_tables_with_lineage(
        tables: List[Dict[str, Any]],
        field_lineage: Dict[str, List[str]],
        synthetic_fields: Optional[List[str]] = None,
        key_fields: Optional[List[str]] = None,
        system_fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Attaches the engine-authoritative lineage from DocInternals.xml
        (`field_lineage`: field -> [source table names]) to each table's
        fields, and flags fields the QlikView engine itself classified
        as synthetic keys, composite keys, or internal system fields.

        This is deliberately additive/non-destructive: LoadScript-based
        table/field parsing (ScriptParserService) stays the primary
        source for a table's own field list; this only adds a
        per-field `source_tables` cross-check and classification flags
        that a script-only parse can't produce, plus a `lineage_conflict`
        flag when the engine says a field lives in table(s) different
        from the one it was declared under.
        """
        if not field_lineage:
            return tables

        synthetic_fields = set(synthetic_fields or [])
        key_fields = set(key_fields or [])
        system_fields = set(system_fields or [])

        enriched: List[Dict[str, Any]] = []
        for table in tables:
            table_name = table.get("name", "")
            fields = table.get("fields", []) or []
            field_lineage_map: Dict[str, Any] = {}
            conflicts: List[str] = []
            for f in fields:
                src_tables = field_lineage.get(f)
                if not src_tables:
                    continue
                field_lineage_map[f] = {
                    "source_tables": src_tables,
                    "is_synthetic_key": f in synthetic_fields,
                    "is_key_field": f in key_fields,
                    "is_system_field": f in system_fields,
                }
                if table_name and table_name not in src_tables:
                    conflicts.append(f)

            new_table = {**table, "field_lineage": field_lineage_map}
            if conflicts:
                new_table["lineage_conflicts"] = conflicts
            enriched.append(new_table)
        return enriched
