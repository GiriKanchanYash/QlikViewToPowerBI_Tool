"""
prj/document_parser.py
------------------------
Parses the document-level PRJ files that describe the app as a whole
rather than one sheet/object:

    DocProperties.xml     -> app-wide properties (title, tab list, etc.)
    QlikViewProject.xml   -> project/document inventory (sheet & object IDs)
    AllProperties.xml     -> consolidated property dump (version-dependent)
    TopLayout.xml         -> sheet ordering / active sheet

Every field is looked up dynamically (see xml_utils.find_first/find_all)
so a missing or renamed node just means that field stays empty rather
than raising.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from .base_prj_parser import BasePRJParser
from .doc_internals_parser import DocInternalsParser
from .group_parser import GroupParser
from .xml_utils import (
    load_xml, find_first, find_all, find_text, text_of, attrs_of, coerce_number,
    local_tag,
)

logger = logging.getLogger(__name__)


class DocumentParser(BasePRJParser):
    """Combines DocProperties.xml / QlikViewProject.xml / AllProperties.xml / TopLayout.xml."""

    def parse(
        self,
        doc_properties_path: Optional[Path] = None,
        project_path: Optional[Path] = None,
        all_properties_path: Optional[Path] = None,
        top_layout_path: Optional[Path] = None,
        doc_internals_path: Optional[Path] = None,
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "title": "",
            "tabs": [],
            "sheet_ids": [],
            "sheet_order": [],
            "active_sheet_id": "",
            "document_settings": {},
            # Locale/regional formatting the document was authored with
            # (decimal/thousands separators, date/time/money formats,
            # collation, first day of week). This is what a faithful
            # Power BI number/date-format conversion needs; previously
            # nothing captured it at all.
            "locale": {},
            "styling": {},
            "alternate_states": [],
            "groups": [],
            # {sheet_id: [{"object_id": ..., "position": {...}}]} - the
            # authoritative sheet->object placement map. Real QlikView
            # PRJ exports don't list an object's containing sheet or its
            # position/Z-order inside the object's own XML at all; both
            # only exist in QlikViewProject.xml's per-sheet child list.
            "sheet_object_placements": {},
            # Populated from DocInternals.xml - see doc_internals_parser.
            "field_lineage": {},
            "field_tags": {},
            "tags_by_field": {},
            "synthetic_fields": [],
            "key_fields": [],
            "hidden_fields": [],
            "system_fields": [],
            "table_layout": [],
            "source_files": [],
        }

        roots: List[Optional[ET.Element]] = []
        all_properties_root: Optional[ET.Element] = None

        if doc_properties_path:
            root = load_xml(doc_properties_path)
            self._merge_doc_properties(root, result)
            result["source_files"].append(Path(doc_properties_path).name)
            roots.append(root)

        if project_path:
            root = load_xml(project_path)
            self._merge_project(root, result)
            result["source_files"].append(Path(project_path).name)
            roots.append(root)

        if top_layout_path:
            top_layout_root = load_xml(top_layout_path)
            self._merge_top_layout(top_layout_root, result)
            self._merge_top_layout_styling(top_layout_root, result)
            result["source_files"].append(Path(top_layout_path).name)

        if all_properties_path:
            root = load_xml(all_properties_path)
            if root is not None:
                all_properties_root = root
                # AllProperties.xml varies the most across versions; keep it
                # as a full dynamic dump rather than picking specific nodes,
                # so nothing in it is lost even if we don't have a named
                # field for it yet.
                result["all_properties_raw"] = self.collect_raw(root, max_depth=6)
                result["source_files"].append(Path(all_properties_path).name)
                roots.append(root)

        if not result["tabs"] and result["sheet_ids"]:
            result["tabs"] = [{"name": sid} for sid in result["sheet_ids"]]

        # Drill-down/cyclic groups are declared document-wide (a chart
        # only references one by name), so they're parsed once here
        # across every document-level file rather than per object.
        result["groups"] = GroupParser.parse_roots(roots)

        # DocInternals.xml's <FieldSrcTables> lineage is keyed by a
        # field's ordinal position in AllProperties.xml's
        # <FieldProperties> list, so that field-name order has to be
        # extracted here and handed to DocInternalsParser.
        field_order = self._field_property_order(all_properties_root)
        doc_internals = DocInternalsParser().parse(doc_internals_path, field_order)
        if doc_internals.get("source_file"):
            result["source_files"].append(doc_internals["source_file"])
        for key in (
            "field_lineage", "field_tags", "tags_by_field", "synthetic_fields",
            "key_fields", "hidden_fields", "system_fields", "table_layout",
        ):
            if doc_internals.get(key):
                result[key] = doc_internals[key]

        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _field_property_order(all_properties_root: Optional[ET.Element]) -> List[str]:
        """
        Returns field names in the exact document order QlikView wrote
        them to <FieldProperties> inside AllProperties.xml - the index
        space DocInternals.xml's <FieldSrcTables> field_index refers to.
        """
        if all_properties_root is None:
            return []
        container = find_first(all_properties_root, "FieldProperties")
        if container is None:
            return []
        names: List[str] = []
        for entry in container:
            if local_tag(entry).lower() != "fieldproperties":
                continue
            names.append(find_text(entry, "Name"))
        return names

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        self._merge_doc_properties(root, result)
        return result

    # ------------------------------------------------------------------
    def _merge_doc_properties(self, root: Optional[ET.Element], result: Dict[str, Any]) -> None:
        if root is None:
            return

        title = find_text(root, "Title", "DocTitle")
        if title:
            result["title"] = title

        tabs: List[Dict[str, str]] = []
        for tab_node in find_all(root, "Tab", "SheetTab"):
            tab_name = find_text(tab_node, "Name", "Caption") or text_of(tab_node)
            if tab_name:
                tabs.append({"name": tab_name})
        if tabs:
            result["tabs"] = tabs

        # Generic settings bag: any direct child of a node literally
        # named *Settings* becomes {tag: text}, whatever those tags are.
        settings_node = find_first(root, "DocumentSettings", "Settings", "GeneralSettings")
        if settings_node is not None:
            settings: Dict[str, Any] = {}
            for child in settings_node:
                from .xml_utils import local_tag
                value = text_of(child)
                if value:
                    settings[local_tag(child)] = coerce_number(value)
            if settings:
                result.setdefault("document_settings", {}).update(settings)

        # Theme/colour-scheme/palette - the document-wide styling that
        # every visual inherits unless it overrides its own colors.
        # "DefaultTheme" is the tag QlikView actually emits in
        # DocProperties.xml; "Theme"/"ColorScheme"/"ApplicationTheme"
        # are kept too since the exact tag has drifted across versions.
        styling: Dict[str, Any] = {}
        theme_node = find_first(root, "DefaultTheme", "Theme", "ColorScheme", "ApplicationTheme")
        if theme_node is not None:
            theme_name = text_of(theme_node) or find_text(theme_node, "Name")
            if theme_name:
                styling["theme"] = theme_name
        palette_node = find_first(root, "Palette", "ColorPalette")
        if palette_node is not None:
            colors = [text_of(c) for c in find_all(palette_node, "Color") if text_of(c)]
            if colors:
                styling["palette"] = colors
        default_font_node = find_first(root, "DefaultFont", "ApplicationFont")
        if default_font_node is not None:
            font_name = find_text(default_font_node, "Name") or text_of(default_font_node)
            if font_name:
                styling["default_font"] = font_name
        if styling:
            result.setdefault("styling", {}).update(styling)

        # Locale/regional formatting the document was authored with.
        # QlikView stores these as flat siblings directly under the
        # root (often nested inside a <LocaleInfo> wrapper, but not
        # always), so each is looked up independently rather than
        # assumed to live under one container.
        locale: Dict[str, Any] = {}
        locale_fields = (
            ("decimal_separator", ("DecimalSep",)),
            ("thousands_separator", ("ThousandSep",)),
            ("money_decimal_separator", ("MoneyDecimalSep",)),
            ("money_thousands_separator", ("MoneyThousandSep",)),
            ("list_separator", ("ListSep",)),
            ("date_format", ("DateFmt",)),
            ("time_format", ("TimeFmt",)),
            ("timestamp_format", ("TimestampFmt",)),
            ("money_format", ("MoneyFmt",)),
            ("collation", ("Collation",)),
            ("first_week_day", ("FirstWeekDay",)),
            ("first_month_of_year", ("FirstMonthOfYear",)),
        )
        for out_key, candidates in locale_fields:
            value = find_text(root, *candidates)
            if value:
                locale[out_key] = value
        if locale:
            result["locale"] = locale

        # Alternate states are named selection contexts a user can
        # switch objects into; useful for understanding which visuals
        # share/diverge in selection state.
        states: List[str] = []
        for state_node in find_all(root, "AlternateState", "State"):
            name = find_text(state_node, "StateName", "Name") or text_of(state_node)
            if name and name not in states:
                states.append(name)
        if states:
            result["alternate_states"] = states

    def _merge_project(self, root: Optional[ET.Element], result: Dict[str, Any]) -> None:
        if root is None:
            return
        sheet_ids: List[str] = []
        placements: Dict[str, List[Dict[str, Any]]] = {}

        for sheet_node in find_all(root, "Sheet", "SheetObject", "PrjSheetProperties"):
            raw_sid = find_text(sheet_node, "SheetId") or self.get_object_id(sheet_node)
            sid = self._strip_doc_prefix(raw_sid)
            if not sid:
                continue
            if sid not in sheet_ids:
                sheet_ids.append(sid)

            objects: List[Dict[str, Any]] = []
            for child_node in find_all(sheet_node, "PrjFrameParentDef", "ChildObject"):
                oid = self._strip_doc_prefix(find_text(child_node, "ObjectId"))
                if not oid:
                    continue
                position = self.get_position(child_node)
                # ZedLevel is QlikView's real stacking-order field (a
                # PrjFrameParentDef sibling of Rect, not nested inside
                # it) - get_position's own Layer/ZOrder/ZPos aliases
                # don't cover it, so it's added here explicitly.
                z_value = find_text(child_node, "ZedLevel")
                if z_value:
                    position["z_order"] = coerce_number(z_value)
                objects.append({"object_id": oid, "position": position})

            if objects:
                placements[sid] = objects

        if sheet_ids:
            result["sheet_ids"] = sheet_ids
        if placements:
            result["sheet_object_placements"] = placements

    @staticmethod
    def _strip_doc_prefix(value: str) -> str:
        """QlikView IDs in QlikViewProject.xml are namespaced as
        "Document\\SH01" / "Document\\CH07"; only the final segment is
        the actual object/sheet ID used as filenames and everywhere
        else in the PRJ folder."""
        if not value:
            return ""
        return value.rsplit("\\", 1)[-1].rsplit("/", 1)[-1]

    def _merge_top_layout(self, root: Optional[ET.Element], result: Dict[str, Any]) -> None:
        if root is None:
            return
        order: List[str] = []
        for node in find_all(root, "SheetId", "ObjectId"):
            value = text_of(node)
            if value and value not in order:
                order.append(value)
        if order:
            result["sheet_order"] = order

        active = find_text(root, "ActiveSheetId", "ActiveSheet")
        if active:
            result["active_sheet_id"] = active

    def _merge_top_layout_styling(self, root: Optional[ET.Element], result: Dict[str, Any]) -> None:
        """
        TopLayout.xml carries the document's overall canvas/tab-row
        appearance (background color, tab-row color, active-tab font,
        tab-row style) - real layout/formatting information that was
        previously discarded entirely (only sheet ordering was ever
        read from this file). Merged into `styling` alongside whatever
        DocProperties.xml already contributed.
        """
        if root is None:
            return
        styling: Dict[str, Any] = {}

        bkg_node = find_first(root, "BkgColor")
        bkg_color = self.get_rgb_color(bkg_node) if bkg_node is not None else ""
        if bkg_color:
            styling["background_color"] = bkg_color

        tab_bg_node = find_first(root, "TabRowBgColor")
        tab_bg_color = self.get_rgb_color(tab_bg_node) if tab_bg_node is not None else ""
        if tab_bg_color:
            styling["tab_row_background_color"] = tab_bg_color

        active_font_node = find_first(root, "TabRowActiveFont")
        if active_font_node is not None:
            font_name = find_text(active_font_node, "FontName")
            if font_name:
                styling["active_tab_font"] = {
                    "name": font_name,
                    "bold": find_text(active_font_node, "Bold") == "true",
                    "italic": find_text(active_font_node, "Italic") == "true",
                }

        tabrow_style = find_text(root, "TabrowStyle")
        if tabrow_style:
            styling["tab_row_style"] = tabrow_style

        show_tab_row = find_text(root, "ShowTabRow")
        if show_tab_row:
            styling["show_tab_row"] = show_tab_row == "true"

        if styling:
            result.setdefault("styling", {}).update(styling)
