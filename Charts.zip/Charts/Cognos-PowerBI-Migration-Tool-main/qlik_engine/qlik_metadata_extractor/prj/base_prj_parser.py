"""
prj/base_prj_parser.py
------------------------
Common conventions shared by nearly every QlikView PRJ object XML
(SH*, CH*, TX*, LB*, MB*, CS*, ...): an object ID, a caption, a
position/size rectangle, show/calculation conditions, and an
expression that carries both a formula string and a per-expression
formatting spec. Every specialised parser subclasses `BasePRJParser`
and reuses these instead of re-implementing the same lookups.

Nothing here is tied to one tag's exact schema: every lookup goes
through `find_first`/`find_all`/`find_text`, which search dynamically
for a tag name rather than assuming a fixed path, so version drift in
QlikView's XML (extra wrapper nodes, renamed attributes, etc.) does
not break the parser - it just means a field comes back empty, which
is recorded rather than raising.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from .xml_utils import (
    load_xml, find_first, find_all, find_text, text_of, attrs_of,
    element_to_dict, coerce_number,
)

logger = logging.getLogger(__name__)


class BasePRJParser:
    """Shared helpers for parsing one PRJ XML file into a metadata dict."""

    def parse_file(self, path: Path) -> Dict[str, Any]:
        """Standard per-file entry point: load, parse, tag with provenance."""
        root = load_xml(path)
        if root is None:
            return {"source_file": str(path), "parse_error": True}
        result = self.parse_element(root)
        result["source_file"] = Path(path).name
        # Real QlikView PRJ exports leave the object's own <ObjectId> tag
        # empty - the ID only exists as the filename itself (CH07.xml is
        # object "CH07"). The XML tag is still tried first since some
        # exports do populate it.
        if not result.get("object_id"):
            result["object_id"] = Path(path).stem
        return result

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        raise NotImplementedError

    # ---------------------------------------------------------------
    # Common cross-object lookups
    # ---------------------------------------------------------------
    @staticmethod
    def get_object_id(root: ET.Element) -> str:
        node = find_first(root, "ObjectId", "ID", "Id")
        if node is not None and text_of(node):
            return text_of(node)
        # Some versions carry the ID as an attribute on the root itself.
        return attrs_of(root).get("ObjectId") or attrs_of(root).get("Id") or ""

    @classmethod
    def get_caption(cls, root: ET.Element) -> str:
        """
        QlikView spells an object's title/name differently depending on
        export flavour and object type: <Caption><Text><v>...</v></Text></Caption>
        in some schemas, a bare <n><v>...</v></n> for charts/gauges, or
        <Name><v>...</v></Name> for list boxes. `get_expression_text`
        already resolves the v-wrapped-or-plain-text shape once the
        right container is found, so this only needs to pick the first
        matching container in document order.
        """
        node = find_first(root, "Caption", "n", "Name", "CaptionText", "Title")
        return cls.get_expression_text(node) if node is not None else ""

    @staticmethod
    def get_rgb_color(root: ET.Element) -> str:
        """
        QlikView colors are near-always a nested `Col` element with
        Red/Green/Blue(/Alpha) children rather than a plain color
        string. Returns a '#RRGGBB' hex string, or '' if no such
        structure is found under `root`.
        """
        col_node = find_first(root, "Col")
        if col_node is None:
            return ""
        try:
            r = int(find_text(col_node, "Red") or 0)
            g = int(find_text(col_node, "Green") or 0)
            b = int(find_text(col_node, "Blue") or 0)
        except ValueError:
            return ""
        return f"#{r:02X}{g:02X}{b:02X}"

    @staticmethod
    def get_position(root: ET.Element) -> Dict[str, Any]:
        rect = find_first(root, "Rect", "Position", "LayoutRect")
        position: Dict[str, Any] = {}
        if rect is not None:
            for tag in ("Left", "Top", "Width", "Height", "X", "Y", "CX", "CY"):
                node = find_first(rect, tag)
                if node is not None and text_of(node):
                    position[tag] = coerce_number(text_of(node))
        # Z-order/stacking is almost never nested inside the position
        # rect itself - QlikView emits it as a sibling of Rect at the
        # object's top level (layer/order among overlapping objects).
        z_node = find_first(root, "Layer", "ZOrder", "ZPos", "StackOrder")
        if z_node is not None and text_of(z_node):
            position["z_order"] = coerce_number(text_of(z_node))
        return position

    @staticmethod
    def get_number_format(root: ET.Element) -> Dict[str, Any]:
        """
        QlikView number/display formatting (<NumFormat> or equivalent):
        format type, decimal/thousands separators, decimal places,
        and whether the field uses the document-default format.
        Missing tags are simply omitted rather than defaulted, so an
        empty dict cleanly means "no explicit format found".
        """
        node = find_first(root, "NumFormat", "FormatSpec", "NumberPresentation")
        if node is None:
            return {}
        fmt: Dict[str, Any] = {}
        for tag in ("Use", "Type", "nDec", "Dec", "UseThou", "Thou", "Fmt", "Format"):
            value = find_text(node, tag)
            if value:
                fmt[tag] = coerce_number(value) if value.lstrip("-").isdigit() else value
        return fmt

    @staticmethod
    def get_expression_text(node: Optional[ET.Element]) -> str:
        """
        QlikView expressions are near-universally wrapped as
        <Expression><v>...</v></Expression> or <Definition><v>...</v></Definition>.
        Falls back to the node's own text if there's no <v> child.
        """
        if node is None:
            return ""
        value_node = find_first(node, "v")
        if value_node is not None and text_of(value_node):
            return text_of(value_node)
        return text_of(node)

    @classmethod
    def get_calc_condition(cls, root: ET.Element) -> str:
        node = find_first(root, "CalcCondition")
        return cls.get_expression_text(node)

    @classmethod
    def get_show_condition(cls, root: ET.Element) -> str:
        node = find_first(root, "ShowCondition", "VisibleCondition")
        return cls.get_expression_text(node)

    @staticmethod
    def get_bool(root: ET.Element, *tag_candidates: str, default: bool = False) -> bool:
        node = find_first(root, *tag_candidates)
        if node is None:
            return default
        value = text_of(node).strip().lower()
        if value in ("true", "-1", "1"):
            return True
        if value in ("false", "0"):
            return False
        return default

    @staticmethod
    def collect_raw(root: ET.Element, max_depth: int = 12) -> Dict[str, Any]:
        """Full dynamic dump of the element - the 'catch everything else' field."""
        return element_to_dict(root, max_depth=max_depth) or {}
