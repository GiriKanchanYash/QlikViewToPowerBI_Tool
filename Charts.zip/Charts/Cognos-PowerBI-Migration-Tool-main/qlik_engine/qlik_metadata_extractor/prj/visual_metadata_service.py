"""
prj/visual_metadata_service.py
---------------------------------
Consolidates everything the other PRJ parsers extracted into the
"visual metadata repository" the migration brief asks for: a single,
report-shaped structure covering every visual on every sheet, meant to
be reviewed and (if needed) hand-edited *before* Power BI report
generation runs against it.

This module does no XML parsing of its own - it only reshapes the
already-parsed `metadata` dict (sheets, charts, objects, variables,
document_properties.groups) that `PRJMetadataService` builds. Two
things come out of `build()`:

    visual_metadata   - nested JSON: report -> sheets -> visuals,
                         plus groups/variable-usage/bookmarks, for the
                         main metadata JSON and for a human reviewing
                         the whole app in one file.
    visual_tables     - the same information flattened into named
                         lists of flat dicts (one row per visual /
                         dimension / measure / variable-usage entry),
                         ready to be written out as CSV for anyone who
                         wants to review or edit this in a spreadsheet.
"""
import logging
import re
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Matches $(varname) / $(=expression) references inside any expression
# string, used to build the variable -> objects-that-use-it map.
_VAR_REF_RE = re.compile(r"\$\((=?)([A-Za-z0-9_.]+)\)")


class VisualMetadataService:
    """Builds the consolidated visual-metadata JSON and flat tables."""

    @classmethod
    def build(cls, metadata: Dict[str, Any]) -> Dict[str, Any]:
        doc_props = metadata.get("document_properties", {}) or {}
        groups = doc_props.get("groups", []) or []
        group_lookup = cls._field_to_group_lookup(groups)

        sheets = metadata.get("sheets", []) or []
        all_charts = metadata.get("charts", []) or []
        all_objects = metadata.get("objects", []) or []
        all_visuals = all_charts + all_objects

        # Backfill each dimension's group_ref now that we know every
        # doc-level group; ChartParser can't do this itself since a
        # single chart's XML never lists other charts' groups.
        for chart in all_charts:
            for dim in chart.get("dimensions", []):
                dim["group_ref"] = group_lookup.get(dim.get("field"))

        sheet_rows: List[Dict[str, Any]] = []
        visual_rows: List[Dict[str, Any]] = []
        dimension_rows: List[Dict[str, Any]] = []
        measure_rows: List[Dict[str, Any]] = []

        sheets_out = []
        for sheet in sheets:
            sheet_id = sheet.get("sheet_id", "")
            sheet_caption = sheet.get("caption", "")
            sheet_rows.append({
                "sheet_id": sheet_id,
                "caption": sheet_caption,
                "order": sheet.get("order", ""),
                "show_condition": sheet.get("show_condition", ""),
                "calc_condition": sheet.get("calc_condition", ""),
            })

            visuals_out = []
            for visual in sheet.get("objects", []):
                visuals_out.append(cls._visual_summary(visual))
                visual_rows.append(cls._visual_row(visual, sheet_id, sheet_caption))
                for i, dim in enumerate(visual.get("dimensions", []) or []):
                    dimension_rows.append(cls._dimension_row(visual, dim, i))
                for i, measure in enumerate(visual.get("measures", []) or []):
                    measure_rows.append(cls._measure_row(visual, measure, i))

            sheets_out.append({
                "sheet_id": sheet_id,
                "caption": sheet_caption,
                "order": sheet.get("order", ""),
                "position": sheet.get("position", {}),
                "show_condition": sheet.get("show_condition", ""),
                "calc_condition": sheet.get("calc_condition", ""),
                "visuals": visuals_out,
            })

        variable_usage = cls._variable_usage(all_visuals, metadata.get("variables", []) or [])
        variable_usage_rows = [
            {"variable_name": name, "used_in_object_ids": "; ".join(ids)}
            for name, ids in variable_usage.items()
        ]

        bookmarks = [
            {
                "object_id": obj.get("object_id"),
                "caption": obj.get("caption"),
            }
            for obj in all_objects if obj.get("category") == "bookmark"
        ]

        visual_metadata = {
            "report": {
                "title": doc_props.get("title", ""),
                "sheet_count": len(sheets_out),
                "visual_count": len(visual_rows),
                "styling": doc_props.get("styling", {}),
                "alternate_states": doc_props.get("alternate_states", []),
            },
            "sheets": sheets_out,
            "groups": groups,
            "variable_usage": variable_usage,
            "bookmarks": bookmarks,
        }

        visual_tables = {
            "sheets": sheet_rows,
            "visuals": visual_rows,
            "dimensions": dimension_rows,
            "measures": measure_rows,
            "variable_usage": variable_usage_rows,
        }

        return {"visual_metadata": visual_metadata, "visual_metadata_tables": visual_tables}

    # ------------------------------------------------------------------
    @staticmethod
    def _visual_summary(visual: Dict[str, Any]) -> Dict[str, Any]:
        """Everything about one visual, minus the bulky 'raw' XML dump."""
        return {k: v for k, v in visual.items() if k != "raw"}

    @staticmethod
    def _visual_row(visual: Dict[str, Any], sheet_id: str, sheet_caption: str) -> Dict[str, Any]:
        position = visual.get("position", {}) or {}
        return {
            "object_id": visual.get("object_id", ""),
            "sheet_id": sheet_id,
            "sheet_caption": sheet_caption,
            "category": visual.get("category", ""),
            "object_type": visual.get("object_type", ""),
            "caption": visual.get("caption", ""),
            "x": position.get("Left", position.get("X", "")),
            "y": position.get("Top", position.get("Y", "")),
            "width": position.get("Width", position.get("CX", "")),
            "height": position.get("Height", position.get("CY", "")),
            "z_order": position.get("z_order", ""),
            "show_condition": visual.get("show_condition", ""),
            "calc_condition": visual.get("calc_condition", ""),
            "alternate_state": visual.get("alternate_state", ""),
            "dimension_count": len(visual.get("dimensions", []) or []),
            "measure_count": len(visual.get("measures", []) or []),
        }

    @staticmethod
    def _dimension_row(visual: Dict[str, Any], dim: Dict[str, Any], index: int) -> Dict[str, Any]:
        group_ref = dim.get("group_ref") or {}
        return {
            "object_id": visual.get("object_id", ""),
            "dimension_index": index,
            "field": dim.get("field", ""),
            "label": dim.get("label", ""),
            "number_format": dim.get("number_format", {}),
            "group_name": group_ref.get("name", ""),
            "group_type": group_ref.get("group_type", ""),
            "top_n": dim.get("top_n", ""),
            "bottom_n": dim.get("bottom_n", ""),
        }

    @staticmethod
    def _measure_row(visual: Dict[str, Any], measure: Dict[str, Any], index: int) -> Dict[str, Any]:
        return {
            "object_id": visual.get("object_id", ""),
            "measure_index": index,
            "label": measure.get("label", ""),
            "expression": measure.get("expression", ""),
            "is_set_analysis": measure.get("is_set_analysis", False),
            "visible": measure.get("visible", True),
            "number_format": measure.get("number_format", {}),
            "color": measure.get("color", {}),
        }

    @staticmethod
    def _field_to_group_lookup(groups: List[Dict[str, Any]]) -> Dict[str, Dict[str, str]]:
        lookup: Dict[str, Dict[str, str]] = {}
        for group in groups:
            for field in group.get("fields", []) or []:
                lookup[field] = {"name": group.get("name", ""), "group_type": group.get("group_type", "")}
        return lookup

    @classmethod
    def _variable_usage(
        cls, visuals: List[Dict[str, Any]], variables: List[Dict[str, Any]]
    ) -> Dict[str, List[str]]:
        """
        Maps each known variable name to the object_ids that reference
        it, scanning every expression-bearing field already extracted
        per visual (measures, dimensions, sort/tooltip/color
        expressions, show/calc conditions) rather than re-parsing XML.
        """
        known_names = {v.get("name") for v in variables if v.get("name")}
        usage: Dict[str, List[str]] = {name: [] for name in known_names}

        for visual in visuals:
            object_id = visual.get("object_id", "")
            texts: List[str] = [
                visual.get("show_condition", "") or "",
                visual.get("calc_condition", "") or "",
            ]
            texts.extend(visual.get("referenced_variables", []) or [])
            texts.extend(visual.get("set_analysis", []) or [])
            texts.extend(visual.get("sort_expressions", []) or [])
            texts.extend(visual.get("tooltip_expressions", []) or [])
            texts.extend(visual.get("color_expressions", []) or [])
            for measure in visual.get("measures", []) or []:
                texts.append(measure.get("expression", "") or "")
            for dim in visual.get("dimensions", []) or []:
                texts.append(dim.get("field", "") or "")

            found_here = set()
            for text in texts:
                for match in _VAR_REF_RE.finditer(text):
                    name = match.group(2)
                    found_here.add(name)
                # referenced_variables already yields bare names (no $()
                # wrapper), so a plain membership check catches those too.
                if text in known_names:
                    found_here.add(text)

            for name in found_here:
                if name in usage and object_id and object_id not in usage[name]:
                    usage[name].append(object_id)

        # Drop variables nobody references - keeps the map focused on
        # what's actually in play across the report's visuals.
        return {name: ids for name, ids in usage.items() if ids}
