"""
prj/sheet_parser.py
---------------------
Parses SH*.xml (sheet) files into normalized sheet metadata: ID,
caption, the object IDs placed on it, show/calc conditions, and any
sheet-level layout info that is present.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List
import xml.etree.ElementTree as ET

from .base_prj_parser import BasePRJParser
from .xml_utils import find_all, find_text, text_of, load_xml

logger = logging.getLogger(__name__)


class SheetParser(BasePRJParser):
    """One SH*.xml file -> one normalized sheet dict."""

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:
        sheet_id = self.get_object_id(root)
        caption = self.get_caption(root)

        object_ids: List[str] = []
        for ref_node in find_all(root, "SheetObjectListItem", "ObjectRef", "ObjectId"):
            ref_id = text_of(ref_node) or find_text(ref_node, "ObjectId")
            if ref_id and ref_id != sheet_id and ref_id not in object_ids:
                object_ids.append(ref_id)

        return {
            "sheet_id": sheet_id,
            "caption": caption,
            "order": find_text(root, "Order", "TabOrder", "Number"),
            "object_ids": object_ids,
            "position": self.get_position(root),
            "show_condition": self.get_show_condition(root),
            "calc_condition": self.get_calc_condition(root),
            "raw": self.collect_raw(root, max_depth=4),
        }

    def parse_all(self, paths: List[Path]) -> List[Dict[str, Any]]:
        sheets = []
        for path in paths:
            sheet = self.parse_file(path)
            if not sheet.get("sheet_id"):
                sheet["sheet_id"] = Path(path).stem
            sheets.append(sheet)
        return sheets
