"""
prj/group_parser.py
---------------------
Parses QlikView's document-level field groups: drill-down groups
(hierarchical, e.g. Year -> Quarter -> Month) and cyclic groups
(interchangeable, e.g. "Sales" / "Cost" / "Margin" swapped on a single
chart axis). Both live in the document-wide property files
(DocProperties.xml / QlikViewProject.xml / AllProperties.xml), not in
any one chart's own XML - a chart only *references* a group by name.

As with every other PRJ parser, lookups are dynamic (tag-name based)
so a version-specific wrapper node degrades to an empty list rather
than raising.
"""
import logging
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from .xml_utils import find_all, find_first, find_text, text_of, local_tag

logger = logging.getLogger(__name__)

# Tag names QlikView has used across versions for each group flavour,
# and the "kind" we normalize them to.
_GROUP_CONTAINER_TAGS = {
    "drilldowngroup": "drilldown",
    "hierarchygroup": "drilldown",
    "cyclegroup": "cyclic",
    "cyclicgroup": "cyclic",
}


class GroupParser:
    """Extracts drill-down and cyclic group definitions from document XML roots."""

    @classmethod
    def parse_roots(cls, roots: List[Optional[ET.Element]]) -> List[Dict[str, Any]]:
        groups: List[Dict[str, Any]] = []
        seen_names = set()
        for root in roots:
            if root is None:
                continue
            for group in cls._parse_one_root(root):
                key = (group["name"], group["group_type"])
                if group["name"] and key not in seen_names:
                    groups.append(group)
                    seen_names.add(key)
        return groups

    @classmethod
    def _parse_one_root(cls, root: ET.Element) -> List[Dict[str, Any]]:
        found: List[Dict[str, Any]] = []
        for node in root.iter():
            tag = local_tag(node).lower()
            group_type = _GROUP_CONTAINER_TAGS.get(tag)
            if group_type is None:
                continue
            name = find_text(node, "Name", "GroupName")
            fields: List[str] = []
            for field_node in find_all(node, "FieldDef", "Field", "FieldName"):
                value = text_of(field_node)
                if value and value not in fields:
                    fields.append(value)
            found.append({
                "name": name,
                "group_type": group_type,
                "fields": fields,
            })
        return found

    @staticmethod
    def field_to_group_lookup(groups: List[Dict[str, Any]]) -> Dict[str, Dict[str, str]]:
        """
        Inverts the group list into {field_name: {"name": ..., "group_type": ...}}
        so a chart dimension can be matched back to the group it belongs
        to (a field only meaningfully belongs to one drill/cyclic group
        at a time in practice, so last-write-wins on overlap is fine).
        """
        lookup: Dict[str, Dict[str, str]] = {}
        for group in groups:
            for field in group.get("fields", []):
                lookup[field] = {"name": group["name"], "group_type": group["group_type"]}
        return lookup
