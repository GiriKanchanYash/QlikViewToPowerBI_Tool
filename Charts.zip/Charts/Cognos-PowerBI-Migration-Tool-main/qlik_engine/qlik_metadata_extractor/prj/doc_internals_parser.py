"""
prj/doc_internals_parser.py
-----------------------------
Parses ``DocInternals.xml`` - the one document-level PRJ file that was
previously never classified (see ``prj_locator.DOCUMENT_LEVEL_FILES``)
and therefore silently dropped into ``unclassified_files``.

DocInternals.xml is QlikView's internal, engine-computed view of the
data model, and is the single most reliable source for two things a
LoadScript-based heuristic can only guess at:

1. **Field -> source-table lineage** (``<FieldSrcTables>``): a flat,
   position-encoded list -
   ``[field_index, table_count, table_name * table_count, field_index, ...]``
   - keyed by the field's *ordinal position* in
   ``AllProperties.xml``'s ``<FieldProperties>`` list (index 0-based).
   This is exact engine output, not a script-parsing inference, so it
   is used as the authoritative lineage source when present.

2. **Field classification tags** (``<FieldTags>``): which fields the
   engine tagged as ``$key``, ``$synthetic``, ``$hidden``, ``$system``,
   numeric/text/timestamp, etc. This is exactly the information needed
   to flag synthetic keys and system/hidden fields that should not be
   surfaced (or should be surfaced differently) in the Power BI model.

Also captured: the internal Table Viewer layout (``<TableViewData>``),
useful for reconstructing a sensible default table-relationship
diagram layout in Power BI, and ``<AlwaysLoose>`` / ``<LinkedTables>``.

As with every other PRJ parser, nothing here is hardcoded to a single
schema version: a missing/renamed node just means that field of the
result stays empty rather than raising.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional
import xml.etree.ElementTree as ET

from .base_prj_parser import BasePRJParser
from .xml_utils import find_all, find_first, local_tag, load_xml, text_of

logger = logging.getLogger(__name__)


class DocInternalsParser(BasePRJParser):
    """Parses DocInternals.xml into lineage + field-classification metadata."""

    def parse(
        self,
        doc_internals_path: Optional[Path],
        field_order: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "field_lineage": {},       # field_name -> [source table names]
            "field_tags": {},          # tag (e.g. "$synthetic") -> [field names]
            "tags_by_field": {},       # field_name -> [tags]
            "synthetic_fields": [],
            "key_fields": [],
            "hidden_fields": [],
            "system_fields": [],
            "table_layout": [],        # [{table, position}] from the Table Viewer
            "source_file": "",
        }
        if not doc_internals_path:
            return result

        root = load_xml(doc_internals_path)
        if root is None:
            return result

        result["source_file"] = Path(doc_internals_path).name
        field_order = field_order or []

        self._parse_field_src_tables(root, field_order, result)
        self._parse_field_tags(root, result)
        self._parse_table_layout(root, result)

        return result

    def parse_element(self, root: ET.Element) -> Dict[str, Any]:  # pragma: no cover - not file-driven
        result: Dict[str, Any] = {}
        self._parse_field_src_tables(root, [], result)
        self._parse_field_tags(root, result)
        self._parse_table_layout(root, result)
        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _string_values(node: Optional[ET.Element]) -> List[str]:
        if node is None:
            return []
        return [text_of(child) for child in node if local_tag(child).lower() == "string"]

    def _parse_field_src_tables(
        self, root: ET.Element, field_order: List[str], result: Dict[str, Any]
    ) -> None:
        """
        Decodes ``<FieldSrcTables>``: a flat sequence of
        ``field_index, table_count, table_name (x table_count)``
        triples-of-variable-width, repeated for every field the engine
        tracked. ``field_index`` is the field's 0-based ordinal
        position in AllProperties.xml's <FieldProperties> list; when
        `field_order` (that list, by name) isn't available the raw
        numeric index is kept as the key instead of being dropped.
        """
        node = find_first(root, "FieldSrcTables")
        values = self._string_values(node)
        lineage: Dict[str, List[str]] = {}

        i = 0
        n = len(values)
        while i < n:
            idx_raw = values[i]
            if not idx_raw.lstrip("-").isdigit():
                # Not a well-formed record boundary - stop rather than
                # misinterpreting the remaining stream as garbage.
                break
            field_index = int(idx_raw)
            if i + 1 >= n or not values[i + 1].isdigit():
                break
            table_count = int(values[i + 1])
            tables = values[i + 2: i + 2 + table_count]
            i = i + 2 + table_count

            if 0 <= field_index < len(field_order):
                field_name = field_order[field_index]
            else:
                field_name = f"$field_index_{field_index}"
            if tables:
                lineage.setdefault(field_name, [])
                for t in tables:
                    if t not in lineage[field_name]:
                        lineage[field_name].append(t)

        if lineage:
            result["field_lineage"] = lineage

    def _parse_field_tags(self, root: ET.Element, result: Dict[str, Any]) -> None:
        """
        Decodes ``<FieldTags>``: one ``<FieldTagData>`` per engine tag
        (``$key``, ``$synthetic``, ``$hidden``, ``$system``, ``$ascii``,
        ``$text``, ``$numeric``, ``$integer``, ``$timestamp``,
        ``$keypart``, ...) each listing every field carrying that tag.
        """
        container = find_first(root, "FieldTags")
        if container is None:
            return

        field_tags: Dict[str, List[str]] = {}
        tags_by_field: Dict[str, List[str]] = {}

        # <FieldTagData> entries are nested a level or two down (under
        # a <ScriptBased>/<Interactive> wrapper), not a direct child of
        # <FieldTags>, so the whole subtree is searched rather than
        # iterating container's immediate children.
        for tag_data in find_all(container, "FieldTagData"):
            tag_name = ""
            names_node = None
            for child in tag_data:
                ctag = local_tag(child).lower()
                if ctag == "tag":
                    tag_name = text_of(child)
                elif ctag == "fieldnames":
                    names_node = child
            field_names = self._string_values(names_node)
            if not tag_name:
                continue
            field_tags[tag_name] = field_names
            for fname in field_names:
                tags_by_field.setdefault(fname, [])
                if tag_name not in tags_by_field[fname]:
                    tags_by_field[fname].append(tag_name)

        if field_tags:
            result["field_tags"] = field_tags
            result["tags_by_field"] = tags_by_field
            result["synthetic_fields"] = list(field_tags.get("$synthetic", []))
            result["key_fields"] = list(field_tags.get("$key", []))
            result["hidden_fields"] = list(field_tags.get("$hidden", []))
            result["system_fields"] = sorted(
                set(field_tags.get("$system", [])) | set(field_tags.get("$hidden", []))
            )

    def _parse_table_layout(self, root: ET.Element, result: Dict[str, Any]) -> None:
        """
        Decodes the Table Viewer's saved window layout for each table
        (``TableViewTableWinSaveInfo``): table name + its on-canvas
        rectangle. Useful as a starting point for a Power BI model
        diagram layout that mirrors how the QlikView author arranged
        their tables, rather than an arbitrary auto-layout.
        """
        layout: List[Dict[str, Any]] = []
        for win in root.iter():
            if local_tag(win).lower() != "tableviewtablewinsaveinfo":
                continue
            caption = ""
            position: Dict[str, Any] = {}
            for child in win:
                ctag = local_tag(child).lower()
                if ctag == "caption":
                    caption = text_of(child)
                elif ctag == "pos":
                    for coord in child:
                        coord_tag = local_tag(coord)
                        if coord_tag in ("Left", "Top", "Width", "Height"):
                            value = text_of(coord)
                            if value:
                                try:
                                    position[coord_tag] = int(value)
                                except ValueError:
                                    position[coord_tag] = value
            if caption:
                layout.append({"table": caption, "position": position})

        if layout:
            result["table_layout"] = layout
