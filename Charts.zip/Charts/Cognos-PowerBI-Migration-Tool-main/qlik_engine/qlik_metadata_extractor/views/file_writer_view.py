"""
views/file_writer_view.py
--------------------------
The "View/Template" rendering layer: takes the extracted raw script and
the parsed metadata model, and persists them as final artifacts
(.txt and .json), using the source .qvw file's base name for both.
"""
import csv
import json
import logging
from pathlib import Path
from typing import Union, Dict, Any, List, Optional

from qlik_metadata_extractor.models.metadata_model import ScriptMetadata

logger = logging.getLogger(__name__)


class FileWriterView:

    def __init__(
        self,
        txt_output_dir: Path,
        json_output_dir: Path,
        visual_metadata_output_dir: Optional[Path] = None,
    ):
        self.txt_output_dir = Path(txt_output_dir)
        self.json_output_dir = Path(json_output_dir)
        self.visual_metadata_output_dir = (
            Path(visual_metadata_output_dir) if visual_metadata_output_dir else None
        )

    def write_script_txt(self, qvw_path: Path, raw_script: str) -> Path:
        out_path = self.txt_output_dir / f"{Path(qvw_path).stem}.txt"
        out_path.write_text(raw_script, encoding="utf-8")
        logger.info(f"Raw script written to: {out_path}")
        return out_path

    def write_metadata_json(
        self, qvw_path: Path, metadata: Union[ScriptMetadata, Dict[str, Any]]
    ) -> Path:
        """
        Accepts either the legacy `ScriptMetadata` dataclass (COM path)
        or the plain, extended metadata dict produced by
        `PRJMetadataService` (PRJ path) - both serialize the same way,
        so callers don't need to branch.
        """
        out_path = self.json_output_dir / f"{Path(qvw_path).stem}.json"
        if isinstance(metadata, ScriptMetadata):
            out_path.write_text(metadata.to_json(), encoding="utf-8")
        else:
            out_path.write_text(json.dumps(metadata, indent=4, ensure_ascii=False), encoding="utf-8")
        logger.info(f"Metadata JSON written to: {out_path}")
        return out_path

    def write_visual_metadata(
        self, qvw_path: Path, metadata: Dict[str, Any]
    ) -> Dict[str, Path]:
        """
        Writes the consolidated visual-metadata repository built by
        `VisualMetadataService`:
          - one nested JSON (report -> sheets -> visuals, groups,
            variable usage, bookmarks) for review or as input to the
            report-generation engine.
          - one CSV per flat table (sheets, visuals, dimensions,
            measures, variable_usage) for anyone who wants to review
            or edit this in a spreadsheet instead.

        No-ops (returns {}) if the metadata dict has no visual_metadata
        section (e.g. it wasn't PRJ-sourced) or no output dir was
        configured.
        """
        visual_metadata = metadata.get("visual_metadata")
        if not visual_metadata or self.visual_metadata_output_dir is None:
            return {}

        written: Dict[str, Path] = {}
        stem = Path(qvw_path).stem

        self.visual_metadata_output_dir.mkdir(parents=True, exist_ok=True)
        json_path = self.visual_metadata_output_dir / f"{stem}_visual_metadata.json"
        json_path.write_text(json.dumps(visual_metadata, indent=4, ensure_ascii=False), encoding="utf-8")
        logger.info(f"Visual metadata JSON written to: {json_path}")
        written["json"] = json_path

        tables = metadata.get("visual_metadata_tables", {}) or {}
        csv_dir = self.visual_metadata_output_dir / "csv"
        csv_dir.mkdir(parents=True, exist_ok=True)
        for table_name, rows in tables.items():
            csv_path = csv_dir / f"{stem}_{table_name}.csv"
            self._write_csv(csv_path, rows)
            written[f"csv_{table_name}"] = csv_path

        return written

    # ------------------------------------------------------------------
    @staticmethod
    def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        # Column set is the union of keys across all rows, since not
        # every row (e.g. a chart with no dimensions) has the same
        # shape - csv.DictWriter needs a fixed fieldname list up front.
        fieldnames: List[str] = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)

        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                # Dict/list values (e.g. number_format, color) don't fit
                # a CSV cell - serialize them to compact JSON text so
                # nothing is silently dropped.
                flat_row = {
                    k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v)
                    for k, v in row.items()
                }
                writer.writerow(flat_row)
        logger.info(f"Visual metadata CSV written to: {path}")
