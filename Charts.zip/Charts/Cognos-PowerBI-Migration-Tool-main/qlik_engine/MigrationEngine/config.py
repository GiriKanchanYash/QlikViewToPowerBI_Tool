"""
MigrationEngine/config.py
--------------------------
Central configuration for the Qlik -> Power BI Migration Engine.
Mirrors the style of qlik_metadata_extractor/config.py so the two
packages stay consistent, but is kept self-contained inside
MigrationEngine so this package can be dropped into any workspace
that already has a `Qlik_Script_MetaData` folder of extracted JSON.
"""
from pathlib import Path


class MigrationConfig:
    # Workspace root (parent of the MigrationEngine folder)
    BASE_DIR = Path(__file__).resolve().parent.parent

    # Input: the JSON metadata produced by qlik_metadata_extractor
    METADATA_INPUT_DIR = BASE_DIR / "Qlik_Script_MetaData"

    # Input: the visual metadata repository produced by qlik_metadata_extractor
    # (report -> sheets -> visuals). Consumed by report_visual_generator to
    # populate actual Power BI report pages/visuals into the PBIP scaffold.
    VISUAL_METADATA_INPUT_DIR = BASE_DIR / "Qlik_Visual_MetaData"

    # Output: everything the Migration Engine generates lands here
    POWERBI_OUTPUT_DIR = BASE_DIR / "PowerBIScript"
    M_QUERY_OUTPUT_DIR = POWERBI_OUTPUT_DIR / "MQueries"
    DAX_OUTPUT_DIR = POWERBI_OUTPUT_DIR / "DAX"
    RELATIONSHIP_OUTPUT_DIR = POWERBI_OUTPUT_DIR / "Relationships"
    PBIP_OUTPUT_DIR = POWERBI_OUTPUT_DIR / "PBIP"

    # File extension used for saved Power Query M scripts
    M_QUERY_EXTENSION = ".pq"

    @classmethod
    def ensure_dirs(cls) -> None:
        for d in (
            cls.POWERBI_OUTPUT_DIR,
            cls.M_QUERY_OUTPUT_DIR,
            cls.DAX_OUTPUT_DIR,
            cls.RELATIONSHIP_OUTPUT_DIR,
            cls.PBIP_OUTPUT_DIR,
        ):
            d.mkdir(parents=True, exist_ok=True)
