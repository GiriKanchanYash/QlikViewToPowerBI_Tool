"""
MigrationEngine/visual_metadata_loader.py
------------------------------------------
Reads the visual metadata repository produced by
qlik_metadata_extractor (Qlik_Visual_MetaData/<app>_visual_metadata.json)
-- report -> sheets -> visuals -- so report_visual_generator can turn it
into actual Power BI report pages/visuals.

Kept separate from MigrationEngine.metadata_parser because that module
reads the *data-model* JSON (Qlik_Script_MetaData); this one reads the
*visual* JSON (Qlik_Visual_MetaData). An app migrates fine without a
visual metadata file (older extractor runs, or apps with no sheets
worth migrating) -- this loader treats a missing file as "no visuals",
not an error, so Stage 2 can still produce the semantic-model scaffold.
"""
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from .config import MigrationConfig
from .utils import qvw_base_name, sanitize_filename

logger = logging.getLogger(__name__)


class VisualMetadataLoader:

    def __init__(self, visual_metadata_dir: Path = MigrationConfig.VISUAL_METADATA_INPUT_DIR):
        self.visual_metadata_dir = Path(visual_metadata_dir)

    def path_for_app(self, app_name: str) -> Path:
        return self.visual_metadata_dir / f"{sanitize_filename(app_name)}_visual_metadata.json"

    def load_for_app(self, app_name: str) -> Optional[Dict[str, Any]]:
        """
        Load the visual metadata repository for one app (matched by the
        same base name used everywhere else: qvw_base_name(script_name)).
        Returns None (and logs a warning) if the file is absent, unreadable,
        or malformed, so callers can skip visual generation gracefully.
        """
        path = self.path_for_app(app_name)
        if not path.exists():
            logger.warning(f"No visual metadata found for '{app_name}' at {path} - skipping report visuals.")
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as exc:
            logger.warning(f"Invalid JSON in {path}: {exc} - skipping report visuals for '{app_name}'.")
            return None

    def load_for_metadata(self, metadata: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convenience wrapper: derive the app name from a Stage-1 data-model
        metadata dict (as loaded by MetadataParser) and load its visuals."""
        app_name = qvw_base_name(metadata.get("script_name", "UnknownApp.qvw"))
        return self.load_for_app(app_name)
