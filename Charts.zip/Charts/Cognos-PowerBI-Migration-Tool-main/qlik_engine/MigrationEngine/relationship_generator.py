"""
MigrationEngine/relationship_generator.py
--------------------------------------------
Infers candidate Power BI model relationships from the shared "keys"
QlikView's associative model built implicitly, and cross-checks them
against the parser's synthetic-key warnings so risky/ambiguous
associations are called out instead of silently modeled.

QlikView has no explicit relationship syntax - tables just associate
on same-named fields. Power BI needs an explicit one-to-many (or
many-to-many) relationship per table pair, so this module has to
*infer* what QlikView left implicit.
"""
import logging
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, List, Set

from .config import MigrationConfig
from .utils import qvw_base_name, sanitize_filename, write_text_file

logger = logging.getLogger(__name__)


class RelationshipGenerator:

    def __init__(self, output_dir: Path = MigrationConfig.RELATIONSHIP_OUTPUT_DIR):
        self.output_dir = Path(output_dir)

    @staticmethod
    def _risky_pairs(metadata: Dict[str, Any]) -> Set[frozenset]:
        """Table-name pairs already flagged as synthetic-key risks."""
        risky = set()
        for entry in metadata.get("synthetic_keys", []) or []:
            tables = entry.get("tables", [])
            if len(tables) == 2:
                risky.add(frozenset(tables))
        return risky

    @staticmethod
    def _find(parent: Dict[str, str], node: str) -> str:
        """Union-Find 'find' with path compression."""
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    @classmethod
    def _union(cls, parent: Dict[str, str], a: str, b: str) -> bool:
        """Union-Find 'union'. Returns False if a and b were already in the
        same set (i.e. joining them would create a cycle / second path)."""
        root_a, root_b = cls._find(parent, a), cls._find(parent, b)
        if root_a == root_b:
            return False
        parent[root_a] = root_b
        return True

    def infer_relationships(self, metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        For every key field in metadata['keys'], find every pair of
        tables that both contain that field and propose a relationship.
        Cardinality is left as "1:* (verify)" since the JSON metadata
        has no uniqueness information to confirm the "one" side.

        IMPORTANT: unlike QlikView's associative model (which happily lets
        every table associate on every shared field, forming cycles),
        Power BI's tabular engine only allows ONE active filter path
        between any two tables. Connecting every pair that shares a key
        (a complete graph) guarantees "ambiguous paths" errors on load as
        soon as 3+ tables share the same key field.

        To avoid that, relationships are built as a spanning tree/forest
        across the whole model: a candidate relationship is only kept if
        the two tables aren't already connected (directly or transitively)
        by a relationship added earlier. Skipped candidates are still
        returned (marked "skipped_ambiguous") so the relationship report
        can tell the person what was left out and why.
        """
        tables = metadata.get("tables", []) or []
        keys = metadata.get("keys", []) or []
        risky_pairs = self._risky_pairs(metadata)

        parent: Dict[str, str] = {t["name"]: t["name"] for t in tables}

        relationships: List[Dict[str, Any]] = []
        for key_field in keys:
            tables_with_key = [t["name"] for t in tables if key_field in (t.get("fields") or [])]
            for table_a, table_b in combinations(sorted(tables_with_key), 2):
                pair = frozenset((table_a, table_b))
                connects = self._union(parent, table_a, table_b)
                relationships.append(
                    {
                        "from_table": table_a,
                        "to_table": table_b,
                        "on_field": key_field,
                        "cardinality": "1:* (verify)",
                        "risky": pair in risky_pairs,
                        # False means this candidate would have created a
                        # second path between two already-connected tables
                        # (an ambiguous path in Power BI) and was left out
                        # of the .tmdl output; it's kept here only for the
                        # markdown report.
                        "active": connects,
                    }
                )
        return relationships

    def generate_report(self, metadata: Dict[str, Any]) -> str:
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        relationships = self.infer_relationships(metadata)

        lines = [
            f"# Candidate Power BI relationships for: {script_name}",
            "",
            "QlikView associates tables implicitly on same-named fields. ",
            "Power BI needs each relationship created explicitly (Model view ",
            "-> Manage relationships), so review every row below before ",
            "building the model - cardinality and cross-filter direction are ",
            "best guesses, not guarantees.",
            "",
        ]

        if not relationships:
            lines.append("No shared key fields were found between tables in this app.")
            return "\n".join(lines) + "\n"

        lines.append("| From table | To table | On field | Suggested cardinality | Status | Risk |")
        lines.append("|---|---|---|---|---|---|")
        for rel in relationships:
            risk = "SYNTHETIC KEY RISK - review before modeling" if rel["risky"] else "-"
            status = "Active" if rel.get("active", True) else "SKIPPED (would create ambiguous path)"
            lines.append(
                f"| {rel['from_table']} | {rel['to_table']} | {rel['on_field']} "
                f"| {rel['cardinality']} | {status} | {risk} |"
            )

        skipped_count = sum(1 for r in relationships if not r.get("active", True))
        if skipped_count:
            lines.append("")
            lines.append(
                f"{skipped_count} candidate relationship(s) above were left out of the "
                f".tmdl model because the two tables were already connected through "
                f"another relationship - adding them too would create multiple paths "
                f"between the same tables, which Power BI rejects as \"ambiguous paths\" "
                f"on load (QlikView's associative model allows this; Power BI's tabular "
                f"engine doesn't). If you need one of these specifically, remove/redirect "
                f"the conflicting relationship in Power BI Desktop first."
            )

        risky_count = sum(1 for r in relationships if r["risky"])
        if risky_count:
            lines.append("")
            lines.append(
                f"{risky_count} relationship(s) above involve tables that the "
                f"Qlik script parser flagged as sharing multiple fields "
                f"(QlikView synthetic-key territory). In Power BI this "
                f"usually means: pick a single real key column, or build a "
                f"proper bridge/dimension table instead of relating on every "
                f"shared field."
            )

        return "\n".join(lines) + "\n"

    def write_report_for_metadata(self, metadata: Dict[str, Any]) -> Path:
        base = sanitize_filename(qvw_base_name(metadata.get("script_name", "UnknownApp.qvw")))
        out_path = self.output_dir / f"{base}_Relationships.md"
        write_text_file(out_path, self.generate_report(metadata))
        logger.info(f"Relationship report written: {out_path}")
        return out_path

    def write_reports_for_all(self, parser) -> List[Path]:
        return [self.write_report_for_metadata(m) for m in parser.load_all()]