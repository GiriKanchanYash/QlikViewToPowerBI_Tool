"""
MigrationEngine/pbip_generator.py
------------------------------------
Assembles a minimal Power BI Project (PBIP/TMDL) scaffold per migrated
Qlik app, wiring together the outputs of the other three generators:
    - m_query_generator   -> each table's M partition source
    - dax_generator       -> starter measures added to the model
    - relationship_generator -> relationships.tmdl

This produces a *scaffold*, not a guaranteed-to-open Power BI project:
TMDL/PBIP is a rich format and the JSON metadata this engine works
from (load-script structure only, no report visuals/layout) can't
reconstruct a full report. The goal is to save the person the
boilerplate of the semantic-model side (tables, M sources,
relationships, starter measures) so they open it in Power BI Desktop,
let it validate/repair, and take it from there.

Layout produced per app, under PowerBIScript/PBIP/<AppName>/:
    <AppName>.pbip
    <AppName>.SemanticModel/definition/database.tmdl
    <AppName>.SemanticModel/definition/model.tmdl
    <AppName>.SemanticModel/definition/relationships.tmdl
    <AppName>.SemanticModel/definition/tables/<table>.tmdl
"""
import logging
import uuid
from pathlib import Path
from typing import Any, Dict, List

from .config import MigrationConfig
from .dax_generator import DaxGenerator
from .m_query_generator import MQueryGenerator
from .metadata_parser import MetadataParser
from .relationship_generator import RelationshipGenerator
from .utils import (
    qvw_base_name,
    quote_m_identifier,
    quote_tmdl_identifier,
    resolve_field_type,
    sanitize_filename,
    write_text_file,
)

logger = logging.getLogger(__name__)


class PbipGenerator:

    def __init__(
        self,
        output_dir: Path = MigrationConfig.PBIP_OUTPUT_DIR,
        m_query_generator: MQueryGenerator = None,
        dax_generator: DaxGenerator = None,
        relationship_generator: RelationshipGenerator = None,
    ):
        self.output_dir = Path(output_dir)
        self.m_query_generator = m_query_generator or MQueryGenerator()
        self.dax_generator = dax_generator or DaxGenerator()
        self.relationship_generator = relationship_generator or RelationshipGenerator()

    # ------------------------------------------------------------------
    # TMDL fragment builders
    # ------------------------------------------------------------------
    @staticmethod
    def _table_tmdl(table: Dict[str, Any], m_query: str, measures: List[str]) -> str:
        table_name = table.get("name", "UnnamedTable")
        fields = table.get("fields", []) or []
        field_type_tags: Dict[str, List[str]] = table.get("field_type_tags") or {}
        derived_expressions: Dict[str, str] = table.get("derived_fields") or {}

        lines = [f"table {quote_tmdl_identifier(table_name)}", ""]
        if table.get("is_mapping"):
            # A Qlik MAPPING LOAD table is a lookup structure ApplyMap()
            # reads from during script execution -- Qlik itself never
            # exposes it as a report-facing table in the associative
            # model, so it shouldn't become a normal *visible* Power BI
            # table either. It still needs to exist and be queryable
            # (the generated ApplyMap() M code references it directly),
            # just hidden from the report's field list.
            lines.append("\tisHidden")
            lines.append("")
        for f in fields:
            _, tmdl_type = resolve_field_type(field_type_tags.get(f), derived_expressions.get(f))
            lines.append(f"\tcolumn {quote_tmdl_identifier(f)}")
            lines.append(f"\t\tdataType: {tmdl_type}")
            lines.append("\t\tsummarizeBy: none")
            lines.append(f"\t\tsourceColumn: {f}")
            lines.append("")

        for measure in measures:
            lines.append(f"\tmeasure {measure}")
            lines.append("")

        # TMDL indentation rules for a multi-line property value (like
        # "source ="):
        #   1) TABS ONLY -- mixing in the spaces that m_query_generator uses
        #      for its own cosmetic M-code indentation produces a line like
        #      "\t\t    Source = ..." which the parser rejects as mixed
        #      indentation.
        #   2) The expression body must be indented STRICTLY DEEPER than the
        #      "source =" property line itself. "source =" sits at 2 tabs
        #      (it's a child of "partition", which is 1 tab), so the body
        #      ("let", "Source = ...", "in", ...) must start at 3 tabs, not
        #      2 -- equal indentation is what previously caused
        #      "Invalid indentation was detected!" on the "let" line.
        # Strip each M line's own leading whitespace first, then apply a
        # single, uniform, deeper tab level to every line.
        indented_m = "\n".join(
            ("\t\t\t" + ln.lstrip(" \t")) if ln.strip() else "" for ln in m_query.splitlines()
        )
        lines.append("\tpartition Source = m")
        lines.append("\t\tmode: import")
        lines.append("\t\tsource =")
        lines.append(indented_m)
        lines.append("")
        return "\n".join(lines)

    @staticmethod
    def _relationships_tmdl(relationships: List[Dict[str, Any]]) -> str:
        # Only write relationships that survived the spanning-tree check in
        # RelationshipGenerator.infer_relationships(). Anything marked
        # active=False was deliberately left out because including it would
        # create a second path between two already-connected tables --
        # exactly what Power BI rejects as "ambiguous paths" on load.
        #
        # NOTE: risky/synthetic-key relationships are NOT flagged with a
        # `//` comment in this file. Two different comment placements
        # (indented under the relationship, and as a standalone top-level
        # line) both made Power BI Desktop's TMDL parser reject the whole
        # project ("Invalid indentation" / "Unexpected line type: Other").
        # That information is already fully documented -- with more detail
        # than a one-line comment could carry -- in the relationship
        # report RelationshipGenerator writes alongside this file
        # (<App>_Relationships.md), so it isn't duplicated here at all.
        active_relationships = [r for r in relationships if r.get("active", True)]

        lines = []
        for i, rel in enumerate(active_relationships, start=1):
            lines.append(f"relationship Rel_{i}")
            lines.append(f"\tfromColumn: {quote_tmdl_identifier(rel['from_table'])}.{quote_tmdl_identifier(rel['on_field'])}")
            lines.append(f"\ttoColumn: {quote_tmdl_identifier(rel['to_table'])}.{quote_tmdl_identifier(rel['on_field'])}")
            lines.append("")
        return "\n".join(lines) if lines else ""

    @staticmethod
    def _platform_file(item_type: str, display_name: str) -> str:
        """Every Fabric/PBIP item folder (.Report, .SemanticModel) needs
        its own .platform file declaring the item's type, display name,
        and a stable logicalId - Power BI Desktop's schema validation
        can't resolve the folder's contents (pages, tables, ...)
        without it, and will fail with generic errors like "The report
        has no pages" even when the pages/visuals are physically
        present on disk."""
        import json as _json

        return _json.dumps(
            {
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
                "metadata": {"type": item_type, "displayName": display_name},
                "config": {"version": "2.0", "logicalId": str(uuid.uuid4())},
            },
            indent=2,
        ) + "\n"

    @staticmethod
    def _pbip_file(app_name: str) -> str:
        return (
            "{\n"
            '  "version": "1.0",\n'
            '  "artifacts": [\n'
            "    {\n"
            f'      "report": {{\n'
            f'        "path": "{app_name}.Report"\n'
            "      }\n"
            "    }\n"
            "  ],\n"
            '  "settings": {\n'
            '    "enableAutoRecovery": true\n'
            "  }\n"
            "}\n"
        )

    @staticmethod
    def _database_tmdl(app_name: str) -> str:
        return f"database {quote_tmdl_identifier(app_name)}\n\tcompatibilityLevel: 1567\n"

    # ------------------------------------------------------------------
    # Minimal Report artifact (PBIR) -- required for the .pbip to open.
    # Power BI Desktop refuses to open a .pbip whose declared Report
    # artifact is missing, even if the semantic model is perfectly
    # valid. This generates the smallest possible blank-page report so
    # Desktop opens cleanly; the person then builds visuals themselves.
    # ------------------------------------------------------------------
    @staticmethod
    def _pbism_file() -> str:
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",\n'
            '  "version": "4.2",\n'
            '  "settings": {\n'
            '    "qnaEnabled": false\n'
            "  }\n"
            "}\n"
        )

    @staticmethod
    def _definition_pbir(app_name: str) -> str:
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",\n'
            '  "version": "4.0",\n'
            '  "datasetReference": {\n'
            '    "byPath": {\n'
            f'      "path": "../{app_name}.SemanticModel"\n'
            "    }\n"
            "  }\n"
            "}\n"
        )

    @staticmethod
    def _report_json() -> str:
        # Schema/shape verified against a PBIP that Power BI Desktop opens
        # successfully (report/3.3.0, with objects.outspacePane rather than
        # the older top-level "layoutOptimization" key). Do not revert this
        # to report/1.2.0 - that older shape is what caused Desktop to
        # reject/blank out the generated report.
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json",\n'
            '  "themeCollection": {},\n'
            '  "objects": {\n'
            '    "outspacePane": [\n'
            "      {\n"
            '        "properties": {\n'
            '          "expanded": {\n'
            '            "expr": {\n'
            '              "Literal": {\n'
            '                "Value": "false"\n'
            "              }\n"
            "            }\n"
            "          }\n"
            "        }\n"
            "      }\n"
            "    ]\n"
            "  }\n"
            "}\n"
        )

    @staticmethod
    def _report_version_json() -> str:
        # Must carry its own $schema (versionMetadata, not the report
        # schema) and version "2.0.0" - the bare {"version": "4.0"} this
        # used to emit doesn't match what Desktop writes for version.json
        # and was flagged during comparison against a working PBIP.
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",\n'
            '  "version": "2.0.0"\n'
            "}\n"
        )

    @staticmethod
    def _pages_json(page_name: str) -> str:
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json",\n'
            f'  "pageOrder": ["{page_name}"],\n'
            f'  "activePageName": "{page_name}"\n'
            "}\n"
        )

    @staticmethod
    def _page_json(page_name: str) -> str:
        return (
            "{\n"
            '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json",\n'
            f'  "name": "{page_name}",\n'
            '  "displayName": "Page 1",\n'
            '  "displayOption": "FitToPage",\n'
            '  "height": 720,\n'
            '  "width": 1280\n'
            "}\n"
        )

    def _write_blank_report(self, app_root: Path, app_name: str) -> None:
        report_dir = app_root / f"{app_name}.Report"
        page_name = "ReportSection1"

        write_text_file(report_dir / ".platform", self._platform_file("Report", app_name))
        write_text_file(report_dir / "definition.pbir", self._definition_pbir(app_name))
        write_text_file(report_dir / "definition" / "report.json", self._report_json())
        write_text_file(report_dir / "definition" / "version.json", self._report_version_json())
        write_text_file(report_dir / "definition" / "pages" / "pages.json", self._pages_json(page_name))
        write_text_file(
            report_dir / "definition" / "pages" / page_name / "page.json",
            self._page_json(page_name),
        )

        model_root = app_root / f"{app_name}.SemanticModel"
        write_text_file(model_root / ".platform", self._platform_file("SemanticModel", app_name))
        write_text_file(model_root / "definition.pbism", self._pbism_file())

    @staticmethod
    def _model_tmdl(table_names: List[str]) -> str:
        lines = [
            "model Model",
            "\tculture: en-US",
            "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
            "\tsourceQueryCulture: en-US",
            "",
        ]
        for name in table_names:
            lines.append(f"ref table {quote_tmdl_identifier(name)}")
        return "\n".join(lines) + "\n"

    # ------------------------------------------------------------------
    # Orchestration
    # ------------------------------------------------------------------
    def generate_for_metadata(self, metadata: Dict[str, Any], parser: MetadataParser) -> Path:
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        app_name = sanitize_filename(qvw_base_name(script_name))
        app_root = self.output_dir / app_name
        model_dir = app_root / f"{app_name}.SemanticModel" / "definition"
        tables_dir = model_dir / "tables"

        enriched_tables = parser.enrich_tables(metadata)
        known_tables = {t["name"] for t in enriched_tables}
        variables = parser.build_variable_map(metadata)
        chain_context = self.m_query_generator._build_chain_context(metadata, parser, enriched_tables)
        m_queries = {
            t["name"]: self.m_query_generator.generate_table_query(
                t, known_tables=known_tables, variables=variables, chain_context=chain_context
            )
            for t in enriched_tables
        }
        relationships = self.relationship_generator.infer_relationships(metadata)

        # One row-count measure per table, matching dax_generator's convention,
        # plus any conditional-formatting color measures derived from sheet
        # objects' ColorExpr - these must live in the real model (not just
        # the advisory .dax file) since conditional formatting binds to an
        # actual measure.
        _object_color_measure, color_measures_by_table, _color_notes = self.dax_generator.color_measures_for_metadata(
            metadata
        )
        # Same reasoning for Statistics box measures: a single-statistic
        # box becomes a Card bound to a real measure on its own table
        # (folded into color_measures_by_table's per-table list below);
        # a multi-statistic box becomes its own small calculated
        # Metric/Value table, written and registered alongside the real
        # ones. See DaxGenerator.statistics_measures_for_metadata.
        _stat_binding, stat_measures_by_table, stat_calculated_tables, _stat_notes = (
            self.dax_generator.statistics_measures_for_metadata(metadata)
        )
        for table in enriched_tables:
            measures = [self.dax_generator.row_count_measure(table["name"])]
            measures.extend(color_measures_by_table.get(table["name"], []))
            measures.extend(stat_measures_by_table.get(table["name"], []))
            write_text_file(
                tables_dir / f"{sanitize_filename(table['name'])}.tmdl",
                self._table_tmdl(table, m_queries[table["name"]], measures),
            )
        for calc_table_name, calc_table_tmdl in stat_calculated_tables.items():
            write_text_file(tables_dir / f"{sanitize_filename(calc_table_name)}.tmdl", calc_table_tmdl)

        write_text_file(model_dir / "relationships.tmdl", self._relationships_tmdl(relationships))
        write_text_file(model_dir / "database.tmdl", self._database_tmdl(app_name))
        write_text_file(
            model_dir / "model.tmdl",
            self._model_tmdl([t["name"] for t in enriched_tables] + list(stat_calculated_tables.keys())),
        )
        write_text_file(app_root / f"{app_name}.pbip", self._pbip_file(app_name))
        self._write_blank_report(app_root, app_name)
        write_text_file(
            app_root / "README_MIGRATION.md",
            (
                f"# {app_name} - migrated scaffold\n\n"
                f"Generated from Qlik metadata for `{script_name}`.\n\n"
                "This is a starting point, not a finished report: it carries "
                "over tables, M sources, inferred relationships and basic "
                "row-count measures. Report visuals/layout have no Qlik "
                "equivalent in the extracted metadata and are not included. "
                "Open the .pbip in Power BI Desktop and let it validate the "
                "semantic model, then build the report canvas from there.\n"
            ),
        )

        logger.info(f"PBIP scaffold written under: {app_root}")
        return app_root

    def generate_for_all(self, parser: MetadataParser) -> List[Path]:
        return [self.generate_for_metadata(m, parser) for m in parser.load_all()]