"""
MigrationEngine
---------------
Qlik -> Power BI migration engine. Consumes the JSON metadata produced
by qlik_metadata_extractor (Qlik_Script_MetaData/*.json) and generates:

    - Power Query M scripts, one per table, named
      "<table_name>_<qvw_file_name>.pq"           (m_query_generator)
    - starter DAX measures, one file per app       (dax_generator)
    - inferred relationship reports, one per app   (relationship_generator)
    - a PBIP/TMDL project scaffold, one per app    (pbip_generator)

All outputs are written under PowerBIScript/ (see config.py).

Typical usage:
    from MigrationEngine import run_migration
    run_migration()
"""
from .config import MigrationConfig
from .metadata_parser import MetadataParser, MetadataParseError
from .m_query_generator import MQueryGenerator
from .dax_generator import DaxGenerator
from .relationship_generator import RelationshipGenerator
from .pbip_generator import PbipGenerator
from .visual_metadata_loader import VisualMetadataLoader
from .report_visual_generator import ReportVisualGenerator

__all__ = [
    "MigrationConfig",
    "MetadataParser",
    "MetadataParseError",
    "MQueryGenerator",
    "DaxGenerator",
    "RelationshipGenerator",
    "PbipGenerator",
    "VisualMetadataLoader",
    "ReportVisualGenerator",
    "run_migration",
]


def run_migration(build_pbip: bool = True, build_report_visuals: bool = True) -> None:
    """
    Run the full migration pipeline over every JSON file in
    Qlik_Script_MetaData/: M queries + DAX measures + relationship
    reports (+ a PBIP scaffold unless build_pbip=False) (+ real report
    pages/visuals generated from Qlik_Visual_MetaData/ unless
    build_report_visuals=False; requires build_pbip=True since it
    populates the PBIP scaffold's Report artifact).
    """
    import logging

    logger = logging.getLogger(__name__)
    MigrationConfig.ensure_dirs()

    parser = MetadataParser()
    m_gen = MQueryGenerator()
    dax_gen = DaxGenerator()
    rel_gen = RelationshipGenerator()

    m_paths = m_gen.write_queries_for_all(parser)
    logger.info(f"Wrote {len(m_paths)} Power Query M file(s) to {m_gen.output_dir}")

    dax_paths = dax_gen.write_dax_for_all(parser)
    logger.info(f"Wrote {len(dax_paths)} DAX measure file(s) to {dax_gen.output_dir}")

    rel_paths = rel_gen.write_reports_for_all(parser)
    logger.info(f"Wrote {len(rel_paths)} relationship report(s) to {rel_gen.output_dir}")

    if build_pbip:
        pbip_gen = PbipGenerator(
            m_query_generator=m_gen,
            dax_generator=dax_gen,
            relationship_generator=rel_gen,
        )
        pbip_paths = pbip_gen.generate_for_all(parser)
        logger.info(f"Wrote {len(pbip_paths)} PBIP scaffold(s) to {pbip_gen.output_dir}")

        if build_report_visuals:
            visual_loader = VisualMetadataLoader()
            report_visual_gen = ReportVisualGenerator(pbip_output_dir=pbip_gen.output_dir)
            visual_paths = report_visual_gen.generate_for_all(parser, visual_loader)
            logger.info(f"Populated report visuals for {len(visual_paths)} app(s)")
