"""
MigrationEngine/metadata_parser.py
-----------------------------------
Reads the JSON metadata produced by qlik_metadata_extractor
(Qlik_Script_MetaData/<name>.json) and reshapes it into the flat,
generator-friendly structures the rest of the Migration Engine
consumes (source lookup per table, alias/rename map, etc.).

This module never talks to QlikView or Power BI directly - it only
understands the JSON schema documented in
qlik_metadata_extractor/models/metadata_model.py.
"""
import json
import logging
from pathlib import Path
from typing import Any, Dict, List

from .config import MigrationConfig
from .utils import qvw_base_name

logger = logging.getLogger(__name__)

# Every metadata field that carries {"table": ..., "path": ...} entries,
# mapped to the source-type label we want on each table.
_SOURCE_FIELDS = {
    "qvd_sources": "QVD",
    "csv_sources": "CSV/TXT",
    "excel_sources": "EXCEL",
    "sql_sources": "SQL",
    "fixed_width_sources": "FIXEDWIDTH",
    "xml_sources": "XML",
}


class MetadataParseError(Exception):
    """Raised when a metadata JSON file can't be read or is malformed."""


class MetadataParser:
    """Loads one or many extracted-metadata JSON files for migration."""

    def __init__(self, metadata_dir: Path = MigrationConfig.METADATA_INPUT_DIR):
        self.metadata_dir = Path(metadata_dir)

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def load_file(self, json_path: Path) -> Dict[str, Any]:
        json_path = Path(json_path)
        if not json_path.exists():
            raise MetadataParseError(f"Metadata file not found: {json_path}")
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                metadata = json.load(f)
        except json.JSONDecodeError as exc:
            raise MetadataParseError(f"Invalid JSON in {json_path}: {exc}") from exc

        if "script_name" not in metadata:
            raise MetadataParseError(
                f"{json_path} is missing 'script_name' - not a valid "
                f"qlik_metadata_extractor output file."
            )
        return metadata

    def load_all(self) -> List[Dict[str, Any]]:
        """Load every *.json file in the metadata directory, sorted by name."""
        if not self.metadata_dir.exists():
            raise MetadataParseError(f"Metadata directory not found: {self.metadata_dir}")

        json_files = sorted(self.metadata_dir.glob("*.json"))
        if not json_files:
            raise MetadataParseError(f"No metadata JSON files found in: {self.metadata_dir}")

        loaded = []
        for jf in json_files:
            try:
                loaded.append(self.load_file(jf))
            except MetadataParseError as exc:
                logger.warning(f"Skipping {jf.name}: {exc}")
        return loaded

    # ------------------------------------------------------------------
    # Enrichment helpers used by the generators
    # ------------------------------------------------------------------
    @staticmethod
    def build_source_lookup(metadata: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
        """
        Merge qvd_sources / csv_sources / excel_sources / sql_sources into
        a single {table_name: {"source_type": ..., "path": ...}} map.
        excel_sources entries also carry a "sheet_name" (the real Excel
        worksheet, parsed from the `table is <SheetName>` clause) when one
        was found; other source types are left with just source_type/path
        to keep their existing shape unchanged.
        """
        lookup: Dict[str, Dict[str, str]] = {}
        for field_name, source_type in _SOURCE_FIELDS.items():
            for entry in metadata.get(field_name, []) or []:
                table = entry.get("table")
                if not table:
                    continue
                info = {
                    "source_type": source_type,
                    "path": entry.get("path") or entry.get("query") or "",
                }
                if "sheet_name" in entry:
                    info["sheet_name"] = entry["sheet_name"]
                if "fields" in entry:
                    info["fixed_width_fields"] = entry["fields"]
                if "node_path" in entry:
                    info["node_path"] = entry["node_path"]
                lookup[table] = info
        return lookup

    @staticmethod
    def build_variable_map(metadata: Dict[str, Any]) -> Dict[str, str]:
        """
        metadata['variables'] is a list of {"name", "value", "type"}
        (SET/LET) entries from the script. Flattened to a plain
        {name: raw_value} map for expression_translator.expand_variables
        to substitute $(name) references with, generically, regardless
        of which variables any given script happens to define.
        """
        variables: Dict[str, str] = {}
        for entry in metadata.get("variables", []) or []:
            name = entry.get("name")
            value = entry.get("value")
            if name and value is not None:
                variables[name] = str(value)
        return variables

    @staticmethod
    def build_alias_map(metadata: Dict[str, Any]) -> Dict[str, str]:
        """
        derived_fields is a flat, file-wide list of {"expression", "alias"}
        pairs (QlikView `expr AS alias`). Build an alias -> expression map
        so the M generator can note renames on the fields that came from
        an aliased expression rather than a plain source column.

        NOTE: this is file-wide, so if two different tables alias to the
        same name with different expressions, the later one wins. Prefer
        build_alias_map_by_table (used by enrich_tables) when the caller
        cares about a specific table.
        """
        alias_map: Dict[str, str] = {}
        for entry in metadata.get("derived_fields", []) or []:
            expr = entry.get("expression")
            alias = entry.get("alias")
            if expr and alias:
                alias_map[alias] = expr
        return alias_map

    @staticmethod
    def build_alias_map_by_table(metadata: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
        """
        Same as build_alias_map, but keyed per-table first:
        {table_name: {alias: expression}}. Each derived_fields entry
        already carries its own "table", so this just groups by it
        instead of flattening everything into one global namespace --
        avoids collisions when two tables happen to use the same alias
        name for two different expressions (e.g. every fact table in a
        star schema deriving its own "RowHash").
        """
        by_table: Dict[str, Dict[str, str]] = {}
        for entry in metadata.get("derived_fields", []) or []:
            table = entry.get("table")
            expr = entry.get("expression")
            alias = entry.get("alias")
            if table and expr and alias:
                by_table.setdefault(table, {})[alias] = expr
        return by_table

    @staticmethod
    def build_load_chain_stages(metadata: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """
        {table_name: [stage, ...]} for every table that was parsed as a
        PRECEDING LOAD chain (script_parser_service.preceding_loads),
        ordered innermost/source stage first. Each stage is reshaped to
        {"fields": [...], "derived": {alias: expression}} -- the dict
        form the M generator's per-stage AddColumn logic expects.
        Tables with no chain simply won't have an entry here.
        """
        by_table: Dict[str, List[Dict[str, Any]]] = {}
        for entry in metadata.get("preceding_loads", []) or []:
            table = entry.get("table")
            stages = entry.get("stages")
            if not table or not stages:
                continue
            by_table[table] = [
                {
                    "fields": stage.get("fields", []) or [],
                    "derived": {
                        d["alias"]: d["expression"]
                        for d in (stage.get("derived") or [])
                        if d.get("alias") and d.get("expression")
                    },
                }
                for stage in stages
            ]
        return by_table

    @staticmethod
    def build_inline_data_lookup(metadata: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """{table_name: {"fields": [...], "rows": [[...], ...]}} for INLINE LOAD tables."""
        lookup: Dict[str, Dict[str, Any]] = {}
        for entry in metadata.get("inline_tables", []) or []:
            table = entry.get("table")
            if table:
                lookup[table] = {"fields": entry.get("fields", []), "rows": entry.get("rows", [])}
        return lookup

    @staticmethod
    def build_joins_by_target_table(metadata: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Groups metadata['joins'] (JOIN/KEEP entries) by the table they
        target, in script order -- generic over any number of joins
        against any table. A table can have more than one JOIN/KEEP
        applied in sequence (each in its own list entry), matching how
        Qlik itself applies them one after another in the order written.
        """
        by_table: Dict[str, List[Dict[str, Any]]] = {}
        for entry in metadata.get("joins", []) or []:
            target = entry.get("target_table")
            if target:
                by_table.setdefault(target, []).append(entry)
        return by_table

    @staticmethod
    def build_resident_occurrence_counts(metadata: Dict[str, Any]) -> Dict[str, int]:
        """
        How many separate `<Name>: LOAD ... RESIDENT ...` definitions the
        script has for each table name (i.e. how many resident_loads
        entries have that name as "new_table"). QlikView scripts commonly
        reuse a table name across a DROP TABLE + reload sequence (a
        reshape/rename-roundtrip idiom - see
        MQueryGenerator._resolve_dead_table_chain); once a name has been
        reused, a downstream RESIDENT reference to that name by itself is
        ambiguous (which occurrence?) without also tracking script
        position, so callers use this count to detect when it's NOT safe
        to reconstruct a dropped table's chain purely by name.
        """
        counts: Dict[str, int] = {}
        for entry in metadata.get("resident_loads", []) or []:
            name = entry.get("new_table")
            if name:
                counts[name] = counts.get(name, 0) + 1
        return counts

    @staticmethod
    def build_resident_source_lookup(metadata: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """
        {table_name: {"source_table":..., "where":..., "group_by":[...],
        "order_by":[...], "is_distinct": bool}} for every RESIDENT-sourced
        table. Last entry wins if a table somehow has more than one (script
        order determines which RESIDENT clause actually applies).
        """
        lookup: Dict[str, Dict[str, Any]] = {}
        for entry in metadata.get("resident_loads", []) or []:
            table = entry.get("new_table")
            if table:
                lookup[table] = {
                    "source_table": entry.get("source_table"),
                    "where": entry.get("where"),
                    "group_by": entry.get("group_by", []) or [],
                    "order_by": entry.get("order_by", []) or [],
                    "is_distinct": entry.get("is_distinct", False),
                }
        return lookup

    def enrich_tables(self, metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Return metadata['tables'] with each table dict augmented with:
          - source_type ("QVD" / "CSV/TXT" / "EXCEL" / "SQL" / "UNKNOWN")
          - source_path (best-effort; "" if not found, e.g. RESIDENT/INLINE)
          - sheet_name (EXCEL only; the actual worksheet name parsed from
            the `table is <SheetName>` clause; "" if not found, e.g. no
            such clause was present in the FROM format spec)
          - script_name (parent .qvw file name, handy for downstream naming)
          - field_type_tags ({field: [tag, ...]}; DocInternals.xml's
            engine-computed $integer/$numeric/$timestamp/$text/... tags
            for this table's own fields, when the PRJ extraction found
            any - empty for COM-path metadata or a PRJ export whose
            DocInternals.xml didn't populate FieldTags. Consumed by
            MQueryGenerator/PbipGenerator to type columns as something
            other than the default text/string.)
        """
        source_lookup = self.build_source_lookup(metadata)
        alias_lookup = self.build_alias_map_by_table(metadata)
        chain_lookup = self.build_load_chain_stages(metadata)
        inline_lookup = self.build_inline_data_lookup(metadata)
        resident_lookup = self.build_resident_source_lookup(metadata)
        table_fields_lookup = {
            t.get("name"): t.get("fields", []) or [] for t in metadata.get("tables", []) or []
        }
        tags_by_field = (metadata.get("document_properties") or {}).get("tags_by_field") or {}
        script_name = metadata.get("script_name", "")

        enriched = []
        for table in metadata.get("tables", []) or []:
            table_name = table.get("name", "UnnamedTable")
            source_info = source_lookup.get(table_name, {})
            resident_info = resident_lookup.get(table_name)
            if resident_info:
                resident_info = {
                    **resident_info,
                    "source_fields": table_fields_lookup.get(resident_info.get("source_table"), []),
                }
            source_type = "RESIDENT" if resident_info else source_info.get("source_type", "UNKNOWN")
            fields = table.get("fields", []) or []
            field_type_tags = {f: tags_by_field[f] for f in fields if f in tags_by_field}
            enriched.append(
                {
                    **table,
                    "script_name": script_name,
                    "source_type": source_type,
                    "source_path": source_info.get("path", ""),
                    "sheet_name": source_info.get("sheet_name", ""),
                    "fixed_width_fields": source_info.get("fixed_width_fields", []),
                    "node_path": source_info.get("node_path", ""),
                    "derived_fields": alias_lookup.get(table_name, {}),
                    "load_chain_stages": chain_lookup.get(table_name),
                    "inline_data": inline_lookup.get(table_name),
                    "resident_source": resident_info,
                    "field_type_tags": field_type_tags,
                }
            )
        return enriched

    @staticmethod
    def base_name(metadata: Dict[str, Any]) -> str:
        return qvw_base_name(metadata.get("script_name", "UnknownApp"))