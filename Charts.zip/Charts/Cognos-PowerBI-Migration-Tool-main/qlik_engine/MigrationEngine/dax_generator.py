"""
MigrationEngine/dax_generator.py
----------------------------------
Produces a starter DAX measures script for each migrated Qlik app.

Two measure sources feed the output:
  - one safe "Row Count" measure per table (a sanity-check measure
    that's useful immediately after import)
  - real chart measures, converted from their Qlik expression when the
    expression is a simple, unambiguous aggregation (Sum/Avg/Min/Max/
    Count/Count(Distinct .../Only) of a single field) - see
    `translate_measure_expression`. Anything more complex (set
    analysis, nested/multi-field formulas, RangeSum, etc.) is emitted
    as a commented-out with the original Qlik expression attached
    rather than guessed at, exactly like the M-query expression
    translator's philosophy: convert what can be converted honestly,
    flag the rest for a human.

Also surfaced:
  - SET/LET variables from the Qlik script, as commented candidates
  - a flag for every synthetic-key warning, so whoever builds the
    model knows which measures need SUM/DISTINCT care due to
    duplicated join keys
  - the document's locale (DocInternals/DocProperties-derived) as a
    FORMAT STRING comment on numeric/date measures, so the DAX the
    person pastes in preserves the source document's number/date
    formatting instead of falling back to whatever culture Power BI
    Desktop happens to default to.
  - conditional-formatting color measures, one per distinct Qlik
    ColorExpr found on a sheet object (almost always a nested
    if(condition, rgb(r,g,b), ...) used to color a KPI text object's
    value) - see `translate_color_expression`. Since the rgb(r,g,b)
    leaves are always literal numbers, they're converted once at
    migration time into hex color strings and only the condition
    itself needs field/operator translation, using the same
    "convert what's unambiguous, flag the rest" approach as chart
    measures. These are embedded directly in each table's .tmdl (by
    PbipGenerator) rather than left as advisory-only text, because
    conditional formatting must bind to a real model measure.
"""
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .config import MigrationConfig
from .expression_translator import _find_matching_paren, _split_call_args
from .utils import qvw_base_name, quote_tmdl_identifier, sanitize_filename, write_text_file

logger = logging.getLogger(__name__)

# Qlik chart-expression aggregation function -> DAX function. Only
# functions whose single-field-argument semantics map cleanly onto a
# DAX aggregation are covered; anything else is left untranslated.
_AGGREGATION_MAP = {
    "sum": "SUM",
    "avg": "AVERAGE",
    "min": "MIN",
    "max": "MAX",
    "count": "COUNT",
    "only": "SELECTEDVALUE",
}
_AGG_PATTERN = re.compile(
    r"^\s*(?P<func>sum|avg|min|max|count|only)\s*\(\s*"
    r"(?P<distinct>distinct\s+)?"
    r"\[?(?P<field>[^()\[\]]+?)\]?\s*\)\s*$",
    re.IGNORECASE,
)


def translate_measure_expression(
    expr: str, field_to_table: Dict[str, str]
) -> Tuple[Optional[str], Optional[str]]:
    """
    Translates a single-field Qlik aggregation expression
    ("Sum(Score)", "Count(distinct [Customer ID])", "Avg(Amount)", ...)
    into an equivalent DAX expression referencing a resolved
    'Table'[Field]. Returns (dax_expression, None) on success, or
    (None, reason) when the expression isn't a pattern this generator
    can confidently convert - the caller is expected to fall back to a
    commented TODO rather than emit something wrong.
    """
    if not expr:
        return None, "empty expression"

    match = _AGG_PATTERN.match(expr)
    if not match:
        return None, "not a simple single-field aggregation"

    func = match.group("func").lower()
    field = match.group("field").strip()
    is_distinct = bool(match.group("distinct"))
    table = field_to_table.get(field)
    if not table:
        return None, f"field '{field}' not found in any migrated table"

    column_ref = f"{quote_tmdl_identifier(table)}[{field}]"

    if func == "count" and is_distinct:
        return f"DISTINCTCOUNT({column_ref})", None
    if func == "only":
        return f"SELECTEDVALUE({column_ref})", None

    dax_func = _AGGREGATION_MAP[func]
    return f"{dax_func}({column_ref})", None


# --- Conditional-formatting (ColorExpr) translation --------------------
# A Qlik ColorExpr on a sheet object is almost always used to color that
# object's displayed value based on the data, e.g.:
#   =if([Home Team Goals]>[Away Team Goals], rgb(0,128,0),
#      if([Home Team Goals]=[Away Team Goals], rgb(0,0,255), rgb(255,0,0)))
# The grammar is narrow and well-defined - (possibly nested) if(cond,
# trueColor, falseColor) calls whose leaves are rgb(r,g,b)/hex colors -
# so it's translated with a small dedicated recursive parser rather than
# the general (and much more limited) chart-measure translator above.
_RGB_LEAF_RE = re.compile(r"^rgb\(\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\)$", re.IGNORECASE)
_HEX_LEAF_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
_IF_CALL_RE = re.compile(r"^if\s*\(", re.IGNORECASE)
_BRACKETED_FIELD_RE = re.compile(r"\[([^\[\]]+)\]")


def _rgb_to_hex(r: str, g: str, b: str) -> str:
    return "#{:02X}{:02X}{:02X}".format(int(r) & 255, int(g) & 255, int(b) & 255)


def _translate_color_condition(cond: str, field_to_table: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
    """
    Translates the boolean condition inside a ColorExpr's if(...) into
    DAX: [Bracketed Field Name] references become 'Table'[Field] (only
    bracketed references are substituted - unlike a bare identifier,
    a bracketed one can't collide with a keyword/operator, so this
    stays safe without needing a full expression grammar), and Qlik's
    'and'/'or' keywords become DAX's '&&'/'||'. Comparison operators
    (>, <, =, <>, >=, <=) are already valid DAX as-is.
    """
    unresolved: List[str] = []

    def _sub(m: "re.Match") -> str:
        field = m.group(1).strip()
        table = field_to_table.get(field)
        if not table:
            unresolved.append(field)
            return m.group(0)
        return f"{quote_tmdl_identifier(table)}[{field}]"

    dax_cond = _BRACKETED_FIELD_RE.sub(_sub, cond)
    if unresolved:
        return None, f"field(s) {', '.join(sorted(set(unresolved)))} not found in any migrated table"
    dax_cond = re.sub(r"(?i)\band\b", "&&", dax_cond)
    dax_cond = re.sub(r"(?i)\bor\b", "||", dax_cond)
    return dax_cond.strip(), None


def _translate_color_leaf(branch: str, field_to_table: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
    branch = branch.strip()
    m = _RGB_LEAF_RE.match(branch)
    if m:
        return f'"{_rgb_to_hex(*m.groups())}"', None
    if _HEX_LEAF_RE.match(branch):
        return f'"{branch.upper()}"', None
    if _IF_CALL_RE.match(branch):
        nested, reason = translate_color_expression(branch, field_to_table)
        return nested, reason
    return None, f"color value '{branch}' is not a literal rgb(r,g,b)/hex color or a nested if()"


def translate_color_expression(expr: str, field_to_table: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
    """
    Translates a Qlik ColorExpr - a (possibly nested)
    if(condition, colorIfTrue, colorIfFalse) expression - into a DAX
    expression that evaluates to a hex color string ("#RRGGBB") Power
    BI's "Format by field value" conditional formatting can consume
    directly. rgb(r,g,b) leaves are computed once here (their
    arguments are always literal numbers, never data-dependent) rather
    than reproduced as a runtime DAX RGB conversion. Returns
    (dax_expression, None) on success, or (None, reason) for anything
    outside this shape - a condition referencing an unmigrated field,
    a leaf that isn't a literal color, malformed parentheses/argument
    count - so the caller can flag it instead of guessing.
    """
    expr = (expr or "").strip()
    if expr.startswith("="):
        expr = expr[1:].strip()
    if not expr:
        return None, "empty expression"

    if not _IF_CALL_RE.match(expr):
        # An unconditional color (just "rgb(...)"/"#RRGGBB" with no
        # if()) is valid too - e.g. a ColorExpr that only overrides
        # the default color without any condition.
        return _translate_color_leaf(expr, field_to_table)

    open_idx = expr.index("(")
    close_idx = _find_matching_paren(expr, open_idx)
    if close_idx != len(expr) - 1:
        return None, "not a plain if(condition, trueColor, falseColor) call"

    args = _split_call_args(expr[open_idx + 1 : close_idx])
    if len(args) != 3:
        return None, f"if() has {len(args)} argument(s) - expected condition, true-color, false-color"

    dax_cond, reason = _translate_color_condition(args[0], field_to_table)
    if dax_cond is None:
        return None, reason
    true_dax, reason = _translate_color_leaf(args[1], field_to_table)
    if true_dax is None:
        return None, reason
    false_dax, reason = _translate_color_leaf(args[2], field_to_table)
    if false_dax is None:
        return None, reason
    return f"IF({dax_cond}, {true_dax}, {false_dax})", None


class DaxGenerator:

    def __init__(self, output_dir: Path = MigrationConfig.DAX_OUTPUT_DIR):
        self.output_dir = Path(output_dir)

    @staticmethod
    def row_count_measure(table_name: str) -> str:
        table_ref = quote_tmdl_identifier(table_name)
        measure_name = f"{table_name} Row Count"
        return (
            f'{quote_tmdl_identifier(measure_name)} = COUNTROWS({table_ref})'
        )

    @staticmethod
    def _variable_comment(variable: Dict[str, Any]) -> str:
        name = variable.get("name", "")
        value = variable.get("value", "")
        vtype = variable.get("type", "SET")
        return (
            f"// Qlik {vtype} variable '{name}' = '{value}'.\n"
            f"// Review whether this belongs in the model as a DAX measure,\n"
            f"// a calculation-group item, or a report-level format string -\n"
            f"// Qlik variables don't map 1:1 onto a single DAX concept."
        )

    @staticmethod
    def _field_to_table(tables: List[Dict[str, Any]]) -> Dict[str, str]:
        """First-table-wins map, same disambiguation rule FieldResolver
        uses in report_visual_generator, so a chart measure resolves to
        the same table its dimensions would."""
        mapping: Dict[str, str] = {}
        for table in tables:
            for field in table.get("fields", []) or []:
                mapping.setdefault(field, table.get("name", ""))
        return mapping

    def color_measures_for_metadata(
        self, metadata: Dict[str, Any]
    ) -> Tuple[Dict[str, Dict[str, str]], Dict[str, List[str]], List[str]]:
        """
        Scans every sheet object's ColorExpr and translates the
        convertible ones into DAX color measures, deduplicating
        identical expressions (the same ColorExpr is typically reused
        across many objects on a sheet) onto a single shared measure.

        Returns:
          - object_color_measure: {object_id: {"table": ..., "measure": ...}}
            for every object whose ColorExpr was successfully translated -
            what report_visual_generator needs to wire up conditional
            formatting on that object's visual.
          - measures_by_table: {table_name: [measure DAX line, ...]} -
            what PbipGenerator embeds into each table's .tmdl, since
            conditional formatting must bind to a real model measure.
          - notes: one entry per ColorExpr that couldn't be converted.
        """
        tables = metadata.get("tables", []) or []
        objects = metadata.get("objects", []) or []
        field_to_table = self._field_to_table(tables)

        object_color_measure: Dict[str, Dict[str, str]] = {}
        measures_by_table: Dict[str, List[str]] = {}
        notes: List[str] = []
        expr_to_binding: Dict[str, Dict[str, str]] = {}
        used_names: set = set()

        for obj in objects:
            color_expr = (obj.get("color_expr") or "").strip()
            if not color_expr:
                continue
            object_id = obj.get("object_id", "object")

            if color_expr in expr_to_binding:
                object_color_measure[object_id] = expr_to_binding[color_expr]
                continue

            dax_expr, reason = translate_color_expression(color_expr, field_to_table)
            if not dax_expr:
                notes.append(
                    f"{object_id}: ColorExpr '{color_expr}' could not be auto-converted "
                    f"({reason}) - add the equivalent conditional formatting manually"
                )
                continue

            referenced_fields = _BRACKETED_FIELD_RE.findall(color_expr)
            table = next((field_to_table[f] for f in referenced_fields if f in field_to_table), None)
            if not table:
                notes.append(
                    f"{object_id}: ColorExpr '{color_expr}' translated to DAX ({dax_expr}) but no "
                    f"target table could be determined - add this measure to the appropriate table manually"
                )
                continue

            measure_name = f"{object_id} Color"
            suffix = 1
            while measure_name in used_names:
                suffix += 1
                measure_name = f"{object_id} Color ({suffix})"
            used_names.add(measure_name)

            measures_by_table.setdefault(table, []).append(
                f"{quote_tmdl_identifier(measure_name)} = {dax_expr}"
            )
            binding = {"table": table, "measure": measure_name}
            expr_to_binding[color_expr] = binding
            object_color_measure[object_id] = binding

        return object_color_measure, measures_by_table, notes

    def statistics_measures_for_metadata(
        self, metadata: Dict[str, Any]
    ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, List[str]], Dict[str, str], List[str]]:
        """
        Converts every StatisticsBoxProperties object's decoded displayed
        statistics (StatisticsBoxParser - see its docstring for the
        MemberMask decoding this relies on) into what
        report_visual_generator needs to bind a real Power BI visual
        instead of an empty/flagged one:

          - exactly one displayed statistic -> a Card, bound to one real
            DAX measure embedded in the field's own table
          - more than one displayed statistic -> a Table, bound to a new
            calculated Metric/Value table (one row per displayed
            statistic, in original order, using each row's real label -
            a plain field+aggregation visual can only lay measures out
            as side-by-side columns, not the row-per-statistic shape a
            Statistics box actually has)

        Returns:
          - object_binding: {object_id: {...}}, one of:
              {"kind": "card", "table": t, "measure": name}
              {"kind": "table", "table": calc_table_name,
               "metric_column": "Metric", "value_column": "Value"}
          - measures_by_table: {table_name: [measure DAX line, ...]} -
            the Card case's measure, embedded the same way color
            measures are (PbipGenerator writes these into the real
            table's .tmdl).
          - calculated_tables: {calc_table_name: tmdl_text} - the Table
            case's extra Metric/Value table, written as its own .tmdl
            file and registered in model.tmdl alongside the real tables.
          - notes: one entry per statistic that couldn't be bound
            (unrecognised MemberMask bit, or field not found in any
            migrated table).
        """
        tables = metadata.get("tables", []) or []
        objects = metadata.get("objects", []) or []
        field_to_table = self._field_to_table(tables)

        object_binding: Dict[str, Dict[str, Any]] = {}
        measures_by_table: Dict[str, List[str]] = {}
        calculated_tables: Dict[str, str] = {}
        notes: List[str] = []
        used_names: set = set()

        for obj in objects:
            if obj.get("object_type") != "StatisticsBoxProperties":
                continue
            object_id = obj.get("object_id", "statistics")
            stats = obj.get("measures", []) or []
            if not stats:
                continue  # nothing displayed at all - caller's existing "no statistics found" note covers this

            field = obj.get("field") or (stats[0].get("field") if stats else "")
            table = field_to_table.get(field)
            if not table:
                notes.append(
                    f"{object_id}: field '{field}' not found in any migrated table - "
                    f"its statistics box couldn't be bound to a real measure"
                )
                continue
            column_ref = f"{quote_tmdl_identifier(table)}[{field}]"

            for stat in stats:
                if stat.get("dax_func") is None:
                    notes.append(
                        f"{object_id}: '{stat.get('label')}' could not be auto-converted "
                        f"to DAX - add the equivalent measure manually"
                    )

            if len(stats) == 1:
                stat = stats[0]
                if not stat.get("dax_func"):
                    continue  # already noted above; nothing left to bind as a Card
                measure_name = f"{object_id} {stat['function']}"
                suffix = 1
                while measure_name in used_names:
                    suffix += 1
                    measure_name = f"{object_id} {stat['function']} ({suffix})"
                used_names.add(measure_name)
                dax_expr = f"{stat['dax_func']}({column_ref})"
                measures_by_table.setdefault(table, []).append(
                    f"{quote_tmdl_identifier(measure_name)} = {dax_expr}"
                )
                object_binding[object_id] = {"kind": "card", "table": table, "measure": measure_name}
            else:
                calc_table_name = f"{object_id} Statistics"
                row_lines = []
                for stat in stats:
                    label_literal = stat.get("label", "").replace('"', '""')
                    if stat.get("dax_func"):
                        value_expr = f"{stat['dax_func']}({column_ref})"
                    else:
                        value_expr = "BLANK()"  # unrecognised statistic - row/label kept, value flagged in notes
                    row_lines.append(f'ROW("Metric", "{label_literal}", "Value", {value_expr})')
                dax_source = "UNION(\n\t" + ",\n\t".join(row_lines) + "\n)"
                calculated_tables[calc_table_name] = self._calculated_table_tmdl(calc_table_name, dax_source)
                object_binding[object_id] = {
                    "kind": "table",
                    "table": calc_table_name,
                    "metric_column": "Metric",
                    "value_column": "Value",
                }

        return object_binding, measures_by_table, calculated_tables, notes

    @staticmethod
    def _calculated_table_tmdl(table_name: str, dax_source: str) -> str:
        """
        A TMDL calculated table: a Metric/Value pair per row, computed
        by a DAX UNION(ROW(...), ...) expression instead of an M query.
        Mirrors PbipGenerator._table_tmdl's column/partition shape as
        closely as a calculated (DAX-sourced) table allows - see
        report_visual_generator._build_statistics_box's caller for why
        this exists instead of a plain field+aggregation visual.

        `sourceColumn` is required even here: real Power BI Desktop
        (26.06) rejected a first version of this table without it -
        "Column 'Metric' in calculated table 'SB01 Statistics' is
        missing the SourceColumn property" - so every calculated-table
        column also needs one, pointing at the same name used inside
        the ROW("Metric", ..., "Value", ...) calls below.
        """
        lines = [f"table {quote_tmdl_identifier(table_name)}", ""]
        lines.append("\tcolumn Metric")
        lines.append("\t\tdataType: string")
        lines.append("\t\tsummarizeBy: none")
        lines.append("\t\tsourceColumn: Metric")
        lines.append("")
        lines.append("\tcolumn Value")
        lines.append("\t\tdataType: double")
        lines.append("\t\tsummarizeBy: sum")
        lines.append("\t\tsourceColumn: Value")
        lines.append("")
        indented_dax = "\n".join(
            ("\t\t\t" + ln.lstrip(" \t")) if ln.strip() else "" for ln in dax_source.splitlines()
        )
        lines.append(f"\tpartition {quote_tmdl_identifier(table_name)} = calculated")
        lines.append("\t\tmode: import")
        lines.append("\t\tsource =")
        lines.append(indented_dax)
        lines.append("")
        return "\n".join(lines)

    def _measure_lines(
        self, charts: List[Dict[str, Any]], field_to_table: Dict[str, str], locale: Dict[str, Any]
    ) -> List[str]:
        lines: List[str] = []
        seen_names: set = set()
        number_format = locale.get("money_format") or ""
        date_format = locale.get("date_format") or ""

        for chart in charts:
            chart_id = chart.get("object_id", "chart")
            for measure in chart.get("measures", []) or []:
                expr = measure.get("expression", "")
                label = measure.get("label") or measure.get("field") or f"{chart_id} Measure"
                measure_name = label
                # Two charts can both define a measure with the same
                # label - de-duplicate rather than emit a DAX file with
                # a repeated measure name TMDL will reject.
                suffix = 1
                while measure_name in seen_names:
                    suffix += 1
                    measure_name = f"{label} ({suffix})"
                seen_names.add(measure_name)

                dax_expr, reason = translate_measure_expression(expr, field_to_table)
                if dax_expr:
                    lines.append(f"{quote_tmdl_identifier(measure_name)} = {dax_expr}")
                    if number_format:
                        lines.append(
                            f"    // Source document number format: {number_format!r} "
                            f"- apply as this measure's Format String if it represents money/quantity."
                        )
                else:
                    lines.append(
                        f"// TODO from chart '{chart_id}', measure '{label}': "
                        f"Qlik expression '{expr}' could not be auto-converted "
                        f"({reason}). Write the DAX equivalent manually, e.g.:"
                    )
                    lines.append(f"// {quote_tmdl_identifier(measure_name)} = <DAX expression for: {expr}>")
                lines.append("")
        return lines

    def generate_for_metadata(self, metadata: Dict[str, Any]) -> str:
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        tables = metadata.get("tables", []) or []
        variables = metadata.get("variables", []) or []
        warnings = metadata.get("warnings", []) or []
        charts = metadata.get("charts", []) or []
        locale = (metadata.get("document_properties") or {}).get("locale", {}) or {}

        lines: List[str] = [
            f"// ============================================================",
            f"// DAX starter measures generated from: {script_name}",
            f"// ============================================================",
            "",
            "// --- Sanity-check measures (one per migrated table) ---------",
        ]
        for table in tables:
            lines.append(self.row_count_measure(table.get("name", "UnnamedTable")))
        lines.append("")

        if charts:
            field_to_table = self._field_to_table(tables)
            lines.append("// --- Measures converted from Qlik chart expressions --------")
            lines.append("// Only simple single-field aggregations (Sum/Avg/Min/Max/Count/")
            lines.append("// Count(Distinct ...)/Only) are auto-converted; anything else is")
            lines.append("// left as a TODO with the original Qlik expression attached.")
            if locale.get("date_format"):
                lines.append(f"// Source document date format: {locale['date_format']!r}")
            lines.append("")
            lines.extend(self._measure_lines(charts, field_to_table, locale))

        if variables:
            lines.append("// --- Qlik script variables (need manual DAX mapping) -------")
            for var in variables:
                lines.append(self._variable_comment(var))
                lines.append("")

        object_color_measure, color_measures_by_table, color_notes = self.color_measures_for_metadata(metadata)
        if color_measures_by_table or color_notes:
            lines.append("// --- Conditional-formatting (ColorExpr) measures -----------")
            lines.append("// Generated from sheet objects' ColorExpr and embedded directly")
            lines.append("// into each table's .tmdl (not just this advisory file), since")
            lines.append("// conditional formatting has to bind to a real model measure.")
            for table, measures in color_measures_by_table.items():
                for measure in measures:
                    lines.append(f"// [{table}] {measure}")
            for note in color_notes:
                lines.append(f"// TODO: {note}")
            lines.append("")

        if warnings:
            lines.append("// --- Carried-over warnings from the Qlik script parser -----")
            lines.append("// These indicate potential duplicate-key / fan-out risk that")
            lines.append("// can silently inflate SUM()/COUNTROWS() measures if the")
            lines.append("// relationships are modeled the same way as in QlikView.")
            for w in warnings:
                lines.append(f"// - {w}")
            lines.append("")

        return "\n".join(lines) + "\n"

    def write_dax_for_metadata(self, metadata: Dict[str, Any]) -> Path:
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        base = sanitize_filename(qvw_base_name(script_name))
        out_path = self.output_dir / f"{base}_Measures.dax"
        content = self.generate_for_metadata(metadata)
        write_text_file(out_path, content)
        logger.info(f"DAX measures written: {out_path}")
        return out_path

    def write_dax_for_all(self, parser) -> List[Path]:
        return [self.write_dax_for_metadata(m) for m in parser.load_all()]

