"""
Run with:
    cd qlik_metadata_extractor
    python -m MigrationEngine

Reads every JSON file in Qlik_Script_MetaData/ and writes Power Query M
scripts, DAX measures, relationship reports, and a PBIP scaffold into
PowerBIScript/.
"""
import logging
import sys

from . import run_migration


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    try:
        run_migration()
        return 0
    except Exception as exc:  # noqa: BLE001
        logging.getLogger(__name__).exception(f"Migration failed: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
