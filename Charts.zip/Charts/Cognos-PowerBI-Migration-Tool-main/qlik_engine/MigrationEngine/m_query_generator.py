"""
MigrationEngine/m_query_generator.py
--------------------------------------
Turns each parsed Qlik table (name, fields, source type/path) into a
Power Query M script that Power BI can run in its Advanced Editor.

Every table gets its own script saved as:
    <table_name>_<qvw_file_name>.pq
e.g. table "Match-Wise Data" from "WorldCup Analysis.qvw" ->
     "Match-Wise Data_WorldCup Analysis.pq"

Supported Qlik source types -> M source functions:
    QVD       -> Csv.Document placeholder (no native QVD connector in
                 Power Query; re-point at the original upstream source
                 or an exported CSV/Parquet copy of the QVD)
    CSV/TXT   -> Csv.Document(File.Contents(...))
    EXCEL     -> Excel.Workbook(File.Contents(...))
    SQL       -> Sql.Database stub
    UNKNOWN   -> blank scaffold (covers RESIDENT/INLINE/mapping loads
                 that have no single external file to point at)

The generated M contains no comments: every step is plain, directly
runnable M code.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .config import MigrationConfig
from .expression_translator import (
    extract_referenced_fields,
    needs_row_index_support,
    translate_aggregate_expression,
    translate_expression,
)
from .metadata_parser import MetadataParser
from .utils import build_table_file_stem, quote_m_identifier, quote_m_string, resolve_field_type, write_text_file

logger = logging.getLogger(__name__)


class MQueryGenerator:

    def __init__(self, output_dir: Path = MigrationConfig.M_QUERY_OUTPUT_DIR):
        self.output_dir = Path(output_dir)

    # ------------------------------------------------------------------
    # Per-table M script generation
    # ------------------------------------------------------------------
    @staticmethod
    def _fields_record(fields: List[str]) -> str:
        """{"Field A", "Field B", ...} literal for Table.SelectColumns.
        Column names here are text data, not M identifiers, so they use
        plain string-literal quoting."""
        return "{" + ", ".join(quote_m_string(f) for f in fields) + "}"

    @staticmethod
    def _type_transform(fields: List[str], field_type_tags: Optional[Dict[str, List[str]]] = None) -> str:
        """
        Builds the {{"Field", <type>}, ...} list for
        Table.TransformColumnTypes. When `field_type_tags` (DocInternals-
        derived $integer/$numeric/$timestamp/$text tags, keyed by field
        name) names a field, its Qlik-inferred type is used; otherwise -
        preserving this tool's original behavior - the column defaults to
        `type text`, since the extractor has no other way to infer a
        Qlik data type. Column names here are text data for
        Table.TransformColumnTypes, so they use plain string-literal
        quoting, not #"..." identifiers.
        """
        field_type_tags = field_type_tags or {}
        pairs = ", ".join(
            f"{{{quote_m_string(f)}, {resolve_field_type(field_type_tags.get(f))[0]}}}"
            for f in fields
        )
        return f"{{{pairs}}}" if fields else "{}"

    def _source_step_qvd(self, table_name: str, source_path: str) -> str:
        return (
            f'    Source = Csv.Document(File.Contents("REPLACE_WITH_EXPORTED_PATH"), '
            f'[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),\n'
            f'    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),'
        )

    def _source_step_csv(self, source_path: str) -> str:
        escaped = source_path.replace('"', '""')
        return (
            f'    Source = Csv.Document(File.Contents("{escaped}"), '
            f'[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),\n'
            f'    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),'
        )

    def _source_step_excel(self, source_path: str, table_name: str, sheet_name: str = "") -> str:
        """
        table_name is the QlikView logical table name (used only as the
        M step name, via #"..." so it survives spaces/special chars).
        sheet_name is the real Excel worksheet name parsed from the
        QlikView `table is <SheetName>` clause and is what must be
        looked up in Source{[Item=..., Kind="Sheet"]} - Power BI has no
        knowledge of the Qlik table name, only the actual sheet. If no
        sheet name could be parsed, fall back to the logical table name
        so the script still renders runnable M (though it may need a
        manual fix if the names differ in the source workbook).
        """
        escaped = source_path.replace('"', '""')
        step_name = quote_m_identifier(table_name)
        resolved_sheet = sheet_name.strip() if sheet_name and sheet_name.strip() else table_name
        sheet_name_literal = quote_m_string(resolved_sheet)
        return (
            f'    Source = Excel.Workbook(File.Contents("{escaped}"), null, true),\n'
            f'    {step_name} = Source{{[Item={sheet_name_literal},Kind="Sheet"]}}[Data],\n'
            f'    #"Promoted Headers" = Table.PromoteHeaders({step_name}, [PromoteAllScalars=true]),'
        )

    def _source_step_sql(self, source_path: str) -> str:
        return (
            f'    Source = Sql.Database("REPLACE_WITH_SERVER", "REPLACE_WITH_DATABASE"),\n'
            f'    #"Promoted Headers" = Source,'
        )

    def _source_step_unknown(self, table_name: str) -> str:
        return (
            f'    Source = #table({{}}, {{}}),\n'
            f'    #"Promoted Headers" = Source,'
        )

    def _source_step_fixed_width(self, source_path: str, codepage: int = 1252) -> str:
        """
        QlikView's `fix` file type has no delimiters -- each row is a
        raw line of text sliced by fixed character positions. M has no
        built-in fixed-width reader, so this reads the file as raw
        lines and returns a single-column table; the caller then slices
        each field out with Text.Middle per the parsed @start:end specs.
        """
        escaped = source_path.replace('"', '""')
        return (
            f'    Source = Lines.FromBinary(File.Contents("{escaped}"), null, null, {codepage}),\n'
            f'    #"Converted to Table" = Table.FromList(Source, Splitter.SplitByNothing(), '
            f'null, null, ExtraValues.Error),'
        )

    def _fixed_width_column_steps(self, prev_var: str, field_specs: List[Dict[str, Any]]) -> Tuple[List[str], str]:
        """
        One Table.AddColumn per @start:end field spec (1-based, inclusive
        character positions in Qlik -> 0-based offset/length for M's
        Text.Middle), wrapped in Text.Trim since fixed-width source files
        are near-universally space-padded to their column width.
        """
        step_lines: List[str] = []
        current_var = prev_var
        for spec in field_specs:
            alias = spec["alias"]
            offset = spec["start"] - 1
            length = spec["end"] - spec["start"] + 1
            step_var = quote_m_identifier(f"Added {alias}")
            step_lines.append(
                f'    {step_var} = Table.AddColumn({current_var}, {quote_m_string(alias)}, '
                f'each Text.Trim(Text.Middle([Column1], {offset}, {length}))),'
            )
            current_var = step_var
        if field_specs:
            step_lines.append(
                f'    #"Removed Columns" = Table.RemoveColumns({current_var}, {{"Column1"}}),'
            )
            current_var = '#"Removed Columns"'
        return step_lines, current_var

    def _generate_fixed_width_query(self, table: Dict[str, Any]) -> str:
        table_name = table.get("name", "UnnamedTable")
        source_path = table.get("source_path", "")
        fields: List[str] = table.get("fields", []) or []
        field_specs: List[Dict[str, Any]] = table.get("fixed_width_fields", []) or []

        body_lines = ["let", self._source_step_fixed_width(source_path)]
        column_steps, current_var = self._fixed_width_column_steps('#"Converted to Table"', field_specs)
        body_lines.extend(column_steps)

        if not field_specs:
            logger.warning(
                f"{table_name}: fixed-width source but no @start:end field "
                f"specs were parsed; only the raw single-column line table "
                f"was generated."
            )

        if fields:
            body_lines.append(
                f'    #"Changed Type" = Table.TransformColumnTypes({current_var}, '
                f'{self._type_transform(fields, table.get("field_type_tags"))})'
            )
        else:
            body_lines.append(f'    #"Changed Type" = {current_var}')
        body_lines += ["in", '    #"Changed Type"']
        return "\n".join(body_lines) + "\n"

    def _generate_inline_query(self, table: Dict[str, Any]) -> str:
        """
        INLINE LOAD embeds its data literally in the script -- the
        parser already captured the header + rows, so this builds a
        real M #table(...) literal instead of an empty scaffold.
        """
        inline = table.get("inline_data") or {}
        fields: List[str] = inline.get("fields") or table.get("fields", []) or []
        rows: List[List[str]] = inline.get("rows", []) or []

        row_literals = [
            "{" + ", ".join(quote_m_string(cell) for cell in row) + "}"
            for row in rows
        ]
        rows_literal = "{" + ", ".join(row_literals) + "}" if row_literals else "{}"

        body_lines = [
            "let",
            f'    Source = #table({self._fields_record(fields)}, {rows_literal}),',
        ]
        if fields:
            body_lines.append(
                f'    #"Changed Type" = Table.TransformColumnTypes(Source, '
                f'{self._type_transform(fields, table.get("field_type_tags"))})'
            )
        else:
            body_lines.append('    #"Changed Type" = Source')
        body_lines += ["in", '    #"Changed Type"']
        return "\n".join(body_lines) + "\n"

    def _add_column_steps(
        self,
        prev_var: str,
        derived_fields: Dict[str, str],
        known_fields: List[str],
        table_name: str,
        variables: Optional[Dict[str, str]] = None,
        known_tables: Optional[Set[str]] = None,
    ) -> Tuple[List[str], str, List[str]]:
        """
        Build one Table.AddColumn step per computed (`expr AS alias`)
        field, chained off `prev_var`. Returns (step_lines, last_var,
        updated_known_fields). Generic over any table/field names --
        driven entirely by whatever derived_fields the metadata
        extractor found.

        Handles the common Qlik in-place-transform pattern where the
        alias reuses the name of a column already on the table (e.g.
        `Num(UnitCost,'#,##0.00') as UnitCost`): M's Table.AddColumn
        errors if you add a column name that already exists, so the
        pre-transform column is renamed out of the way first and the
        expression is pointed at the renamed column instead.

        If any expression here uses Peek()/Previous() in their
        "current table, relative row" form (see
        expression_translator.needs_row_index_support), a
        Table.AddIndexColumn step is injected first so those calls have
        an [Index] to reference, and each field's own AddColumn step
        variable is passed through as that call's self-reference target
        (see translate_expression's peek_context) -- generic for any
        field name, not just a hardcoded "RunningBalance"-style example.
        """
        step_lines: List[str] = []
        known_fields = list(known_fields)
        current_var = prev_var

        needs_index = any(needs_row_index_support(expr) for expr in derived_fields.values())
        index_step: Optional[str] = None
        if needs_index:
            index_step = quote_m_identifier("Added Index")
            step_lines.append(
                f'    {index_step} = Table.AddIndexColumn({current_var}, "Index", 0, 1, Int64.Type),'
            )
            current_var = index_step

        for alias, expr in derived_fields.items():
            rename_map: Dict[str, str] = {}
            if alias in known_fields:
                temp_name = f"{alias} (Source)"
                suffix = 2
                while temp_name in known_fields:
                    temp_name = f"{alias} (Source {suffix})"
                    suffix += 1
                rename_step = quote_m_identifier(f"Renamed {alias} Source")
                step_lines.append(
                    f'    {rename_step} = Table.RenameColumns({current_var}, '
                    f'{{{{{quote_m_string(alias)}, {quote_m_string(temp_name)}}}}}),'
                )
                current_var = rename_step
                known_fields = [temp_name if f == alias else f for f in known_fields]
                rename_map[alias] = temp_name

            step_var = quote_m_identifier(f"Added {alias}")
            peek_context = {"index_step": index_step, "self_step": step_var, "self_alias": alias} if needs_index else None
            m_expr, warnings = translate_expression(
                expr,
                known_fields,
                label=f"{table_name}.{alias}",
                rename_map=rename_map,
                variables=variables,
                peek_context=peek_context,
                known_tables=known_tables,
            )
            for w in warnings:
                logger.warning(w)
            step_lines.append(
                f'    {step_var} = Table.AddColumn({current_var}, '
                f'{quote_m_string(alias)}, each {m_expr}),'
            )
            current_var = step_var
            if alias not in known_fields:
                known_fields.append(alias)

        return step_lines, current_var, known_fields

    def _resolve_dead_table_chain(
        self,
        source_table: str,
        table_name: str,
        known_tables: Set[str],
        chain_context: Dict[str, Any],
    ) -> Optional[Tuple[List[str], str]]:
        """
        Walks backward from `source_table` (already confirmed absent from
        `known_tables`) through resident_loads entries to find the
        ordered chain of DROP TABLE'd intermediate tables needed to
        reconstruct it, and the name of the ultimate root (either a live
        table, or a name with a real external source of its own).
        Generic over any table/chain shape and length -- nothing here is
        specific to any one script.

        Returns (hop_names_leaf_first, root_name), or None if the chain
        can't be safely resolved:
          - a hop's name was reused for more than one RESIDENT-sourced
            table definition in the script (build_resident_occurrence_
            counts > 1) -- a downstream reference to that name by itself
            is ambiguous (which occurrence?) without also tracking
            script position, which this tool doesn't do;
          - the chain would resolve back to `table_name` itself (the
            table currently being generated) -- a common QlikView idiom
            is `DROP TABLE X; ... X: LOAD ... RESIDENT Y; ...` followed
            later by another `DROP TABLE Y; ... Y: LOAD ... RESIDENT X`
            reusing the *original* X's name; referencing "X" naively
            there would make the generated M query for X circularly
            reference itself;
          - the chain doesn't terminate (a genuine circular reference).
        """
        resident_lookup: Dict[str, Dict[str, Any]] = chain_context.get("resident", {})
        occurrence_counts: Dict[str, int] = chain_context.get("occurrence_counts", {})
        hops: List[str] = []
        current = source_table
        visited = set()
        while current not in known_tables:
            if current in visited or current == table_name:
                return None
            visited.add(current)
            if occurrence_counts.get(current, 0) > 1:
                return None
            hops.append(current)
            resident_info = resident_lookup.get(current)
            if resident_info is None:
                break
            next_table = resident_info.get("source_table")
            if not next_table:
                return None
            current = next_table
        if current == table_name:
            # The chain bottoms out at a *live* table, but that live
            # table is this very table -- e.g. `DROP TABLE X; ... X:
            # LOAD ... RESIDENT Y; ... ` where Y's own (now-dropped)
            # definition was itself `RESIDENT X` from an *earlier*
            # incarnation of X. Referencing "X" here would make X's own
            # generated M query circularly reference itself. Safe to
            # detect generically since `known_tables` only ever
            # contains the single, final live table per name -- if the
            # walk lands back on the name we started generating for,
            # it can only be this exact self-reference case, not some
            # other legitimately-live table that happens to share the
            # name (Qlik table names are unique at any point in time).
            return None
        return hops, current

    def _build_reconstructed_prefix(
        self,
        hops: List[str],
        root: str,
        known_tables: Set[str],
        chain_context: Dict[str, Any],
        variables: Optional[Dict[str, str]],
        label_prefix: str,
        self_table_name: Optional[str] = None,
    ) -> Tuple[List[str], str, List[str]]:
        """
        Builds the M steps that reconstruct a chain of DROP TABLE'd
        intermediate tables (`hops`, leaf-first as returned by
        _resolve_dead_table_chain) rooted at `root`, so a table whose
        RESIDENT source was dropped can still reference real upstream
        data instead of an empty scaffold. Applies each hop's own WHERE
        filter and derived-field AddColumn steps -- using the exact same
        generic translate_expression/_add_column_steps machinery as any
        other table, nothing hop-specific or hardcoded -- in original
        script order. The caller's own resident layer continues on top
        of the returned current_var exactly as if it had been a plain
        `Source = #"<name>"` reference.
        """
        resident_lookup: Dict[str, Dict[str, Any]] = chain_context.get("resident", {})
        alias_lookup: Dict[str, Dict[str, str]] = chain_context.get("alias", {})
        source_lookup: Dict[str, Dict[str, Any]] = chain_context.get("source", {})
        inline_lookup: Dict[str, Dict[str, Any]] = chain_context.get("inline", {})
        live_fields: Dict[str, List[str]] = chain_context.get("live_fields", {})

        step_lines: List[str] = []
        known_fields: List[str] = []

        if root in known_tables:
            step_lines.append(f'    Source = {quote_m_identifier(root)},')
            current_var = "Source"
            known_fields = list(live_fields.get(root, []))
        else:
            inline_info = inline_lookup.get(root)
            info = source_lookup.get(root)
            if inline_info:
                fields = inline_info.get("fields") or []
                rows = inline_info.get("rows") or []
                row_literals = [
                    "{" + ", ".join(quote_m_string(c) for c in row) + "}" for row in rows
                ]
                rows_literal = "{" + ", ".join(row_literals) + "}" if row_literals else "{}"
                step_lines.append(f'    Source = #table({self._fields_record(fields)}, {rows_literal}),')
                current_var = "Source"
                known_fields = list(fields)
            elif info:
                source_type = info.get("source_type")
                path = info.get("path", "")
                if source_type == "QVD":
                    step_lines.append(self._source_step_qvd(root, path))
                elif source_type == "CSV/TXT":
                    step_lines.append(self._source_step_csv(path))
                elif source_type == "EXCEL":
                    step_lines.append(self._source_step_excel(path, root, info.get("sheet_name", "")))
                elif source_type == "SQL":
                    step_lines.append(self._source_step_sql(path))
                else:
                    step_lines.append(self._source_step_unknown(root))
                current_var = '#"Promoted Headers"'
            else:
                step_lines.append(self._source_step_unknown(root))
                current_var = '#"Promoted Headers"'

        for hop_name in reversed(hops):  # hops is leaf-first; apply root-to-leaf (script order)
            resident_info = resident_lookup.get(hop_name) or {}
            if resident_info.get("where"):
                m_expr, warnings = translate_expression(
                    resident_info["where"], known_fields, label=f"{label_prefix}.{hop_name}.WHERE",
                    variables=variables, known_tables=known_tables,
                )
                for w in warnings:
                    logger.warning(w)
                step_var = quote_m_identifier(f"{hop_name} Filtered")
                step_lines.append(f'    {step_var} = Table.SelectRows({current_var}, each {m_expr}),')
                current_var = step_var

            derived = alias_lookup.get(hop_name) or {}
            if derived:
                add_steps, current_var, known_fields = self._add_column_steps(
                    current_var, derived, known_fields, f"{label_prefix}.{hop_name}",
                    variables=variables, known_tables=known_tables,
                )
                step_lines.extend(add_steps)

            if resident_info.get("is_distinct"):
                step_var = quote_m_identifier(f"{hop_name} Distinct")
                step_lines.append(f'    {step_var} = Table.Distinct({current_var}),')
                current_var = step_var

            if resident_info.get("order_by"):
                sort_items = ", ".join(
                    f'{{{quote_m_string(o["field"])}, '
                    f'Order.{"Descending" if o.get("direction") == "DESC" else "Ascending"}}}'
                    for o in resident_info["order_by"]
                )
                step_var = quote_m_identifier(f"{hop_name} Sorted")
                step_lines.append(f'    {step_var} = Table.Sort({current_var}, {{{sort_items}}}),')
                current_var = step_var

            hop_joins = chain_context.get("joins", {}).get(hop_name)
            if hop_joins:
                join_steps, current_var, known_fields = self._apply_join_steps(
                    current_var, known_fields, hop_joins, known_tables, chain_context,
                    variables, self_table_name or label_prefix, f"{label_prefix}.{hop_name}",
                )
                step_lines.extend(join_steps)

        return step_lines, current_var, known_fields

    def _apply_join_steps(
        self,
        current_var: str,
        known_fields: List[str],
        join_entries: List[Dict[str, Any]],
        known_tables: Set[str],
        chain_context: Dict[str, Any],
        variables: Optional[Dict[str, str]],
        self_table_name: str,
        label_prefix: str,
    ) -> Tuple[List[str], str, List[str]]:
        """
        Applies each JOIN/KEEP entry targeting this table/hop, in script
        order, as generic Power Query steps. Qlik always joins/keeps on
        every field the two tables have in common (there is no explicit
        ON clause like SQL), so the join key is inferred as the case-
        insensitive intersection of the current known_fields and the
        source table's own known fields -- nothing here assumes any
        particular table or field names.

          JOIN  -> Table.NestedJoin + Table.ExpandTableColumn (only the
                   *new* columns the join statement's own field list
                   declares, beyond the join key, are pulled in).
          KEEP  -> Table.NestedJoin (JoinKind.Inner, semi-join) +
                   Table.RemoveColumns, so rows are filtered without
                   adding any columns. Only LEFT/INNER KEEP are
                   supported: both filter *this* table to rows that
                   also exist in the source. RIGHT KEEP instead filters
                   the *other* (source) table -- a cross-table effect
                   this per-table generator can't retroactively apply to
                   an already-generated query, so it's skipped with a
                   clear warning rather than silently ignored.

        If the source table was itself DROP TABLE'd, its own chain is
        reconstructed the same way a RESIDENT source would be (see
        _resolve_dead_table_chain); if that can't be done safely either,
        the join/keep is skipped (this table's own data is left as-is)
        rather than emitting a reference to something that doesn't exist.
        """
        step_lines: List[str] = []
        join_kind_map = {
            "LEFT": "JoinKind.LeftOuter",
            "RIGHT": "JoinKind.RightOuter",
            "INNER": "JoinKind.Inner",
            "OUTER": "JoinKind.FullOuter",
            None: "JoinKind.FullOuter",
        }

        for i, entry in enumerate(join_entries):
            kind = entry.get("kind", "JOIN")
            modifier = entry.get("modifier")
            source_table = entry.get("source_table")
            join_fields = entry.get("fields") or []
            step_suffix = f"{kind.title()}{i}"

            if not source_table:
                logger.warning(f"{label_prefix}: {kind} has no resolvable source table; skipped.")
                continue

            if kind == "KEEP" and modifier == "RIGHT":
                logger.warning(
                    f"{label_prefix}: RIGHT KEEP (source '{source_table}') filters the "
                    f"*other* table, not this one -- that cross-table effect can't be "
                    f"retroactively applied to an already-generated query here; skipped. "
                    f"Consider restating it as a LEFT KEEP on '{source_table}' instead."
                )
                continue

            if source_table in known_tables:
                source_ref = quote_m_identifier(source_table)
                source_known_fields = chain_context.get("live_fields", {}).get(source_table, [])
            else:
                reconstructed = self._resolve_dead_table_chain(
                    source_table, self_table_name, known_tables, chain_context
                )
                if not reconstructed:
                    logger.warning(
                        f"{label_prefix}: {kind} source table '{source_table}' has no "
                        f"query of its own in this migration (it may have been DROP "
                        f"TABLE'd under a name this tool couldn't safely trace back); "
                        f"{kind.lower()} skipped."
                    )
                    continue
                hops, root = reconstructed
                prefix_steps, source_ref, source_known_fields = self._build_reconstructed_prefix(
                    hops, root, known_tables, chain_context, variables,
                    f"{label_prefix}.{source_table}", self_table_name,
                )
                step_lines.extend(prefix_steps)

            known_lower = {f.lower() for f in known_fields}
            source_lower = {f.lower() for f in source_known_fields}
            join_keys = [f for f in known_fields if f.lower() in source_lower]
            if not join_keys and join_fields:
                # source_known_fields wasn't fully resolvable (e.g. a
                # reconstructed chain rooted at an external source with
                # no verified schema) -- fall back to whichever of the
                # join statement's own declared fields this table
                # already has, which are exactly its intended key(s).
                join_keys = [f for f in join_fields if f.lower() in known_lower]
            if not join_keys:
                logger.warning(
                    f"{label_prefix}: {kind} with '{source_table}' has no field in "
                    f"common with the current table to join on; {kind.lower()} skipped."
                )
                continue
            key_record = self._fields_record(join_keys)

            if kind == "KEEP":
                step_var = quote_m_identifier(f"{step_suffix} {source_table}")
                step_lines.append(
                    f'    {step_var} = Table.NestedJoin({current_var}, {key_record}, '
                    f'{source_ref}, {key_record}, "_{step_suffix}", JoinKind.Inner),'
                )
                clean_var = quote_m_identifier(f"{step_suffix} {source_table} Cleaned")
                step_lines.append(f'    {clean_var} = Table.RemoveColumns({step_var}, {{"_{step_suffix}"}}),')
                current_var = clean_var
                continue

            m_join_kind = join_kind_map.get(modifier, "JoinKind.FullOuter")
            key_lower = {f.lower() for f in join_keys}
            new_columns = [f for f in join_fields if f.lower() not in key_lower]
            if not new_columns:
                logger.info(
                    f"{label_prefix}: {kind} with '{source_table}' contributes no new "
                    f"columns beyond the join key(s); no columns added."
                )
                continue
            step_var = quote_m_identifier(f"{step_suffix} {source_table}")
            step_lines.append(
                f'    {step_var} = Table.NestedJoin({current_var}, {key_record}, '
                f'{source_ref}, {key_record}, "_{step_suffix}", {m_join_kind}),'
            )
            new_cols_record = self._fields_record(new_columns)
            expand_var = quote_m_identifier(f"{step_suffix} {source_table} Expanded")
            step_lines.append(
                f'    {expand_var} = Table.ExpandTableColumn({step_var}, "_{step_suffix}", '
                f'{new_cols_record}, {new_cols_record}),'
            )
            current_var = expand_var
            known_fields = known_fields + [f for f in new_columns if f not in known_fields]

        return step_lines, current_var, known_fields

    def generate_table_query(
        self,
        table: Dict[str, Any],
        known_tables: Optional[Set[str]] = None,
        variables: Optional[Dict[str, str]] = None,
        chain_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Build the full M script (as a string) for one enriched table dict.

        known_tables, when provided, is the set of table names that will
        actually get their own generated query in this app (i.e. every
        table this method will be/was called for). RESIDENT loads whose
        source_table isn't in that set point at a Qlik staging table that
        was DROP TABLE'd before the end of the script -- it never made it
        into the final data model, so it never gets a query of its own.
        Emitting `Source = #"<that name>"` in that case would reference an
        M identifier that doesn't exist anywhere in the generated project,
        which Power BI Desktop rejects at file-open time with an
        'M Engine error ... Invalid identifier' failure (it can't even
        build the local model). Falling back to a blank scaffold keeps the
        project openable; the affected table just needs its RESIDENT chain
        traced and re-pointed at a real source by hand."""
        if table.get("inline_data"):
            return self._generate_inline_query(table)
        if table.get("source_type") == "FIXEDWIDTH":
            return self._generate_fixed_width_query(table)

        table_name = table.get("name", "UnnamedTable")
        source_type = table.get("source_type", "UNKNOWN")
        source_path = table.get("source_path", "")
        fields: List[str] = table.get("fields", []) or []
        derived_fields: Dict[str, str] = table.get("derived_fields", {}) or {}
        resident: Dict[str, Any] = table.get("resident_source") or {}

        # PRECEDING LOAD tables (a stack of LOAD statements where only the
        # bottom one has a source) are parsed into ordered stages,
        # innermost/source stage first. A plain table is just one stage.
        stages = table.get("load_chain_stages") or [{"fields": fields, "derived": derived_fields}]
        source_stage = stages[0]
        final_fields = stages[-1]["fields"]
        group_by: List[str] = resident.get("group_by") or []

        # GROUP BY items are either a plain field name ("ProductID") or a
        # full expression repeated from the SELECT list -- Qlik (like SQL)
        # requires GROUP BY to restate the SELECT expression verbatim
        # rather than its alias, e.g.
        #   LOAD ProductID, Date(MonthStart(SalesOrderDate)) as SalesMonth,
        #        Sum(Amount) as Total
        #   ... GROUP BY ProductID, Date(MonthStart(SalesOrderDate));
        # Only a plain field name is an actual pre-existing column
        # Table.Group can key on directly. An expression item is matched
        # back to the derived-field alias that declares the identical
        # expression (`group_key_aliases`) and handled by the group-key
        # Table.AddColumn logic below the source-step; it must NOT be
        # treated as a literal source column here.
        if group_by:
            group_key_aliases: Dict[str, str] = {
                expr.strip(): alias
                for alias, expr in source_stage["derived"].items()
                if expr.strip() in group_by
            }
            source_fields = [g for g in group_by if g not in group_key_aliases]
        else:
            group_key_aliases = {}
            source_fields = [f for f in source_stage["fields"] if f not in source_stage["derived"]]

        # Expressions (any row-wise stage) may read fields that never
        # appear as standalone output columns on this table (e.g.
        # `MatchID&'-'&RoundID AS [Key]`). Those still have to be pulled
        # from source to compute the expression; the final projection
        # step below drops them again since they aren't real output.
        known_lower = {f.lower() for f in source_fields}
        helper_fields: List[str] = []
        for stage in stages:
            stage_derived = {} if (group_by and stage is source_stage) else stage["derived"]
            for expr in stage_derived.values():
                for ref in extract_referenced_fields(expr):
                    if ref.lower() not in known_lower:
                        helper_fields.append(ref)
                        known_lower.add(ref.lower())
        select_fields = source_fields + helper_fields

        # ---- Source step ----
        prefix_lines: List[str] = []
        reconstructed_source_fields: List[str] = []
        if resident:
            source_table = resident.get("source_table")
            is_known_source = source_table and (known_tables is None or source_table in known_tables)
            reconstructed = None
            if source_table and not is_known_source and chain_context:
                reconstructed = self._resolve_dead_table_chain(
                    source_table, table_name, known_tables or set(), chain_context
                )
            if is_known_source:
                source_step = f'    Source = {quote_m_identifier(source_table)},'
                current_var = "Source"
                reconstructed_source_fields: List[str] = chain_context.get("live_fields", {}).get(source_table, []) if chain_context else []
            elif reconstructed:
                hops, root = reconstructed
                prefix_lines, current_var, reconstructed_source_fields = self._build_reconstructed_prefix(
                    hops, root, known_tables or set(), chain_context, variables, table_name, table_name
                )
                source_step = prefix_lines[0]
                prefix_lines = prefix_lines[1:]
                logger.info(
                    f"{table_name}: RESIDENT source table '{source_table}' was "
                    f"DROP TABLE'd, but its full derivation chain "
                    f"({' <- '.join([root] + list(reversed(hops)))}) was "
                    f"reconstructed from real upstream data instead of an "
                    f"empty scaffold."
                )
            elif source_table:
                logger.warning(
                    f"{table_name}: RESIDENT source table '{source_table}' is a "
                    f"Qlik staging table that gets DROP TABLE'd before the end "
                    f"of the script, so it has no query of its own in this "
                    f"migration; generated a blank scaffold instead of a "
                    f"dangling reference. Trace '{source_table}'s LOAD in the "
                    f"original script and point this table at that real "
                    f"source."
                )
                source_step = self._source_step_unknown(table_name)
                current_var = '#"Promoted Headers"'
            else:
                logger.warning(
                    f"{table_name}: RESIDENT source table name could not be "
                    f"determined; generated a blank scaffold."
                )
                source_step = self._source_step_unknown(table_name)
                current_var = '#"Promoted Headers"'
        elif source_type == "QVD":
            source_step = self._source_step_qvd(table_name, source_path)
            current_var = '#"Promoted Headers"'
        elif source_type == "CSV/TXT":
            source_step = self._source_step_csv(source_path)
            current_var = '#"Promoted Headers"'
        elif source_type == "EXCEL":
            sheet_name = table.get("sheet_name", "")
            source_step = self._source_step_excel(source_path, table_name, sheet_name)
            current_var = '#"Promoted Headers"'
        elif source_type == "SQL":
            source_step = self._source_step_sql(source_path)
            current_var = '#"Promoted Headers"'
        else:
            source_step = self._source_step_unknown(table_name)
            current_var = '#"Promoted Headers"'

        body_lines = ["let", source_step] + prefix_lines
        known_fields = list(select_fields)
        has_row_wise_derived = any(
            (stage["derived"] if not (group_by and stage is source_stage) else {})
            for stage in stages
        )

        # WHERE applies to the RESIDENT source before anything else in
        # that LOAD (filter, then aggregate/select, then dedupe/sort).
        if resident.get("where"):
            where_fields = source_fields or reconstructed_source_fields or resident.get("source_fields") or []
            m_expr, warnings = translate_expression(
                resident["where"], where_fields, label=f"{table_name}.WHERE", variables=variables, known_tables=known_tables
            )
            for w in warnings:
                logger.warning(w)
            body_lines.append(
                f'    #"Filtered Rows" = Table.SelectRows({current_var}, each {m_expr}),'
            )
            current_var = '#"Filtered Rows"'

        if group_by:
            # Expression-based group keys must exist as real columns
            # before Table.Group runs. They're plain row-wise
            # expressions (not aggregates), so they go through
            # translate_expression/Table.AddColumn exactly like any
            # other derived field, using the RESIDENT source table's
            # own field list to resolve bare identifiers (no
            # Table.SelectColumns step runs before Table.Group, so every
            # original column - not just the declared group_by/derived
            # ones - is still available on `current_var` at this point).
            source_field_names = reconstructed_source_fields or resident.get("source_fields") or fields
            resolved_group_by: List[str] = []
            for g in group_by:
                alias = group_key_aliases.get(g)
                if alias is None:
                    resolved_group_by.append(g)
                    continue
                m_expr, warnings = translate_expression(
                    g, source_field_names, label=f"{table_name}.{alias}", variables=variables, known_tables=known_tables
                )
                for w in warnings:
                    logger.warning(w)
                step_var = quote_m_identifier(f"Added {alias}")
                body_lines.append(
                    f'    {step_var} = Table.AddColumn({current_var}, '
                    f'{quote_m_string(alias)}, each {m_expr}),'
                )
                current_var = step_var
                resolved_group_by.append(alias)

            agg_specs = []
            for alias, expr in source_stage["derived"].items():
                if expr.strip() in group_key_aliases:
                    continue  # already computed above as a group key, not an aggregate
                m_expr, warnings = translate_aggregate_expression(expr, label=f"{table_name}.{alias}")
                for w in warnings:
                    logger.warning(w)
                agg_specs.append(f'{{{quote_m_string(alias)}, each {m_expr}, type any}}')
            body_lines.append(
                f'    #"Grouped Rows" = Table.Group({current_var}, '
                f'{self._fields_record(resolved_group_by)}, {{{", ".join(agg_specs)}}}),'
            )
            current_var = '#"Grouped Rows"'
            known_fields = list(resolved_group_by) + [
                alias for alias, expr in source_stage["derived"].items()
                if expr.strip() not in group_key_aliases
            ]
        elif select_fields:
            body_lines.append(
                f'    #"Selected Columns" = Table.SelectColumns({current_var}, '
                f'{self._fields_record(select_fields)}, MissingField.UseNull),'
            )
            current_var = '#"Selected Columns"'

        for stage in stages:
            stage_derived = {} if (group_by and stage is source_stage) else stage["derived"]
            if not stage_derived:
                continue
            add_steps, current_var, known_fields = self._add_column_steps(
                current_var, stage_derived, known_fields, table_name, variables=variables, known_tables=known_tables
            )
            body_lines.extend(add_steps)

        if resident.get("is_distinct"):
            body_lines.append(f'    #"Distinct Rows" = Table.Distinct({current_var}),')
            current_var = '#"Distinct Rows"'

        if resident.get("order_by"):
            sort_items = ", ".join(
                f'{{{quote_m_string(o["field"])}, '
                f'Order.{"Descending" if o.get("direction") == "DESC" else "Ascending"}}}'
                for o in resident["order_by"]
            )
            body_lines.append(f'    #"Sorted Rows" = Table.Sort({current_var}, {{{sort_items}}}),')
            current_var = '#"Sorted Rows"'

        table_joins = (chain_context or {}).get("joins", {}).get(table_name)
        if table_joins:
            known_fields_before = list(known_fields)
            join_steps, current_var, known_fields = self._apply_join_steps(
                current_var, known_fields, table_joins, known_tables or set(), chain_context or {},
                variables, table_name, table_name,
            )
            body_lines.extend(join_steps)
            newly_joined = [f for f in known_fields if f not in known_fields_before]
            final_fields = final_fields + [f for f in newly_joined if f not in final_fields]

        if final_fields and (
            helper_fields or has_row_wise_derived or group_by or set(final_fields) != set(select_fields)
        ):
            # Final projection: matches Qlik's actual visible output
            # columns (drops any source-only helper fields, applies to
            # both the simple case and every PRECEDING LOAD stage).
            body_lines.append(
                f'    #"Final Columns" = Table.SelectColumns({current_var}, '
                f'{self._fields_record(final_fields)}, MissingField.UseNull),'
            )
            current_var = '#"Final Columns"'

        if final_fields:
            type_step = (
                f'    #"Changed Type" = Table.TransformColumnTypes({current_var}, '
                f'{self._type_transform(final_fields, table.get("field_type_tags"))})'
            )
        else:
            type_step = f'    #"Changed Type" = {current_var}'
        body_lines.append(type_step)
        body_lines.append("in")
        body_lines.append('    #"Changed Type"')

        return "\n".join(body_lines) + "\n"

    # ------------------------------------------------------------------
    # File-level orchestration
    # ------------------------------------------------------------------
    def generate_for_metadata(self, metadata: Dict[str, Any], parser: MetadataParser) -> Dict[str, str]:
        """Return {table_name: m_query_string} for every table in one app."""
        enriched_tables = parser.enrich_tables(metadata)
        known_tables = {t["name"] for t in enriched_tables}
        variables = parser.build_variable_map(metadata)
        chain_context = self._build_chain_context(metadata, parser, enriched_tables)
        return {
            t["name"]: self.generate_table_query(
                t, known_tables=known_tables, variables=variables, chain_context=chain_context
            )
            for t in enriched_tables
        }

    @staticmethod
    def _build_chain_context(
        metadata: Dict[str, Any], parser: MetadataParser, enriched_tables: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Bundles the lookups _resolve_dead_table_chain/
        _build_reconstructed_prefix need, built once per app rather than
        once per table."""
        return {
            "resident": parser.build_resident_source_lookup(metadata),
            "occurrence_counts": parser.build_resident_occurrence_counts(metadata),
            "alias": parser.build_alias_map_by_table(metadata),
            "source": parser.build_source_lookup(metadata),
            "inline": parser.build_inline_data_lookup(metadata),
            "live_fields": {t["name"]: t.get("fields", []) for t in enriched_tables},
            "joins": parser.build_joins_by_target_table(metadata),
        }

    def write_queries_for_metadata(
        self, metadata: Dict[str, Any], parser: MetadataParser
    ) -> List[Path]:
        """
        Generate and save one .pq file per table for a single app's
        metadata, using the <table_name>_<qvw_file_name>.pq convention.
        Returns the list of paths written.
        """
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        queries = self.generate_for_metadata(metadata, parser)

        written: List[Path] = []
        for table_name, m_script in queries.items():
            file_stem = build_table_file_stem(table_name, script_name)
            out_path = self.output_dir / f"{file_stem}{MigrationConfig.M_QUERY_EXTENSION}"
            write_text_file(out_path, m_script)
            logger.info(f"M query written: {out_path}")
            written.append(out_path)
        return written

    def write_queries_for_all(self, parser: MetadataParser) -> List[Path]:
        """Run write_queries_for_metadata over every app the parser can load."""
        all_written: List[Path] = []
        for metadata in parser.load_all():
            all_written.extend(self.write_queries_for_metadata(metadata, parser))
        return all_written