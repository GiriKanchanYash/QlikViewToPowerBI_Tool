"""
MigrationEngine/expression_translator.py
------------------------------------------
Translates a QlikView LOAD-script field expression (the left side of an
`<expr> AS <alias>` clause) into a Power Query M expression suitable for
use inside `Table.AddColumn(prevStep, "<alias>", each <M expression>)`.

This is what was missing for cases like:

    MatchID&'-'&RoundID AS [MatchID-RoundID-KEY]

Previously the generator treated every field in a table's `fields` list
as if it were a literal column already present in the source file, so
Table.SelectColumns silently nulled out anything that was actually a
computed expression (MissingField.UseNull). This module lets the M
generator tell the difference and emit a real `Table.AddColumn` step
for computed fields, generically -- nothing here is specific to any
one script, table, or field name.

Architecture: a single recursive-descent function-call engine
(_transpile_functions / _translate_expression_core) walks an expression
left to right, and whenever it finds a call to a *registered* Qlik
function (FUNCTION_REGISTRY), first recursively translates that call's
own arguments (so arbitrarily nested calls like `Date(MonthStart(x))`
or `If(A>0, Date(B), Null())` are translated inside-out automatically),
then hands the already-translated arguments to that function's builder
to produce the M replacement. Everything the engine does NOT recognize
(operators, parentheses that aren't a registered call's own, Qlik
keywords, field references) is left untouched at this stage and handled
by the existing field-wrapping / string-literal-conversion passes that
already run after it.

Scope / honesty about limits: QlikView script expressions are a full
expression grammar (set analysis, associative lookups like Exists(),
row-order functions like Peek()/Previous() that depend on execution
order, etc.). This module deliberately does NOT attempt a full-script
lexer/parser/AST -- it's a generic *expression-level* translator, and
anything it cannot confidently and generically translate (regardless of
which script it came from) is swapped for a flagged, syntactically-valid
`error "TODO: ..."` placeholder in `translate_expression`'s output
rather than silently guessed at or emitted as invalid M.
"""
import re
from typing import Callable, Dict, Iterable, List, Optional, Tuple

# ---------------------------------------------------------------------
# Qlik -> M function name mapping.
# Only covers functions whose arguments map 1:1 with no reordering,
# index-base change, or argument-count-dependent logic. Those are
# handled by dedicated builder functions in FUNCTION_REGISTRY instead.
# ---------------------------------------------------------------------
SIMPLE_FUNCTION_MAP = {
    "trim": "Text.Trim",
    "ltrim": "Text.TrimStart",
    "rtrim": "Text.TrimEnd",
    "upper": "Text.Upper",
    "lower": "Text.Lower",
    "len": "Text.Length",
    "left": "Text.Start",
    "right": "Text.End",
    "year": "Date.Year",
    "month": "Date.Month",
    "day": "Date.Day",
    "weekday": "Date.DayOfWeek",
    "num": "Number.From",
    "text": "Text.From",
    "floor": "Number.RoundDown",
    "ceil": "Number.RoundUp",
    "ceiling": "Number.RoundUp",
    "round": "Number.Round",
    "sqrt": "Number.Sqrt",
    "abs": "Number.Abs",
    "isnull": "Value.Is",  # flagged as approximate -- see FUNCTIONS_NEEDING_REVIEW
}

# Functions whose semantics don't map cleanly 1:1 even after the name
# swap above (different null/blank handling, different rounding rules,
# etc.). The translator still substitutes them so the script no longer
# contains a hard error, but always adds a warning so a human checks
# the result rather than trusting it blindly.
FUNCTIONS_NEEDING_REVIEW = {"isnull", "round", "floor", "ceil", "ceiling", "week", "dual", "wildmatch", "interval"}

_QLIK_KEYWORDS = {
    "and", "or", "not", "like", "true", "false", "null", "if", "then", "else",
}

_STRING_LITERAL_RE = re.compile(r"'((?:[^']|'')*)'")
_BRACKETED_FIELD_RE = re.compile(r"\[[^\]]+\]")
_M_STRING_LITERAL_RE = re.compile(r'"(?:[^"]|"")*"')
_IDENTIFIER_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_.]*#?)")

# Matches a bare (undotted) identifier immediately followed by "(" -
# i.e. a function call written as `Name(...)` rather than
# `Namespace.Name(...)`. Every M library call this module emits is
# fully-qualified (Text.From, List.Sum, Date.FromText, ...), so a match
# here after all translation has run means an untranslated Qlik
# function slipped through untouched - see the safety-net check at the
# end of translate_expression.
_UNTRANSLATED_CALL_RE = re.compile(r"(?<![.\w#])([A-Za-z_][A-Za-z0-9_]*)\s*\(")
# M keywords that can be legitimately followed by "(" (e.g. `if (x > 1)
# then ...`) without being a function call on that keyword's name.
_M_KEYWORDS_NOT_CALLS = {"if", "then", "else", "each", "try", "otherwise", "type", "let", "in", "not", "and", "or"}


def _convert_string_literals(text: str) -> str:
    """Qlik '...' (with '' as an escaped quote) -> M "..." (with "" escaped)."""

    def _repl(m: "re.Match[str]") -> str:
        inner = m.group(1).replace("''", "'").replace('"', '""')
        return f'"{inner}"'

    return _STRING_LITERAL_RE.sub(_repl, text)


def _strip_quotes(raw: str) -> str:
    """Strip a Qlik 'literal' or M "literal" wrapper, returning its raw
    text content, for builders that need the actual string VALUE (e.g.
    a mapping-table name or a format code), not its M-expression form."""
    raw = raw.strip()
    if re.fullmatch(r"'(?:[^']|'')*'", raw):
        return raw[1:-1].replace("''", "'")
    if re.fullmatch(r'"(?:[^"]|"")*"', raw):
        return raw[1:-1].replace('""', '"')
    return raw


def _find_matching_paren(text: str, open_idx: int) -> int:
    depth = 0
    for i in range(open_idx, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _split_call_args(arg_text: str) -> List[str]:
    """
    Splits a function-call argument list on top-level commas, respecting
    nested (), [], Qlik '...' string literals, and (in case the text
    was already partially translated) M "..." string literals.
    """
    parts, current, depth, quote = [], "", 0, None
    i, n = 0, len(arg_text)
    while i < n:
        ch = arg_text[i]
        if quote:
            current += ch
            if ch == quote:
                if i + 1 < n and arg_text[i + 1] == quote:
                    current += arg_text[i + 1]
                    i += 2
                    continue
                quote = None
            i += 1
            continue
        if ch in "'\"":
            quote = ch
            current += ch
            i += 1
            continue
        if ch in "([":
            depth += 1
            current += ch
            i += 1
            continue
        if ch in ")]":
            depth = max(0, depth - 1)
            current += ch
            i += 1
            continue
        if ch == "," and depth == 0:
            parts.append(current)
            current = ""
            i += 1
            continue
        current += ch
        i += 1
    if current.strip():
        parts.append(current)
    return [p.strip() for p in parts]


def _split_top_level_concat(expr: str) -> List[str]:
    """
    Splits a Qlik expression on top-level `&` (string concatenation),
    ignoring `&` that appears inside a quoted string literal or nested
    inside brackets/parentheses.
    """
    parts: List[str] = []
    current = ""
    depth = 0
    in_string = False
    i, n = 0, len(expr)
    while i < n:
        ch = expr[i]
        if in_string:
            current += ch
            if ch == "'":
                if i + 1 < n and expr[i + 1] == "'":
                    current += expr[i + 1]
                    i += 2
                    continue
                in_string = False
            i += 1
            continue
        if ch == "'":
            in_string = True
            current += ch
            i += 1
            continue
        if ch in "([":
            depth += 1
            current += ch
            i += 1
            continue
        if ch in ")]":
            depth = max(0, depth - 1)
            current += ch
            i += 1
            continue
        if ch == "&" and depth == 0:
            parts.append(current)
            current = ""
            i += 1
            continue
        current += ch
        i += 1
    if current.strip():
        parts.append(current)
    return [p.strip() for p in parts]


class TranslationContext:
    """Carries everything a function builder or the field-wrapping pass
    needs, threaded unchanged through every level of recursion."""

    def __init__(
        self,
        known_fields: Iterable[str],
        label: str,
        rename_map: Optional[Dict[str, str]] = None,
        peek_context: Optional[Dict[str, str]] = None,
        known_tables: Optional[Iterable[str]] = None,
    ):
        self.known_fields = list(known_fields)
        self.label = label
        self.rename_map = rename_map or {}
        self.peek_context = peek_context or {}
        self.known_tables = set(known_tables) if known_tables is not None else None
        self.warnings: List[str] = []

    def warn(self, message: str) -> None:
        self.warnings.append(f"{self.label}: {message}")


# ---------------------------------------------------------------------
# Variable expansion ($(vName)) -- runs once, before any expression
# translation, so a variable's own definition (which may itself call
# functions or reference other variables) gets fed through the exact
# same translator as everything else once substituted in.
# ---------------------------------------------------------------------
_VARIABLE_REF_RE = re.compile(r"\$\(\s*([A-Za-z_][A-Za-z0-9_.]*)\s*\)")


def expand_variables(
    expr: str, variables: Optional[Dict[str, str]], label: str = "expression", _seen: Optional[frozenset] = None
) -> Tuple[str, List[str]]:
    """
    Replaces every `$(vName)` reference in `expr` with that variable's
    raw script-defined value text (from SET/LET), recursively, so a
    variable that itself references another variable expands fully
    before translation runs. Generic for any variable name -- nothing
    here is specific to any one script's variable names.

    Cycle-safe: a variable that (directly or indirectly) references
    itself stops expanding and is left as literal `$(name)` text with a
    warning, rather than recursing forever.
    """
    warnings: List[str] = []
    if not variables or "$(" not in expr:
        return expr, warnings
    _seen = _seen or frozenset()

    def _repl(m: "re.Match[str]") -> str:
        name = m.group(1)
        key = name.lower()
        if key in _seen:
            warnings.append(
                f"{label}: variable '$({name})' is part of a circular "
                f"reference chain; left unexpanded."
            )
            return m.group(0)
        value = variables.get(name)
        if value is None:
            value = next((v for k, v in variables.items() if k.lower() == key), None)
        if value is None:
            warnings.append(f"{label}: variable '$({name})' has no known definition; left unexpanded.")
            return m.group(0)
        expanded, nested_warnings = expand_variables(str(value), variables, label, _seen | {key})
        warnings.extend(nested_warnings)
        return f"({expanded})"

    result = _VARIABLE_REF_RE.sub(_repl, expr)
    if result != expr:
        result, more_warnings = expand_variables(result, variables, label, _seen)
        warnings.extend(more_warnings)
    return result, warnings


def _wrap_field_references(
    text: str, known_fields: Iterable[str], rename_map: Optional[Dict[str, str]] = None
) -> str:
    """
    Wrap bare identifiers that match a known source-column name in M's
    `[Field]` row-reference syntax. Bracketed refs ([Field Name]) are
    already valid M syntax and left untouched. Identifiers immediately
    followed by '(' are treated as function calls, not field refs.

    rename_map (original bare name -> the column name to reference
    instead) takes priority over known_fields -- used when an
    expression's alias reuses the name of the field it reads (e.g.
    `Num(UnitCost,'#,##0.00') as UnitCost`), where the generator has
    already renamed the pre-transform column out of the way and needs
    the expression to point at that renamed column, not the new alias.
    """
    if not known_fields and not rename_map:
        return text

    rename_map = rename_map or {}
    rename_lookup = {k.lower(): v for k, v in rename_map.items()}

    protected: List[str] = []

    def _protect(m: "re.Match[str]") -> str:
        protected.append(m.group(0))
        return f"\x00{len(protected) - 1}\x00"

    working = _BRACKETED_FIELD_RE.sub(_protect, text)
    working = _M_STRING_LITERAL_RE.sub(_protect, working)

    field_lookup = {f.lower(): f for f in known_fields}

    def _ident_repl(m: "re.Match[str]") -> str:
        ident = m.group(1)
        end = m.end()
        if end < len(working) and working[end:].lstrip().startswith("("):
            return ident
        if ident.lower() in _QLIK_KEYWORDS:
            return ident
        renamed = rename_lookup.get(ident.lower())
        if renamed is not None:
            return f"[{renamed}]"
        actual = field_lookup.get(ident.lower())
        if actual is None:
            return ident
        return f"[{actual}]"

    working = _IDENTIFIER_RE.sub(_ident_repl, working)

    def _restore(m: "re.Match[str]") -> str:
        return protected[int(m.group(1))]

    working = re.sub(r"\x00(\d+)\x00", _restore, working)
    return working


_KNOWN_FUNCTION_NAMES: set = set()  # populated after FUNCTION_REGISTRY is built, below


def extract_referenced_fields(expr: str) -> List[str]:
    """
    Best-effort discovery of field names an expression reads, whether or
    not those fields also appear as standalone output columns on the
    same LOAD. This matters because a QlikView LOAD like:

        LOAD MatchID&'-'&RoundID AS [MatchID-RoundID-KEY], [Team Initials]
        FROM ...

    reads MatchID and RoundID from the source file to compute the key,
    even though neither is itself an output column of this table -- so
    the M generator must still select them from source (then drop them)
    or the AddColumn step will reference undefined identifiers.

    Without the real source schema this is heuristic: any bracketed
    [Field Name] is trusted as a field; any bare identifier that isn't a
    known function name, a Qlik keyword, purely numeric, or immediately
    followed by '(' is treated as a candidate field reference.
    """
    working = _STRING_LITERAL_RE.sub(" ", expr)

    fields: List[str] = []
    seen = set()

    for m in _BRACKETED_FIELD_RE.finditer(working):
        name = m.group(0)[1:-1]
        if name.lower() not in seen:
            seen.add(name.lower())
            fields.append(name)

    working_no_brackets = _BRACKETED_FIELD_RE.sub(" ", working)
    for m in _IDENTIFIER_RE.finditer(working_no_brackets):
        ident = m.group(1)
        end = m.end()
        if end < len(working_no_brackets) and working_no_brackets[end:].lstrip().startswith("("):
            continue
        low = ident.lower()
        if low in _QLIK_KEYWORDS or low in _KNOWN_FUNCTION_NAMES:
            continue
        if ident[:1].isdigit():
            continue
        if low not in seen:
            seen.add(low)
            fields.append(ident)

    return fields


# =======================================================================
# Function registry: one entry per supported Qlik function. Each builder
# receives (args, raw_args, ctx):
#   args     - this call's arguments, each already fully translated to M
#              (nested calls inside an argument are translated before
#              the parent's builder ever runs -- this is what gives the
#              engine its recursion).
#   raw_args - the same arguments' original, untranslated Qlik text,
#              for the few builders that need a literal value (a
#              mapping-table name, a format code) rather than a
#              sub-expression.
#   ctx      - the TranslationContext for warnings/label/known_fields/etc.
# A builder returns the M replacement text, or None to signal it can't
# handle this particular call shape (wrong argument count, etc.) -- the
# engine then falls back to a flagged placeholder for the whole
# expression rather than emitting something wrong.
# =======================================================================
BuilderFn = Callable[[List[str], List[str], "TranslationContext"], Optional[str]]


def _b_simple(m_name: str) -> BuilderFn:
    def _b(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        return f"{m_name}({', '.join(args)})"

    return _b


def _b_reviewed(m_name: str, qlik_name: str) -> BuilderFn:
    simple = _b_simple(m_name)

    def _b(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        ctx.warn(
            f"'{qlik_name}()' was mapped to '{m_name}()' -- semantics differ "
            f"slightly between Qlik and M (null/rounding behavior); please "
            f"review the generated step."
        )
        return simple(args, raw_args, ctx)

    return _b


def _b_mid(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik Mid(str, start[, len]) is 1-based; M Text.Middle is 0-based."""
    if len(args) < 2:
        return None
    src, start = args[0], args[1]
    if len(args) >= 3:
        return f"Text.Middle({src}, ({start}) - 1, {args[2]})"
    return f"Text.Middle({src}, ({start}) - 1)"


def _b_num(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """
    Qlik Num(value, 'format') both converts to a number AND carries a
    display format in the same call. M has no equivalent that keeps a
    display format on the value itself -- that belongs on the column/
    measure format property in the Power BI model, not baked into the M
    expression. Keeps the numeric value and drops the format string,
    flagging it so a human can set the equivalent column format.
    """
    if not args:
        return None
    if len(args) > 1:
        ctx.warn(
            "Num()'s display-format string was dropped (Number.From keeps "
            "the numeric value only); set the equivalent column format on "
            "this field in the Power BI model if display formatting matters."
        )
    return f"Number.From({args[0]})"


def _b_null(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    return "null"


def _b_if(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik If(cond, then[, else]) -> M's `if cond then then else else`
    keyword syntax. The else branch defaults to null when omitted.
    Parenthesized so it composes safely as a sub-expression (e.g. when
    used as an argument to another function, or compared with `=`)."""
    if len(args) < 2:
        return None
    condition, then_val = args[0], args[1]
    else_val = args[2] if len(args) > 2 else "null"
    return f"(if {condition} then {then_val} else {else_val})"


def _b_alt(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik Alt(a, b, c, ...) returns the first argument that isn't
    null/an error, falling back to the last argument. List.First(
    List.RemoveNulls({...}), null) matches the common first-non-null
    case but not Qlik's error-value handling, so this is flagged."""
    if len(args) < 2:
        return None
    ctx.warn(
        "'Alt()' was mapped to List.First(List.RemoveNulls(...), null) -- "
        "matches Qlik's first-non-null behavior but not its error-value "
        "handling; review if any argument can evaluate to an M error."
    )
    return f"List.First(List.RemoveNulls({{{', '.join(args)}}}), null)"


def _b_hash(m_name: str, qlik_name: str) -> BuilderFn:
    """Qlik's Date#/Time#/Timestamp#/Num#/Interval# *interpret* a text
    value using an explicit input format. M's *.FromText functions
    don't take a custom parse-pattern the same way, so the format
    string is dropped and the value is parsed with M's default rules;
    flagged so a human can verify the source format actually parses."""

    def _b(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        if not args:
            return None
        ctx.warn(
            f"'{qlik_name}()' was mapped to '{m_name}()' with its explicit "
            f"input format dropped (M has no direct equivalent custom-"
            f"pattern parse); verify the source values parse correctly "
            f"with M's default conversion rules."
        )
        return f"{m_name}({args[0]})"

    return _b


def _b_rangesum(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik RangeSum(a, b, c, ...) sums any number of arguments while
    ignoring nulls (returns 0, not null, if every argument is null),
    unlike `+`. Generic for any argument count."""
    if not args:
        return None
    return f"List.Sum(List.RemoveNulls({{{', '.join(args)}}}))"


def _b_date(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik Date(x[, format]) reinterprets/displays a value as a date --
    the format argument (if any) is a display concern, not a value one."""
    if not args:
        return None
    if len(args) > 1:
        ctx.warn(
            "Date()'s display-format string was dropped; set the "
            "equivalent column format on this field in the Power BI "
            "model if display formatting matters."
        )
    return f"Date.From({args[0]})"


def _b_timestamp(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik Timestamp(x[, format]) is Date()'s datetime counterpart."""
    if not args:
        return None
    if len(args) > 1:
        ctx.warn(
            "Timestamp()'s display-format string was dropped; set the "
            "equivalent column format on this field in the Power BI "
            "model if display formatting matters."
        )
    return f"DateTime.From({args[0]})"


def _b_dual(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik Dual(text, number) stores one value with two simultaneous
    representations. M has no dual-value type; the numeric side is kept
    since it's almost always the one used downstream -- flagged since
    the paired display text is lost."""
    if len(args) < 2:
        return None
    ctx.warn(
        "Dual(text, number) has no Power Query equivalent (M has no dual "
        "text/number value); kept the numeric side only -- set a display "
        "format on the Power BI column if the paired text mattered."
    )
    return f"Number.From({args[1]})"


def _b_makedate(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik MakeDate(year, month[, day]) -> M's #date(year, month, day)."""
    if len(args) < 2:
        return None
    day = args[2] if len(args) > 2 else "1"
    return f"#date(Number.Round({args[0]}), Number.Round({args[1]}), Number.Round({day}))"


def _b_now(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    return "DateTime.LocalNow()"


def _b_today(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    return "Date.From(DateTime.LocalNow())"


def _b_monthstart(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik MonthStart(date[, offsetMonths]) -> Date.StartOfMonth, with
    Date.AddMonths applied first when an offset is given."""
    if not args:
        return None
    base = args[0] if len(args) < 2 else f"Date.AddMonths({args[0]}, Number.Round({args[1]}))"
    return f"Date.StartOfMonth(Date.From({base}))"


def _b_monthend(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    if not args:
        return None
    base = args[0] if len(args) < 2 else f"Date.AddMonths({args[0]}, Number.Round({args[1]}))"
    return f"Date.EndOfMonth(Date.From({base}))"


def _b_week(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik's Week() number depends on the script's FirstWeekDay/
    BrokenWeeks locale settings and isn't guaranteed to match M's
    Date.WeekOfYear numbering exactly -- flagged for verification."""
    if not args:
        return None
    ctx.warn(
        "'Week()' was mapped to 'Date.WeekOfYear()' -- Qlik's week "
        "numbering depends on script-level locale settings "
        "(FirstWeekDay/BrokenWeeks) that may not match M's default week "
        "numbering; please verify week boundaries."
    )
    return f"Date.WeekOfYear({args[0]})"


def _b_makelist(fn_name: str) -> BuilderFn:
    """Shared builder for Match()/Pick(): both reduce a variable-length
    argument list to a single nested if/else chain, with a different
    comparison/selection rule per function."""

    def _b_match(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        if len(args) < 2:
            return None
        target, choices = args[0], args[1:]
        expr = "0"
        for position in range(len(choices), 0, -1):
            expr = f"if {target} = {choices[position - 1]} then {position} else {expr}"
        return f"({expr})"

    def _b_pick(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        if len(args) < 2:
            return None
        index, choices = args[0], args[1:]
        expr = "null"
        for position in range(len(choices), 0, -1):
            expr = f"if {index} = {position} then {choices[position - 1]} else {expr}"
        return f"({expr})"

    return {"match": _b_match, "pick": _b_pick}[fn_name]


def _wildcard_to_m(field_expr: str, pattern: str) -> Optional[str]:
    """
    Translates one Qlik wildcard pattern (from WildMatch's 2nd+
    arguments, already lower-cased and quote-stripped) into an M
    boolean expression. Qlik wildcards use '*' (zero or more
    characters) and '?' (exactly one character); M's standard library
    has no regex/wildcard engine, so only '*' forms -- which cover the
    overwhelming majority of real WildMatch() usage (prefix*, *suffix,
    *contains*, and multi-segment a*b*c) -- get a real translation. A
    pattern containing '?' returns None so the caller can fall back to
    a flagged placeholder instead of guessing at character matching.
    """
    if "?" in pattern:
        return None
    if "*" not in pattern:
        return f'{field_expr} = "{pattern}"'
    segments = [s for s in pattern.split("*") if s]
    if not segments:
        return "true"
    starts_with_star = pattern.startswith("*")
    ends_with_star = pattern.endswith("*")
    if len(segments) == 1:
        seg = segments[0]
        if starts_with_star and ends_with_star:
            return f'Text.Contains({field_expr}, "{seg}")'
        if ends_with_star:
            return f'Text.StartsWith({field_expr}, "{seg}")'
        if starts_with_star:
            return f'Text.EndsWith({field_expr}, "{seg}")'
        return f'{field_expr} = "{seg}"'
    # Multiple '*'-separated segments: require the first/last literal
    # segments to anchor the string appropriately, and every segment to
    # be present via Text.Contains (a generic presence check across any
    # number of segments; it doesn't enforce relative ordering between
    # interior segments, which is a reasonable trade-off given M has no
    # regex engine to do this precisely).
    checks = []
    if not starts_with_star:
        checks.append(f'Text.StartsWith({field_expr}, "{segments[0]}")')
    if not ends_with_star:
        checks.append(f'Text.EndsWith({field_expr}, "{segments[-1]}")')
    for seg in segments:
        checks.append(f'Text.Contains({field_expr}, "{seg}")')
    return "(" + " and ".join(checks) + ")"


def _b_wildmatch(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik WildMatch(field, pattern1[, pattern2, ...]) -- true if field
    matches ANY of the given wildcard patterns (case-insensitive)."""
    if len(args) < 2:
        return None
    field_expr = f"Text.Lower(Text.From({args[0]}))"
    checks = []
    for raw in raw_args[1:]:
        pattern = _strip_quotes(raw).lower()
        m = _wildcard_to_m(field_expr, pattern)
        if m is None:
            ctx.warn(
                f"WildMatch() pattern '{_strip_quotes(raw)}' uses '?' "
                f"(single-character wildcard), which has no generic Power "
                f"Query translation (M has no regex/wildcard engine); left "
                f"as a flagged placeholder -- please translate manually."
            )
            return None
        checks.append(m)
    ctx.warn(
        "'WildMatch()' was translated using Text.StartsWith/EndsWith/"
        "Contains -- covers '*' wildcards but not the full pattern-"
        "matching semantics of Qlik's WildMatch(); please review."
    )
    return "(" + " or ".join(checks) + ")"


def _b_exists(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """Qlik's Exists() has no Power Query equivalent at all (no concept
    of 'values loaded so far') -- always a flagged placeholder. Since
    the M engine parses the whole mashup section as one unit, leaving
    this as invalid M (`Not Exists(...)`, which M can't parse as
    bare-word function application) would be enough to make the
    *entire* .pbip fail to open."""
    ctx.warn(
        "Qlik's Exists() has no Power Query M equivalent (no direct "
        "concept of 'values loaded so far'); left as a flagged "
        "placeholder -- please translate manually, typically by "
        "merging/joining against the referenced field's source table "
        "instead."
    )
    return None


def _b_iterno(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """IterNo() only has meaning inside a Qlik WHILE-loop LOAD;
    translating it requires reconstructing that loop as a Power Query
    iteration (List.Generate), which is a table/script-level
    transformation rather than a per-expression one."""
    ctx.warn(
        "IterNo() only has meaning inside a Qlik WHILE-loop LOAD; "
        "translating it requires reconstructing that loop as a Power "
        "Query iteration (List.Generate), which is a table/script-level "
        "transformation rather than a per-expression one -- left as a "
        "flagged placeholder."
    )
    return None


def _b_applymap(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """
    Qlik ApplyMap('MapName', field[, default]) looks up `field` in a
    two-column MAPPING LOAD table and returns the matching value, or
    `default` (or NULL if omitted) when there's no match. Translated
    generically -- without assuming the mapping table's actual column
    names -- by referencing the mapping table's first two columns
    positionally (its key and value columns, in MAPPING LOAD order), so
    this works for any mapping table regardless of what its columns
    are called.
    """
    if len(raw_args) < 2:
        return None
    map_name = _strip_quotes(raw_args[0])
    lookup_expr = args[1]
    default_expr = args[2] if len(args) > 2 else "null"
    map_ref = f'#"{map_name}"'
    ctx.warn(
        f"'ApplyMap()' against mapping table '{map_name}' was translated "
        f"generically using its first two columns as key/value (positional, "
        f"since the mapping table's actual column names aren't visible "
        f"here); verify '{map_name}' is generated as a real M query with "
        f"the key column first and the value column second."
    )
    return (
        f'try (let _row = Table.SelectRows({map_ref}, each '
        f'Record.Field(_, (Table.ColumnNames({map_ref})){{0}}) = {lookup_expr}){{0}} '
        f'in Record.Field(_row, (Table.ColumnNames({map_ref})){{1}})) '
        f'otherwise {default_expr}'
    )


def _b_peek_or_previous(is_previous: bool) -> BuilderFn:
    """
    Qlik Peek(field[, offset[, table]]) / Previous(field) read a value
    from another row of a table:
      - 3-argument Peek(field, offset, 'TableName') is fully self-
        contained (a literal target table + a row offset) and
        translates generically to positional row access on that
        table's M query, regardless of which table is named.
      - The 1/2-argument "current table, relative row" form (and
        Previous(), which is Peek(field, -1) on the table currently
        being built) needs to know the M step variable that holds an
        indexed copy of *this* table -- supplied by the caller as
        ctx.peek_context only when the surrounding table's LOAD
        actually needs it (see MQueryGenerator's Index-column
        injection). Without that context there's nothing generic to
        translate against, so this returns None and the caller emits a
        flagged placeholder instead of guessing.
    """

    def _b(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
        if not raw_args:
            return None
        field_name = _strip_quotes(raw_args[0])

        if not is_previous and len(raw_args) >= 3:
            table_name = _strip_quotes(raw_args[2])
            if ctx.known_tables is not None and table_name not in ctx.known_tables:
                # The named table has no query of its own in this
                # migration (e.g. it was DROP TABLE'd and this tool
                # couldn't -- or hasn't yet been asked to -- reconstruct
                # its chain). Referencing it directly here would be
                # exactly the dangling-identifier pattern that makes an
                # entire .pbip fail to open; fail this call instead so
                # it becomes a flagged placeholder.
                ctx.warn(
                    f"'Peek()' against table '{table_name}' can't be "
                    f"translated: '{table_name}' has no query of its own "
                    f"in this migration (it was likely DROP TABLE'd), so "
                    f"referencing it directly would create a dangling M "
                    f"reference; left as a flagged placeholder -- trace "
                    f"'{table_name}'s data and point this at a real "
                    f"table instead."
                )
                return None
            table_ref = f'#"{table_name}"'
            try:
                offset_literal: Optional[int] = int(_strip_quotes(raw_args[1]))
            except ValueError:
                offset_literal = None
            if offset_literal is not None and offset_literal < 0:
                row_index = f"Table.RowCount({table_ref}) + ({offset_literal})"
            elif offset_literal is not None:
                row_index = str(offset_literal)
            else:
                offset_expr = args[1]
                row_index = (
                    f"(if ({offset_expr}) < 0 then Table.RowCount({table_ref}) + ({offset_expr}) "
                    f"else ({offset_expr}))"
                )
            ctx.warn(
                f"'Peek()' against table '{table_name}' was translated to "
                f"direct row/column access; verify '{table_name}' is fully "
                f"loaded before this table runs (Power BI evaluates queries "
                f"on demand, not in the original script's execution order)."
            )
            return f'{table_ref}{{{row_index}}}[{field_name}]'

        offset_literal = -1
        if not is_previous and len(raw_args) >= 2:
            try:
                offset_literal = int(_strip_quotes(raw_args[1]))
            except ValueError:
                ctx.warn(
                    "Peek()'s row-offset argument must be a constant integer "
                    "for the current-table form to be translated generically; "
                    "left as a flagged placeholder."
                )
                return None

        pc = ctx.peek_context
        if not pc or not pc.get("index_step"):
            return None

        self_alias = pc.get("self_alias", "")
        row_step = pc["self_step"] if field_name.lower() == self_alias.lower() else pc["index_step"]
        row_ref = f"({row_step}){{[Index] + ({offset_literal})}}"
        field_literal = '"' + field_name.replace('"', '""') + '"'
        return f"(if [Index] + ({offset_literal}) < 0 then null else Record.Field({row_ref}, {field_literal}))"

    return _b


def _b_interval(args: List[str], raw_args: List[str], ctx: "TranslationContext") -> Optional[str]:
    """
    Qlik Interval(numericDuration, formatCode) re-expresses a numeric
    difference (Qlik dates are numeric, so a date subtraction is
    already a number of days) as a specific unit. Only the common
    whole-unit format codes are handled generically (day/hour/minute/
    second); a full custom pattern (e.g. 'D hh:mm') has no single
    generic numeric conversion and falls back to a flagged placeholder.
    """
    if not args:
        return None
    unit = _strip_quotes(raw_args[1]).strip().upper() if len(raw_args) > 1 else "D"
    factor = {"D": 1, "H": 24, "M": 24 * 60, "S": 24 * 60 * 60}.get(unit[:1])
    if factor is None:
        ctx.warn(
            f"Interval()'s format code '{unit}' isn't one of the simple "
            f"whole-unit patterns (D/h/m/s) this tool converts generically; "
            f"left as a flagged placeholder -- please translate manually."
        )
        return None
    ctx.warn(
        f"'Interval()' was translated as a numeric day-based conversion "
        f"(factor {factor} for unit '{unit}'); only simple whole-unit "
        f"format codes are supported, not full custom interval-format "
        f"patterns -- please review."
    )
    return f"(({args[0]}) * {factor})" if factor != 1 else f"({args[0]})"


FUNCTION_REGISTRY: Dict[str, BuilderFn] = {
    "mid": _b_mid,
    "num": _b_num,
    "null": _b_null,
    "if": _b_if,
    "alt": _b_alt,
    "date#": _b_hash("Date.FromText", "date#"),
    "time#": _b_hash("Time.FromText", "time#"),
    "timestamp#": _b_hash("DateTime.FromText", "timestamp#"),
    "num#": _b_hash("Number.FromText", "num#"),
    "interval#": _b_hash("Duration.FromText", "interval#"),
    "rangesum": _b_rangesum,
    "date": _b_date,
    "timestamp": _b_timestamp,
    "dual": _b_dual,
    "makedate": _b_makedate,
    "now": _b_now,
    "today": _b_today,
    "monthstart": _b_monthstart,
    "monthend": _b_monthend,
    "week": _b_week,
    "match": _b_makelist("match"),
    "pick": _b_makelist("pick"),
    "wildmatch": _b_wildmatch,
    "exists": _b_exists,
    "iterno": _b_iterno,
    "applymap": _b_applymap,
    "peek": _b_peek_or_previous(is_previous=False),
    "previous": _b_peek_or_previous(is_previous=True),
    "interval": _b_interval,
}
for _qlik_name, _m_name in SIMPLE_FUNCTION_MAP.items():
    if _qlik_name == "num":
        continue  # handled by _b_num, which also strips the format arg
    FUNCTION_REGISTRY[_qlik_name] = (
        _b_reviewed(_m_name, _qlik_name) if _qlik_name in FUNCTIONS_NEEDING_REVIEW else _b_simple(_m_name)
    )

_KNOWN_FUNCTION_NAMES = set(FUNCTION_REGISTRY.keys())


def _find_next_call(text: str, registry: Dict[str, BuilderFn]) -> Optional[Tuple[str, int, int, int]]:
    """
    Finds the leftmost call in `text` to a function present in
    `registry`, skipping over ['bracketed field names'], "M strings",
    and 'Qlik strings' so a '(' inside any of those is never mistaken
    for a call. Returns (name_lower, name_start_idx, open_paren_idx,
    close_paren_idx), or None if no registered call is found.
    """
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "'" or ch == '"':
            quote = ch
            j = i + 1
            while j < n:
                if text[j] == quote:
                    if j + 1 < n and text[j + 1] == quote:
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            i = j
            continue
        if ch == "[":
            j = text.find("]", i)
            i = (j + 1) if j != -1 else n
            continue
        if ch.isalpha() or ch == "_":
            j = i
            while j < n and (text[j].isalnum() or text[j] in "_#"):
                j += 1
            name = text[i:j]
            k = j
            while k < n and text[k].isspace():
                k += 1
            preceded_by_dot = i > 0 and text[i - 1] in ".#"
            if not preceded_by_dot and k < n and text[k] == "(" and name.lower() in registry:
                close_idx = _find_matching_paren(text, k)
                if close_idx != -1:
                    return name.lower(), i, k, close_idx
            i = j
            continue
        i += 1
    return None


class _UntranslatableCall(Exception):
    """Raised when a registered function's builder can't handle the
    specific call it was given (see _transpile_functions)."""


def _transpile_functions(text: str, ctx: "TranslationContext", registry: Dict[str, BuilderFn]) -> str:
    """
    Repeatedly finds the leftmost call to a registered function (within
    the still-unprocessed suffix of `text`) and replaces it with its M
    translation, recursing into that call's own arguments first (via
    _translate_expression_core) -- this is what lets nested calls like
    Date(MonthStart(x)) or If(A>0, Date(B), Null()) translate correctly
    regardless of nesting depth, since each argument goes through this
    exact same recursive path before its parent call is ever built.

    Scanning resumes strictly *after* each substitution rather than
    restarting from the beginning of `text`: some builders emit M
    keyword syntax (`if ... then ... else ...` for If/Match/Pick) that
    can coincidentally contain the substring "if (" once embedded next
    to another translated sub-expression, which would otherwise be
    misread as a fresh call on a second pass. Text before the current
    scan position was already proven call-free by the previous
    left-to-right scan, so it never needs re-checking either.
    """
    search_from = 0
    while True:
        found = _find_next_call(text[search_from:], registry)
        if not found:
            return text
        name, rel_start, rel_open, rel_close = found
        start, open_idx, close_idx = rel_start + search_from, rel_open + search_from, rel_close + search_from
        raw_args = _split_call_args(text[open_idx + 1:close_idx])
        translated_args = [_translate_expression_core(a, ctx) for a in raw_args]
        replacement = registry[name](translated_args, raw_args, ctx)
        if replacement is None:
            raise _UntranslatableCall(text[start:close_idx + 1])
        text = text[:start] + replacement + text[close_idx + 1:]
        search_from = start + len(replacement)


def _translate_expression_core(part: str, ctx: "TranslationContext") -> str:
    """One recursive translation pass over a single (non-concatenation)
    sub-expression: resolve every registered function call (recursing
    into arguments first), convert any remaining raw Qlik string
    literals, then wrap field references."""
    part = part.strip()
    if re.fullmatch(r"'(?:[^']|'')*'", part):
        return _convert_string_literals(part)
    sub = _transpile_functions(part, ctx, FUNCTION_REGISTRY)
    sub = _convert_string_literals(sub)
    sub = _wrap_field_references(sub, ctx.known_fields, ctx.rename_map)
    return sub


_PREVIOUS_TOKEN_RE = re.compile(r"\bprevious\s*\(", re.IGNORECASE)
_PEEK_TOKEN_RE = re.compile(r"\bpeek\s*\(", re.IGNORECASE)


def needs_row_index_support(expr: str) -> bool:
    """
    True if `expr` contains a Peek()/Previous() call needing Index-
    column support (the "current table, relative row" form) rather
    than being fully self-contained (Peek's 3-argument named-table
    form, which needs no such support). MQueryGenerator uses this to
    decide whether to inject a Table.AddIndexColumn step before a
    table's row-wise derived columns -- generic over any expression,
    not tied to any specific field or table name.
    """
    if _PREVIOUS_TOKEN_RE.search(expr):
        return True
    for m in _PEEK_TOKEN_RE.finditer(expr):
        open_idx = expr.index("(", m.start())
        close_idx = _find_matching_paren(expr, open_idx)
        if close_idx == -1:
            continue
        if len(_split_call_args(expr[open_idx + 1:close_idx])) < 3:
            return True
    return False


# ---------------------------------------------------------------------
# Expression-based type inference (fallback for derived fields with no
# DocInternals tag -- see utils.resolve_field_type, which tries the
# DocInternals tag first and only falls back to this).
# ---------------------------------------------------------------------
_FUNCTION_RETURN_TYPE: Dict[str, str] = {
    "sum": "double", "avg": "double", "rangesum": "double", "num": "double",
    "num#": "double", "sqrt": "double", "abs": "double",
    "count": "int64", "year": "int64", "month": "int64", "day": "int64",
    "weekday": "int64", "week": "int64", "len": "int64", "iterno": "int64",
    "floor": "int64", "round": "double", "ceil": "int64", "ceiling": "int64",
    "date": "date", "monthstart": "date", "monthend": "date", "makedate": "date",
    "date#": "date", "today": "date",
    "timestamp": "datetime", "timestamp#": "datetime", "now": "datetime",
    "text": "string", "upper": "string", "lower": "string", "trim": "string",
    "ltrim": "string", "rtrim": "string", "left": "string", "right": "string",
    "mid": "string", "pick": None, "match": "int64",
    "isnull": "boolean", "wildmatch": "boolean",
}


def infer_expression_type(expr: str) -> Optional[str]:
    """
    Best-effort inference of a derived field's underlying value type
    from its own Qlik expression -- "int64"/"double"/"date"/"datetime"/
    "string"/"boolean", or None if the expression's shape doesn't
    confidently indicate a single type (callers keep their existing
    text/string default in that case, same as before this existed).

    This is a fallback ONLY: a real DocInternals engine-computed tag
    (see utils.resolve_field_type) always takes priority, since it
    reflects the field's actual loaded data rather than a guess from
    syntax. This matters for fields that never get their own tag in
    the first place -- e.g. a GROUP BY key or other column this
    migration tool computes itself while reconstructing a dropped
    table's chain (see MQueryGenerator) has no corresponding DocInternals
    entry to read at all.

    Generic over any expression shape; nothing here is specific to any
    one script's field or table names.
    """
    expr = expr.strip()
    if not expr:
        return None

    call_match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*#?)\s*\(", expr)
    if call_match:
        open_idx = call_match.end() - 1
        close_idx = _find_matching_paren(expr, open_idx)
        if close_idx == len(expr.rstrip()) - 1:
            name = call_match.group(1).lower()
            inner = expr[open_idx + 1:close_idx]
            if name == "if":
                args = _split_call_args(inner)
                if len(args) >= 3:
                    then_type = infer_expression_type(args[1])
                    else_type = infer_expression_type(args[2])
                    if then_type and then_type == else_type:
                        return then_type
                return None
            if name == "alt":
                for arg in _split_call_args(inner):
                    inferred = infer_expression_type(arg)
                    if inferred:
                        return inferred
                return None
            return _FUNCTION_RETURN_TYPE.get(name)

    if len(_split_top_level_concat(expr)) > 1:
        return "string"

    if re.fullmatch(r"'(?:[^']|'')*'", expr):
        return "string"

    if re.fullmatch(r"-?\d+(\.\d+)?", expr):
        return "double" if "." in expr else "int64"

    # Top-level arithmetic (outside any nested call/bracket and outside
    # a string literal) implies a numeric result.
    scan = _STRING_LITERAL_RE.sub(" ", expr)
    scan = _BRACKETED_FIELD_RE.sub(" ", scan)
    depth = 0
    for ch in scan:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth = max(0, depth - 1)
        elif depth == 0 and ch in "+-*/":
            return "double"

    return None


_AGG_FUNCTION_MAP = {
    "sum": "List.Sum",
    "avg": "List.Average",
    "min": "List.Min",
    "max": "List.Max",
}
_COUNT_DISTINCT_RE = re.compile(r"^\s*count\s*\(\s*distinct\s+(.+?)\s*\)\s*$", re.IGNORECASE)
_COUNT_RE = re.compile(r"^\s*count\s*\(\s*(.+?)\s*\)\s*$", re.IGNORECASE)
_SIMPLE_AGG_RE = re.compile(r"^\s*(sum|avg|min|max)\s*\(\s*(.+?)\s*\)\s*$", re.IGNORECASE)


def translate_aggregate_expression(expr: str, label: str = "aggregate") -> Tuple[str, List[str]]:
    """
    Translates a Qlik GROUP BY aggregate expression (Sum(Amount),
    Count(OrderID), Count(Distinct CustomerID), ...) into the form
    needed inside Table.Group's aggregation spec, where `_` is the
    sub-table for that group (so a field becomes `_[Field]`, a list of
    that column's values, rather than a row-context `[Field]`).

    Only Sum/Avg/Min/Max/Count/Count(Distinct) are recognized -- anything
    else is returned as a flagged placeholder rather than guessed at.
    """
    warnings: List[str] = []
    expr = expr.strip()

    m = _COUNT_DISTINCT_RE.match(expr)
    if m:
        field = m.group(1).strip().strip("[]")
        return f"List.Count(List.Distinct(_[{field}]))", warnings

    m = _SIMPLE_AGG_RE.match(expr)
    if m:
        func, field = m.groups()
        field = field.strip().strip("[]")
        return f"{_AGG_FUNCTION_MAP[func.lower()]}(_[{field}])", warnings

    m = _COUNT_RE.match(expr)
    if m:
        arg = m.group(1).strip()
        if arg == "*":
            return "Table.RowCount(_)", warnings
        return f"List.Count(_[{arg.strip('[]')}])", warnings

    warnings.append(
        f"{label}: aggregate expression '{expr}' wasn't recognized (only "
        f"Sum/Avg/Min/Max/Count/Count(Distinct ...) are auto-translated); "
        f"left as a flagged placeholder -- please translate manually."
    )
    return f'error "TODO: translate aggregate expression: {expr}"', warnings


def translate_expression(
    expr: str,
    known_fields: Iterable[str] = (),
    label: str = "expression",
    rename_map: Optional[Dict[str, str]] = None,
    variables: Optional[Dict[str, str]] = None,
    peek_context: Optional[Dict[str, str]] = None,
    known_tables: Optional[Iterable[str]] = None,
) -> Tuple[str, List[str]]:
    """
    Translate one Qlik LOAD-script expression into an M expression usable
    inside `each <...>`. Returns (m_expression, warnings).

    known_fields should be the list of column names available at the
    point this expression runs (i.e. the table's real source columns,
    plus any derived columns added by earlier AddColumn steps).

    rename_map: see _wrap_field_references -- lets the caller redirect a
    bare identifier to a renamed column (self-referencing transform
    handling, e.g. `Num(UnitCost,...) as UnitCost`).

    variables: {name: raw_value} from the script's SET/LET statements --
    every $(name) reference is expanded (recursively) before any other
    translation runs.

    peek_context: supplied by the M generator only when it has already
    arranged Index-column support for this table (see
    MQueryGenerator._needs_row_index_support) -- enables translating
    Peek()/Previous()'s "current table, relative row" form.

    known_tables: the set of table names that will actually get their
    own generated query in this migration (see MQueryGenerator.
    generate_table_query). Used only to sanity-check Peek()'s 3-argument
    named-table form -- referencing a table that isn't in this set would
    be a dangling M reference (e.g. the named table was DROP TABLE'd and
    never reconstructed), so that call fails instead of emitting one.
    """
    expr = expr.strip()
    expr, var_warnings = expand_variables(expr, variables, label)

    ctx = TranslationContext(known_fields, label, rename_map, peek_context, known_tables)
    ctx.warnings.extend(var_warnings)

    parts = _split_top_level_concat(expr)
    is_concat = len(parts) > 1

    try:
        translated_parts = []
        for part in parts:
            sub = _translate_expression_core(part, ctx)
            if is_concat:
                is_literal = bool(re.fullmatch(r'"(?:[^"]|"")*"', sub))
                translated_parts.append(sub if is_literal else f"Text.From({sub})")
            else:
                translated_parts.append(sub)
    except _UntranslatableCall as exc:
        ctx.warn(
            f"function call {exc} couldn't be translated (either its "
            f"argument shape isn't supported, or it depends on context "
            f"this tool doesn't have, e.g. Exists()/IterNo(), or "
            f"Peek()/Previous() without an Index column on this table); "
            f"left as a flagged placeholder -- please translate manually."
        )
        return f'error "TODO: translate expression: {expr}"', ctx.warnings

    m_expr = " & ".join(translated_parts)

    # Safety net: this module only ever emits fully-qualified M library
    # calls (Text.From, List.Sum, Date.FromText, ...) or M keyword forms
    # (if...then...else) - every builder above produces one of those. A
    # bare (undotted) identifier immediately followed by "(" that
    # survives all of them is therefore a Qlik function this translator
    # has no rule for at all, passed through untouched. Emitting that
    # as-is produces M that calls an undefined identifier, which is
    # exactly what triggers Power BI's generic, whole-mashup-section "M
    # Engine error ... Invalid identifier" failure at file-open time
    # (the M engine parses the whole mashup document as one unit, so one
    # such call in any one table's query is enough to block every table
    # from opening, not just the one that generated it). Caught here and
    # swapped for a syntactically-valid flagged placeholder instead.
    #
    # [Field references] and "M string literals" are excluded from the
    # scan first: a renamed self-referencing column like
    # `[UnitCost (Source)]` or any field/string text that happens to
    # contain a literal "(" is not a function call and must not trip
    # this check.
    scan_text = _BRACKETED_FIELD_RE.sub(" ", m_expr)
    scan_text = _M_STRING_LITERAL_RE.sub(" ", scan_text)
    untranslated_calls = sorted({
        m.group(1) for m in _UNTRANSLATED_CALL_RE.finditer(scan_text)
        if m.group(1).lower() not in _M_KEYWORDS_NOT_CALLS
    })
    if untranslated_calls:
        ctx.warn(
            f"function call(s) {untranslated_calls} have no Power Query M "
            f"translation in this tool and were left untranslated; swapped "
            f"for a flagged placeholder instead of emitting M that calls an "
            f"undefined identifier (which would fail to open in Power BI "
            f"Desktop) -- please translate manually."
        )
        return f'error "TODO: translate expression (unsupported function(s) {untranslated_calls}): {expr}"', ctx.warnings

    if not known_fields and not rename_map:
        ctx.warn(
            "no known source-field list was available, so bare identifiers "
            "could not be verified/bracketed as field references; review "
            "the generated expression."
        )

    return m_expr, ctx.warnings