"""
MigrationEngine/utils.py
------------------------
Small shared helpers used by every generator in the Migration Engine
(filename sanitizing, M identifier quoting, safe file writes).
Kept in one place so the naming convention stays identical across
m_query_generator, dax_generator, relationship_generator and
pbip_generator.
"""
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from .expression_translator import infer_expression_type

# Characters that are illegal in Windows/macOS/Linux filenames.
_INVALID_FILENAME_CHARS = re.compile(r'[\\/:*?"<>|]')


def sanitize_filename(name: str) -> str:
    """
    Make a string safe to use as a file/folder name while keeping it
    human-readable (spaces and hyphens are preserved, since QlikView
    table/app names commonly contain them).
    """
    cleaned = _INVALID_FILENAME_CHARS.sub("_", name).strip()
    return cleaned or "Unnamed"


def qvw_base_name(script_name: str) -> str:
    """'WorldCup Analysis.qvw' -> 'WorldCup Analysis'"""
    return Path(script_name).stem


def build_table_file_stem(table_name: str, script_name: str) -> str:
    """
    Canonical naming convention for every per-table artifact this
    engine produces: <table_name>_<qvw_file_name> (both sanitized).
    e.g. table 'Match-Wise Data' from 'WorldCup Analysis.qvw' ->
         'Match-Wise Data_WorldCup Analysis'
    """
    base = qvw_base_name(script_name)
    return f"{sanitize_filename(table_name)}_{sanitize_filename(base)}"


def quote_m_identifier(name: str) -> str:
    """Wrap a column/table name in M's #"..." quoted-identifier form.
    Use ONLY for actual M identifiers: step names (X = ...) and
    references to those step names. Do NOT use this for column names
    that appear as plain text data inside a list/record literal (e.g.
    Table.SelectColumns's column list) -- those need quote_m_string
    instead."""
    escaped = name.replace('"', '""')
    return f'#"{escaped}"'


def quote_m_string(value: str) -> str:
    """Wrap a value in a plain M string literal: "...". Use this for
    column names passed as text data, e.g. inside
    Table.SelectColumns({...}) or Table.TransformColumnTypes({{...}}).
    M only needs the quote character itself doubled; backslashes are
    NOT an escape character in M and must not be doubled."""
    escaped = value.replace('"', '""')
    return f'"{escaped}"'


_VALID_BARE_TMDL_IDENTIFIER = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')


def quote_tmdl_identifier(name: str) -> str:
    """
    Quote a name for use as a TMDL object identifier (database, table,
    column, measure, role, etc.) or inside a DAX expression (table/
    column references). Both TMDL and DAX use single quotes around
    names that aren't valid bare identifiers (e.g. contain spaces,
    start with a digit, or contain punctuation); a plain identifier is
    left unquoted. This is a different convention from M's #"..."
    quoting used by quote_m_identifier.
    """
    if _VALID_BARE_TMDL_IDENTIFIER.match(name):
        return name
    escaped = name.replace("'", "''")
    return f"'{escaped}'"


# DocInternals.xml's engine-computed FieldTags (see
# qlik_metadata_extractor/prj/doc_internals_parser.py), mapped to the
# Power Query M type literal (used inside Table.TransformColumnTypes)
# and the matching TMDL column dataType. Order matters: it is the
# precedence used when a field carries more than one tag (e.g. Qlik
# tags an integer field as both "$integer" and "$numeric" - the more
# specific "$integer" should win over the generic "$numeric").
_FIELD_TAG_TYPE_PRECEDENCE: List[Tuple[str, str, str]] = [
    # $timestamp/$date are checked before $integer/$numeric: Qlik's
    # dual-value system stores every date/timestamp as a number
    # internally, so a genuine date field is consistently tagged with
    # BOTH $integer and $date/$timestamp together (confirmed against
    # real DocInternals.xml output, not just in theory) -- checking
    # $integer first would misclassify every date field in a script as
    # a plain int64 column instead of a date, silently losing all of
    # Power BI's native date handling (calendar hierarchies, relative
    # date filters, etc.) for those columns.
    ("$timestamp", "type datetime", "dateTime"),
    ("$date", "type date", "date"),
    ("$integer", "Int64.Type", "int64"),
    ("$numeric", "type number", "double"),
    ("$text", "type text", "string"),
]
_DEFAULT_M_TYPE = "type text"
_DEFAULT_TMDL_TYPE = "string"

# Maps expression_translator.infer_expression_type's return values to
# the same (m_type_literal, tmdl_data_type) shape _FIELD_TAG_TYPE_
# PRECEDENCE produces from a real DocInternals tag, so both paths in
# resolve_field_type agree on the exact same pair of literals.
_INFERRED_TYPE_TO_M: Dict[str, Tuple[str, str]] = {
    "int64": ("Int64.Type", "int64"),
    "double": ("type number", "double"),
    "date": ("type date", "date"),
    "datetime": ("type datetime", "dateTime"),
    "string": ("type text", "string"),
    "boolean": ("type logical", "boolean"),
}


def resolve_field_type(tags: Optional[Iterable[str]], expression: Optional[str] = None) -> Tuple[str, str]:
    """
    Maps a field's DocInternals.xml FieldTags (e.g. ["$integer",
    "$numeric"]) to (m_type_literal, tmdl_data_type) - the exact pair
    m_query_generator and pbip_generator need to agree on so the M
    query's TransformColumnTypes and the TMDL column's dataType
    describe the same type (a mismatch there is a Power BI Desktop
    refresh-time type error, not just a cosmetic difference).

    A real DocInternals tag always wins when present, since it reflects
    the field's actual loaded data. When no tag resolved to anything
    specific -- e.g. a field this migration tool computed itself while
    reconstructing a table (a GROUP BY key, a chain-reconstructed
    derived column) has no corresponding DocInternals entry to read at
    all -- and the caller can supply that field's own Qlik `expression`,
    a best-effort type inferred from the expression's own shape (see
    expression_translator.infer_expression_type) is used instead. If
    neither yields anything confident, this falls back to text/string,
    preserving the tool's original default behavior.
    """
    tag_set = set(tags or [])
    for tag, m_type, tmdl_type in _FIELD_TAG_TYPE_PRECEDENCE:
        if tag in tag_set:
            return m_type, tmdl_type
    if expression:
        inferred = infer_expression_type(expression)
        if inferred in _INFERRED_TYPE_TO_M:
            return _INFERRED_TYPE_TO_M[inferred]
    return _DEFAULT_M_TYPE, _DEFAULT_TMDL_TYPE


def write_text_file(path: Path, content: str) -> Path:
    """Write UTF-8 text, creating parent directories as needed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path