"""
MigrationEngine/report_visual_generator.py
--------------------------------------------
Stage 3 of the toolkit (see README.md): reads the visual metadata
repository built by qlik_metadata_extractor
(Qlik_Visual_MetaData/<app>_visual_metadata.json) and turns it into
real Power BI report pages/visuals inside the PBIP scaffold that
PbipGenerator already wrote (<app>.Report/definition/pages/...),
replacing the single blank placeholder page.

Scope and honest limits
------------------------
QlikView and Power BI Desktop don't have a 1:1 visual model, so this
is a best-effort mapping, not a guaranteed pixel-perfect port:

  - textbox            -> Power BI "textbox" visual (static text)
  - chart (bar/pivot/…) -> nearest built-in Power BI visual type,
                           with dimensions/measures wired to real
                           table.column fields resolved against the
                           Stage-2 semantic model. Numeric measures use
                           a Sum aggregation (Qlik expressions like
                           "Sum(Score)" aren't re-derived as DAX; the
                           column + Sum aggregation is the closest
                           faithful equivalent without inventing a
                           measure the person hasn't reviewed).
  - listbox / drop-down / multibox -> Power BI "slicer", bound to the
                           field the object actually filters (its
                           <Def> or <FieldDef> block, extracted by
                           ListBoxParser/MultiBoxParser), falling back
                           to the caption only for older metadata that
                           doesn't carry that field explicitly. A
                           MultiBoxProperties object stacking several
                           fields into one filter widget only has its
                           first field migrated (Power BI's slicer
                           binds one field); the rest are flagged in
                           the migration notes to add as separate
                           slicers manually.
  - button              -> Power BI "actionButton" (label only; Qlik
                           button actions/macros have no Power BI
                           action equivalent and are not wired up).
  - statistics (StatisticsBoxProperties, QlikView's "Statistics box")
                           -> Power BI "card" (one statistic) or
                           "multiRowCard" (2+ statistics), one line
                           per selected Sum/Average/Min/Max/Count of a
                           field. A plain Sum is bound as a real Sum
                           measure exactly like a chart's Sum-only
                           measure handling; every other statistic
                           (Average/Min/Max/Count) is bound as a raw
                           column instead of guessing at Power BI's
                           internal aggregation-function encoding, and
                           flagged in the migration notes with the
                           exact function to pick in the Values well
                           to match the original Qlik expression.
  - chart with no dimensions and one or more visible measures -> this
                           is Qlik's standard way of building a
                           single-value/KPI display (a chart or table
                           object with only an expression, no
                           dimension), so it's mapped to a Power BI
                           "card" (one measure) or "multiRowCard"
                           (2+ measures) instead of the chart's nominal
                           chart-type visual, which would otherwise be
                           meaningless with nothing to categorize by.
  - textbox whose Text property is a calculated expression (leading
    "=") rather than literal text -- Qlik's other standard single-
    value/KPI idiom -- is resolved, in order of confidence: a plain
    Sum(field) aggregate becomes a real Sum measure; an expression
    that's nothing but one field reference (e.g. "=Referee",
    "=[Total Attendance]") is bound to that field directly; anything
    more complex (string concatenation, if()/len() logic, ...) is
    bound to the first field it references as a best-effort
    placeholder, flagged in the migration notes for a human to
    replace with the real calculated column/measure. Only an
    expression that references no known field at all falls back to
    rendering the literal formula text, so nothing is silently lost.
    A textbox with genuinely literal text always renders as a static
    "textbox" visual.
  - current_selection_box, layout (lines/dividers), and any other
    category -> skipped. Power BI's Filter pane covers the role of a
    current-selection box, and decorative lines have no visual-JSON
    equivalent worth guessing at. Every skip is recorded in
    <app>_visuals_migration_notes.md next to the PBIP output so
    nothing silently disappears.

Position/size: rather than replaying Qlik's original absolute
coordinates (which routinely overlap once mapped onto Power BI's
different canvas/visual proportions), every migrated visual is placed
on a clean left-to-right, top-to-bottom flow/grid layout: each visual
keeps a size derived from its original Qlik dimensions (scaled to fit
the page, with sane per-category defaults when a size is missing),
and visuals are packed shelf-by-shelf with fixed spacing so nothing
overlaps and everything stays within the page boundaries.

As with the rest of the Migration Engine, this produces a *starting
point*: open the .pbip in Power BI Desktop, let it validate/repair,
and expect to refine visuals/formatting from there.
"""
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .config import MigrationConfig
from .dax_generator import DaxGenerator, _AGG_PATTERN
from .metadata_parser import MetadataParser
from .utils import qvw_base_name, sanitize_filename, write_text_file

logger = logging.getLogger(__name__)

# Target width (px) every sheet's Qlik-unit bounding box is scaled
# relative to when sizing visuals; page height is derived from however
# many rows the flow layout below ends up needing.
TARGET_PAGE_WIDTH = 1280
MIN_PAGE_HEIGHT = 400

# Grid/flow layout tuning. Visuals are packed left-to-right, wrapping
# to a new row (top-to-bottom) whenever the next one would overflow
# the page width, with a fixed gutter between visuals and a margin
# around the page edge - a plain CSS-flexbox-style "shelf" packing,
# generic over any number/shape of visuals on any sheet.
PAGE_MARGIN = 24
GRID_GUTTER = 20
MIN_VISUAL_WIDTH = 160
MIN_VISUAL_HEIGHT = 90
MAX_VISUAL_HEIGHT = 360

# Fallback size (px) per category when a visual's original Qlik
# position is missing/degenerate, so it still gets a sane footprint
# in the grid instead of collapsing to the absolute floor size.
DEFAULT_VISUAL_SIZE = {
    "textbox": (360, 80),
    "button": (180, 50),
    "listbox": (240, 220),
    "multibox": (240, 220),
    "chart": (480, 320),
    "statistics": (220, 140),
}
# KPI/Card-style visuals (see _build_chart/_build_textbox) read best
# as a small tile rather than a full chart-sized box.
DEFAULT_KPI_SIZE = (220, 140)
KPI_VISUAL_TYPES = {"card", "multiRowCard"}

# Qlik GraphProperties chart_type -> nearest built-in Power BI visual type.
# Anything not listed here (including chart types with no real Power BI
# equivalent, e.g. radar/gauge/block charts) falls back to FALLBACK_CHART_VISUAL
# so the data still lands on the page in some visible form.
CHART_TYPE_MAP = {
    "GRAPH_MODE_BAR": "clusteredColumnChart",
    "GRAPH_MODE_LINE": "lineChart",
    "GRAPH_MODE_COMBO": "lineClusteredColumnCombo",
    "GRAPH_MODE_PIE": "pieChart",
    "GRAPH_MODE_SCATTER": "scatterChart",
    "GRAPH_MODE_GRID": "tableEx",
    "GRAPH_MODE_PIVOTTABLE": "pivotTable",
}
FALLBACK_CHART_VISUAL = "tableEx"

SUPPORTED_CATEGORIES = {"textbox", "chart", "listbox", "multibox", "button", "statistics"}
SUM_AGGREGATION_FUNCTION = 0  # Power BI query aggregation enum: 0 = Sum

# Power BI query aggregation enum (QueryAggregateFunction) - the same
# numeric codes report.json/visual.json store under
# field.Aggregation.Function. Only Sum (0) was previously encoded here;
# chart/statistics measures using any other single-field aggregate
# (Avg/Min/Max/Count/Count(Distinct...)) were being silently dropped
# instead of bound with the matching function code, which is what left
# charts like a Count(DISTINCT ...) bar chart or a count(distinct ...)
# pie chart with a Category but no Values - i.e. broken/blank visuals.
AGGREGATION_FUNCTION_CODE = {
    "sum": 0,
    "avg": 1,
    "distinctcount": 2,
    "min": 3,
    "max": 4,
    "count": 5,
}


import re as _re

# Qlik expressions commonly wrap the field in square brackets when it
# contains spaces/special characters, e.g. "sum([Home Team Goals])"
# as well as the plain "Sum(Score)". Shared by chart measures and by
# expression-driven KPI textboxes (see _build_chart / _build_textbox)
# since both need to recognise the same "just a plain aggregate"
# shape before it can be re-bound as a real Power BI measure.
_SUM_EXPR_RE = _re.compile(r"^\s*Sum\(\s*\[?([^()\[\]]+?)\]?\s*\)\s*$", _re.IGNORECASE)


def _sum_expression_field(expr: str) -> Optional[str]:
    """Returns the bare field name if `expr` is a plain Sum(field) (optionally
    bracketed) aggregate - Qlik's most common single-value/KPI expression
    shape - or None if it's anything more complex (set analysis, multi-field
    formulas, other aggregation functions)."""
    m = _SUM_EXPR_RE.match(expr or "")
    return m.group(1).strip() if m else None


_BARE_FIELD_RE = _re.compile(r"^\[([^\[\]]+)\]$|^[A-Za-z_][A-Za-z0-9_]*$")
_BRACKETED_FIELD_RE = _re.compile(r"\[([^\[\]]+)\]")


def _bare_field_reference(expr: str) -> Optional[str]:
    """If `expr` is *nothing but* a single field reference - bracketed
    (e.g. "[Total Attendance]") or a plain identifier (e.g. "Referee") -
    returns that field name; otherwise None. This is Qlik's simplest
    calculated-text-object idiom: a text box that just shows one field's
    current value, with no aggregation or combination involved."""
    token = (expr or "").strip()
    m = _BARE_FIELD_RE.match(token)
    if not m:
        return None
    return (m.group(1) or token).strip()


def _first_bracketed_field(expr: str) -> Optional[str]:
    """First [Bracketed Field Name] referenced anywhere in `expr` - used
    as a best-effort fallback for expressions (string concatenation,
    if()/len() logic, ...) that combine multiple fields and can't be
    re-derived as a single DAX formula automatically, matching the same
    "bind the closest column and flag it for review" approach already
    used for non-Sum chart measures."""
    m = _BRACKETED_FIELD_RE.search(expr or "")
    return m.group(1).strip() if m else None


def _dax_literal(value: str) -> str:
    """Quote a string the way Power BI's report JSON stores literal text
    constants in `objects.*.properties.*.expr.Literal.Value`."""
    escaped = (value or "").replace("'", "''")
    return f"'{escaped}'"


class FieldResolver:
    """Resolves a Qlik field name to the semantic-model table that
    contains it, using the same enriched-table list PbipGenerator built
    the TMDL tables from. Ambiguous fields (present in 2+ tables) are
    resolved to the first table found and flagged, since the visual
    metadata doesn't record which table a chart's field came from.

    When DocInternals.xml's engine-computed field lineage is available
    (`field_lineage`, field -> source table(s)) and it names exactly
    one table for a field, that table is preferred over the
    LoadScript-parser's first match: the LoadScript parser is a
    regex-based heuristic and can misattribute a field (most commonly
    a RESIDENT-load table whose fields it can't always trace back to
    the correct alias), whereas DocInternals is QlikView's own runtime
    computation of where each field actually lives. When lineage lists
    2+ tables for a field, it's a genuinely shared key and there's no
    more information available to prefer one over another, so the
    existing first-match behavior is left as-is.
    """

    def __init__(
        self,
        enriched_tables: List[Dict[str, Any]],
        field_lineage: Optional[Dict[str, List[str]]] = None,
    ):
        self.field_to_table: Dict[str, str] = {}
        self.ambiguous_fields: set = set()
        table_names = {t.get("name", "") for t in enriched_tables}
        for table in enriched_tables:
            table_name = table.get("name", "")
            for field in table.get("fields", []) or []:
                if field in self.field_to_table and self.field_to_table[field] != table_name:
                    self.ambiguous_fields.add(field)
                else:
                    self.field_to_table[field] = table_name

        field_lineage = field_lineage or {}
        for field, source_tables in field_lineage.items():
            resolved_sources = [t for t in source_tables if t in table_names]
            if len(resolved_sources) == 1 and self.field_to_table.get(field) != resolved_sources[0]:
                self.field_to_table[field] = resolved_sources[0]
                self.ambiguous_fields.discard(field)

    def resolve(self, field: str) -> Optional[str]:
        return self.field_to_table.get(field)


class ReportVisualGenerator:

    def __init__(self, pbip_output_dir: Path = MigrationConfig.PBIP_OUTPUT_DIR):
        self.pbip_output_dir = Path(pbip_output_dir)

    # ------------------------------------------------------------------
    # Layout helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _sheet_bounds(visuals: List[Dict[str, Any]]) -> Tuple[float, float]:
        max_x, max_y = 0.0, 0.0
        for v in visuals:
            p = v.get("position") or {}
            left, top = p.get("Left"), p.get("Top")
            width, height = p.get("Width"), p.get("Height")
            if None in (left, top, width, height):
                continue
            max_x = max(max_x, left + width)
            max_y = max(max_y, top + height)
        return max_x or TARGET_PAGE_WIDTH, max_y or MIN_PAGE_HEIGHT

    @staticmethod
    def _scaled_position(position: Dict[str, Any], scale: float, z: int) -> Optional[Dict[str, Any]]:
        left, top = position.get("Left"), position.get("Top")
        width, height = position.get("Width"), position.get("Height")
        if None in (left, top, width, height):
            return None
        return {
            "x": round(left * scale, 2),
            "y": round(top * scale, 2),
            "z": z,
            "width": max(round(width * scale, 2), 4),
            "height": max(round(height * scale, 2), 4),
            "tabOrder": z,
        }

    @staticmethod
    def _natural_size(
        position: Dict[str, Any], scale: float, category: str, visual_type: str
    ) -> Tuple[float, float]:
        """
        A visual's footprint for the grid layout: its original Qlik
        size scaled to the target page (preserving relative sizing
        between visuals on the same sheet), falling back to a sane
        per-category default when the original size is missing or
        degenerate (e.g. zero), then clamped to a sensible min/max so
        no visual ends up unreadably tiny or absurdly large.
        """
        width, height = position.get("Width"), position.get("Height")
        if visual_type in KPI_VISUAL_TYPES:
            default_w, default_h = DEFAULT_KPI_SIZE
        else:
            default_w, default_h = DEFAULT_VISUAL_SIZE.get(category, DEFAULT_VISUAL_SIZE["chart"])

        if width and height and width > 0 and height > 0:
            w, h = width * scale, height * scale
        else:
            w, h = default_w, default_h

        max_w = TARGET_PAGE_WIDTH - 2 * PAGE_MARGIN
        w = min(max(w, MIN_VISUAL_WIDTH), max_w)
        h = min(max(h, MIN_VISUAL_HEIGHT), MAX_VISUAL_HEIGHT)
        return round(w, 2), round(h, 2)

    @staticmethod
    def _flow_layout(
        items: List[Tuple[str, float, float]]
    ) -> Tuple[Dict[str, Tuple[float, float]], float]:
        """
        Places each (object_id, width, height) on a left-to-right,
        top-to-bottom "shelf" grid: visuals are packed one after
        another along a row until the next one would overflow the
        page width, at which point a new row starts below the tallest
        visual in the row so far. A fixed gutter separates visuals and
        a margin frames the page, so - regardless of how many visuals
        a sheet has or what their original Qlik coordinates were -
        nothing ever overlaps and everything stays within the page.
        Returns ({object_id: (x, y)}, page_height).
        """
        usable_width = TARGET_PAGE_WIDTH - PAGE_MARGIN
        cursor_x = PAGE_MARGIN
        cursor_y = PAGE_MARGIN
        row_height = 0.0
        positions: Dict[str, Tuple[float, float]] = {}

        for object_id, width, height in items:
            if cursor_x > PAGE_MARGIN and cursor_x + width > usable_width:
                cursor_y += row_height + GRID_GUTTER
                cursor_x = PAGE_MARGIN
                row_height = 0.0
            positions[object_id] = (round(cursor_x, 2), round(cursor_y, 2))
            cursor_x += width + GRID_GUTTER
            row_height = max(row_height, height)

        page_height = max(cursor_y + row_height + PAGE_MARGIN, MIN_PAGE_HEIGHT)
        return positions, page_height

    # ------------------------------------------------------------------
    # Field-query builders
    # ------------------------------------------------------------------
    @staticmethod
    def _column_projection(table: str, field: str) -> Dict[str, Any]:
        return {
            "field": {
                "Column": {
                    "Expression": {"SourceRef": {"Entity": table}},
                    "Property": field,
                }
            },
            "queryRef": f"{table}.{field}",
            "nativeQueryRef": field,
        }

    @staticmethod
    def _sum_projection(table: str, field: str) -> Dict[str, Any]:
        return {
            "field": {
                "Aggregation": {
                    "Expression": {
                        "Column": {
                            "Expression": {"SourceRef": {"Entity": table}},
                            "Property": field,
                        }
                    },
                    "Function": SUM_AGGREGATION_FUNCTION,
                }
            },
            "queryRef": f"Sum({table}.{field})",
            "nativeQueryRef": f"Sum of {field}",
        }

    @staticmethod
    def _aggregation_projection(table: str, field: str, dax_func: str) -> Dict[str, Any]:
        """
        Same shape as _sum_projection but for any of the single-field
        aggregations dax_generator.translate_measure_expression already
        recognises (Sum/Avg/Min/Max/Count/Count Distinct). Used so a
        chart/statistics measure whose Qlik expression is, say,
        "Count(DISTINCT [Field])" or "count(distinct Field)" still gets
        a real Values/Y aggregation instead of being dropped - dropping
        it left the visual with a Category but no value, which Power BI
        renders as an empty box.
        """
        func_key = "distinctcount" if dax_func == "DISTINCTCOUNT" else dax_func.lower()
        function_code = AGGREGATION_FUNCTION_CODE.get(func_key, SUM_AGGREGATION_FUNCTION)
        display = {
            "SUM": "Sum",
            "AVERAGE": "Average",
            "MIN": "Min",
            "MAX": "Max",
            "COUNT": "Count",
            "DISTINCTCOUNT": "Distinct count",
        }.get(dax_func, dax_func.title())
        query_ref_func = display.replace(" ", "")
        return {
            "field": {
                "Aggregation": {
                    "Expression": {
                        "Column": {
                            "Expression": {"SourceRef": {"Entity": table}},
                            "Property": field,
                        }
                    },
                    "Function": function_code,
                }
            },
            "queryRef": f"{query_ref_func}({table}.{field})",
            "nativeQueryRef": f"{display} of {field}",
        }

    @staticmethod
    def _measure_projection(table: str, measure: str) -> Dict[str, Any]:
        """A real named model measure (e.g. one DaxGenerator.statistics_measures_for_metadata
        embedded into `table`'s .tmdl), as opposed to _column_projection's raw
        column or _aggregation_projection's column+built-in-aggregation - needed
        wherever the underlying value isn't a single Sum/Avg/Min/Max/Count of one
        column (e.g. "Total count" -> COUNTA, which Power BI's visual-level
        Aggregation.Function enum has no code for)."""
        return {
            "field": {
                "Measure": {
                    "Expression": {"SourceRef": {"Entity": table}},
                    "Property": measure,
                }
            },
            "queryRef": f"{table}.{measure}",
            "nativeQueryRef": measure,
        }

    @staticmethod
    def _query_state(roles: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        return {role: {"projections": projections} for role, projections in roles.items() if projections}

    # ------------------------------------------------------------------
    # Per-category visual builders. Each returns (visual_dict, unresolved_fields).
    # ------------------------------------------------------------------
    @staticmethod
    def _card_color_objects(
        v: Dict[str, Any], color_measure_lookup: Optional[Dict[str, Dict[str, str]]]
    ) -> Tuple[Dict[str, Any], Optional[str]]:
        """
        Returns an "objects" fragment applying this object's ColorExpr
        (translated to a DAX measure by DaxGenerator.color_measures_for_metadata,
        looked up by object_id) as the card's conditional font color, plus
        an optional note when a ColorExpr exists but couldn't be converted.
        ({}, None) when there's nothing to apply, so callers can merge the
        result into their own "objects" dict unconditionally.
        """
        if color_measure_lookup is None:
            return {}, None
        object_id = v.get("object_id")
        binding = color_measure_lookup.get(object_id)
        if not binding:
            color_expr = (v.get("color_expr") or "").strip()
            if color_expr:
                return {}, (
                    f"{object_id}: ColorExpr '{color_expr}' could not be converted to a DAX "
                    f"conditional-formatting measure - apply the color rule manually in Power BI"
                )
            return {}, None
        return (
            {
                "value": [
                    {
                        "properties": {
                            "fontColor": {
                                "solid": {
                                    "color": {
                                        "expr": {
                                            "Measure": {
                                                "Expression": {"SourceRef": {"Entity": binding["table"]}},
                                                "Property": binding["measure"],
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                ]
            },
            None,
        )

    def _build_textbox(
        self,
        v: Dict[str, Any],
        resolver: Optional[FieldResolver] = None,
        color_measure_lookup: Optional[Dict[str, Dict[str, str]]] = None,
    ) -> Tuple[Dict[str, Any], List[str]]:
        text = v.get("text_content") or v.get("caption") or ""
        stripped = text.strip()

        # Qlik's other standard single-value/KPI idiom: a text object
        # whose Text property is a calculated expression (leading "=")
        # rather than literal text. `resolver` is optional so existing
        # callers/tests that only want static-text handling (no field
        # binding available) are unaffected.
        if resolver is not None and stripped.startswith("="):
            expr = stripped[1:].strip()
            title = v.get("caption") or ""
            objects: Dict[str, Any] = {}
            if title:
                objects["title"] = [
                    {"properties": {"text": {"expr": {"Literal": {"Value": _dax_literal(title)}}}}}
                ]
            # A ColorExpr colors whatever value ends up being shown, so
            # it applies the same way regardless of which resolution
            # path below actually fires.
            color_objects, color_note = self._card_color_objects(v, color_measure_lookup)
            objects.update(color_objects)
            color_notes = [color_note] if color_note else []

            # 1) A plain Sum(field) aggregate - build a real Sum measure.
            sum_field = _sum_expression_field(expr)
            table = resolver.resolve(sum_field) if sum_field else None
            if table:
                return (
                    {
                        "visualType": "card",
                        "query": {"queryState": self._query_state({"Values": [self._sum_projection(table, sum_field)]})},
                        "objects": objects,
                    },
                    color_notes,
                )

            # 2) The whole expression is nothing but one field reference
            # (e.g. "=Referee", "=[Total Attendance]") - the very common
            # "just show this field's current value" text object. Bound
            # as a plain (unaggregated) column, same as a slicer/chart
            # dimension, since there's no aggregation to apply.
            bare_field = _bare_field_reference(expr)
            table = resolver.resolve(bare_field) if bare_field else None
            if table:
                return (
                    {
                        "visualType": "card",
                        "query": {"queryState": self._query_state({"Values": [self._column_projection(table, bare_field)]})},
                        "objects": objects,
                    },
                    color_notes,
                )

            # 3) Anything more complex (string concatenation, if()/len()
            # logic, multi-field formulas) can't be re-derived as a
            # single DAX expression automatically. As with a non-Sum
            # chart measure elsewhere in this file, the closest
            # referenced field is bound as a raw column instead of
            # losing the object entirely, flagged for a human to
            # replace with the real calculated column/measure.
            fallback_field = _first_bracketed_field(expr)
            table = resolver.resolve(fallback_field) if fallback_field else None
            if table:
                return (
                    {
                        "visualType": "card",
                        "query": {"queryState": self._query_state({"Values": [self._column_projection(table, fallback_field)]})},
                        "objects": objects,
                    },
                    color_notes
                    + [
                        f"{v.get('object_id')}: text expression '{text}' combines multiple fields/functions "
                        f"and wasn't fully re-derived - bound to '{fallback_field}' alone as a placeholder; "
                        f"replace with the real calculated column or DAX measure"
                    ],
                )

            unresolved = color_notes + [
                f"{v.get('object_id')}: text expression '{text}' could not be resolved to any known field "
                f"- rendered as static text instead of a live value"
            ]
        else:
            unresolved = []

        fonts = v.get("fonts") or []
        bold = bool(fonts) and str(fonts[0].get("bold", "false")).lower() == "true"
        text_style = {"fontWeight": "bold"} if bold else {}
        return (
            {
                "visualType": "textbox",
                "objects": {
                    "general": [
                        {
                            "properties": {
                                "paragraphs": [
                                    {"textRuns": [{"value": text, "textStyle": text_style}]}
                                ]
                            }
                        }
                    ]
                },
            },
            [],
        )

    def _build_button(self, v: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
        caption = v.get("caption") or v.get("text_content") or "Button"
        return (
            {
                "visualType": "actionButton",
                "objects": {
                    "text": [{"properties": {"text": {"expr": {"Literal": {"Value": _dax_literal(caption)}}}}}],
                },
            },
            [],
        )

    def _build_slicer(self, v: Dict[str, Any], resolver: FieldResolver) -> Tuple[Optional[Dict[str, Any]], List[str]]:
        # ListBoxParser/MultiBoxParser read the object's real bound
        # field(s) out of its <Def>/<FieldDef> block(s) (v["field"]/
        # v["fields"]); only fall back to the caption for older/other
        # metadata that didn't carry that field, since a filter's
        # caption is a free-text display label and isn't guaranteed
        # to match the field it filters.
        fields: List[str] = list(v.get("fields") or [])
        if not fields and v.get("field"):
            fields = [v["field"]]
        source = "field(s)" if fields else "caption"
        if not fields and v.get("caption"):
            fields = [v["caption"]]

        object_id = v.get("object_id")
        category = v.get("category", "listbox")
        if not fields:
            return None, [f"{category} {object_id}: no bound field found"]

        field = fields[0]
        table = resolver.resolve(field)
        if not table:
            return None, [f"{category} {object_id}: field '{field}' (from {source}) not found in any table"]

        unresolved: List[str] = []
        if len(fields) > 1:
            # A QlikView MultiBox can stack several fields into one
            # widget; Power BI's single-select slicer only binds one
            # field, so the rest are flagged rather than silently
            # dropped - add them as separate slicers if they're needed.
            unresolved.append(
                f"{category} {object_id}: filters on multiple fields {fields} - only the first "
                f"('{field}') was migrated to this slicer; add the rest ({fields[1:]}) as separate "
                f"slicers manually if needed"
            )
        # A Qlik listbox/multibox's caption is a free-text display label
        # and, as _build_chart/_build_statistics_box already do for
        # their visuals, should win over Power BI's default of showing
        # the raw bound field name - the two aren't guaranteed to match
        # (e.g. a listbox captioned "City" that's actually bound to an
        # "Assistant 1" field in the source data). Without this, every
        # migrated slicer loses its original caption.
        title = v.get("caption") or ""
        objects: Dict[str, Any] = {}
        if title:
            objects["title"] = [
                {"properties": {"text": {"expr": {"Literal": {"Value": _dax_literal(title)}}}}}
            ]

        return (
            {
                "visualType": "slicer",
                "query": {"queryState": self._query_state({"Values": [self._column_projection(table, field)]})},
                "objects": objects,
            },
            unresolved,
        )

    def _build_statistics_box(
        self, v: Dict[str, Any], statistics_binding: Optional[Dict[str, Dict[str, Any]]]
    ) -> Tuple[Optional[Dict[str, Any]], List[str]]:
        """
        StatisticsBoxProperties -> a Power BI Card (exactly one displayed
        statistic) or Table (more than one), per `statistics_binding`
        (DaxGenerator.statistics_measures_for_metadata - a real DAX
        measure for the Card case, a real Metric/Value calculated table
        for the Table case; both already embedded into the semantic
        model by PbipGenerator using the exact same computation). The
        specific reason a box has no binding (unrecognised MemberMask
        bit, field not found, ...) is already in that function's own
        `notes`, merged into this sheet's notes by the caller - so a
        missing binding here just means "not migrated", not silence.
        """
        object_id = v.get("object_id")
        binding = (statistics_binding or {}).get(object_id)
        if not binding:
            if not (v.get("measures") or []):
                return None, [f"statistics {object_id}: no statistics/expressions found"]
            return None, [f"statistics {object_id}: not migrated (see the DAX conversion note above)"]

        title = v.get("caption") or ""
        objects: Dict[str, Any] = {}
        if title:
            objects["title"] = [
                {"properties": {"text": {"expr": {"Literal": {"Value": _dax_literal(title)}}}}}
            ]

        if binding["kind"] == "card":
            values = [self._measure_projection(binding["table"], binding["measure"])]
            return (
                {
                    "visualType": "card",
                    "query": {"queryState": self._query_state({"Values": values})},
                    "objects": objects,
                },
                [],
            )

        # "table" kind: the calculated Metric/Value table PbipGenerator
        # wrote for this box, one row per originally-displayed statistic
        # in its original order (see DaxGenerator._calculated_table_tmdl).
        values = [
            self._column_projection(binding["table"], binding["metric_column"]),
            self._column_projection(binding["table"], binding["value_column"]),
        ]
        return (
            {
                "visualType": "tableEx",
                "query": {"queryState": self._query_state({"Values": values})},
                "objects": objects,
            },
            [],
        )

    def _build_chart(self, v: Dict[str, Any], resolver: FieldResolver) -> Tuple[Optional[Dict[str, Any]], List[str]]:
        chart_type = v.get("chart_type", "")
        visual_type = CHART_TYPE_MAP.get(chart_type, FALLBACK_CHART_VISUAL)
        unresolved: List[str] = []

        dim_projections = []
        for dim in v.get("dimensions", []) or []:
            field = dim.get("field")
            table = resolver.resolve(field) if field else None
            if not field:
                continue
            if not table:
                unresolved.append(f"{v.get('object_id')}: dimension field '{field}' not found in any table")
                continue
            dim_projections.append(self._column_projection(table, field))

        measure_projections = []
        for measure in v.get("measures", []) or []:
            field = measure.get("field") or measure.get("label")
            expr = measure.get("expression", "")
            # Any plain single-field aggregation Qlik supports on a
            # chart expression - Sum/Avg/Min/Max/Count, optionally
            # Count(DISTINCT ...) - maps cleanly onto a column +
            # matching Power BI aggregation function. This reuses the
            # exact same recognizer dax_generator.translate_measure_expression
            # already uses for the advisory .dax script, so a chart
            # measure and its script counterpart agree on what counts
            # as "simple enough to auto-convert". Anything else (set
            # analysis, multi-field formulas, RangeSum, ...) can't be
            # re-derived without a human writing the real DAX measure,
            # so it's flagged instead of silently guessed at.
            agg_match = _AGG_PATTERN.match(expr or "")
            source_field = (agg_match.group("field").strip() if agg_match else None) or field
            table = resolver.resolve(source_field) if source_field else None
            if not table:
                unresolved.append(
                    f"{v.get('object_id')}: measure '{measure.get('label', '')}' "
                    f"(expression '{expr}') could not be resolved to a table column "
                    f"- add the equivalent DAX measure manually"
                )
                continue
            if agg_match:
                func = agg_match.group("func").lower()
                is_distinct = bool(agg_match.group("distinct"))
                if func == "only":
                    unresolved.append(
                        f"{v.get('object_id')}: measure '{measure.get('label', '')}' expression "
                        f"'{expr}' is an Only(field) - no matching chart-Values aggregation in "
                        f"Power BI; bound as a raw column instead, review before publishing"
                    )
                    measure_projections.append(self._column_projection(table, source_field))
                else:
                    dax_func = "DISTINCTCOUNT" if (func == "count" and is_distinct) else {
                        "sum": "SUM", "avg": "AVERAGE", "min": "MIN", "max": "MAX", "count": "COUNT",
                    }[func]
                    measure_projections.append(self._aggregation_projection(table, source_field, dax_func))
            else:
                unresolved.append(
                    f"{v.get('object_id')}: measure '{measure.get('label', '')}' expression "
                    f"'{expr}' is not a plain Sum/Avg/Min/Max/Count(field) - bound as a raw "
                    f"column instead of re-deriving the expression; review before publishing"
                )
                measure_projections.append(self._column_projection(table, source_field))

        if not dim_projections and not measure_projections:
            return None, unresolved or [f"{v.get('object_id')}: chart has no resolvable dimensions/measures"]

        # Qlik's standard way of building a single-value/KPI display is
        # a chart (or straight/pivot table) with an expression but no
        # dimension - there's nothing to categorize by, so whatever
        # chart type was nominally configured (bar/line/pivot/...) is
        # meaningless; Power BI's actual single-value visuals ("card"
        # for one measure, "multiRowCard" for several) are the honest
        # equivalent. This is a purely structural check (dimension
        # count), so it applies uniformly to any QlikView report.
        if not dim_projections and measure_projections:
            visual_type = "card" if len(measure_projections) == 1 else "multiRowCard"

        if visual_type in KPI_VISUAL_TYPES:
            roles = {"Values": measure_projections}
        elif visual_type == "pivotTable":
            roles = {"Rows": dim_projections, "Values": measure_projections}
        elif visual_type == "tableEx":
            roles = {"Values": dim_projections + measure_projections}
        else:
            roles = {"Category": dim_projections, "Y": measure_projections}

        title = v.get("caption") or ""
        objects: Dict[str, Any] = {}
        if title:
            objects["title"] = [
                {"properties": {"text": {"expr": {"Literal": {"Value": _dax_literal(title)}}}}}
            ]

        return (
            {
                "visualType": visual_type,
                "query": {"queryState": self._query_state(roles)},
                "objects": objects,
            },
            unresolved,
        )

    # ------------------------------------------------------------------
    # Orchestration
    # ------------------------------------------------------------------
    @staticmethod
    def _pages_json(page_names_and_display: List[Tuple[str, str]]) -> str:
        import json as _json

        return _json.dumps(
            {
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json",
                "pageOrder": [name for name, _ in page_names_and_display],
                "activePageName": page_names_and_display[0][0] if page_names_and_display else "",
            },
            indent=2,
        ) + "\n"

    @staticmethod
    def _page_json(name: str, display_name: str, width: float, height: float) -> str:
        import json as _json

        return _json.dumps(
            {
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json",
                "name": name,
                "displayName": display_name or name,
                "displayOption": "FitToPage",
                "height": round(height, 2),
                "width": round(width, 2),
            },
            indent=2,
        ) + "\n"

    @staticmethod
    def _visual_json(name: str, position: Dict[str, Any], visual: Dict[str, Any]) -> str:
        import json as _json

        return _json.dumps(
            {
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.0.0/schema.json",
                "name": name,
                "position": position,
                "visual": visual,
            },
            indent=2,
        ) + "\n"

    def generate_for_app(
        self,
        metadata: Dict[str, Any],
        visual_metadata: Dict[str, Any],
        parser: MetadataParser,
    ) -> Tuple[Path, List[str]]:
        """
        Populate <app>.Report/definition/pages/ with one page per Qlik
        sheet and one visual folder per migrated visual, replacing the
        blank placeholder page PbipGenerator wrote. Returns the app root
        path and the list of migration notes (skips/warnings) to write
        alongside the PBIP output.
        """
        script_name = metadata.get("script_name", "UnknownApp.qvw")
        app_name = sanitize_filename(qvw_base_name(script_name))
        app_root = self.pbip_output_dir / app_name
        report_dir = app_root / f"{app_name}.Report"
        pages_dir = report_dir / "definition" / "pages"

        if not report_dir.exists():
            raise FileNotFoundError(
                f"No PBIP report scaffold found at {report_dir} - run PbipGenerator first."
            )

        resolver = FieldResolver(
            parser.enrich_tables(metadata),
            field_lineage=(metadata.get("document_properties") or {}).get("field_lineage"),
        )
        # PbipGenerator embeds these same color measures into the real
        # model (see pbip_generator._table_tmdl); this call is a pure
        # function of metadata, so recomputing it here yields the exact
        # same measure names/tables to reference from the visual JSON.
        color_measure_lookup, _color_measures_by_table, color_notes = DaxGenerator().color_measures_for_metadata(
            metadata
        )
        # PbipGenerator embeds these same measures/calculated tables into
        # the real model (see pbip_generator.generate_for_metadata); this
        # call is a pure function of metadata, so recomputing it here
        # yields the exact same table/measure names to reference from
        # the visual JSON - same reasoning as color_measure_lookup above.
        statistics_binding, _stat_measures_by_table, _stat_calculated_tables, stat_notes = (
            DaxGenerator().statistics_measures_for_metadata(metadata)
        )
        notes: List[str] = [f"[{metadata.get('script_name', '')}] {n}" for n in color_notes]
        notes.extend(f"[{metadata.get('script_name', '')}] {n}" for n in stat_notes)
        page_names_and_display: List[Tuple[str, str]] = []

        # Remove the single placeholder page PbipGenerator wrote; it has
        # no visuals worth preserving and would otherwise linger as an
        # extra blank page alongside the real ones.
        placeholder = pages_dir / "ReportSection1"
        if placeholder.exists():
            import shutil

            shutil.rmtree(placeholder)

        sheets = visual_metadata.get("sheets", []) or []
        if not sheets:
            notes.append("No sheets found in the visual metadata repository - nothing to generate.")

        for sheet in sheets:
            sheet_id = sheet.get("sheet_id") or f"Sheet{len(page_names_and_display) + 1}"
            page_name = sanitize_filename(sheet_id)
            display_name = sheet.get("caption") or page_name
            visuals = sheet.get("visuals", []) or []

            bounds_w, _bounds_h = self._sheet_bounds(visuals)
            scale = TARGET_PAGE_WIDTH / bounds_w if bounds_w else 1.0

            # Reading order (top-to-bottom, then left-to-right) is used
            # only to decide the order visuals are packed into the grid
            # below - it approximates how the sheet was meant to be
            # scanned. Qlik's original z_order no longer matters for
            # positioning once the flow layout guarantees no overlap;
            # it's kept as a final tiebreaker for determinism.
            ordered = sorted(
                visuals,
                key=lambda v: (
                    (v.get("position") or {}).get("Top", 0) or 0,
                    (v.get("position") or {}).get("Left", 0) or 0,
                    (v.get("position") or {}).get("z_order", 0) or 0,
                ),
            )

            # Pass 1: build every visual that can be migrated (recording
            # skips/failures exactly as before) without touching layout.
            built: List[Tuple[str, Dict[str, Any], float, float]] = []
            for v in ordered:
                category = v.get("category")
                object_type = v.get("object_type")
                object_id = sanitize_filename(v.get("object_id") or f"visual_{len(built)}")

                # A PRJ file's two-letter prefix is usually enough to know
                # its category (see prj_metadata_service.py), but not every
                # QlikView export uses this repo's assumed prefix for every
                # object flavour. The object's own declared type is
                # authoritative for these two, so it overrides an
                # unexpected category here too - a second safety net on
                # top of the extraction-side one, so a MultiBoxProperties
                # or StatisticsBoxProperties object is never silently
                # skipped as "unsupported" purely because of a prefix
                # mismatch upstream.
                if object_type == "MultiBoxProperties" and category not in ("multibox", "listbox"):
                    category = "multibox"
                elif object_type == "StatisticsBoxProperties" and category != "statistics":
                    category = "statistics"

                if category not in SUPPORTED_CATEGORIES:
                    if category not in ("layout", "current_selection_box"):
                        notes.append(f"[{sheet_id}] {object_id}: category '{category}' not migrated (unsupported)")
                    else:
                        notes.append(f"[{sheet_id}] {object_id}: category '{category}' skipped by design")
                    continue

                if category == "textbox":
                    visual, unresolved = self._build_textbox(v, resolver, color_measure_lookup)
                elif category == "button":
                    visual, unresolved = self._build_button(v)
                elif category in ("listbox", "multibox"):
                    visual, unresolved = self._build_slicer(v, resolver)
                elif category == "chart":
                    visual, unresolved = self._build_chart(v, resolver)
                elif category == "statistics":
                    visual, unresolved = self._build_statistics_box(v, statistics_binding)
                else:
                    visual, unresolved = None, []

                notes.extend(f"[{sheet_id}] {u}" for u in unresolved)

                if visual is None:
                    notes.append(f"[{sheet_id}] {object_id}: not migrated (unresolved fields, see above)")
                    continue

                width, height = self._natural_size(
                    v.get("position") or {}, scale, category, visual.get("visualType", "")
                )
                built.append((object_id, visual, width, height))

            # Pass 2: lay every surviving visual out on a clean,
            # non-overlapping grid instead of replaying Qlik's original
            # (often overlapping) absolute coordinates - see module
            # docstring.
            positions_by_id, page_height = self._flow_layout(
                [(object_id, width, height) for object_id, _v, width, height in built]
            )

            visual_dir = pages_dir / page_name / "visuals"
            for z, (object_id, visual, width, height) in enumerate(built):
                x, y = positions_by_id[object_id]
                position = {
                    "x": x,
                    "y": y,
                    "z": z,
                    "width": width,
                    "height": height,
                    "tabOrder": z,
                }
                write_text_file(
                    visual_dir / object_id / "visual.json",
                    self._visual_json(object_id, position, visual),
                )

            write_text_file(
                pages_dir / page_name / "page.json",
                self._page_json(page_name, display_name, TARGET_PAGE_WIDTH, page_height),
            )
            page_names_and_display.append((page_name, display_name))
            logger.info(
                f"[{app_name}] page '{display_name}' ({page_name}): {len(built)}/{len(visuals)} visuals migrated"
            )

        write_text_file(pages_dir / "pages.json", self._pages_json(page_names_and_display))

        return app_root, notes

    def generate_for_all(self, parser: MetadataParser, visual_loader) -> List[Path]:
        results = []
        for metadata in parser.load_all():
            visual_metadata = visual_loader.load_for_metadata(metadata)
            if visual_metadata is None:
                continue
            app_root, notes = self.generate_for_app(metadata, visual_metadata, parser)
            app_name = sanitize_filename(qvw_base_name(metadata.get("script_name", "UnknownApp.qvw")))
            notes_path = app_root / f"{app_name}_visuals_migration_notes.md"
            write_text_file(
                notes_path,
                "# Visual migration notes for " + app_name + "\n\n"
                + (
                    "\n".join(f"- {n}" for n in notes)
                    if notes
                    else "Every visual in the metadata repository was migrated with no warnings."
                )
                + "\n",
            )
            results.append(app_root)
        return results
