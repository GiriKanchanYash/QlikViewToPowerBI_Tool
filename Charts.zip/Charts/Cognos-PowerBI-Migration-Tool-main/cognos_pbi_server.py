#!/usr/bin/env python3
"""
IBM Cognos Analytics → Power BI Migration Server
Watches a source folder for Cognos report/spec/package files and converts
each one into a .pbit (and optionally .pbix) template, streaming progress to
the browser UI via Server-Sent Events (SSE).

Architecture note
------------------
This module is a sibling engine to ``tableau_pbi_server.py`` and is loaded
in-process by ``report_migration_tool.py`` exactly the way the Tableau engine
is — as an importable module exposing ``conversion_state``, ``broadcast()``,
``log()``, ``conversion_worker()`` and ``process_file()``.  The unified
router monkey-patches ``broadcast`` the same way it does for Tableau so that
Cognos log/job/status events reach the same SSE stream used by the rest of
the application.

``tableau_pbi_server.py`` is NOT modified. A handful of small, fully generic
helpers (JSON/GUID utilities, PBI M-type mapping, safe-name/unique-name
helpers, the M sample-value generator, and the PBIT → PBIX conversion
helpers) are imported from it and reused here, exactly as the coding
standards for this project require — this keeps naming, encoding rules, and
PBIX conversion behaviour identical across every migration engine instead of
re-implementing (and risking drift in) logic that has nothing to do with
Cognos parsing.

Usage (standalone, for local testing only — normally loaded by
report_migration_tool.py):
    python cognos_pbi_server.py --source ./cognos_source --target ./cognos_target
"""

import base64
import json
import os
import queue
import quopri
import re
import sys
import threading
import time
import traceback
import uuid
import zipfile
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
import xml.etree.ElementTree as ET


# ─────────────────────────────────────────────────────────────────────────────
# Reuse fully-generic helpers from the Tableau engine (reference architecture).
# tableau_pbi_server.py is never modified — we only import from it.
# ─────────────────────────────────────────────────────────────────────────────
try:
    import tableau_pbi_server as _tbl
    _TBL_HELPERS_OK = True
except Exception:
    _tbl = None
    _TBL_HELPERS_OK = False


def _guid() -> str:
    if _TBL_HELPERS_OK:
        return _tbl._guid()
    return str(uuid.uuid4())


def _now_iso() -> str:
    if _TBL_HELPERS_OK:
        return _tbl._now_iso()
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _jmin(obj) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._jmin(obj)
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':'))


def _jstr(obj, indent=2) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._jstr(obj, indent=indent)
    return json.dumps(obj, ensure_ascii=False, indent=indent)


def _sanitise_json(text: str) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._sanitise_json(text)
    text = text.replace('\x00', '')
    return re.sub(r'[\x01-\x08\x0b\x0c\x0e-\x1f]',
                  lambda m: f'\\u{ord(m.group(0)):04x}', text)


def _pbi_m_type(datatype: str) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._pbi_m_type(datatype)
    return {
        'int64': 'number', 'double': 'number', 'string': 'text',
        'date': 'date', 'dateTime': 'datetime', 'boolean': 'logical',
    }.get(datatype, 'text')


def _safe_pbi_name(raw: str, max_len: int = 100) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._safe_pbi_name(raw, max_len=max_len)
    name = re.sub(r'[^\w\s]', '_', (raw or '').strip())
    name = re.sub(r'[\s_]+', '_', name).strip('_')
    if name and name[0].isdigit():
        name = 'T_' + name
    return (name or 'Table')[:max_len]


def _unique_name(desired: str, seen: set, case_insensitive: bool = False) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._unique_name(desired, seen, case_insensitive=case_insensitive)

    def _key(name):
        return name.lower() if case_insensitive else name
    if _key(desired) not in seen:
        seen.add(_key(desired))
        return desired
    i = 2
    while _key(f"{desired}_{i}") in seen:
        i += 1
    result = f"{desired}_{i}"
    seen.add(_key(result))
    return result


def _m_str(s: str) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._m_str(s)
    return s.replace('"', '""')


def _m_col_name_type(col_name: str, col_datatype: str) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._m_col_name_type(col_name, col_datatype)
    needs_quoting = bool(re.search(r'[^A-Za-z0-9_]', col_name))
    identifier = ('#"' + col_name.replace('"', '""') + '"') if needs_quoting else col_name
    return f"{identifier} = {_pbi_m_type(col_datatype)}"


def _m_col_types(columns: list, cols_per_line: int = 3) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._m_col_types(columns, cols_per_line=cols_per_line)
    entries = ['{{"{}", type {}}}'.format(_m_str(c["name"]), _pbi_m_type(c["datatype"]))
               for c in columns]
    if not entries:
        return ''
    rows = []
    for i in range(0, len(entries), cols_per_line):
        rows.append(', '.join(entries[i:i + cols_per_line]))
    return (',\n' + ' ' * 8).join(rows) + '})'


def _m_sample_value(col_name: str, datatype: str, row_idx: int) -> str:
    if _TBL_HELPERS_OK:
        return _tbl._m_sample_value(col_name, datatype, row_idx)
    return '""'


def _extract_pbix_params(payload: dict) -> dict:
    if _TBL_HELPERS_OK:
        return _tbl._extract_pbix_params(payload)
    return {}


def _pbix_via_desktop(*args, **kwargs):
    if _TBL_HELPERS_OK:
        return _tbl._pbix_via_desktop(*args, **kwargs)
    log("warn", "PBIX-via-Desktop unavailable — Tableau engine helpers not loaded.")


def _pbix_via_api(*args, **kwargs):
    if _TBL_HELPERS_OK:
        return _tbl._pbix_via_api(*args, **kwargs)
    log("warn", "PBIX-via-API unavailable — Tableau engine helpers not loaded.")


# ─────────────────────────────────────────────────────────────────────────────
# Optional dependency: python-docx, used for the migration documentation
# deliverable. Auto-installed silently, mirroring the Tableau engine's
# _ensure_openpyxl() pattern, and falls back gracefully if install fails.
# ─────────────────────────────────────────────────────────────────────────────
def _ensure_docx():
    try:
        import docx  # noqa: F401
        return True
    except ImportError:
        print("  [INFO] python-docx not found — installing…", flush=True)
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "python-docx", "--quiet"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print("  [INFO] python-docx installed successfully.", flush=True)
            return True
        print(f"  [WARN] python-docx install failed: {result.stderr.strip()}", flush=True)
        return False


_DOCX_OK = _ensure_docx()


# ─────────────────────────────────────────────────────────────────────────────
# Global event bus — mirrors tableau_pbi_server.py exactly so the unified
# router in report_migration_tool.py can wire this engine in the same way.
# ─────────────────────────────────────────────────────────────────────────────
_clients: list = []
_clients_lock = threading.Lock()

conversion_state = {
    "running": False,
    "source": "",
    "target": "",
    "jobs": {},          # filename -> {status, message, started, finished}
}


def broadcast(event: str, data: dict):
    """Push an SSE event to all connected browser clients."""
    payload = f"event: {event}\ndata: {json.dumps(data)}\n\n"
    with _clients_lock:
        dead = []
        for q in _clients:
            try:
                q.put_nowait(payload)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _clients.remove(q)


def log(level: str, message: str, filename: str = ""):
    ts = datetime.now().strftime("%H:%M:%S")
    broadcast("log", {"ts": ts, "level": level, "message": message, "file": filename})
    print(f"[{ts}] [{level.upper():5s}] {('[' + filename + '] ') if filename else ''}{message}",
          flush=True)




# ─────────────────────────────────────────────────────────────────────────────
# Supported Cognos input formats
# ─────────────────────────────────────────────────────────────────────────────
SUPPORTED_EXTENSIONS = ('.xml', '.spec', '.report', '.zip', '.mht', '.mhtml',
                         '.html', '.htm', '.json')


# ─────────────────────────────────────────────────────────────────────────────
# Cognos report parsing — XML / JSON / ZIP / MHT / HTML
# ─────────────────────────────────────────────────────────────────────────────
#
# Cognos report specifications are XML documents (default namespace typically
# something like "http://developer.cognos.com/schemas/report/...") built from
# roughly:
#
#   <report>
#     <queries>
#       <query name="Query1">
#         <selection>
#           <dataItem name="Revenue" aggregate="total"><expression>...</expression></dataItem>
#           ...
#         </selection>
#         <detailFilters><detailFilter><filterExpression>...</filterExpression></detailFilter></detailFilters>
#         <sortList>...</sortList>
#       </query>
#     </queries>
#     <layouts><layout><reportPages><page name="Page1">
#       <pageBody><contents>
#         <list refQuery="Query1">...</list>
#         <crosstab refQuery="Query2">...</crosstab>
#         <chart refQuery="Query3" type="column">...</chart>
#       </contents></pageBody>
#     </page></reportPages></layout></layouts>
#   </report>
#
# Cognos Framework Manager packages / data modules describe queryable tables,
# relationships (joins) and calculated data items in a similar XML/JSON shape.
#
# Because real-world exports vary across Cognos versions (10.x, 11.x, Cognos
# Analytics data modules exported as JSON, etc.), every helper below is
# namespace-agnostic (matches on local tag name only) and tolerant of missing
# elements — it extracts everything it can find and records what it could not
# understand as a warning rather than failing the whole conversion.
# ─────────────────────────────────────────────────────────────────────────────

def _normalize_aggregate(raw: str) -> str:
    """
    Cognos report specs frequently write out an EXPLICIT aggregate="none"
    (meaning "no aggregation applied"), which is a real, meaningful value —
    not an omission. Treating that non-empty string as truthy ("this item
    has an aggregate") is exactly the kind of bug that turns every plain
    dimension column in a report into a broken measure, so every aggregate
    value is normalized through this one place before it's used anywhere.
    """
    raw = (raw or '').strip().lower()
    if raw in ('', 'none', 'automatic', 'calculated'):
        return ''
    return raw


def _local(tag: str) -> str:
    """Strip an XML namespace URI from a tag, e.g. '{ns}query' -> 'query'."""
    if tag is None:
        return ''
    return tag.rsplit('}', 1)[-1] if '}' in tag else tag


def _iter_local(root, *local_names):
    """Yield every descendant element whose local tag matches local_names."""
    names = set(local_names)
    for el in root.iter():
        if _local(el.tag) in names:
            yield el


def _find_local(el, local_name):
    """Return the first direct/descendant child whose local tag matches."""
    for child in el.iter():
        if child is not el and _local(child.tag) == local_name:
            return child
    return None


def _text_of(el) -> str:
    if el is None:
        return ''
    return ''.join(el.itertext()).strip()


def _attr_any(el, *names, default=''):
    for n in names:
        if n in el.attrib:
            return el.attrib[n]
    return default


# ── Cognos expression helpers used while walking queries ──────────────────────

_NUMERIC_HINTS = ('amount', 'revenue', 'sales', 'cost', 'price', 'qty',
                   'quantity', 'total', 'sum', 'count', 'profit', 'margin',
                   'balance', 'value', 'num', 'number', 'pct', 'percent',
                   'rate', 'score', 'units')
_DATE_HINTS = ('date', 'year', 'month', 'day', 'time', 'quarter', 'period')


def _tokenize_name(name: str) -> set:
    """Split a column name into whole-word tokens (snake_case, spaces, and
    camelCase/PascalCase all handled), used for hint matching so a
    substring like 'count' inside 'Country' is never mistaken for a match."""
    parts = re.split(r'[\s_\-]+', name or '')
    tokens = []
    for p in parts:
        tokens.extend(re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+', p))
    return {t.lower() for t in tokens if t}


_GEO_DATA_CATEGORY_HINTS = [
    ({'country'}, 'Country'),
    ({'continent'}, 'Continent'),
    ({'state'}, 'StateOrProvince'),
    ({'province'}, 'StateOrProvince'),
    ({'county'}, 'County'),
    ({'city'}, 'City'),
    ({'postal', 'code'}, 'PostalCode'),
    ({'postalcode'}, 'PostalCode'),
    ({'zip', 'code'}, 'PostalCode'),
    ({'zipcode'}, 'PostalCode'),
    ({'zip'}, 'PostalCode'),
    ({'latitude'}, 'Latitude'),
    ({'lat'}, 'Latitude'),
    ({'longitude'}, 'Longitude'),
    ({'lng'}, 'Longitude'),
]


def _guess_geo_data_category(name: str):
    """
    Detect whether a column name looks geographic (Country/State/City/
    PostalCode/Latitude/Longitude/...) so it can be tagged with the
    matching TOM dataCategory — this is what lets Power BI's Map/Filled
    Map visuals auto-geocode the field instead of just plotting it as a
    meaningless category axis. Returns None for anything not confidently
    geographic (deliberately excludes ambiguous names like "Region",
    which is very often just a generic business dimension, not a place).
    """
    tokens = _tokenize_name(name)
    for required, category in _GEO_DATA_CATEGORY_HINTS:
        if required <= tokens:
            return category
    return None


def _guess_datatype(name: str, aggregate: str = '', expression: str = '') -> str:
    """Best-effort datatype inference for a Cognos data item.

    Cognos report specifications frequently omit an explicit type for
    dataItems (the true type lives in the Framework Manager package/data
    module, which may not be present in a bare report export). We infer a
    reasonable PBI datatype from the aggregate rule, the column name, and any
    literal hints in the expression so the generated model is still usable.
    """
    name_tokens = _tokenize_name(name)
    if re.search(r'\b(case|then|else)\b.*?[\'"][A-Za-z]', expression or '', re.I | re.S):
        # CASE/IF expressions whose branches return quoted string literals
        # ('High', 'Medium', ...) are categorical, regardless of column name.
        return 'string'
    if aggregate and aggregate.lower() in ('total', 'sum', 'average', 'avg',
                                            'maximum', 'max', 'minimum', 'min',
                                            'count', 'count-distinct'):
        return 'double'
    if name_tokens & set(_DATE_HINTS):
        return 'dateTime'
    if name_tokens & set(_NUMERIC_HINTS):
        return 'double'
    if re.search(r'\bcast\s*\(.*as\s*(date|timestamp)\)', expression or '', re.I):
        return 'dateTime'
    if re.search(r'\bcast\s*\(.*as\s*(int|integer|decimal|numeric|float|double)\)',
                 expression or '', re.I):
        return 'double'
    return 'string'


def _parse_query_element(q_el) -> dict:
    """Parse one Cognos <query> element into a normalized dict."""
    q_name = _attr_any(q_el, 'name', default=f'Query{abs(hash(str(q_el)))%1000}')
    items = []
    seen_item_names = set()
    for sel in q_el:
        if _local(sel.tag) not in ('selection', 'dataItems'):
            continue
        for di in sel:
            if _local(di.tag) != 'dataItem':
                continue
            di_name = _attr_any(di, 'name', default=f'Item{len(items)+1}')
            di_agg = _normalize_aggregate(_attr_any(di, 'aggregate', 'rollupAggregate', default=''))
            di_usage = _attr_any(di, 'usage', default='')
            expr_el = _find_local(di, 'expression')
            expression = _text_of(expr_el) if expr_el is not None else ''
            if di_name in seen_item_names:
                di_name = f"{di_name}_{len(items)+1}"
            seen_item_names.add(di_name)
            items.append({
                'name': di_name,
                'expression': expression,
                'aggregate': di_agg,
                'usage': di_usage,
                'datatype': _guess_datatype(di_name, di_agg, expression),
                'is_calculated': bool(expression) and not re.match(
                    r'^\s*(?:\[[^\[\]]+\]\.)*\[[^\[\]]+\]\s*$', expression),
            })
    # Also accept dataItem elements declared directly under the query
    # (some Cognos exports skip the <selection> wrapper).
    if not items:
        for di in q_el:
            if _local(di.tag) != 'dataItem':
                continue
            di_name = _attr_any(di, 'name', default=f'Item{len(items)+1}')
            expr_el = _find_local(di, 'expression')
            expression = _text_of(expr_el) if expr_el is not None else ''
            items.append({
                'name': di_name, 'expression': expression,
                'aggregate': _normalize_aggregate(_attr_any(di, 'aggregate', default='')),
                'usage': _attr_any(di, 'usage', default=''),
                'datatype': _guess_datatype(di_name, '', expression),
                'is_calculated': bool(expression),
            })

    filters = []
    for df in _iter_local(q_el, 'detailFilter', 'filter'):
        fexpr = _find_local(df, 'filterExpression')
        if fexpr is not None:
            filters.append(_text_of(fexpr))

    sorts = []
    for si in _iter_local(q_el, 'sortItem'):
        ref = _attr_any(si, 'refDataItem', default='')
        order = 'desc' if 'desc' in _text_of(_find_local(si, 'sortOrder')).lower() else 'asc'
        if ref:
            sorts.append({'item': ref, 'order': order})

    return {
        'name': q_name,
        'items': items,
        'filters': filters,
        'sorts': sorts,
    }



def _is_page_layout_table(el) -> bool:
    """
    Cognos explicitly marks pure CSS/grid-positioning tables (used only to
    lay out other content — headers, side-by-side visuals, footers — never
    to hold data themselves) with a direct-child
    <XMLAttributes><XMLAttribute name="isPageLayoutTable" value="true"/>.
    These must never be converted into a Power BI table visual, or every
    report ends up with spurious extra "table" visuals that don't
    correspond to anything in the original Cognos report.
    """
    for child in el:
        if _local(child.tag) == 'XMLAttributes':
            for attr_el in child:
                if (_local(attr_el.tag) == 'XMLAttribute'
                        and _attr_any(attr_el, 'name', default='').lower() == 'ispagelayouttable'
                        and _attr_any(attr_el, 'value', default='').lower() == 'true'):
                    return True
    return False


def _table_has_nested_report_object(tbl_el) -> bool:
    """
    Fallback heuristic for layout-wrapper <table> elements that aren't
    explicitly flagged with isPageLayoutTable: if a table's cells contain
    another real report object (a list, crosstab, chart, vizControl,
    gauge, singleton, or another table), this table's role is purely
    structural positioning, not data — it must not itself become a visual,
    or it get converted into a bogus, contentless "table" using the label
    text of whatever it's wrapping.
    """
    for child in tbl_el.iter():
        if child is tbl_el:
            continue
        tag = _local(child.tag).lower()
        if tag in ('list', 'crosstab', 'vizcontrol', 'singleton', 'table') \
                or 'chart' in tag or tag in ('gauge', 'treemap', 'map', 'geomap', 'filledmap', 'shapemap',
                                             'heatmap', 'quadrant', 'bullet', 'radar', 'ribbon',
                                             'funnel', 'network', 'radial', 'sunburst', 'chord',
                                             'sankey', 'decomposition', 'kpi'):
            return True
    return False


_CHART_SUBELEMENT_TAGS = {
    'charttitle', 'chartseries', 'chartsortlist', 'chartsortitem',
    'chartcategories', 'chartcategory', 'chartaxis', 'chartaxes',
    'chartlegend', 'chartdatalabels', 'chartplotarea', 'chartcolor',
}


def _classify_layout_object(el) -> str:
    """Return a normalized Cognos object-kind string for a layout element."""
    tag = _local(el.tag).lower()
    if tag in ('list',):
        return 'list'
    if tag in ('crosstab',):
        return 'crosstab'
    if tag in ('vizcontrol',):
        return 'chart'
    if tag in _CHART_SUBELEMENT_TAGS:
        # Interior part of a parent <chart> (e.g. <chartTitle>,
        # <chartSeries>, <chartSortList>/<chartSortItem>) — NOT a chart
        # object in its own right. Excluded before the broad 'chart' in tag
        # substring check below, which would otherwise misclassify every
        # one of these as its own standalone chart visual.
        return ''
    if ('chart' in tag or tag in ('gauge', 'treemap', 'map', 'geomap', 'filledmap', 'shapemap', 'heatmap',
                                  'quadrant', 'bullet', 'radar', 'ribbon', 'funnel',
                                  'network', 'radial', 'sunburst', 'chord', 'sankey',
                                  'decomposition', 'kpi', 'promptcontrol', 'selectvalueui',
                                  'selectvalueprompt', 'valuepromptbutton', 'slicer')):
        return 'chart'
    if tag in ('singleton',):
        return 'singleton'
    if tag in ('textitem', 'text'):
        return 'text'
    if tag in ('image',):
        return 'image'
    if tag in ('table',):
        if _is_page_layout_table(el) or _table_has_nested_report_object(el):
            return ''   # pure positioning scaffold — its real contents are
                        # still discovered independently by the page walk.
        return 'table'
    return ''



def _collect_referenced_items(el) -> list:
    """Collect every dataItem name referenced anywhere inside a layout object."""
    names = []
    for child in el.iter():
        ln = _local(child.tag)
        if ln in ('dataItemLabel', 'dataItemValue', 'dataSourceRef', 'dataItem'):
            ref = _attr_any(child, 'refDataItem', 'dataItem', default='')
            if not ref:
                ref = _text_of(child)
            if ref and ref not in names:
                names.append(ref)
    return names


def _cell_text(cell_el) -> str:
    """Extract literal text from one <tableCell>: a Cognos static table cell
    is normally <tableCell><contents><textItem><dataSource><staticValue>
    TEXT</staticValue></dataSource></textItem></contents></tableCell>, but we
    fall back to any text content in case of minor structural variants."""
    sv = _find_local(cell_el, 'staticValue')
    if sv is not None:
        return _text_of(sv)
    return _text_of(cell_el)


def _extract_static_table_rows(tbl_el) -> list:
    """
    Pull literal row/column data out of a Cognos <table> layout element that
    was authored as a static grid (tableRows/tableRow/tableCells/tableCell
    with staticValue content) rather than bound to a query. Returns a
    list-of-rows (list of cell-text lists), or [] if the table has no rows.
    """
    rows = []
    for row_el in _iter_local(tbl_el, 'tableRow'):
        cells = [_cell_text(c) for c in _iter_local(row_el, 'tableCell')]
        if cells:
            rows.append(cells)
    return rows


def _parse_data_stores(root) -> dict:
    """
    Parse <reportDataStores>, which is how IBM's modern "vizControl" chart
    elements bind to a query — a data store has a name and points at a
    query (dsV5ListQuery/refQuery); the vizControl itself only references
    the data store by name, never the query directly.
    """
    stores = {}
    for ds_el in _iter_local(root, 'reportDataStore'):
        name = _attr_any(ds_el, 'name', default='')
        q_el = _find_local(ds_el, 'dsV5ListQuery')
        if q_el is None:
            q_el = _find_local(ds_el, 'dsListQuery')
        if q_el is None:
            q_el = _find_local(ds_el, 'dsQuery')
        ref_query = _attr_any(q_el, 'refQuery', default='') if q_el is not None else ''
        if name and ref_query:
            stores[name] = ref_query
    return stores


def _parse_vizcontrol(el, data_stores: dict):
    """Resolve a <vizControl>'s query binding and category/value/series
    field references. The raw type= attribute is returned as-is; mapping
    it to an internal visual kind happens in one place,
    visual_converter.map_visual_type(), not here."""
    chart_type = _attr_any(el, 'type', default='')
    ref_query = ''
    ds_el = _find_local(el, 'vcDataSet')
    if ds_el is not None:
        store_name = _attr_any(ds_el, 'refDataStore', default='')
        ref_query = data_stores.get(store_name, '')
    item_refs = []
    for slot_el in _iter_local(el, 'vcSlotData'):
        for col_el in _iter_local(slot_el, 'vcSlotDsColumn'):
            ref = _attr_any(col_el, 'refDsColumn', default='')
            if ref and ref not in item_refs:
                item_refs.append(ref)
    return ref_query, item_refs, chart_type


def _parse_layout_pages(layouts_root, report: dict) -> list:
    """Extract report pages (and the objects placed on them) from <layouts>.

    Query-bound layout objects (list/crosstab/chart/singleton with
    dataItemLabel/dataItemValue references) are linked back to their
    <query> via refQuery. Cognos <table> elements with no query binding at
    all — i.e. a literal static grid built directly from <staticValue> cells,
    a common authoring pattern for simple/demo reports — are extracted as
    exact embedded data and registered as a synthetic query, exactly like
    the HTML/MHT rendered-table extraction tier, so they still produce a
    real, populated Power BI table instead of an empty placeholder.
    """
    pages = []
    page_elements = list(_iter_local(layouts_root, 'page'))
    if not page_elements:
        # Some exports have a single unnamed layout with no explicit <page>;
        # treat the whole layout body as one page.
        page_elements = [layouts_root]

    static_table_counter = [0]

    for p_idx, p_el in enumerate(page_elements):
        p_name = _attr_any(p_el, 'name', default=f'Page{p_idx + 1}')
        objects = []
        # Parent map so we can tell whether a <textItem>/<table> is actually
        # loose page content vs. just the internal contents of a <tableCell>
        # inside a table we already extract as one unit (avoids one spurious
        # "text" placeholder per static-table cell).
        parent_map = {child: parent for parent in p_el.iter() for child in parent}

        def _has_ancestor(el, local_names):
            cur = el
            while cur in parent_map:
                cur = parent_map[cur]
                if _local(cur.tag).lower() in local_names:
                    return True
            return False

        for obj_el in p_el.iter():
            kind = _classify_layout_object(obj_el)
            if not kind or kind in ('text',) and not _text_of(obj_el):
                continue
            if kind == '':
                continue
            if kind == 'text' and _has_ancestor(obj_el, {'tablecell', 'table', 'list', 'crosstab'}):
                # Interior content of a table/list cell we already handle as
                # a unit — not an independent layout object.
                continue
            if kind == 'table' and _has_ancestor(obj_el, {'pageheader', 'pagefooter'}):
                # Tables inside the page header/footer are repeating report
                # chrome (titles, logos, date/page-number/time strips) by
                # Cognos convention, never the report's actual List/Table
                # content — must never become a Power BI table visual.
                continue
            if _has_ancestor(obj_el, {'chart', 'vizcontrol'}):
                # Interior content of a chart we already capture as ONE
                # object (categories, series, axes, legend, dataLabels,
                # plotArea, and any other sub-element not already caught
                # by tag name in _classify_layout_object) — never an
                # independent layout object on its own.
                continue

            ref_query = _attr_any(obj_el, 'refQuery', 'refDataItem', default='')
            item_refs = _collect_referenced_items(obj_el)
            chart_type = 'column'
            if _local(obj_el.tag).lower() == 'vizcontrol':
                ref_query, item_refs, chart_type = _parse_vizcontrol(
                    obj_el, report.get('data_stores', {}))
            elif kind == 'chart':
                tag_l = _local(obj_el.tag)
                type_attr = _attr_any(obj_el, 'type', 'chartType', default='')
                chart_type = type_attr or tag_l
            text_value = _text_of(obj_el) if kind == 'text' else ''

            if kind == 'table' and not ref_query and not item_refs:
                # No query binding whatsoever -> only treat this as a
                # genuine static data grid (the Cognos "hand-built List
                # Report" pattern) if it actually has tabular shape: a
                # header row PLUS at least one real data row. A single row
                # of static text is page furniture (a banner, a label
                # strip), not tabular data, and must not become a visual.
                static_rows = _extract_static_table_rows(obj_el)
                query, records = (None, None)
                if len(static_rows) >= 2:
                    static_table_counter[0] += 1
                    synth_name = _attr_any(obj_el, 'name', default='') or \
                        f"StaticTable{static_table_counter[0]}"
                    query, records = _build_query_from_rows(static_rows, synth_name)
                if query is None:
                    # Not a real, convertible data table — e.g. a decorative
                    # single-row strip, or a table whose cells carry no
                    # extractable static data. Never create a placeholder
                    # visual for it; just skip it entirely.
                    continue
                report['queries'].append(query)
                if records:
                    report['sample_rows'][synth_name] = records
                ref_query = synth_name
                item_refs = [it['name'] for it in query['items']]

            local_filters = []
            if kind in ('list', 'crosstab', 'chart', 'singleton'):
                for df_el in _iter_local(obj_el, 'detailFilter', 'filter'):
                    fexpr_el = _find_local(df_el, 'filterExpression')
                    if fexpr_el is not None:
                        local_filters.append(_text_of(fexpr_el))

            objects.append({
                'kind': kind,
                'ref_query': ref_query,
                'item_refs': item_refs,
                'chart_type': chart_type,
                'text': text_value[:300],
                'name': _attr_any(obj_el, 'name', default=f'{kind}{len(objects)+1}'),
                'local_filters': local_filters,
                '_el_id': id(obj_el),
            })
        # De-duplicate by XML element identity only (guards against the same
        # element somehow being visited twice). Deliberately NOT by content
        # signature (kind/ref_query/item_refs) — two distinct sibling
        # visuals legitimately can and do share identical field bindings
        # (e.g. two Pie Charts both showing Region/Revenue split by a
        # different filter), and must both be preserved, one Power BI
        # visual per Cognos visual.
        dedup = []
        seen_el_ids = set()
        for o in objects:
            if o['_el_id'] in seen_el_ids:
                continue
            seen_el_ids.add(o['_el_id'])
            del o['_el_id']
            dedup.append(o)
        pages.append({'name': p_name, 'objects': dedup})
    return pages


def _extract_css_colors(root) -> list:
    """
    Pull a representative color palette from the report's own CSS
    (background-color/color declarations inside <style><CSS value="...">),
    so different Cognos reports get visually distinct Power BI themes
    instead of always falling back to one fixed default palette.
    """
    colors = []
    seen = set()
    for css_el in _iter_local(root, 'CSS'):
        value = _attr_any(css_el, 'value', default='')
        for m in re.finditer(r'(?:background-color|color)\s*:\s*(#[0-9a-fA-F]{3,8})', value):
            c = m.group(1)
            if c.lower() not in seen and c.lower() not in (
                    '#ffffff', '#fff', '#000000', '#000', '#f4f4f4'):
                seen.add(c.lower())
                colors.append(c if len(c) == 7 else c)
    return colors[:12]


def _parse_relationships(root) -> list:
    """Extract join/relationship metadata from a Cognos package or data module."""
    rels = []
    for rel_el in _iter_local(root, 'relationship', 'join'):
        left = _find_local(rel_el, 'left')
        if left is None:
            left = _find_local(rel_el, 'leftQuery')
        right = _find_local(rel_el, 'right')
        if right is None:
            right = _find_local(rel_el, 'rightQuery')
        left_ref = _attr_any(rel_el, 'leftTable', 'left', default='') or _text_of(left)
        right_ref = _attr_any(rel_el, 'rightTable', 'right', default='') or _text_of(right)
        left_col = _attr_any(rel_el, 'leftColumn', default='')
        right_col = _attr_any(rel_el, 'rightColumn', default='')
        # <refObj>/<expression> based joins used in some FM exports
        expr_el = _find_local(rel_el, 'expression')
        if expr_el is not None and (not left_col or not right_col):
            m = re.search(
                r'\[([^\[\]]+)\]\.\[([^\[\]]+)\]\s*=\s*\[([^\[\]]+)\]\.\[([^\[\]]+)\]',
                _text_of(expr_el))
            if m:
                left_ref, left_col, right_ref, right_col = m.groups()
        if left_ref and right_ref and left_col and right_col:
            rels.append({
                'fromTable': left_ref, 'fromColumn': left_col,
                'toTable': right_ref, 'toColumn': right_col,
            })
    return rels


def _parse_cognos_xml_report(xml_text: str, source_name: str) -> dict:
    """Parse one Cognos report-specification XML document."""
    report = _new_report_skeleton(source_name)
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        report['warnings'].append(f"Invalid XML in {source_name}: {exc}")
        return report

    report_name = (_attr_any(root, 'name', default='')
                  or _text_of(_find_local(root, 'reportName'))
                  or Path(source_name).stem)
    report['name'] = report_name

    # ── Queries ────────────────────────────────────────────────────────────
    for q_el in _iter_local(root, 'query'):
        parsed = _parse_query_element(q_el)
        if parsed['items']:
            report['queries'].append(parsed)

    # ── Data stores (IBM vizControl query bindings) ─────────────────────────
    report['data_stores'] = _parse_data_stores(root)

    # ── Theme colors (from the report's own CSS, if any) ───────────────────
    report['data_colors'] = _extract_css_colors(root)

    # ── Parameters / prompts ──────────────────────────────────────────────
    for prompt_el in _iter_local(root, 'prompt', 'parameter'):
        p_name = _attr_any(prompt_el, 'name', 'parameter', default='')
        if p_name:
            report['parameters'].append({
                'name': p_name,
                'type': _attr_any(prompt_el, 'type', default='string'),
            })

    # ── Layout / pages ─────────────────────────────────────────────────────
    layouts_root = _find_local(root, 'layouts') or root
    report['pages'] = _parse_layout_pages(layouts_root, report)

    # ── Relationships (present in some report-level data modules) ─────────
    report['relationships'].extend(_parse_relationships(root))

    if not report['queries']:
        report['warnings'].append(
            f"{source_name}: no <query>/<dataItem> definitions were found; "
            f"this file may be a rendered output rather than a report "
            f"specification.")
    return report


def _new_report_skeleton(source_name: str) -> dict:
    return {
        'name': Path(source_name).stem,
        'source_files': [source_name],
        'queries': [],          # [{name, items, filters, sorts}]
        'parameters': [],       # [{name, type}]
        'pages': [],            # [{name, objects:[{kind, ref_query, item_refs, ...}]}]
        'relationships': [],    # [{fromTable, fromColumn, toTable, toColumn}]
        'sample_rows': {},      # query_name -> list[dict] (exact extracted rows)
        'data_stores': {},      # dataStore name -> query name (IBM vizControl bindings)
        'warnings': [],
        'data_colors': [],
    }


def _merge_reports(base: dict, extra: dict) -> dict:
    base['source_files'].extend(extra.get('source_files', []))
    base['queries'].extend(extra.get('queries', []))
    base['parameters'].extend(extra.get('parameters', []))
    base['pages'].extend(extra.get('pages', []))
    base['relationships'].extend(extra.get('relationships', []))
    base['warnings'].extend(extra.get('warnings', []))
    for k, v in extra.get('sample_rows', {}).items():
        base['sample_rows'].setdefault(k, v)
    base['data_stores'].update(extra.get('data_stores', {}))
    if not base.get('data_colors'):
        base['data_colors'] = extra.get('data_colors', [])
    return base


# ═══════════════════════════════════════════════════════════════════════════
# IBM Cognos Framework Manager (.xml) model migration
# ═══════════════════════════════════════════════════════════════════════════
#
# A Framework Manager model XML describes the DATA MODEL (query subjects,
# relationships, physical/business/presentation layers) rather than a
# report's pages and visuals. It is a completely different schema from the
# report-specification XML handled above (root <project> with nested
# <namespace>/<querySubject>/<relationship>, vs. a report's <report> root
# with <queries>/<layouts>) even though both commonly use a plain .xml
# extension, so every .xml file is sniffed by its root tag / distinguishing
# child elements before parsing, and routed to whichever parser matches.
#
# The FM parser below produces a report dict in EXACTLY the same shape as
# the report-XML parser (_new_report_skeleton) -- one "query" per Cognos
# Query Subject, with the query subject's Query Items as its items -- so
# the entire existing pipeline (build_data_model_schema, relationship/cycle
# handling, DAX conversion, TOM validation, PBIT packaging) runs completely
# unchanged on the result. No new entry points, no architecture changes.

_FM_DATATYPE_TO_PBI = {
    'integer': 'int64', 'smallint': 'int64', 'bigint': 'int64', 'int': 'int64',
    'decimal': 'double', 'numeric': 'double', 'double': 'double', 'real': 'double',
    'float': 'double', 'money': 'double',
    'date': 'dateTime', 'timestamp': 'dateTime', 'datetime': 'dateTime', 'time': 'dateTime',
    'boolean': 'boolean', 'bool': 'boolean',
    'character': 'string', 'char': 'string', 'varchar': 'string', 'nvarchar': 'string',
    'clob': 'string', 'text': 'string', 'longvarchar': 'string',
    'blob': 'string',   # no native binary type in this pipeline; imported as text with a warning
}


def _fm_map_datatype(raw: str) -> str:
    key = re.sub(r'\(.*?\)', '', (raw or '')).strip().lower()   # strip "(10,2)" precision/scale
    return _FM_DATATYPE_TO_PBI.get(key, 'string')


def _fm_object_id_of(el) -> str:
    """
    A Framework Manager object's objectID may appear as a dedicated
    <objectID> child element (the shape used by fuller/newer FM XML
    exports) or as an 'objectID'/'id' attribute directly on the element
    (the shape used by some relationship <left>/<right> endpoints and
    older exports). Checked in that order so a real child element always
    wins over a same-named attribute if both happen to be present.
    """
    if el is None:
        return ''
    id_el = _find_local(el, 'objectID')
    if id_el is not None:
        text = _text_of(id_el).strip()
        if text:
            return text
    return _attr_any(el, 'objectID', 'id', default='').strip()


def _fm_classify_namespace_layer(ns_el) -> str:
    """
    Classify a top-level Framework Manager <namespace> as 'physical',
    'business', 'presentation', or 'unlayered' from its name, using the
    standard Cognos naming convention Framework Manager itself generates
    by default ("Database Layer"/"Physical Layer", "Business Layer",
    "Presentation Layer") and that real-world models almost never rename.
    Used so a classic 3-tier layered model contributes exactly ONE table
    per real-world entity (from the Business Layer) instead of one per
    layer, while a simple/older single-namespace model (or a Cognos
    Analytics data module with no layering at all) is left untouched.
    """
    name = _attr_any(ns_el, 'name', default='').strip().lower()
    if 'business' in name:
        return 'business'
    if 'presentation' in name:
        return 'presentation'
    if 'physical' in name or 'database' in name:
        return 'physical'
    return 'unlayered'


def detect_cognos_artifact_type(root) -> str:
    """
    Inspect an XML root and its distinguishing descendant tags to classify
    the uploaded Cognos artifact as either a report specification or a
    Framework Manager model — both are ordinary .xml files with no
    extension-level distinction, so the whole decision has to come from the
    element structure itself. Returns 'report' or 'framework_manager'.
    """
    root_tag = _local(root.tag).lower()
    if root_tag in ('project', 'model'):
        return 'framework_manager'
    if root_tag in ('report', 'reportdefinition'):
        return 'report'

    fm_signals = ('querysubject', 'namespace', 'package', 'determinant',
                 'relationshipref', 'dbquery', 'modelquery', 'sqlquerysubject')
    report_signals = ('reportdefinition', 'layout', 'page', 'list', 'crosstab',
                      'chart', 'queries', 'reportpages', 'pagebody')

    all_tags = {_local(el.tag).lower() for el in root.iter()}
    fm_score = sum(1 for t in fm_signals if t in all_tags)
    report_score = sum(1 for t in report_signals if t in all_tags)

    if fm_score > report_score:
        return 'framework_manager'
    if report_score > fm_score:
        return 'report'
    return 'report'   # genuine tie (e.g. an empty/minimal file) — report is the more common upload


def _looks_like_framework_manager_model(root) -> bool:
    """Kept for backward compatibility with existing call sites."""
    return detect_cognos_artifact_type(root) == 'framework_manager'


def _fm_ref_last_segment(refobj_text: str) -> str:
    """
    An FM <refobj> path looks like:
        [Namespace].[Folder].[QuerySubjectName].[QueryItemName]
    or a plain bracket chain without the leading '['/']' delimiters in some
    exports. The last segment is the query item; the second-to-last is its
    owning query subject -- the same "last bracket = the real name"
    convention already used for report-XML field references.
    """
    segments = re.findall(r'\[([^\[\]]+)\]', refobj_text or '')
    if not segments:
        segments = [s.strip() for s in (refobj_text or '').split('.') if s.strip()]
    return segments[-1] if segments else (refobj_text or '').strip()


def _fm_ref_owning_subject(refobj_text: str) -> str:
    segments = re.findall(r'\[([^\[\]]+)\]', refobj_text or '')
    if len(segments) >= 2:
        return segments[-2]
    return ''


def _fm_looks_like_dax_expression(text: str) -> bool:
    """
    Cheap sanity check for "does this look like it could plausibly be a
    real DAX/calculation expression at all" — used as a last-resort guard
    against writing a mis-parsed reference (most often a Framework Manager
    object's raw internal objectID, e.g. "_qi_phys_customerid_0001", picked
    up when an <expression> shape isn't one this parser recognizes) into a
    calculated column, which Power BI Desktop cannot evaluate and which
    reliably breaks the whole semantic model on load. A real expression —
    even a trivial one — always contains at least one of: a bracket column
    reference, a quoted table/string literal, a function call, an
    arithmetic/comparison operator, or a numeric literal. A single bare
    word/token with none of those is essentially never a valid expression.
    """
    text = (text or '').strip()
    if not text:
        return False
    if re.search(r'[\[\](){}+\-*/=<>,\'"]', text):
        return True
    if re.search(r'\d', text):
        return True
    if ' ' in text:
        return True
    return False


def _fm_parse_query_item(qi_el, owning_subject_name: str,
                         item_objectid_map: dict = None) -> dict:
    """Parse one <queryItem> into the same item shape used everywhere else
    in this pipeline: {name, expression, aggregate, usage, datatype, is_calculated}."""
    name = _attr_any(qi_el, 'name', default='')
    expr_el = _find_local(qi_el, 'expression')
    raw_expr = ''
    is_objectid_ref = False
    if expr_el is not None:
        ref_el = _find_local(expr_el, 'refobj')
        if ref_el is not None:
            raw_expr = _text_of(ref_el)
        else:
            # Some FM exports (typically Business/Presentation-layer query
            # items) point an <expression> at another object by objectID
            # instead of a bracket-path string, e.g.
            # <expression><refObjectID>_qi_phys_...</refObjectID></expression>.
            # Resolved via the same objectID map relationships use, so it
            # becomes a plain passthrough column instead of the referenced
            # object's raw internal ID being misread as a literal formula.
            oid_el = _find_local(expr_el, 'refObjectID')
            if oid_el is None:
                oid_el = _find_local(expr_el, 'refQueryItem')
            oid_text = _text_of(oid_el).strip() if oid_el is not None else ''
            resolved = item_objectid_map.get(oid_text) if (oid_text and item_objectid_map) else None
            if resolved:
                is_objectid_ref = True
            else:
                raw_expr = _text_of(expr_el)

    datatype_el = _find_local(qi_el, 'datatype')
    usage_el = _find_local(qi_el, 'usage')
    agg_el = _find_local(qi_el, 'regularAggregate')
    if agg_el is None:
        agg_el = _find_local(qi_el, 'aggregateRule')
    nullable_el = _find_local(qi_el, 'nullable')

    usage = _text_of(usage_el).strip().lower() if usage_el is not None else ''
    raw_agg = _normalize_aggregate(_text_of(agg_el)) if agg_el is not None else ''
    # FM tags fact-usage numeric items as summable even when no explicit
    # aggregate rule is present -- Cognos's own convention for measures.
    if not raw_agg and usage == 'fact':
        raw_agg = 'total'

    # A query item whose expression is just a single reference to another
    # object (its own physical/business-layer source column) is a plain
    # passthrough column, not a calculation -- Cognos calls this a
    # "mapped"/non-calculated query item. Anything else (arithmetic,
    # functions, CASE/IF, multiple refobjs combined) is a real calculation.
    is_single_ref = bool(re.match(r'^\s*\[[^\[\]]+\](?:\.\[[^\[\]]+\])*\s*$', raw_expr))
    # Defensive fallback: an expression that doesn't even look like a
    # plausible DAX/calculation formula (no brackets, quotes, operators,
    # function-call parens, or literals — just a bare word/token) is far
    # more likely to be an unrecognized reference shape this parser missed
    # than a genuine calculation. Treating it as calculated would write
    # something Power BI Desktop cannot evaluate straight into the model.
    looks_bogus = bool(raw_expr) and not is_single_ref and not _fm_looks_like_dax_expression(raw_expr)

    if is_single_ref or not raw_expr or is_objectid_ref or looks_bogus:
        # Deliberately self-referential: keep this query subject's own
        # namespace as the item's qualifying table, rather than the deep
        # physical-layer lineage path, so downstream star-schema inference
        # never tries to merge/split query subjects based on a shared
        # physical source table -- every FM Query Subject is its own table.
        expression = f"[{owning_subject_name}].[{name}]"
        is_calculated = False
    else:
        expression = raw_expr
        is_calculated = True

    datatype = _fm_map_datatype(_text_of(datatype_el)) if datatype_el is not None else \
        _guess_datatype(name, raw_agg, raw_expr)

    return {
        'name': name,
        'expression': expression,
        'aggregate': raw_agg,
        'usage': usage,
        'datatype': datatype,
        'is_calculated': is_calculated,
        '_nullable': _text_of(nullable_el).strip().lower() != 'false' if nullable_el is not None else True,
        '_hidden': _attr_any(qi_el, 'hidden', default='').lower() == 'true',
    }



def _fm_parse_determinants(qs_el) -> dict:
    """
    Parse a Query Subject's own <determinant>/<determinants> block(s) —
    distinct from a <relationship>'s determinant-pair join syntax. A
    determinant declares which column(s) uniquely (or non-uniquely)
    identify a row of this query subject; this is what tells us whether a
    query subject is safe to use as the "one" side of a relationship.
    Returns {column_name: is_unique_bool}.
    """
    result = {}
    for det_el in _iter_local(qs_el, 'determinant'):
        # A determinant's key column(s) may appear as <key><queryItem>Name</queryItem></key>,
        # a bare <queryItem>Name</queryItem>, or a <refobj> pointing at one.
        key_el = _find_local(det_el, 'key')
        if key_el is None:
            key_el = det_el
        col_names = []
        for qi_el in _iter_local(key_el, 'queryItem'):
            col_names.append(_text_of(qi_el).strip())
        for ref_el in _iter_local(key_el, 'refobj'):
            col_names.append(_fm_ref_last_segment(_text_of(ref_el)))
        # NOTE: ElementTree elements with zero child ELEMENTS (e.g. a plain
        # text leaf like <uniquelyIdentified>true</uniquelyIdentified>) are
        # falsy, so "a or b" here would silently discard a real match with
        # no children — explicit 'is not None' checks are required.
        unique_el = _find_local(det_el, 'uniquelyIdentified')
        if unique_el is None:
            unique_el = _find_local(det_el, 'unique')
        is_unique = _text_of(unique_el).strip().lower() == 'true' if unique_el is not None else \
            _attr_any(det_el, 'uniquelyIdentified', 'unique', default='').lower() == 'true'
        for c in col_names:
            if c:
                result[c] = result.get(c, False) or is_unique
    return result


def _fm_parse_query_subject(qs_el, folder_path: str, item_objectid_map: dict = None) -> dict:
    """Parse one <querySubject> (model/db/SQL query subject -- all three
    share the same <queryItem> selection shape) into a query-shaped dict,
    plus bookkeeping (folder path, hidden flag, description, determinants)."""
    name = _attr_any(qs_el, 'name', default='')
    items = []
    for qi_el in _iter_local(qs_el, 'queryItem'):
        it = _fm_parse_query_item(qi_el, name, item_objectid_map)
        if it['name']:
            items.append(it)

    desc_el = _find_local(qs_el, 'description')
    hidden = _attr_any(qs_el, 'hidden', default='').lower() == 'true'
    determinants = _fm_parse_determinants(qs_el)
    # A query item explicitly flagged usage="identifier" is Cognos's own
    # convention for "this is (part of) the query subject's key" even when
    # no separate <determinant> block spells that out — treated as an
    # additional, weaker signal of uniqueness.
    for it in items:
        if it.get('usage') == 'identifier' and it['name'] not in determinants:
            determinants[it['name']] = True

    return {
        'name': name,
        'items': items,
        'filters': [],
        'sorts': [],
        '_folder': folder_path,
        '_hidden': hidden,
        '_description': _text_of(desc_el) if desc_el is not None else '',
        '_determinants': determinants,
    }


def _fm_parse_dotted_ref(text: str, known_tables: set = None):
    """
    Parse a plain 'Table.Column' reference (the determinant-pair syntax
    uses dots directly, not bracket chains) into (table, column).

    Schema-qualified table names (e.g. 'dbo.Sales') themselves contain a
    dot, which makes a naive "split on the last dot" wrong for a value
    like 'dbo.Sales.CustomerID' — it would parse as table='Sales',
    column='CustomerID' and silently drop the 'dbo.' prefix, failing to
    match the real query subject name 'dbo.Sales'. When known_tables (the
    real set of query subject names already extracted from this model) is
    supplied, the longest dot-prefix that's an actual known table name is
    preferred over the naive last-segment split.
    """
    text = (text or '').strip()
    if not text or '.' not in text:
        return None, None
    parts = [p.strip() for p in text.split('.') if p.strip()]
    if len(parts) < 2:
        return None, None
    if known_tables:
        for split_at in range(len(parts) - 1, 0, -1):
            candidate_table = '.'.join(parts[:split_at])
            if candidate_table in known_tables:
                return candidate_table, '.'.join(parts[split_at:])
    return parts[-2], parts[-1]


def _fm_resolve_side_via_objectid(side_el, subject_objectid_map: dict = None,
                                   item_objectid_map: dict = None) -> tuple:
    """
    Resolve one relationship <left>/<right> endpoint that references its
    query subject/item by Framework Manager objectID rather than a
    bracket-path string — the shape real FM exports commonly use for
    Business/Presentation-layer relationships, e.g.
    <left><refObjectID>_qs_0001</refObjectID><refQueryItem>_qi_0001</refQueryItem></left>.
    Checked as either a child element (<refObjectID>text</refObjectID>) or
    an attribute (refObjectID="...") on the endpoint element itself, since
    both shapes appear across different Cognos versions/exports.
    Returns (table, column) resolved through the supplied objectID maps,
    or (None, None) if nothing resolves (e.g. maps not supplied, or this
    endpoint doesn't use objectID references at all).
    """
    if side_el is None:
        return None, None

    def _ref_text(local_name):
        child = _find_local(side_el, local_name)
        text = _text_of(child).strip() if child is not None else ''
        return text or _attr_any(side_el, local_name, default='').strip()

    item_id = _ref_text('refQueryItem')
    if item_id and item_objectid_map and item_id in item_objectid_map:
        return item_objectid_map[item_id]

    subj_id = _ref_text('refObjectID')
    if subj_id and subject_objectid_map and subj_id in subject_objectid_map:
        return subject_objectid_map[subj_id], None

    return None, None


def _fm_parse_table_column_ref(el, known_tables: set = None) -> tuple:
    """
    Resolve a table/column reference from any of the shapes Framework
    Manager exports use for it: a <refobj> bracket chain, a plain
    'Table.Column' text node, or explicit <table>/<column> (or
    <querySubject>/<queryItem>) child elements.
    """
    if el is None:
        return None, None
    ref_el = _find_local(el, 'refobj')
    if ref_el is not None:
        text = _text_of(ref_el)
        if '[' in text:
            return _fm_ref_owning_subject(text), _fm_ref_last_segment(text)
        return _fm_parse_dotted_ref(text, known_tables)
    table_el = _find_local(el, 'table')
    if table_el is None:
        table_el = _find_local(el, 'querySubject')
    col_el = _find_local(el, 'column')
    if col_el is None:
        col_el = _find_local(el, 'queryItem')
    if table_el is not None or col_el is not None:
        return (_text_of(table_el).strip() if table_el is not None else None,
               _text_of(col_el).strip() if col_el is not None else None)
    text = _text_of(el)
    if '[' in text:
        return _fm_ref_owning_subject(text), _fm_ref_last_segment(text)
    return _fm_parse_dotted_ref(text, known_tables)


_CARDINALITY_TEXT_MAP = {
    '1:1': ('one', 'one'), 'one-to-one': ('one', 'one'), 'onetoone': ('one', 'one'),
    '1:n': ('one', 'many'), 'one-to-many': ('one', 'many'), 'onetomany': ('one', 'many'),
    'n:1': ('many', 'one'), 'many-to-one': ('many', 'one'), 'manytoone': ('many', 'one'),
    'n:n': ('many', 'many'), 'many-to-many': ('many', 'many'), 'manytomany': ('many', 'many'),
}


def _fm_maxcard_to_side(maxcard: str) -> str:
    """'0'/'1'/'0..1' -> 'one'; 'n'/'0..n'/'1..n'/anything else -> 'many'."""
    v = (maxcard or '').strip().lower()
    return 'one' if v in ('1', '0..1', '0,1') else 'many'


def _fm_parse_relationship(rel_el, determinants_by_subject: dict = None,
                           named_relationships: dict = None, known_tables: set = None,
                           subject_objectid_map: dict = None,
                           item_objectid_map: dict = None) -> dict:
    """
    Parse one Framework Manager relationship object into
    {fromTable, fromColumn, toTable, toColumn, fromCardinality, toCardinality,
     crossFilterDirection, isActive, cardinality_inferred, warning}.

    Supports every relationship shape Framework Manager exports use:
      - <left>/<right> each with <refobj> + <mincard>/<maxcard>, and a join
        <expression> containing "[A].[x] = [B].[y]"  (classic FM XML) —
        including namespace/schema-qualified paths with MORE than two
        bracket segments per side (e.g. "[Business Layer].[Sales].
        [Orders].[Customer ID]"), resolved via the same "last segment is
        the column, second-to-last is its owning table" convention used
        for refobj paths elsewhere, not a rigid exactly-2-segments regex
      - <left>/<right> referencing their query subject/item by objectID
        (<refObjectID>/<refQueryItem>, as child element or attribute)
        instead of a bracket-path string — the shape used by
        Business/Presentation-layer relationships in real FM exports,
        resolved via the optional subject_objectid_map/item_objectid_map
      - two or more <determinant>Table.Column</determinant> children
        directly under <relationship> (dot-syntax, no brackets)
      - <join> wrapping either <leftColumn>/<rightColumn>, its own
        <determinant> pairs, or <foreignKey>/<primaryKey>
      - <foreignKey>/<primaryKey> as direct children of <relationship>
      - <relationshipRef name="..."/> — a reference to a relationship
        defined elsewhere by name, resolved via named_relationships
      - an explicit <cardinality>1:n</cardinality>-style element, which
        always overrides mincard/maxcard-based inference when present
    """
    determinants_by_subject = determinants_by_subject or {}
    warning = None
    from_subject = from_col = to_subject = to_col = None
    left_maxcard = right_maxcard = ''
    explicit_cardinality = None

    # ── relationshipRef: resolve against another named relationship ────────
    ref_el = _find_local(rel_el, 'relationshipRef')
    if ref_el is not None and named_relationships is not None:
        target_name = _attr_any(ref_el, 'name', default='') or _text_of(ref_el).strip()
        resolved = named_relationships.get(target_name)
        if resolved:
            return dict(resolved)
        return {'_warning': f"<relationshipRef> to '{target_name}' could not be resolved "
                            f"— no relationship with that name was found elsewhere in the model."}

    # ── Strategy 1: classic <left>/<right> + join <expression>, or
    #     objectID-based endpoints ─────────────────────────────────────────
    left_el = _find_local(rel_el, 'left')
    right_el = _find_local(rel_el, 'right')
    if left_el is not None and right_el is not None:
        # objectID-based endpoint resolution (Business/Presentation-layer
        # relationships) takes priority when present — it names the exact
        # query item directly, with no ambiguity from bracket-path depth.
        objid_from_subject, objid_from_col = _fm_resolve_side_via_objectid(
            left_el, subject_objectid_map, item_objectid_map)
        objid_to_subject, objid_to_col = _fm_resolve_side_via_objectid(
            right_el, subject_objectid_map, item_objectid_map)

        left_subject, _ = _fm_parse_table_column_ref(left_el, known_tables)
        right_subject, _ = _fm_parse_table_column_ref(right_el, known_tables)
        left_subject = left_subject or objid_from_subject
        right_subject = right_subject or objid_to_subject
        left_maxcard = _text_of(_find_local(left_el, 'maxcard')) or \
            _text_of(_find_local(left_el, 'maxCardinality'))
        right_maxcard = _text_of(_find_local(right_el, 'maxcard')) or \
            _text_of(_find_local(right_el, 'maxCardinality'))
        expr_el = _find_local(rel_el, 'expression')
        join_text = _text_of(_find_local(expr_el, 'refobj')) if expr_el is not None else ''
        if not join_text and expr_el is not None:
            join_text = _text_of(expr_el)
        if join_text and '=' in join_text:
            lhs, rhs = [s.strip() for s in join_text.split('=', 1)]
            # Bracket-chain sides may be "[Table].[Column]" (2 segments) or
            # deeper namespace/schema-qualified paths — the last bracket
            # segment is always the column, the one before it the table,
            # regardless of how many segments precede them.
            if '[' in lhs:
                lhs_segments = re.findall(r'\[([^\[\]]+)\]', lhs)
                if len(lhs_segments) >= 2:
                    from_subject, from_col = lhs_segments[-2], lhs_segments[-1]
            else:
                from_subject, from_col = _fm_parse_dotted_ref(lhs, known_tables)
            if '[' in rhs:
                rhs_segments = re.findall(r'\[([^\[\]]+)\]', rhs)
                if len(rhs_segments) >= 2:
                    to_subject, to_col = rhs_segments[-2], rhs_segments[-1]
            else:
                to_subject, to_col = _fm_parse_dotted_ref(rhs, known_tables)
        if not from_col and objid_from_col:
            from_subject, from_col = objid_from_subject, objid_from_col
        if not to_col and objid_to_col:
            to_subject, to_col = objid_to_subject, objid_to_col
        if not from_subject:
            from_subject = left_subject
        if not to_subject:
            to_subject = right_subject

    # ── Strategy 2: <join> wrapper (leftColumn/rightColumn, its own
    #     determinant pair, or foreignKey/primaryKey) ────────────────────
    if not (from_subject and to_subject):
        join_el = _find_local(rel_el, 'join')
        if join_el is not None:
            lc_el = _find_local(join_el, 'leftColumn')
            rc_el = _find_local(join_el, 'rightColumn')
            if lc_el is not None and rc_el is not None:
                from_subject, from_col = _fm_parse_table_column_ref(lc_el, known_tables)
                to_subject, to_col = _fm_parse_table_column_ref(rc_el, known_tables)
            else:
                dets = list(_iter_local(join_el, 'determinant'))
                if len(dets) >= 2:
                    from_subject, from_col = _fm_parse_dotted_ref(_text_of(dets[0]), known_tables)
                    to_subject, to_col = _fm_parse_dotted_ref(_text_of(dets[1]), known_tables)
                else:
                    fk_el = _find_local(join_el, 'foreignKey')
                    pk_el = _find_local(join_el, 'primaryKey')
                    if fk_el is not None and pk_el is not None:
                        from_subject, from_col = _fm_parse_table_column_ref(fk_el, known_tables)
                        to_subject, to_col = _fm_parse_table_column_ref(pk_el, known_tables)

    # ── Strategy 3: <foreignKey>/<primaryKey> directly under <relationship> ─
    if not (from_subject and to_subject):
        fk_el = _find_local(rel_el, 'foreignKey')
        pk_el = _find_local(rel_el, 'primaryKey')
        if fk_el is not None and pk_el is not None:
            from_subject, from_col = _fm_parse_table_column_ref(fk_el, known_tables)
            to_subject, to_col = _fm_parse_table_column_ref(pk_el, known_tables)
            explicit_cardinality = ('many', 'one')   # foreignKey side is always the "many" side by definition

    # ── Strategy 4: two or more <determinant>Table.Column</determinant>
    #     children directly under <relationship> (dot-syntax) ─────────────
    if not (from_subject and to_subject):
        dets = [d for d in _iter_local(rel_el, 'determinant')
               if _find_local(d, 'key') is None]   # exclude a query-subject-style <determinant><key>...
        if len(dets) >= 2:
            from_subject, from_col = _fm_parse_dotted_ref(_text_of(dets[0]), known_tables)
            to_subject, to_col = _fm_parse_dotted_ref(_text_of(dets[1]), known_tables)
            if len(dets) > 2:
                warning = (f"Relationship has {len(dets)} determinants (a composite-key join); "
                          f"only the first pair ({from_subject}.{from_col} = {to_subject}.{to_col}) "
                          f"was used — verify the remaining key columns manually.")

    if not (from_subject and from_col and to_subject and to_col):
        return {'_warning': "Relationship could not be parsed — none of the recognized join "
                           "formats (left/right expression, determinant pair, join, "
                           "foreignKey/primaryKey) matched."}

    # ── Cardinality: explicit <cardinality> tag > foreignKey/primaryKey >
    #     mincard/maxcard > determinant-uniqueness inference > default ─────
    card_el = _find_local(rel_el, 'cardinality')
    inferred = False
    if card_el is not None:
        card_text = _text_of(card_el).strip().lower()
        mapped = _CARDINALITY_TEXT_MAP.get(card_text) or _CARDINALITY_TEXT_MAP.get(
            re.sub(r'\s+', '', card_text))
        if mapped:
            explicit_cardinality = mapped
    if explicit_cardinality:
        from_card, to_card = explicit_cardinality
    elif left_maxcard or right_maxcard:
        from_card, to_card = _fm_maxcard_to_side(left_maxcard), _fm_maxcard_to_side(right_maxcard)
    else:
        # No explicit cardinality anywhere — infer from whether the "to"
        # side's join column is a known unique determinant (or identifier)
        # on its own query subject: a unique key column makes that side the
        # "one" side of a one-to-many relationship, which is the far more
        # common real-world case for a fact -> dimension join.
        to_is_unique = determinants_by_subject.get(to_subject, {}).get(to_col, False)
        from_is_unique = determinants_by_subject.get(from_subject, {}).get(from_col, False)
        if to_is_unique and not from_is_unique:
            from_card, to_card = 'many', 'one'
        elif from_is_unique and not to_is_unique:
            from_card, to_card = 'one', 'many'
        else:
            from_card, to_card = 'many', 'one'
            inferred = True
            warning = (warning or '') + (
                f" Cardinality could not be determined from the model (no unique determinant "
                f"found on either side of {from_subject}.{from_col} = {to_subject}.{to_col}) — "
                f"defaulted to Many-to-One; please verify.")

    return {
        'fromTable': from_subject, 'fromColumn': from_col,
        'toTable': to_subject, 'toColumn': to_col,
        'fromCardinality': from_card, 'toCardinality': to_card,
        'crossFilterDirection': 'Single', 'isActive': True,
        'cardinality_inferred': inferred,
        '_warning': warning.strip() if warning else None,
    }
    from_subject, from_col, to_subject, to_col = m.groups()

    # Cardinality convention: the side whose maxcard is "n"/"many" is the
    # "many" (fact-like) side; a relationship pointing many -> one matches
    # how build_data_model_schema already expects fromTable/toTable.
    many_is_left = 'n' in (left_maxcard or '').lower() or (left_maxcard or '') not in ('1', '0..1', '')
    if many_is_left:
        return {'fromTable': from_subject or left_subject, 'fromColumn': from_col,
               'toTable': to_subject or right_subject, 'toColumn': to_col}
    return {'fromTable': to_subject or right_subject, 'fromColumn': to_col,
           'toTable': from_subject or left_subject, 'toColumn': from_col}


# ── Hierarchy detection ─────────────────────────────────────────────────────

_HIERARCHY_NAME_PATTERNS = [
    (['year', 'quarter', 'month', 'day'], 'Calendar Hierarchy'),
    (['year', 'quarter', 'month'], 'Calendar Hierarchy'),
    (['year', 'month'], 'Calendar Hierarchy'),
    (['category', 'subcategory', 'product'], 'Product Hierarchy'),
    (['category', 'subcategory'], 'Product Hierarchy'),
    (['country', 'state', 'city'], 'Geography Hierarchy'),
    (['region', 'country', 'state', 'city'], 'Geography Hierarchy'),
]


def _fm_parse_explicit_hierarchies(qs_el) -> list:
    """Some Framework Manager exports declare navigation paths/hierarchies
    explicitly (<hierarchy> with ordered <level> children referencing query
    items) -- when present, these are authoritative and used as-is instead
    of guessing from naming conventions."""
    hierarchies = []
    for h_el in _iter_local(qs_el, 'hierarchy', 'navigationPath'):
        h_name = _attr_any(h_el, 'name', default='Hierarchy')
        levels = []
        for lvl_el in _iter_local(h_el, 'level'):
            ref_el = _find_local(lvl_el, 'refobj')
            item_name = _fm_ref_last_segment(_text_of(ref_el)) if ref_el is not None else \
                _attr_any(lvl_el, 'name', default='')
            if item_name:
                levels.append(item_name)
        if levels:
            hierarchies.append({'name': h_name, 'levels': levels})
    return hierarchies


def _detect_hierarchies_by_name(item_names: list) -> list:
    """Fallback when a query subject has no explicit FM hierarchy: group
    query items into a synthetic hierarchy when their names match a common
    dimensional drill pattern (Year->Quarter->Month->Day,
    Category->Subcategory->Product, ...)."""
    tokens_by_item = {name: _tokenize_name(name) for name in item_names}
    hierarchies = []
    used = set()
    for pattern, hier_name in _HIERARCHY_NAME_PATTERNS:
        matched_levels = []
        for level_word in pattern:
            match = next((name for name, toks in tokens_by_item.items()
                         if level_word in toks and name not in used), None)
            if match:
                matched_levels.append(match)
        if len(matched_levels) == len(pattern) and len(matched_levels) >= 2:
            hierarchies.append({'name': hier_name, 'levels': matched_levels})
            used.update(matched_levels)
    return hierarchies


def _fm_build_tom_hierarchies(hierarchies: list, col_name_map: dict) -> list:
    """Convert detected {'name','levels':[cognos_item_names]} dicts into
    the TOM 'hierarchies' array shape."""
    tom_hierarchies = []
    for h in hierarchies:
        levels = []
        for ordinal, cognos_name in enumerate(h['levels']):
            pbi_name = col_name_map.get(cognos_name, cognos_name)
            levels.append({'name': pbi_name, 'column': pbi_name, 'ordinal': ordinal,
                           'lineageTag': _guid()})
        if levels:
            tom_hierarchies.append({'name': h['name'], 'lineageTag': _guid(), 'levels': levels})
    return tom_hierarchies


# ── Top-level Framework Manager model walker ────────────────────────────────

def _fm_walk_namespace(ns_el, folder_path: str, query_subjects: list, relationship_elements: list,
                       hierarchies_by_subject: dict, warnings: list,
                       item_objectid_map: dict = None):
    """
    Recursively walk <namespace>/<folder> elements, collecting every query
    subject found anywhere inside (tracking its presentation-layer folder
    path along the way) and every relationship-like element for later
    parsing. Relationship elements are deferred rather than parsed
    immediately: cardinality inference needs every query subject's
    determinants already collected, which isn't guaranteed until the whole
    model has been walked.
    """
    for child in ns_el:
        tag = _local(child.tag)
        if tag == 'querySubject':
            qs = _fm_parse_query_subject(child, folder_path, item_objectid_map)
            if qs['items']:
                query_subjects.append(qs)
                explicit = _fm_parse_explicit_hierarchies(child)
                if explicit:
                    hierarchies_by_subject[qs['name']] = explicit
            else:
                warnings.append(f"Query subject '{qs['name']}' has no query items and was skipped.")
        elif tag in ('relationship', 'association'):
            relationship_elements.append(child)
        elif tag in ('namespace', 'folder'):
            sub_name = _attr_any(child, 'name', default='')
            next_path = f"{folder_path}/{sub_name}" if folder_path and sub_name else (sub_name or folder_path)
            _fm_walk_namespace(child, next_path, query_subjects, relationship_elements,
                              hierarchies_by_subject, warnings, item_objectid_map)


def _fm_walk_presentation_namespace(ns_el, folder_leaf: str,
                                    folder_refs: dict, item_refs: dict) -> None:
    """
    Walk a Framework Manager Presentation Layer namespace, collecting two
    reference maps keyed by the LEAF folder name (lower-cased) — matching
    the "second-to-last bracket segment" convention every report expression
    uses (e.g. [HR Enterprise Reporting].[Employee].[Employee ID] -> leaf
    folder 'Employee'):

      folder_refs[leaf_name] = refObjectID of the <queryItemFolderRef>
          this folder carries -- the Business Layer query subject this
          presentation folder is a view onto.
      item_refs[(leaf_name, item_name)] = refObjectID of the
          <presentationQueryItem>'s own reference -- the Business Layer
          query ITEM it re-exposes, possibly under a friendlier name.

    THIS IS THE ROOT-CAUSE FIX for report queries turning into orphan
    "Query1"/"Query2" tables instead of resolving to their real Framework
    Manager table: report authors drag fields from the Presentation
    Layer's folder tree (friendly names like "Employee Name"), never from
    the Business Layer directly (raw names like "ENAME") — but the
    Business-Layer-only walk in _parse_framework_manager_model previously
    never parsed the Presentation Layer at all, so those friendly names
    had nothing to resolve against and fell back to being modeled as
    unrelated standalone tables.
    """
    for child in ns_el:
        tag = _local(child.tag)
        if tag == 'folder':
            leaf = _attr_any(child, 'name', default='') or folder_leaf
            # Direct children only -- _find_local/_iter_local search the
            # WHOLE subtree, which would incorrectly attribute a nested
            # subfolder's own queryItemFolderRef/presentationQueryItem
            # elements to this (ancestor) folder as well.
            for sub in child:
                sub_tag = _local(sub.tag)
                if sub_tag == 'queryItemFolderRef':
                    oid = _attr_any(sub, 'refObjectID', default='').strip()
                    if oid and leaf:
                        folder_refs[leaf.lower()] = oid
                elif sub_tag == 'presentationQueryItem':
                    pqi_name = _attr_any(sub, 'name', default='')
                    ref_el = _find_local(sub, 'refObjectID')
                    oid = _text_of(ref_el).strip() if ref_el is not None else \
                        _attr_any(sub, 'refObjectID', default='').strip()
                    if pqi_name and oid and leaf:
                        item_refs[(leaf.lower(), pqi_name.lower())] = oid
            _fm_walk_presentation_namespace(child, leaf, folder_refs, item_refs)
        elif tag == 'namespace':
            _fm_walk_presentation_namespace(child, folder_leaf, folder_refs, item_refs)


def _parse_framework_manager_model(xml_text: str, source_name: str) -> dict:
    """
    Parse an IBM Cognos Framework Manager model (.xml) into the same
    report-shaped dict the rest of this pipeline already consumes -- one
    "query" per Query Subject, with the Query Subject's Query Items as its
    items, and every Relationship converted directly into
    report['relationships']. Everything downstream (semantic model
    generation, cycle detection, DAX conversion, TOM validation, PBIT
    packaging) runs completely unchanged on the result.
    """
    log('info', "Loading Framework Manager Model...")
    log('info', "Reading XML...")
    report = _new_report_skeleton(source_name)
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        report['warnings'].append(f"Invalid Framework Manager XML in {source_name}: {exc}")
        return report

    report['name'] = _attr_any(root, 'name', default='') or Path(source_name).stem

    # Build objectID -> (subject, item) lookup maps from EVERY query subject
    # in the document up front, regardless of which layer(s) end up
    # contributing actual tables below — relationship <left>/<right>
    # endpoints that reference their query subject/item by objectID
    # (<refObjectID>/<refQueryItem>) need these to resolve, and they must
    # be complete before any relationship gets parsed.
    subject_objectid_map: dict = {}
    item_objectid_map: dict = {}
    for qs_el in _iter_local(root, 'querySubject'):
        subj_name = _attr_any(qs_el, 'name', default='')
        subj_oid = _fm_object_id_of(qs_el)
        if subj_oid and subj_name:
            subject_objectid_map[subj_oid] = subj_name
        for qi_el in _iter_local(qs_el, 'queryItem'):
            item_name = _attr_any(qi_el, 'name', default='')
            item_oid = _fm_object_id_of(qi_el)
            if item_oid and item_name:
                item_objectid_map[item_oid] = (subj_name, item_name)

    log('info', "Extracting Namespaces...")
    query_subjects: list = []
    relationship_elements: list = []
    hierarchies_by_subject: dict = {}
    warnings: list = []

    # Classic Framework Manager models are layered Physical -> Business ->
    # Presentation, with the SAME real-world entity modeled once per layer
    # under a different (often just re-cased) name — walking every
    # namespace indiscriminately would double every table and relationship.
    # When both a physical-looking and a business-looking namespace are
    # present, only the Business Layer (the semantic layer reports are
    # actually authored against) plus any unlayered namespace is walked for
    # tables/relationships; a simple/older single-namespace export (or a
    # Cognos Analytics data module with no layering at all) is unaffected.
    top_level_namespaces = [child for child in root if _local(child.tag) == 'namespace']
    presentation_folder_refs: dict = {}   # leaf_folder_name.lower() -> business querySubject objectID
    presentation_item_refs: dict = {}     # (leaf_folder_name.lower(), item_name.lower()) -> business queryItem objectID
    if top_level_namespaces:
        layer_buckets: dict = {}
        for ns in top_level_namespaces:
            layer_buckets.setdefault(_fm_classify_namespace_layer(ns), []).append(ns)
        for pres_ns in layer_buckets.get('presentation', []):
            _fm_walk_presentation_namespace(pres_ns, '', presentation_folder_refs, presentation_item_refs)
        if layer_buckets.get('business') and layer_buckets.get('physical'):
            namespaces_to_walk = layer_buckets.get('business', []) + layer_buckets.get('unlayered', [])
            log('info', "Detected a layered Framework Manager model (Physical -> Business -> "
                        "Presentation) — building the semantic model from the Business Layer "
                        "only; the Physical Layer's duplicate query subjects and relationships "
                        "are skipped to avoid doubled tables.")
        else:
            namespaces_to_walk = top_level_namespaces
        for ns in namespaces_to_walk:
            _fm_walk_namespace(ns, '', query_subjects, relationship_elements, hierarchies_by_subject, warnings, item_objectid_map)
    else:
        # No namespace wrapper at all (some exports put query subjects
        # directly under the model root) — fall back to a whole-document walk.
        _fm_walk_namespace(root, '', query_subjects, relationship_elements, hierarchies_by_subject, warnings, item_objectid_map)

    # Determinants are looked up by each query subject's ORIGINAL (pre-rename)
    # name, since relationship elements reference subjects by that same
    # original name.
    determinants_by_subject = {qs['name']: qs.get('_determinants', {}) for qs in query_subjects}

    log('info', f"Extracting Query Subjects... ({len(query_subjects)} found)")
    seen_names: set = set()
    original_to_final: dict = {}
    for qs in query_subjects:
        original_name = qs['name']
        qs['name'] = _unique_name(qs['name'] or 'QuerySubject', seen_names, case_insensitive=True)
        original_to_final[original_name] = qs['name']
        report['queries'].append(qs)
        report.setdefault('_fm_object_log', []).append({
            'original': f"Query Subject: {original_name}", 'pbi_object': f"Table: {qs['name']}",
            'status': 'Converted', 'warnings': [], 'errors': [], 'manual_intervention': '',
        })
        explicit_h = hierarchies_by_subject.get(original_name)
        if explicit_h:
            report.setdefault('_fm_hierarchies', {})[qs['name']] = explicit_h
        else:
            detected = _detect_hierarchies_by_name([it['name'] for it in qs['items']])
            if detected:
                report.setdefault('_fm_hierarchies', {})[qs['name']] = detected

    log('info', f"Extracting Relationships... ({len(relationship_elements)} found)")
    # Pass 1: parse every explicitly-named relationship that isn't itself a
    # <relationshipRef>, so a ref appearing anywhere in the model (including
    # before its target in document order) can resolve against it.
    named_relationships: dict = {}
    for rel_el in relationship_elements:
        if _find_local(rel_el, 'relationshipRef') is not None:
            continue
        name = _attr_any(rel_el, 'name', default='')
        if not name:
            continue
        parsed = _fm_parse_relationship(rel_el, determinants_by_subject,
                                         known_tables=set(determinants_by_subject.keys()),
                                         subject_objectid_map=subject_objectid_map,
                                         item_objectid_map=item_objectid_map)
        if parsed.get('fromTable'):
            named_relationships[name] = parsed

    # Pass 2: parse everything for real (relationshipRef now resolvable).
    relationships: list = []
    for rel_el in relationship_elements:
        parsed = _fm_parse_relationship(rel_el, determinants_by_subject, named_relationships,
                                         known_tables=set(determinants_by_subject.keys()),
                                         subject_objectid_map=subject_objectid_map,
                                         item_objectid_map=item_objectid_map)
        rel_name = _attr_any(rel_el, 'name', default='(unnamed)')
        if parsed.get('_warning') and not parsed.get('fromTable'):
            warnings.append(f"Relationship '{rel_name}': {parsed['_warning']}")
            continue
        if parsed.get('_warning'):
            warnings.append(f"Relationship '{rel_name}': {parsed['_warning']}")
        if parsed.get('cardinality_inferred'):
            log('warn', f"Cardinality could not be determined for relationship '{rel_name}' "
                        f"— defaulted to Many-to-One.")
        relationships.append(parsed)

    subject_names = {qs['name'] for qs in query_subjects}
    for rel in relationships:
        from_t = original_to_final.get(rel.get('fromTable', ''), rel.get('fromTable', ''))
        to_t = original_to_final.get(rel.get('toTable', ''), rel.get('toTable', ''))
        if from_t not in subject_names or to_t not in subject_names:
            warnings.append(f"Relationship references a query subject not found in this model "
                            f"({rel.get('fromTable')} -> {rel.get('toTable')}) — skipped.")
            continue
        rel['fromTable'], rel['toTable'] = from_t, to_t
        report['relationships'].append(rel)
        report.setdefault('_fm_object_log', []).append({
            'original': f"Relationship: {from_t}.{rel['fromColumn']} = {to_t}.{rel['toColumn']}",
            'pbi_object': f"Relationship: {from_t} ({rel['fromCardinality']}) -> "
                         f"{to_t} ({rel['toCardinality']})",
            'status': 'Converted', 'warnings': [rel['_warning']] if rel.get('_warning') else [],
            'errors': [], 'manual_intervention': '',
        })

    report['warnings'].extend(warnings)
    if not query_subjects:
        report['warnings'].append(
            f"{source_name}: no Query Subjects were found — this may not be a Framework "
            f"Manager model export, or uses an XML structure this parser doesn't recognize yet.")

    # Resolve the Presentation Layer's folder/item reference maps (raw
    # objectIDs) into final, post-uniquification table/item names, using
    # the same subject_objectid_map/item_objectid_map/original_to_final
    # lookups already built above for relationship resolution. This is
    # what lets a report expression like
    # [HR Enterprise Reporting].[Employee].[Employee ID] resolve straight
    # to table 'EMPLOYEE', column 'ENAME' — see
    # resolve_report_item_to_framework_table().
    presentation_folder_to_table: dict = {}
    for leaf, subj_oid in presentation_folder_refs.items():
        business_name = subject_objectid_map.get(subj_oid)
        if business_name:
            presentation_folder_to_table[leaf] = original_to_final.get(business_name, business_name)

    presentation_item_to_business: dict = {}
    for (leaf, item_name_lower), item_oid in presentation_item_refs.items():
        resolved = item_objectid_map.get(item_oid)
        if resolved:
            business_table, business_item = resolved
            final_table = original_to_final.get(business_table, business_table)
            presentation_item_to_business[(leaf, item_name_lower)] = (final_table, business_item)

    report['_presentation_folder_to_table'] = presentation_folder_to_table
    report['_presentation_item_to_business'] = presentation_item_to_business
    if presentation_item_to_business:
        log('info', f"Extracting Presentation Layer... ({len(presentation_item_to_business)} "
                    f"presentation item(s) mapped across {len(presentation_folder_to_table)} "
                    f"folder(s)) — report expressions using presentation-layer paths will "
                    f"resolve directly to their real Framework Manager table.")

    log('info', f"Framework Manager model parsed: {len(report['queries'])} table(s), "
                f"{len(report['relationships'])} relationship(s).")
    return report


# ── JSON data-module / query export parsing ────────────────────────────────

def _parse_cognos_json(data, source_name: str) -> dict:
    """
    Parse Cognos JSON exports. Two shapes are commonly seen in the wild:

    1. A "data module" style export:
         {"tables": [{"name": "Sales", "columns": [{"name":"Revenue","dataType":"decimal",
                       "expression": "...", "usage": "fact"}]}], "relationships": [...]}
    2. A simplified query export:
         {"queries": [{"name": "Query1", "items": [{"name": "Revenue",
                       "expression": "...", "aggregate": "total"}]}]}

    Anything else is treated as a flat list of records (a single implicit
    table named after the file), which is a reasonable fallback for ad-hoc
    Cognos "run report as JSON" exports.
    """
    report = _new_report_skeleton(source_name)

    if isinstance(data, dict) and isinstance(data.get('tables'), list):
        for t in data['tables']:
            items = []
            for c in t.get('columns', []) or t.get('items', []):
                name = c.get('name') or c.get('label') or f"Column{len(items)+1}"
                expr = c.get('expression', '')
                agg = _normalize_aggregate(c.get('aggregate', '')) or ('total' if c.get('usage') == 'fact' else '')
                items.append({
                    'name': name, 'expression': expr, 'aggregate': agg,
                    'usage': c.get('usage', ''),
                    'datatype': _map_json_datatype(c.get('dataType', '')) or
                                _guess_datatype(name, agg, expr),
                    'is_calculated': bool(expr),
                })
            if items:
                report['queries'].append({
                    'name': t.get('name', f'Table{len(report["queries"])+1}'),
                    'items': items, 'filters': [], 'sorts': [],
                })
        for rel in data.get('relationships', []) or data.get('joins', []):
            ft = rel.get('fromTable') or rel.get('leftTable') or rel.get('left')
            tt = rel.get('toTable') or rel.get('rightTable') or rel.get('right')
            fc = rel.get('fromColumn') or rel.get('leftColumn')
            tc = rel.get('toColumn') or rel.get('rightColumn')
            if ft and tt and fc and tc:
                report['relationships'].append({
                    'fromTable': ft, 'fromColumn': fc, 'toTable': tt, 'toColumn': tc,
                })
        report['name'] = data.get('name', Path(source_name).stem)
        return report

    if isinstance(data, dict) and isinstance(data.get('queries'), list):
        for q in data['queries']:
            items = []
            for it in q.get('items', []) or q.get('dataItems', []):
                name = it.get('name') or f"Item{len(items)+1}"
                expr = it.get('expression', '')
                agg = _normalize_aggregate(it.get('aggregate', ''))
                items.append({
                    'name': name, 'expression': expr, 'aggregate': agg,
                    'usage': it.get('usage', ''),
                    'datatype': _map_json_datatype(it.get('dataType', '')) or
                                _guess_datatype(name, agg, expr),
                    'is_calculated': bool(expr),
                })
            if items:
                report['queries'].append({
                    'name': q.get('name', f'Query{len(report["queries"])+1}'),
                    'items': items, 'filters': q.get('filters', []) or [],
                    'sorts': [],
                })
        report['name'] = data.get('name', Path(source_name).stem)
        return report

    # Fallback: flat list-of-records export → one implicit table.
    records = data if isinstance(data, list) else data.get('rows') if isinstance(data, dict) else None
    if isinstance(records, list) and records and isinstance(records[0], dict):
        cols = list(records[0].keys())
        items = [{'name': c, 'expression': '', 'aggregate': '', 'usage': '',
                  'datatype': _infer_type_from_values([r.get(c) for r in records[:25]]),
                  'is_calculated': False} for c in cols]
        table_name = Path(source_name).stem
        report['queries'].append({'name': table_name, 'items': items,
                                   'filters': [], 'sorts': []})
        report['sample_rows'][table_name] = records
        return report

    report['warnings'].append(
        f"{source_name}: JSON structure not recognized as a Cognos data "
        f"module, query export, or record list — no tables extracted.")
    return report


def _map_json_datatype(dt: str) -> str:
    dt = (dt or '').lower()
    if dt in ('int', 'integer', 'int64', 'long', 'bigint'):
        return 'int64'
    if dt in ('decimal', 'double', 'float', 'number', 'numeric'):
        return 'double'
    if dt in ('date', 'datetime', 'timestamp'):
        return 'dateTime'
    if dt in ('boolean', 'bool'):
        return 'boolean'
    if dt in ('string', 'text', 'varchar', 'char'):
        return 'string'
    return ''


def _infer_type_from_values(values) -> str:
    vals = [v for v in values if v is not None and v != '']
    if not vals:
        return 'string'
    if all(isinstance(v, bool) for v in vals):
        return 'boolean'
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in vals):
        return 'double'
    if all(isinstance(v, str) and re.match(r'^\d{4}-\d{2}-\d{2}', v) for v in vals):
        return 'dateTime'
    return 'string'


# ── MHT / HTML table extraction (rendered Cognos report output) ───────────
#
# Cognos frequently exports rendered reports as MHTML ("Save as .mht") or
# plain HTML. These carry no query/expression metadata, but they DO carry
# real, exact cell values — so this path extracts each <table> as a
# synthetic query and keeps the literal rows for embedding, which produces
# a higher-fidelity Power BI model than sample/synthetic data.

class _TableExtractor(HTMLParser):
    """Minimal, dependency-free HTML <table> extractor."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables = []
        self._stack = []
        self._cur_table = None
        self._cur_row = None
        self._cur_cell = None
        self._title_parts = []
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag == 'title':
            self._in_title = True
        elif tag == 'table':
            self._cur_table = []
            self._stack.append('table')
        elif tag == 'tr' and self._cur_table is not None:
            self._cur_row = []
        elif tag in ('td', 'th') and self._cur_row is not None:
            self._cur_cell = []

    def handle_endtag(self, tag):
        if tag == 'title':
            self._in_title = False
        elif tag == 'table' and self._cur_table is not None:
            if self._cur_table:
                self.tables.append(self._cur_table)
            self._cur_table = None
        elif tag == 'tr' and self._cur_row is not None:
            if self._cur_table is not None:
                self._cur_table.append(self._cur_row)
            self._cur_row = None
        elif tag in ('td', 'th') and self._cur_cell is not None:
            text = ''.join(self._cur_cell).strip()
            if self._cur_row is not None:
                self._cur_row.append(text)
            self._cur_cell = None

    def handle_data(self, data):
        if self._in_title:
            self._title_parts.append(data)
        if self._cur_cell is not None:
            self._cur_cell.append(data)

    @property
    def title(self):
        return ''.join(self._title_parts).strip()


def _decode_mht(raw: bytes) -> str:
    """Decode a .mht/.mhtml file, returning the concatenated text/html parts."""
    text = raw.decode('utf-8', errors='replace')
    parts = re.split(r'\r?\n--[^\r\n]+\r?\n', text)
    html_chunks = []
    for part in parts:
        if 'text/html' not in part.lower()[:400]:
            continue
        header, _, body = part.partition('\n\n')
        if not body:
            header, _, body = part.partition('\r\n\r\n')
        header_l = header.lower()
        try:
            if 'base64' in header_l:
                body_clean = re.sub(r'\s+', '', body)
                body = base64.b64decode(body_clean + '=' * (-len(body_clean) % 4)).decode(
                    'utf-8', errors='replace')
            elif 'quoted-printable' in header_l:
                body = quopri.decodestring(body.encode('ascii', errors='ignore')).decode(
                    'utf-8', errors='replace')
        except Exception:
            pass
        html_chunks.append(body)
    if not html_chunks:
        # Not a proper MIME document — perhaps a plain HTML file with an
        # .mht extension. Treat the whole thing as HTML.
        html_chunks = [text]
    return '\n'.join(html_chunks)


def _build_query_from_rows(rows: list, table_name: str):
    """
    Convert a plain list-of-rows (row 0 = header, rest = data — the shape
    produced by both the HTML table extractor and the Cognos static-table
    extractor) into a (query_dict, records) pair, or (None, None) if the
    rows don't contain a usable header.
    """
    if not rows or len(rows) < 1:
        return None, None
    header = rows[0]
    data_rows = rows[1:] if len(rows) > 1 else []
    if not any(str(h).strip() for h in header):
        return None, None
    seen = set()
    col_names = []
    for i, h in enumerate(header):
        name = str(h).strip() or f'Column{i + 1}'
        name = _unique_name(name, seen, case_insensitive=True)
        col_names.append(name)
    records = []
    for r in data_rows[:500]:
        rec = {}
        for i, col in enumerate(col_names):
            rec[col] = r[i] if i < len(r) else ''
        records.append(rec)
    items = []
    for i, col in enumerate(col_names):
        col_values = [r.get(col) for r in records]
        items.append({
            'name': col, 'expression': '', 'aggregate': '', 'usage': '',
            'datatype': _infer_type_from_string_values(col_values),
            'is_calculated': False,
        })
    query = {'name': table_name, 'items': items, 'filters': [], 'sorts': []}
    return query, records


def _tables_to_report(tables: list, title: str, source_name: str) -> dict:
    report = _new_report_skeleton(source_name)
    report['name'] = title or Path(source_name).stem
    for t_idx, rows in enumerate(tables):
        table_name = (f"{Path(source_name).stem}_Table{t_idx + 1}"
                     if len(tables) > 1 else Path(source_name).stem)
        query, records = _build_query_from_rows(rows, table_name)
        if query is None:
            continue
        report['queries'].append(query)
        if records:
            report['sample_rows'][table_name] = records
    if not report['queries']:
        report['warnings'].append(f"{source_name}: no non-empty <table> elements found.")
    return report


def _infer_type_from_string_values(values) -> str:
    vals = [str(v).strip() for v in values if v not in (None, '')]
    if not vals:
        return 'string'
    if all(re.match(r'^-?\d+(\.\d+)?%?$', v.replace(',', '')) for v in vals):
        return 'double'
    if all(re.match(r'^\d{1,4}[-/]\d{1,2}[-/]\d{1,4}', v) for v in vals):
        return 'dateTime'
    return 'string'


def _parse_html_report(html_text: str, source_name: str) -> dict:
    extractor = _TableExtractor()
    try:
        extractor.feed(html_text)
    except Exception as exc:
        report = _new_report_skeleton(source_name)
        report['warnings'].append(f"{source_name}: HTML parse error: {exc}")
        return report
    return _tables_to_report(extractor.tables, extractor.title, source_name)


# ── ZIP package extraction ─────────────────────────────────────────────────

def _parse_cognos_zip(zip_path: Path) -> dict:
    """
    Extract and analyze a Cognos package/report ZIP: report specifications,
    report XML, queries, datasets, data modules, and packages are all
    inspected; every recognizable member is parsed and merged.
    """
    report = _new_report_skeleton(zip_path.name)
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as exc:
        report['warnings'].append(f"Corrupted or invalid ZIP package: {exc}")
        return report

    with zf:
        members = [n for n in zf.namelist() if not n.endswith('/')]
        if not members:
            report['warnings'].append("ZIP package is empty.")
            return report
        for name in members:
            ext = Path(name).suffix.lower()
            try:
                raw = zf.read(name)
            except Exception as exc:
                report['warnings'].append(f"Could not read {name} from ZIP: {exc}")
                continue
            try:
                if ext in ('.xml', '.spec', '.report'):
                    text = raw.decode('utf-8', errors='replace')
                    sub = _parse_cognos_xml_report(text, name)
                    _merge_reports(report, sub)
                elif ext == '.json':
                    data = json.loads(raw.decode('utf-8', errors='replace'))
                    sub = _parse_cognos_json(data, name)
                    _merge_reports(report, sub)
                elif ext in ('.html', '.htm'):
                    sub = _parse_html_report(raw.decode('utf-8', errors='replace'), name)
                    _merge_reports(report, sub)
                elif ext in ('.mht', '.mhtml'):
                    sub = _parse_html_report(_decode_mht(raw), name)
                    _merge_reports(report, sub)
                # Other members (images, .csv datasets, etc.) are not report
                # specifications and are intentionally skipped here — they do
                # not carry additional metadata to convert.
            except Exception as exc:
                report['warnings'].append(f"Failed to parse ZIP member {name}: {exc}")

    if not report['queries']:
        report['warnings'].append(
            "No report specification, data module, or renderable table was "
            "found inside the ZIP package.")
    report['name'] = Path(zip_path).stem
    return report


# ── Top-level dispatcher ────────────────────────────────────────────────────

def parse_cognos_report(path: Path) -> dict:
    """
    Parse a Cognos input file of any supported format into a normalized
    report dict:
        {
          name, source_files, queries: [{name, items, filters, sorts}],
          parameters, pages, relationships, sample_rows, warnings, data_colors,
          _artifact_type: 'report' | 'framework_manager'
        }
    """
    report = _parse_cognos_report_inner(path)
    report.setdefault('_artifact_type', 'report')
    return report


def _parse_cognos_report_inner(path: Path) -> dict:
    ext = path.suffix.lower()
    if ext == '.zip':
        return _parse_cognos_zip(path)

    if ext == '.json':
        try:
            data = json.loads(path.read_text(encoding='utf-8', errors='replace'))
        except json.JSONDecodeError as exc:
            report = _new_report_skeleton(path.name)
            report['warnings'].append(f"Invalid JSON: {exc}")
            return report
        return _parse_cognos_json(data, path.name)

    if ext in ('.mht', '.mhtml'):
        raw = path.read_bytes()
        return _parse_html_report(_decode_mht(raw), path.name)

    if ext in ('.html', '.htm'):
        text = path.read_text(encoding='utf-8', errors='replace')
        return _parse_html_report(text, path.name)

    # .xml / .spec / .report — could be either a Cognos report specification
    # or a Framework Manager model; both are ordinary .xml files, so the
    # root element is sniffed before deciding which parser applies.
    text = path.read_text(encoding='utf-8', errors='replace')
    try:
        root = ET.fromstring(text)
        artifact_type = detect_cognos_artifact_type(root)
        if artifact_type == 'framework_manager':
            log('info', "Detected Artifact:")
            log('info', "  Framework Manager Model")
            log('info', "Generating:")
            log('info', "  Power BI Semantic Model (.pbip)")
            report = _parse_framework_manager_model(text, path.name)
            report['_artifact_type'] = 'framework_manager'
            return report
        log('info', "Detected Artifact:")
        log('info', "  Cognos Report Specification")
        log('info', "Generating:")
        log('info', "  Power BI Template (.pbit)")
    except ET.ParseError:
        pass   # fall through; _parse_cognos_xml_report will surface the parse error consistently
    report = _parse_cognos_xml_report(text, path.name)
    report['_artifact_type'] = 'report'
    return report




# ─────────────────────────────────────────────────────────────────────────────
# Cognos expression → DAX conversion
# ─────────────────────────────────────────────────────────────────────────────
#
# Cognos Report Studio / Framework Manager expressions use a SQL-flavoured
# macro language. This converter handles the patterns that appear in the
# overwhelming majority of real reports: field references, CASE/IF/COALESCE,
# common date/string functions, aggregations, and basic arithmetic/logical
# operators. Anything it cannot confidently translate is left as a commented
# DAX placeholder and reported back to the caller so it surfaces in both the
# UI log stream and the migration documentation (never silently dropped).

_COGNOS_FUNCTIONS = [
    'case', 'when', 'then', 'else', 'end', 'if', 'coalesce', 'ifnull',
    'total', 'average', 'maximum', 'minimum', 'count', 'count-distinct',
    'running-total', 'rank', 'moving-average', 'percentage',
    '_add_days', '_add_months', '_add_years', '_days_between',
    '_first_of_month', '_last_of_month', '_make_timestamp',
    'extract', 'day', 'month', 'year', 'current_date', 'current_timestamp',
    'substring', '_length', 'trim', 'ltrim', 'rtrim', 'uppercase', 'lowercase',
    'cast',
]


def _detect_cognos_functions(expr: str) -> list:
    found = []
    low = expr.lower()
    for fn in _COGNOS_FUNCTIONS:
        if re.search(r'\b' + re.escape(fn) + r'\b', low):
            found.append(fn)
    return found


def _strip_field_refs(expr: str, table_name: str, col_name_map: dict = None,
                       measure_names: set = None) -> str:
    """
    Convert Cognos bracketed field references to DAX references.

    Cognos:  [Namespace].[Query].[Item]  or  [Query].[Item]  or  [Item]
    DAX column:   'TableName'[Item]
    DAX measure:  [Item]     (measures are NEVER table-qualified in DAX —
                              unlike columns, using 'Table'[MeasureName] is
                              a syntax error)

    Only the final bracketed segment is a genuine field name in Cognos —
    everything before it is namespace/query qualification which DAX does not
    need (DAX qualifies by table name instead). measure_names holds the
    final PBI names (post rename-for-collision) of every measure already
    built for this table, so a reference that resolves to a measure is
    emitted in the correct measure syntax instead of being treated as a
    column by default.
    """
    col_name_map = col_name_map or {}
    measure_names = measure_names or set()

    def _repl(m):
        full = m.group(0)
        segments = re.findall(r'\[([^\[\]]+)\]', full)
        item = segments[-1] if segments else full
        mapped = col_name_map.get(item, item)
        if mapped in measure_names:
            return f"[{mapped}]"
        return f"'{table_name}'[{mapped}]"

    # Match one or more consecutive [..] groups (namespace.query.item chains).
    return re.sub(r'(?:\[[^\[\]]+\]\.)*\[[^\[\]]+\]', _repl, expr)


def _convert_case(expr: str) -> str:
    """CASE [WHEN a THEN b]+ [ELSE c] END  ->  SWITCH(TRUE(), a, b, ..., c)

    Handles arbitrary nesting -- a CASE expression appearing inside a WHEN,
    THEN, or ELSE branch of another CASE. THIS IS THE ROOT-CAUSE FIX for the
    "keyword CASE is neither a property nor an object" TMDL parse error:
    the previous implementation used a single non-recursive
    ``re.sub(r'\bcase\b(.*?)\bend\b', ...)`` pass. On nested input, that
    regex's non-greedy ``.*?`` matches from the OUTER "case" to the FIRST
    "end" it finds textually -- which is the INNER case's "end", not the
    outer one. The result: the outer CASE's own ELSE/END are left completely
    outside the match, so they pass through untouched as literal text sitting
    right after the (partially garbled) SWITCH(...) this produced. Downstream,
    cognos_expr_to_dax() correctly *detected* that leftover CASE/ELSE/END
    text and refused to emit it as DAX -- but its own fallback path then
    wrote the raw original Cognos expression (containing CASE/WHEN/END)
    into a DAX comment, which is exactly what TMDL's parser choked on. That
    fallback is fixed separately below (see cognos_expr_to_dax); this fix
    addresses the actual reason a fallback was ever needed in the first
    place: nested CASE not converting.

    Fix: repeatedly find and convert the INNERMOST CASE...END block first --
    defined as the first "case" keyword (scanning left to right) whose body
    (up to its own nearest "end") contains no further "case" keyword -- and
    substitute its SWITCH(...) form in place. Because each converted inner
    CASE becomes "SWITCH(...)" text (no longer containing the literal word
    "case"), the next loop iteration's search naturally finds the next
    (now-innermost, e.g. the original outer) CASE, correctly cascading
    inward-out to any nesting depth.
    """
    def _convert_one_case_body(body):
        when_pairs = re.findall(
            r'when\s+(.*?)\s+then\s+(.*?)(?=\s+when\s|\s+else\s|$)',
            body, re.I | re.S)
        else_m = re.search(r'\belse\s+(.*)$', body, re.I | re.S)
        if re.match(r'^\s*when\b', body, re.I):
            # Searched CASE — conditions are boolean expressions already.
            args = []
            for cond, val in when_pairs:
                args.append(cond.strip())
                args.append(val.strip())
            switch_args = ', '.join(args)
            if else_m:
                switch_args += f", {else_m.group(1).strip()}"
            return f"SWITCH(TRUE(), {switch_args})"
        else:
            # Simple CASE: case <scrutinee> when v1 then r1 ... else rN end
            scrut_m = re.match(r'^\s*(.*?)\s+when\s', body, re.I | re.S)
            scrutinee = scrut_m.group(1).strip() if scrut_m else ''
            args = [scrutinee]
            for val, res in when_pairs:
                args.append(val.strip())
                args.append(res.strip())
            switch_args = ', '.join(args)
            if else_m:
                switch_args += f", {else_m.group(1).strip()}"
            return f"SWITCH({switch_args})"

    guard = 0
    while re.search(r'\bcase\b', expr, re.I) and guard < 50:
        guard += 1
        progressed = False
        for case_m in re.finditer(r'\bcase\b', expr, re.I):
            body_start = case_m.end()
            end_m = re.search(r'\bend\b', expr[body_start:], re.I)
            if not end_m:
                continue  # unmatched "case" with no "end" at all -- leave as-is
            body = expr[body_start:body_start + end_m.start()]
            if re.search(r'\bcase\b', body, re.I):
                continue  # not innermost -- a nested CASE opens inside this body first
            full_end = body_start + end_m.end()
            replacement = _convert_one_case_body(body)
            expr = expr[:case_m.start()] + replacement + expr[full_end:]
            progressed = True
            break  # restart the scan against the newly-rewritten string
        if not progressed:
            break  # every remaining "case" is unmatched/malformed -- stop rather than loop forever
    return expr


def _convert_if(expr: str) -> str:
    """if (cond) then (a) [else (b)]  ->  IF(cond, a, b)"""
    def _repl(m):
        cond, then_val, else_val = m.group(1), m.group(2), m.group(3)
        cond = cond.strip()
        then_val = then_val.strip()
        if else_val is not None:
            return f"IF({cond}, {then_val}, {else_val.strip()})"
        return f"IF({cond}, {then_val})"

    pattern = (r'\bif\s*\(?(.*?)\)?\s+then\s*\(?(.*?)\)?'
               r'(?:\s+else\s*\(?(.*?)\)?)?(?=\s+if\b|\s*$)')
    # Process innermost/last IF first by repeated substitution to roughly
    # handle nesting; this is a pragmatic, non-recursive-descent approach.
    prev = None
    cur = expr
    guard = 0
    while prev != cur and guard < 25:
        prev = cur
        cur = re.sub(pattern, _repl, cur, count=1, flags=re.I | re.S)
        guard += 1
    return cur


def _convert_coalesce(expr: str) -> str:
    conv = re.sub(r'\bifnull\s*\(', 'COALESCE(', expr, flags=re.I)
    conv = re.sub(r'\bcoalesce\s*\(', 'COALESCE(', conv, flags=re.I)
    return conv


_AGG_KEYWORD_TO_DAX = {'total': 'SUM', 'average': 'AVERAGE', 'maximum': 'MAX',
                       'minimum': 'MIN', 'count-distinct': 'DISTINCTCOUNT', 'count': 'COUNT'}


def _convert_aggregations(expr: str, table_name: str) -> str:
    conv = expr

    # Context-qualified aggregation: FUNC(value) for (dim1, dim2, ...)
    # Cognos's "for" clause fixes the aggregation to a specific dimensional
    # context — the closest DAX equivalent is CALCULATE(..., ALLEXCEPT(...)).
    # This must run BEFORE the plain aggregate substitution below, since it
    # needs to see the original Cognos keyword together with its "for" tail.
    def _ctx_repl(m):
        kw, val, dims_raw = m.group(1).lower(), m.group(2), m.group(3)
        fn = _AGG_KEYWORD_TO_DAX.get(kw, 'SUM')
        dims = re.findall(r"'[^']+'\[[^\]]+\]", dims_raw)
        dims_str = ', '.join(dims) if dims else f"'{table_name}'"
        return f"CALCULATE({fn}({val}), ALLEXCEPT('{table_name}', {dims_str}))"

    conv = re.sub(
        r"\b(total|average|maximum|minimum|count-distinct|count)\s*\(\s*(.*?)\s+for\s+\(?((?:'[^']+'\[[^\]]+\]\s*,?\s*)+)\)?\s*\)",
        _ctx_repl, conv, flags=re.I)

    conv = re.sub(r'\btotal\s*\(', 'SUM(', conv, flags=re.I)
    conv = re.sub(r'\baverage\s*\(', 'AVERAGE(', conv, flags=re.I)
    conv = re.sub(r'\bmaximum\s*\(', 'MAX(', conv, flags=re.I)
    conv = re.sub(r'\bminimum\s*\(', 'MIN(', conv, flags=re.I)
    conv = re.sub(r'\bcount-distinct\s*\(', 'DISTINCTCOUNT(', conv, flags=re.I)
    conv = re.sub(r'\bcount\s*\(', 'COUNT(', conv, flags=re.I)
    conv = re.sub(
        r'\brunning-total\s*\((.*?)\)(?:\s+for\s+report)?',
        lambda m: f"CALCULATE(SUM({m.group(1)}), FILTER(ALLSELECTED('{table_name}'), "
                  f"'{table_name}'[__RowIndex__] <= EARLIER('{table_name}'[__RowIndex__])))",
        conv, flags=re.I)
    conv = re.sub(
        r'\brank\s*\((.*?)\)',
        lambda m: f"RANKX(ALLSELECTED('{table_name}'), {m.group(1)})",
        conv, flags=re.I)
    return conv


def _convert_date_functions(expr: str) -> str:
    conv = expr
    conv = re.sub(r'\b_add_days\s*\(\s*(.*?)\s*,\s*(.*?)\)', r'(\1 + \2)', conv, flags=re.I)
    conv = re.sub(r'\b_add_months\s*\(\s*(.*?)\s*,\s*(.*?)\)', r'EDATE(\1, \2)', conv, flags=re.I)
    conv = re.sub(r'\b_add_years\s*\(\s*(.*?)\s*,\s*(.*?)\)', r'EDATE(\1, (\2)*12)', conv, flags=re.I)
    conv = re.sub(r'\b_days_between\s*\(\s*(.*?)\s*,\s*(.*?)\)',
                 r'DATEDIFF(\2, \1, DAY)', conv, flags=re.I)
    conv = re.sub(r'\b_months_between\s*\(\s*(.*?)\s*,\s*(.*?)\)',
                 r'DATEDIFF(\2, \1, MONTH)', conv, flags=re.I)
    conv = re.sub(r'\b_years_between\s*\(\s*(.*?)\s*,\s*(.*?)\)',
                 r'DATEDIFF(\2, \1, YEAR)', conv, flags=re.I)
    conv = re.sub(r'\b_first_of_month\s*\(\s*(.*?)\)',
                 r'DATE(YEAR(\1), MONTH(\1), 1)', conv, flags=re.I)
    conv = re.sub(r'\b_last_of_month\s*\(\s*(.*?)\)',
                 r'EOMONTH(\1, 0)', conv, flags=re.I)
    conv = re.sub(r"\bextract\s*\(\s*year\s*,\s*(.*?)\)", r'YEAR(\1)', conv, flags=re.I)
    conv = re.sub(r"\bextract\s*\(\s*quarter\s*,\s*(.*?)\)", r'ROUNDUP(MONTH(\1)/3, 0)', conv, flags=re.I)
    conv = re.sub(r"\bextract\s*\(\s*month\s*,\s*(.*?)\)", r'MONTH(\1)', conv, flags=re.I)
    conv = re.sub(r"\bextract\s*\(\s*day\s*,\s*(.*?)\)", r'DAY(\1)', conv, flags=re.I)
    conv = re.sub(r'\bcurrent_date\b', 'TODAY()', conv, flags=re.I)
    conv = re.sub(r'\bcurrent_timestamp\b', 'NOW()', conv, flags=re.I)
    return conv


# ─────────────────────────────────────────────────────────────────────────────
# Table-driven function registry — the extensibility point requested for the
# conversion engine. Every entry here is a pure 1:1 name swap (Cognos
# function name -> DAX function name, same argument order/count), applied by
# a single generic pass instead of one hand-written regex per function.
# Adding support for a new Cognos function that maps this way going forward
# means adding ONE line here — nothing else in the pipeline changes.
# ─────────────────────────────────────────────────────────────────────────────
SIMPLE_FUNCTION_RENAMES = {
    'coalesce': 'COALESCE', 'nvl': 'COALESCE', 'ifnull': 'COALESCE',
    'abs': 'ABS', 'round': 'ROUND', 'mod': 'MOD', 'sqrt': 'SQRT', 'power': 'POWER',
    'upper': 'UPPER', 'uppercase': 'UPPER', 'lower': 'LOWER', 'lowercase': 'LOWER',
    'length': 'LEN', '_length': 'LEN',
    'sum': 'SUM', 'avg': 'AVERAGE', 'average': 'AVERAGE',
    'min': 'MIN', 'minimum': 'MIN', 'max': 'MAX', 'maximum': 'MAX',
    'isnull': 'ISBLANK',
}


def _apply_simple_function_renames(expr: str) -> str:
    """Apply every 1:1 name swap in SIMPLE_FUNCTION_RENAMES in one generic
    pass (case-insensitive, only when immediately followed by '(' so plain
    words in string literals or field names are never touched)."""
    conv = expr
    for cognos_name, dax_name in SIMPLE_FUNCTION_RENAMES.items():
        conv = re.sub(rf'\b{re.escape(cognos_name)}\s*\(', f'{dax_name}(', conv, flags=re.I)
    return conv


def _convert_not_isnull(expr: str) -> str:
    """'not isNull(x)' -> NOT(ISBLANK(x)); handled before the generic rename
    pass so the NOT wraps the fully-converted ISBLANK(...) call cleanly."""
    def _repl(m):
        return f'NOT(ISBLANK({m.group(1)}))'
    return re.sub(r'\bnot\s+isnull\s*\(\s*(.*?)\s*\)', _repl, expr, flags=re.I)


def _convert_count_distinct(expr: str) -> str:
    """count(distinct X) -> DISTINCTCOUNT(X); plain count(X) is handled by
    the generic rename pass (count -> COUNT)."""
    return re.sub(r'\bcount\s*\(\s*distinct\s+(.*?)\)', r'DISTINCTCOUNT(\1)', expr, flags=re.I)


def _convert_function_call_if(expr: str) -> str:
    """Cognos also supports SQL/function-call style IF(condition, a, b) —
    identical argument order to DAX's own IF(), so this is a case-only
    rename. Handled separately from the CASE/IF *macro* syntax
    ("if (x) then (y) else (z)") converted by _convert_if()."""
    return re.sub(r'\bif\s*\(', 'IF(', expr, flags=re.I)


def _convert_in_between_like(expr: str) -> str:
    """
    General-expression (scalar DAX) versions of IN / BETWEEN / LIKE — the
    report/visual *filter* JSON has its own equivalent conversion
    (build_pbi_filter_json); this is for the same operators appearing
    inside a calculated column/measure expression instead.
    """
    conv = expr
    # x BETWEEN a AND b  ->  (x >= a) && (x <= b)
    conv = re.sub(
        r'([\'"A-Za-z0-9_\[\].]+)\s+between\s+(.+?)\s+and\s+(.+?)(?=\s+and\b|\s+or\b|$|\))',
        r'(\1 >= \2 && \1 <= \3)', conv, flags=re.I)
    # x IN (a, b, c)  ->  x IN {a, b, c}   (native DAX IN-operator syntax)
    conv = re.sub(r'\bin\s*\(([^()]*)\)', lambda m: 'IN {' + m.group(1) + '}', conv, flags=re.I)
    # x LIKE '%text%'  ->  best-effort SEARCH()-based containment check
    def _like_repl(m):
        field, pattern = m.group(1), m.group(2)
        needle = pattern.strip('%')
        return f'(NOT ISERROR(SEARCH("{needle}", {field}, 1)))'
    conv = re.sub(r"([\'\"A-Za-z0-9_\[\].]+)\s+like\s+'([^']*)'", _like_repl, conv, flags=re.I)
    return conv


def _convert_string_functions(expr: str) -> str:
    conv = expr
    conv = re.sub(r'\bsubstring\s*\(\s*(.*?)\s*,\s*(.*?)\s*,\s*(.*?)\)',
                 r'MID(\1, \2, \3)', conv, flags=re.I)
    conv = re.sub(r'\b_length\s*\(\s*(.*?)\)', r'LEN(\1)', conv, flags=re.I)
    conv = re.sub(r'\b(l|r)?trim\s*\(\s*(.*?)\)', r'TRIM(\2)', conv, flags=re.I)
    conv = re.sub(r'\buppercase\s*\(\s*(.*?)\)', r'UPPER(\1)', conv, flags=re.I)
    conv = re.sub(r'\blowercase\s*\(\s*(.*?)\)', r'LOWER(\1)', conv, flags=re.I)
    # Cognos string concatenation operator '||' -> DAX '&'
    conv = conv.replace('||', ' & ')
    return conv


# Placeholder used in place of a literal '||' when _convert_logical_operators
# converts Cognos 'or' -> DAX logical-or. Using a plain '||' immediately
# would be indistinguishable, on a later/repeated pass, from genuine Cognos
# string-concatenation '||' -- which _convert_string_functions rewrites to
# '&'. Without this, converting the SAME (already-converted) expression a
# second time -- exactly what the Validation-2 retry in cognos_expr_to_dax
# does -- would silently corrupt a correct 'x || y' logical-or back into
# the wrong 'x & y' string-concatenation. Resolved back to a real '||' by
# _resolve_dax_or_placeholder() once, after every pipeline pass (including
# any retry) has finished running.
_DAX_OR_PLACEHOLDER = '__DAX_LOGICAL_OR_PLACEHOLDER__'


def _convert_logical_operators(expr: str) -> str:
    conv = expr
    conv = re.sub(r'\band\b', '&&', conv, flags=re.I)
    conv = re.sub(r'\bor\b', _DAX_OR_PLACEHOLDER, conv, flags=re.I)
    conv = re.sub(r'\bnot\b', 'NOT', conv, flags=re.I)
    return conv


def _resolve_dax_or_placeholder(expr: str) -> str:
    return expr.replace(_DAX_OR_PLACEHOLDER, '||')


def _convert_cast(expr: str) -> str:
    def _repl(m):
        inner, target = m.group(1), m.group(2).lower()
        if target in ('int', 'integer', 'bigint'):
            return f'INT({inner})'
        if target in ('decimal', 'numeric', 'float', 'double'):
            return f'VALUE({inner})'
        if target in ('date', 'timestamp'):
            return f'DATEVALUE({inner})'
        if target in ('varchar', 'char', 'string'):
            return f'FORMAT({inner}, "General")'
        return inner
    return re.sub(r'\bcast\s*\(\s*(.*?)\s+as\s+(\w+)\s*\)', _repl, expr, flags=re.I)


_LEFTOVER_CHECK_FUNCTIONS = [
    'total', 'maximum', 'minimum', 'count-distinct', 'running-total',
    'moving-average', 'percentage', '_add_days', '_add_months', '_add_years',
    '_days_between', '_first_of_month', '_last_of_month', '_make_timestamp',
    'extract', 'substring', '_length', 'ltrim', 'rtrim', 'uppercase',
    'lowercase', 'current_date', 'current_timestamp', 'cast', 'ifnull',
]


def _detect_leftover_functions(dax: str) -> list:
    found = []
    low = dax.lower()
    for fn in _LEFTOVER_CHECK_FUNCTIONS:
        if re.search(r'\b' + re.escape(fn) + r'\b', low):
            found.append(fn)
    return found


# ─────────────────────────────────────────────────────────────────────────────
# Tokenizer + validation — the "use parsing/tokenization where possible" and
# "validate every generated expression" requirements. Kept separate from the
# conversion passes above: conversion transforms text, validation inspects
# the *result* structurally rather than by more string substitution.
# ─────────────────────────────────────────────────────────────────────────────

_DAX_TOKEN_SPEC = [
    ('STRING', r'"(?:[^"]|"")*"'),
    ('TABLECOL', r"'[^']+'\[[^\]]+\]"),
    ('BLANKSTR', r"'(?:[^']|'')*'"),
    ('COL', r'\[[^\]]+\]'),
    ('NUMBER', r'\d+(\.\d+)?'),
    ('IDENT', r'[A-Za-z_][A-Za-z0-9_]*'),
    ('LPAREN', r'\('), ('RPAREN', r'\)'),
    ('LBRACE', r'\{'), ('RBRACE', r'\}'),
    ('COMMA', r','),
    ('OP', r'<>|>=|<=|&&|\|\||[+\-*/=<>&%]'),
    ('WS', r'\s+'),
]
_DAX_TOKEN_RE = re.compile('|'.join(f'(?P<{n}>{p})' for n, p in _DAX_TOKEN_SPEC))

# Known-good DAX function names -- used only to flag identifiers that are
# almost certainly an untranslated Cognos function (i.e. NOT a table/column
# name, NOT a recognized DAX function, but sitting directly in front of a
# '('), never to reject anything else. Extended with every function this
# engine itself emits, plus the common ones, so real conversions never
# self-flag.
_KNOWN_DAX_FUNCTIONS = {
    'if', 'switch', 'true', 'false', 'and', 'or', 'not', 'coalesce', 'isblank',
    'blank', 'sum', 'average', 'min', 'max', 'count', 'counta', 'countrows',
    'distinctcount', 'calculate', 'filter', 'allexcept', 'allselected', 'all',
    'related', 'relatedtable', 'rankx', 'sumx', 'averagex', 'minx', 'maxx',
    'today', 'now', 'date', 'datevalue', 'year', 'month', 'day', 'edate',
    'eomonth', 'datediff', 'mid', 'len', 'trim', 'upper', 'lower', 'left',
    'right', 'substitute', 'concatenate', 'format', 'value', 'int', 'abs',
    'round', 'roundup', 'rounddown', 'mod', 'sqrt', 'power', 'ln', 'log',
    'exp', 'search', 'iserror', 'iferror', 'divide', 'selectedvalue', 'values',
    'hasonevalue', 'firstdate', 'lastdate', 'totalytd', 'sameperiodlastyear',
    'dateadd',
}


def tokenize_dax_expression(expr: str) -> list:
    """Tokenize a (post-conversion) DAX-candidate expression. Whitespace
    tokens are dropped from the returned list; everything else is kept in
    document order as (kind, text) pairs."""
    tokens = []
    pos = 0
    while pos < len(expr):
        m = _DAX_TOKEN_RE.match(expr, pos)
        if not m:
            tokens.append(('UNKNOWN', expr[pos]))
            pos += 1
            continue
        kind = m.lastgroup
        if kind != 'WS':
            tokens.append((kind, m.group()))
        pos = m.end()
    return tokens


def validate_dax_expression(dax: str, table_name: str = None, valid_columns: set = None) -> list:
    """
    Validate a converted DAX expression. Returns a list of human-readable
    problems (empty list == valid). Checks:
      - balanced ( ) and { }
      - balanced quotes
      - every IDENT immediately followed by '(' is either a known DAX
        function or looks like a genuine table/measure reference -- anything
        else is flagged as a probable untranslated Cognos function
      - (when valid_columns is supplied) every 'Table'[Column] reference
        actually exists in the model
    """
    problems = []
    if not dax or not dax.strip():
        return problems

    depth_paren = 0
    depth_brace = 0
    for ch in dax:
        if ch == '(':
            depth_paren += 1
        elif ch == ')':
            depth_paren -= 1
            if depth_paren < 0:
                problems.append("Unbalanced parentheses: an extra ')' was found.")
                break
        elif ch == '{':
            depth_brace += 1
        elif ch == '}':
            depth_brace -= 1
            if depth_brace < 0:
                problems.append("Unbalanced braces: an extra '}' was found.")
                break
    if depth_paren > 0:
        problems.append(f"Unbalanced parentheses: {depth_paren} unclosed '('.")
    if depth_brace > 0:
        problems.append(f"Unbalanced braces: {depth_brace} unclosed '{{'.")
    if dax.count("'") % 2 != 0:
        problems.append("Unbalanced single quotes in expression.")
    else:
        for m in re.finditer(r"'[^']*'", dax):
            if dax[m.end():m.end() + 1] != '[':
                problems.append(
                    f"String literal {m.group(0)} uses single quotes -- DAX requires string "
                    f"literals to use double quotes (single quotes are reserved for table "
                    f"names); this would be misread as an unresolved table reference.")

    tokens = tokenize_dax_expression(dax)
    for i, (kind, text) in enumerate(tokens):
        if kind == 'IDENT' and i + 1 < len(tokens) and tokens[i + 1][0] == 'LPAREN':
            if text.lower() not in _KNOWN_DAX_FUNCTIONS:
                problems.append(f"Unrecognized function '{text}(...)' -- this looks like an "
                                f"untranslated Cognos function; manual review required.")
        if kind == 'TABLECOL' and valid_columns is not None:
            m = re.match(r"'([^']+)'\[([^\]]+)\]", text)
            if m and (m.group(1), m.group(2)) not in valid_columns and m.group(2) not in valid_columns:
                problems.append(f"Referenced column {text} was not found in the migrated data model.")
        if kind == 'UNKNOWN':
            problems.append(f"Unrecognized character '{text}' in generated DAX.")

    return problems


# ─────────────────────────────────────────────────────────────────────────────
# Final defence-in-depth: literal Cognos-only syntax must NEVER reach a
# generated .tmdl file, no matter which code path produced the string. This
# is deliberately independent of, and stricter than, validate_dax_expression
# (which checks that the DAX that IS there is well-formed) -- this instead
# checks that no raw, untranslated Cognos source text is hiding in there at
# all, even text that would otherwise tokenize "successfully" as a sequence
# of plain identifiers (a raw CASE/WHEN/END block does exactly that).
# ─────────────────────────────────────────────────────────────────────────────

_COGNOS_ONLY_KEYWORDS_RE = re.compile(r'\b(CASE|WHEN|THEN|ELSE|END|ROLLUP)\b', re.I)
_COGNOS_UNCONVERTED_FOR_CLAUSE_RE = re.compile(r'\)\s*\bfor\b\s*\(?', re.I)
_COGNOS_UNCONVERTED_TOTAL_RE = re.compile(r'\btotal\s*\(', re.I)
_COGNOS_UNCONVERTED_NVL_RE = re.compile(r'\bnvl\s*\(', re.I)
_COGNOS_UNCONVERTED_IFNULL_RE = re.compile(r'\bifnull\s*\(', re.I)
# Lower/mixed-case 'coalesce(' only -- upper-case 'COALESCE(' is valid DAX
# and is exactly what a correctly-converted Cognos coalesce()/nvl()/ifnull()
# call looks like; flagging it too would reject good output.
_COGNOS_UNCONVERTED_COALESCE_RE = re.compile(r'\bcoalesce\s*\(')
_COGNOS_UNCONVERTED_IN_SET_RE = re.compile(r'\bin\s*\((?!\s*\{)', re.I)


def validate_no_cognos_syntax(expression: str) -> list:
    """
    Scan an expression that is about to be written into TMDL as a
    calculated-column or measure body for any literal Cognos-only syntax.
    Returns a list of human-readable problems; an empty list means the
    expression contains no detectable raw Cognos source and is safe to
    write. Called:
      - immediately after every cognos_expr_to_dax() conversion attempt
        (Validation 1/2/3 in the translation pipeline), and
      - again, as a whole-file safety net, on every fully-rendered .tmdl
        file text immediately before it is written (Validation 4, in
        _validate_and_write_tmdl) -- so even a future code path that
        builds a calculated column/measure without going through
        cognos_expr_to_dax at all is still caught before anything reaches
        disk.

    Double-quoted DAX string literals are blanked out before scanning so a
    legitimate value such as "End of Year" or "Case Number" can never
    trigger a false positive.
    """
    if not expression:
        return []
    scan_text = re.sub(r'"[^"]*"', '""', expression)

    problems = []
    kw_hits = _COGNOS_ONLY_KEYWORDS_RE.findall(scan_text)
    if kw_hits:
        found = sorted({k.upper() for k in kw_hits})
        problems.append(
            f"Untranslated Cognos keyword(s) found: {', '.join(found)}. "
            f"This expression was not fully converted to DAX and must not be written to TMDL.")
    if _COGNOS_UNCONVERTED_FOR_CLAUSE_RE.search(scan_text):
        problems.append("Untranslated Cognos context-modifier clause ('for (...)') found.")
    if _COGNOS_UNCONVERTED_TOTAL_RE.search(scan_text):
        problems.append("Untranslated Cognos aggregate function 'total(' found (should be SUM(...)).")
    if _COGNOS_UNCONVERTED_NVL_RE.search(scan_text):
        problems.append("Untranslated Cognos function 'nvl(' found (should be COALESCE(...)).")
    if _COGNOS_UNCONVERTED_IFNULL_RE.search(scan_text):
        problems.append("Untranslated Cognos function 'ifnull(' found (should be COALESCE(...)).")
    if _COGNOS_UNCONVERTED_COALESCE_RE.search(scan_text):
        problems.append(
            "Lower/mixed-case 'coalesce(' found -- DAX's COALESCE must be upper-case; "
            "this looks like the raw Cognos call was never normalized.")
    if _COGNOS_UNCONVERTED_IN_SET_RE.search(scan_text):
        problems.append("Untranslated Cognos 'IN (...)' set found (DAX requires 'IN {...}').")
    return problems


def translate_string_literals(dax: str) -> str:
    """
    Convert every Cognos-style single-quoted string literal ('Low Salary')
    remaining in an already-converted DAX expression into a valid DAX
    double-quoted literal ("Low Salary") -- DAX uses single quotes
    exclusively for table names and double quotes exclusively for string
    literals; Cognos uses single quotes for string literals, so a literal
    carried straight through from the source expression is misinterpreted
    by Power BI as a reference to a table that doesn't exist, rather than
    as text, unless it's converted.

    Must run AFTER every field-reference substitution (which is what
    introduces the legitimate 'Table'[Column] single-quote patterns into
    the expression) — by that point every single-quoted segment is either
    a real table reference (immediately followed by '[') or a leftover
    string literal (not followed by '['), distinguished with a manual
    left-to-right scan (not a single regex with a lookahead: quote-pairs
    sitting right next to each other, e.g. 'EMP'[X] < 1, 'Low Salary', can
    make a lookahead-based regex resync on the wrong quote after skipping
    a rejected table-reference match, corrupting everything after it).
    """
    if "'" not in dax:
        return dax
    out = []
    i, n = 0, len(dax)
    while i < n:
        ch = dax[i]
        if ch != "'":
            out.append(ch)
            i += 1
            continue
        close = dax.find("'", i + 1)
        if close == -1:
            out.append(dax[i:])  # unbalanced trailing quote -- pass through
            break
        next_char = dax[close + 1] if close + 1 < n else ''
        if next_char == '[':
            out.append(dax[i:close + 1])  # legitimate 'Table'[Column] ref
        else:
            out.append(f'"{dax[i + 1:close]}"')  # string literal
        i = close + 1
    return ''.join(out)


def cognos_expr_to_dax(expression: str, table_name: str,
                        col_name_map: dict = None, item_name: str = '',
                        valid_columns: set = None, measure_names: set = None) -> dict:
    """
    Convert one Cognos data-item expression into DAX.

    Returns:
        {
          'dax': str,
          'functions': list[str]   (Cognos functions detected in the source),
          'confidence': 'high' | 'medium' | 'low',
          'status': 'Converted' | 'Converted with warnings' | 'Failed',
          'validation': 'Passed' | 'Passed with warnings' | 'Failed',
          'validation_problems': list[str],
          'warnings': list[str]
        }
    """
    warnings = []
    label = f" [{item_name}]" if item_name else ""
    if not expression or not expression.strip():
        return {'dax': 'BLANK()', 'functions': [], 'confidence': 'high',
               'status': 'Converted', 'validation': 'Passed',
               'validation_problems': [], 'warnings': []}

    log('info', f"Extracting Cognos calculation...{label}")
    log('info', f"Parsing Cognos expression...{label}")
    functions = _detect_cognos_functions(expression)

    def _run_pipeline(text: str) -> str:
        """One full pass of every conversion step, in order. Idempotent on
        already-converted DAX (every step's regex only matches Cognos-shaped
        source syntax) — safe to call a second time on partially-converted
        output, which is exactly what the Validation-2 retry below does."""
        out = text
        out = _strip_field_refs(out, table_name, col_name_map, measure_names)
        out = _convert_cast(out)
        out = _convert_not_isnull(out)
        out = _convert_count_distinct(out)
        out = _convert_case(out)
        out = _convert_if(out)
        out = _convert_function_call_if(out)
        out = _convert_coalesce(out)
        out = _convert_aggregations(out, table_name)
        out = _convert_date_functions(out)
        out = _convert_string_functions(out)
        out = _convert_in_between_like(out)
        out = _apply_simple_function_renames(out)
        out = _convert_logical_operators(out)
        out = translate_string_literals(out)
        out = re.sub(r'<>', '<>', out)   # Cognos and DAX both use <> for "not equal"
        return out.strip()

    def _has_unconverted_syntax(text: str) -> list:
        """Validation 1 + 5: does this candidate DAX string still contain
        any literal, untranslated Cognos syntax? Combines the raw keyword
        scan (validate_no_cognos_syntax) with the pre-existing "for"-clause
        heuristic so every known failure shape is covered in one place."""
        problems = validate_no_cognos_syntax(text)
        if not problems and re.search(r"\)\s+for\s+\(?'", text):
            problems = ["Unrecognized Cognos context-modifier clause ('for'/'in') "
                       "could not be translated."]
        return problems

    log('info', f"Converting expression to DAX...{label}")
    dax = _run_pipeline(expression)
    conv_problems = _has_unconverted_syntax(dax)

    # ── Validation 2: conversion failed -> attempt another conversion pass ──
    # A second full pass over the CURRENT (partially-converted) string lets
    # constructs that only become isolated/visible after the first pass
    # (e.g. a CASE that was nested inside an IF's THEN branch) get picked up
    # on this pass instead of being permanently missed.
    retried = False
    if conv_problems:
        retried = True
        log('info', f"Initial conversion left untranslated Cognos syntax; retrying...{label}")
        dax = _run_pipeline(dax)
        conv_problems = _has_unconverted_syntax(dax)

    # Resolve the '||' placeholder back to real DAX '||' exactly once, now
    # that every pipeline pass (initial + any retry) is finished — see
    # _DAX_OR_PLACEHOLDER for why this can't just be a literal '||' during
    # the passes themselves.
    dax = _resolve_dax_or_placeholder(dax)

    unresolved_control = bool(conv_problems)
    for p in conv_problems:
        warnings.append(p)

    # Confidence heuristic: if any raw Cognos-only tokens remain untouched,
    # flag medium/low confidence so it's easy to find in the audit doc.
    leftover_fns = _detect_leftover_functions(dax)
    if unresolved_control:
        confidence = 'low'
    elif leftover_fns:
        confidence = 'medium'
        warnings.append(f"Unconverted Cognos function(s) remain: {', '.join(leftover_fns)}")
    else:
        confidence = 'high'

    # ── Validation 3: still failing after the retry -> BLANK(), never the
    # original Cognos text. The raw expression goes ONLY into the log/audit
    # trail, never into the string that gets written to TMDL. (This replaces
    # the previous behaviour of wrapping the raw expression in a DAX
    # comment, e.g. "/* CASE WHEN ... END */ BLANK()" -- a comment is still
    # literal text inside the .tmdl file, and is exactly what produced the
    # "keyword CASE is neither a property nor an object" parse error.)
    if unresolved_control:
        log('warn', f"Unable to convert Cognos expression for calculated column/measure "
                    f"'{item_name or '(unnamed)'}'. Original expression: {expression}")
        dax = "BLANK()"

    log('info', f"Validating DAX syntax...{label}")
    validation_problems = [] if unresolved_control else validate_dax_expression(dax, table_name, valid_columns)
    for p in validation_problems:
        if 'Unrecognized function' in p:
            log('warn', f"Unsupported Cognos function detected.{label} {p}")
        else:
            log('warn', f"DAX validation issue.{label} {p}")

    if unresolved_control:
        status = 'Failed'
    elif validation_problems or leftover_fns:
        status = 'Converted with warnings'
    else:
        status = 'Converted'
    validation_status = 'Failed' if unresolved_control else ('Passed with warnings' if validation_problems else 'Passed')

    if status == 'Converted':
        log('info', f"Expression converted successfully.{label}"
                    + (" (on retry)" if retried else ""))

    return {'dax': dax, 'functions': functions, 'confidence': confidence,
           'status': status, 'validation': validation_status,
           'validation_problems': validation_problems, 'warnings': warnings}


# ═══════════════════════════════════════════════════════════════════════════
# Cognos Formula Translation Engine — public, reusable API
#
# Every name below is a thin, documented entry point onto the conversion
# pipeline above (already exercised end-to-end by cognos_expr_to_dax, and
# already covered by validate_dax_expression) — metadata-driven and
# generic: none of them hardcode a formula, table, or column name. They
# exist so callers (and future maintainers) have one clearly-named function
# per translation concern instead of needing to know the internal
# conversion pipeline's private helper names.
# ═══════════════════════════════════════════════════════════════════════════

def translate_cognos_expression(expression: str, table_name: str, col_name_map: dict = None,
                                item_name: str = '', valid_columns: set = None,
                                measure_names: set = None) -> dict:
    """Top-level entry point: translate one Cognos expression (from either
    model.xml or report.xml) into a validated DAX expression. Identical to
    cognos_expr_to_dax — kept as the public name this engine is documented
    under; cognos_expr_to_dax remains available for existing call sites."""
    return cognos_expr_to_dax(expression, table_name, col_name_map, item_name,
                              valid_columns, measure_names)


# translate_expression_tree: the engine has no separate AST/tree structure
# to walk -- expression translation is done via a fixed, ordered sequence
# of pattern-based passes (each responsible for one Cognos construct:
# CASE, IF, aggregates, string/date functions, boolean operators, ...),
# which already correctly handles arbitrarily nested expressions because
# each pass operates on whatever the previous pass produced. This alias
# exists so "walk and translate the whole expression" has an explicit name.
translate_expression_tree = translate_cognos_expression


def translate_case_to_switch(expr: str) -> str:
    """CASE [WHEN a THEN b]+ [ELSE c] END  ->  SWITCH(TRUE(), a, b, ..., c)."""
    return _convert_case(expr)


def translate_if(expr: str) -> str:
    """if (cond) then (a) [else (b)]  ->  IF(cond, a, b)."""
    return _convert_if(expr)


def translate_boolean_expression(expr: str) -> str:
    """Cognos AND/OR/NOT  ->  DAX &&/||/NOT()."""
    return _convert_logical_operators(expr)


def translate_functions(expr: str) -> str:
    """Rename Cognos scalar functions to their direct DAX equivalents
    (e.g. Trim -> TRIM, Uppercase -> UPPER)."""
    return _apply_simple_function_renames(expr)


def translate_aggregations(expr: str, table_name: str) -> str:
    """Cognos aggregate functions (total(), average(), ...)  ->  DAX
    aggregations (SUM(), AVERAGE(), ...) scoped to table_name."""
    return _convert_aggregations(expr, table_name)


def translate_date_functions(expr: str) -> str:
    """Cognos date/time functions  ->  their DAX equivalents."""
    return _convert_date_functions(expr)


def translate_numeric_functions(expr: str) -> str:
    """Cognos numeric/type-cast functions (cast(x as decimal), ...)  ->
    their DAX equivalents. Plain arithmetic (+ - * /) needs no translation
    at all -- Cognos and DAX share that syntax already."""
    return _convert_cast(expr)


def normalize_identifiers(expr: str, table_name: str, col_name_map: dict = None,
                          measure_names: set = None) -> str:
    """Resolve every Cognos [Table].[Column] / [Column] bracket reference
    in expr into a DAX 'Table'[Column] (or bare measure name) reference,
    using table_name as the default table for unqualified references."""
    return _strip_field_refs(expr, table_name, col_name_map, measure_names)


def convert_model_formula(item: dict, table_name: str, col_name_map: dict = None,
                          valid_columns: set = None, measure_names: set = None) -> dict:
    """
    Translate one Framework Manager calculated query item (a dict as
    produced by _fm_parse_query_item, i.e. {name, expression, is_calculated,
    ...}) into DAX. Only meaningful for items where is_calculated is True;
    plain passthrough columns have nothing to translate and are returned
    with their expression untouched.
    """
    if not item.get('is_calculated'):
        return {'dax': item.get('expression', ''), 'functions': [], 'confidence': 'high',
               'status': 'Not applicable (plain column)', 'validation': 'Passed',
               'validation_problems': [], 'warnings': []}
    return cognos_expr_to_dax(item['expression'], table_name, col_name_map,
                              item_name=item.get('name', ''),
                              valid_columns=valid_columns, measure_names=measure_names)


def convert_report_formula(data_item: dict, table_name: str, col_name_map: dict = None,
                           valid_columns: set = None, measure_names: set = None) -> dict:
    """
    Translate one report.xml-level calculation into DAX — a calculated
    dataItem, a filter expression, a sort-by expression, or any other
    report-authored formula (as opposed to one defined in the Framework
    Manager package). Same underlying engine as convert_model_formula;
    kept as a separate named entry point since report-level and
    model-level formulas come from different source documents and are
    reported separately in the migration log/audit trail.
    """
    expression = data_item.get('expression', '') if isinstance(data_item, dict) else str(data_item)
    item_name = data_item.get('name', '') if isinstance(data_item, dict) else ''
    return cognos_expr_to_dax(expression, table_name, col_name_map, item_name=item_name,
                              valid_columns=valid_columns, measure_names=measure_names)


def discover_calculated_fields(fm_report: dict = None, report_report: dict = None) -> list:
    """
    Scan both already-parsed Cognos structures (fm_report from
    parse_cognos_report() on model.xml, report_report from the same on
    report.xml) and return every calculated field found in either one, for
    the migration audit trail — "log the conversion in the migration
    report" per the formula-translation requirements. Does not itself
    translate anything (that's convert_model_formula/convert_report_formula
    /cognos_expr_to_dax); this only discovers and catalogs what exists.

    Returns a list of:
        {'source': 'model.xml' | 'report.xml', 'table': str, 'name': str,
         'expression': str, 'kind': 'calculated_column' | 'measure'}
    """
    discovered = []
    for source_label, report in (('model.xml', fm_report), ('report.xml', report_report)):
        if not report:
            continue
        for q in report.get('queries', []):
            for item in q.get('items', []):
                if not item.get('is_calculated'):
                    continue
                kind = 'measure' if item.get('aggregate') else 'calculated_column'
                discovered.append({
                    'source': source_label, 'table': q['name'], 'name': item['name'],
                    'expression': item.get('expression', ''), 'kind': kind,
                })
    for entry in discovered:
        log('info', f"Discovered {entry['kind']} '{entry['name']}' on table "
                    f"'{entry['table']}' in {entry['source']}.")
    return discovered


# ─────────────────────────────────────────────────────────────────────────────
# Filters — report-level, page-level, and visual-level
# ─────────────────────────────────────────────────────────────────────────────
#
# Cognos filter expressions are SQL-flavoured boolean conditions, e.g.:
#   [Region] = 'West'
#   [Status] <> 'Cancelled'
#   [Category] in ('A', 'B', 'C')
#   [OrderDate] between #2024-01-01# and #2024-12-31#
#   [Name] like '%Corp%'
#   [Revenue] > 10000
#
# Each is parsed into a structured condition (field/operator/values) and
# converted into a Power BI report-filter JSON object, applied at whichever
# scope it was found: a query's own detailFilters become report-level
# filters; a filter embedded directly inside one layout object (list,
# crosstab, chart) becomes a filter on that one visual only.

_FILTER_OPERATOR_PATTERNS = [
    (re.compile(r"^\[?([\w .]+?)\]?\s+between\s+(.+?)\s+and\s+(.+)$", re.I), 'BETWEEN'),
    (re.compile(r"^\[?([\w .]+?)\]?\s+not\s+in\s*\((.+)\)$", re.I), 'NOT IN'),
    (re.compile(r"^\[?([\w .]+?)\]?\s+in\s*\((.+)\)$", re.I), 'IN'),
    (re.compile(r"^\[?([\w .]+?)\]?\s+not\s+like\s+(.+)$", re.I), 'NOT LIKE'),
    (re.compile(r"^\[?([\w .]+?)\]?\s+like\s+(.+)$", re.I), 'LIKE'),
    (re.compile(r"^\[?([\w .]+?)\]?\s*<>\s*(.+)$"), '<>'),
    (re.compile(r"^\[?([\w .]+?)\]?\s*!=\s*(.+)$"), '<>'),
    (re.compile(r"^\[?([\w .]+?)\]?\s*>=\s*(.+)$"), '>='),
    (re.compile(r"^\[?([\w .]+?)\]?\s*<=\s*(.+)$"), '<='),
    (re.compile(r"^\[?([\w .]+?)\]?\s*>\s*(.+)$"), '>'),
    (re.compile(r"^\[?([\w .]+?)\]?\s*<\s*(.+)$"), '<'),
    (re.compile(r"^\[?([\w .]+?)\]?\s*=\s*(.+)$"), '='),
]


def _strip_quotes(v: str) -> str:
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
        return v[1:-1]
    if len(v) >= 2 and v[0] == '#' and v[-1] == '#':
        return v[1:-1]
    return v


def _split_top_level_and(expr: str) -> list:
    """Split a Cognos filter expression on top-level ' and ' — not inside
    quotes, parentheses, or a BETWEEN...AND...  clause (whose own "and" is
    not a conjunction between two conditions). OR-combined conditions are
    left as one unsplit clause (advanced boolean filters aren't decomposed
    further; they're still preserved as a single filter's textual
    condition rather than dropped)."""
    parts = []
    depth = 0
    in_quote = None
    buf = []
    pending_between = 0   # counts BETWEEN clauses whose connecting AND is still due
    i = 0
    while i < len(expr):
        ch = expr[i]
        if in_quote:
            buf.append(ch)
            if ch == in_quote:
                in_quote = None
            i += 1
            continue
        if ch in ("'", '"'):
            in_quote = ch
            buf.append(ch)
            i += 1
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if depth == 0 and expr[i:i + 8].lower() == 'between ':
            pending_between += 1
        if depth == 0 and expr[i:i + 5].lower() == ' and ':
            if pending_between > 0:
                pending_between -= 1
                buf.append(ch)
                i += 1
                continue
            parts.append(''.join(buf))
            buf = []
            i += 5
            continue
        buf.append(ch)
        i += 1
    if buf:
        parts.append(''.join(buf))
    return [p.strip() for p in parts if p.strip()]


def parse_filter_expression(expr: str) -> list:
    """
    Parse one Cognos filter expression (which may be several AND-joined
    conditions) into a list of structured conditions:
        [{'field': 'Region', 'operator': '=', 'values': ['West']}, ...]
    Returns [] if nothing could be confidently parsed (the raw text is
    still preserved elsewhere for documentation purposes even then).
    """
    conditions = []
    for clause in _split_top_level_and(expr or ''):
        matched = False
        for pattern, op in _FILTER_OPERATOR_PATTERNS:
            m = pattern.match(clause.strip())
            if not m:
                continue
            field = re.sub(r'^\[?([^\[\]]+?)\]?\.\[?([^\[\]]+?)\]?$', r'\2', m.group(1).strip())
            field = field.strip('[]').strip()
            if op == 'BETWEEN':
                values = [_strip_quotes(m.group(2)), _strip_quotes(m.group(3))]
            elif op in ('IN', 'NOT IN'):
                values = [_strip_quotes(v) for v in re.split(r',(?=(?:[^\']*\'[^\']*\')*[^\']*$)', m.group(2))]
            else:
                values = [_strip_quotes(m.group(2))]
            conditions.append({'field': field, 'operator': op, 'values': values})
            matched = True
            break
        if not matched and clause.strip():
            conditions.append({'field': None, 'operator': 'RAW', 'values': [clause.strip()]})
    return conditions


_FILTER_COMPARISON_KIND = {'=': 0, '>': 1, '>=': 2, '<': 3, '<=': 4}


def _filter_literal(v: str) -> str:
    try:
        float(v)
        return v
    except ValueError:
        return "'" + v.replace("'", "''") + "'"


def build_pbi_filter_json(condition: dict, table_name: str, col_name_map: dict = None):
    """
    Convert one structured filter condition into a Power BI report-filter
    JSON object (the schema used for the 'filters' property found on the
    report, a page/section, and each individual visual container).
    Returns None for conditions that couldn't be confidently translated
    (e.g. a raw/OR-combined clause) rather than emitting something wrong.
    """
    field = condition.get('field')
    if not field:
        return None
    col_name_map = col_name_map or {}
    column = col_name_map.get(field, field)
    op = condition['operator']
    values = condition['values']
    col_ref = {"Column": {"Expression": {"SourceRef": {"Source": "t"}}, "Property": column}}
    from_clause = [{"Name": "t", "Entity": table_name, "Type": 0}]

    if op in _FILTER_COMPARISON_KIND:
        where_expr = {"Comparison": {"ComparisonKind": _FILTER_COMPARISON_KIND[op],
                                     "Left": col_ref, "Right": {"Literal": {"Value": _filter_literal(values[0])}}}}
    elif op == '<>':
        where_expr = {"Not": {"Expression": {"Comparison": {
            "ComparisonKind": 0, "Left": col_ref,
            "Right": {"Literal": {"Value": _filter_literal(values[0])}}}}}}
    elif op == 'BETWEEN':
        where_expr = {"And": {
            "Left": {"Comparison": {"ComparisonKind": 2, "Left": col_ref,
                                    "Right": {"Literal": {"Value": _filter_literal(values[0])}}}},
            "Right": {"Comparison": {"ComparisonKind": 4, "Left": col_ref,
                                     "Right": {"Literal": {"Value": _filter_literal(values[1])}}}}}}
    elif op in ('IN', 'NOT IN'):
        in_expr = {"In": {"Expressions": [col_ref],
                          "Values": [[{"Literal": {"Value": _filter_literal(v)}}] for v in values]}}
        where_expr = {"Not": {"Expression": in_expr}} if op == 'NOT IN' else in_expr
    elif op in ('LIKE', 'NOT LIKE'):
        pattern = values[0]
        fn = 'Contains'
        needle = pattern.strip('%')
        if pattern.startswith('%') and not pattern.endswith('%'):
            fn = 'EndsWith'
        elif pattern.endswith('%') and not pattern.startswith('%'):
            fn = 'StartsWith'
        contains_expr = {fn: {"Left": col_ref, "Right": {"Literal": {"Value": _filter_literal(needle)}}}}
        where_expr = {"Not": {"Expression": contains_expr}} if op == 'NOT LIKE' else contains_expr
    else:
        return None

    return {
        "name": _guid(),
        "expression": col_ref["Column"],
        "type": "Advanced",
        "filterType": 1,
        "howCreated": 2,
        "filter": {
            "Version": 2,
            "From": from_clause,
            "Where": [{"Condition": where_expr}],
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Power BI data model (DataModelSchema) builder
# ─────────────────────────────────────────────────────────────────────────────

_AGG_TO_DAX_FN = {
    'total': 'SUM', 'sum': 'SUM',
    'average': 'AVERAGE', 'avg': 'AVERAGE',
    'maximum': 'MAX', 'max': 'MAX',
    'minimum': 'MIN', 'min': 'MIN',
    'count': 'COUNT', 'count-distinct': 'DISTINCTCOUNT',
}

# When an aggregate wraps a genuine row-level expression (e.g.
# total([Quantity] * [UnitPrice])) rather than a single plain field, DAX
# needs the row-context ITERATOR form -- SUM(<expr>) is not valid/meaningful
# over a multi-column expression the way SUMX(<table>, <expr>) is.
_AGG_TO_DAX_ITERATOR = {
    'SUM': 'SUMX', 'AVERAGE': 'AVERAGEX', 'MIN': 'MINX', 'MAX': 'MAXX',
}


def _ensure_referenced_fields_exist(expression: str, col_name_map: dict, seen_field_names: set,
                                    pbi_columns: list, table_measure_names: set = None) -> None:
    """
    Scan an expression for bracket-chain field references and auto-create a
    hidden numeric base column for any final segment that doesn't already
    resolve to a known column or measure — e.g. a business-layer calculated
    item like [Quantity] * [UnitPrice] where UnitPrice isn't separately
    exposed as its own query item on this query subject. Without this, the
    generated DAX would reference a column that was never actually created,
    which is exactly the class of "syntax error" this engine exists to
    prevent. Mutates col_name_map / seen_field_names / pbi_columns in place.
    """
    table_measure_names = table_measure_names or set()
    for full in re.findall(r'(?:\[[^\[\]]+\]\.)*\[[^\[\]]+\]', expression or ''):
        segments = re.findall(r'\[([^\[\]]+)\]', full)
        item = segments[-1] if segments else full
        if item in col_name_map and col_name_map[item] not in (None, ''):
            continue
        if item.lower() in seen_field_names:
            continue
        new_col = _unique_name(item, seen_field_names, case_insensitive=True)
        col_name_map[item] = new_col
        pbi_columns.append(_build_data_column(new_col, "double", source_column=new_col, is_hidden=True))


def _is_plain_field_ref(expression: str) -> bool:
    return bool(re.match(r'^\s*(?:\[[^\[\]]+\]\.)*\[[^\[\]]+\]\s*$', expression or ''))


def _m_type_literal(datatype: str) -> str:
    """M (Power Query) type literal for Table.TransformColumnTypes."""
    return {
        'int64': 'Int64.Type', 'double': 'type number', 'string': 'type text',
        'date': 'type date', 'dateTime': 'type datetime', 'boolean': 'type logical',
    }.get(datatype, 'type text')


def _m_path_literal(path: Path) -> str:
    return str(path).replace('"', '""')


def find_source_data_file(source_data_folder, table_name: str, query_name: str):
    """
    Look for a real data file to back one converted table, so the PBIT can
    read live data on refresh instead of synthetic/embedded sample rows.

    Matches <folder>/<name>.<ext> case-insensitively against BOTH the final
    Power BI table name and the original Cognos query name, trying
    CSV/text before Excel. Returns (kind, Path) or (None, None).
    """
    if not source_data_folder:
        return None, None
    folder = Path(source_data_folder)
    if not folder.is_dir():
        return None, None
    candidate_names = {table_name.lower(), query_name.lower()}
    for f in sorted(folder.iterdir()):
        if not f.is_file() or f.stem.lower() not in candidate_names:
            continue
        ext = f.suffix.lower()
        if ext in ('.csv', '.txt', '.tsv'):
            return 'csv', f.resolve()
        if ext in ('.xlsx', '.xlsm', '.xls'):
            return 'excel', f.resolve()
    return None, None


def _build_csv_backed_m_query(columns: list, file_path: Path) -> str:
    delim = '\\t' if file_path.suffix.lower() == '.tsv' else ','
    type_pairs = ', '.join(
        '{"%s", %s}' % (_m_str(c['name']), _m_type_literal(c['datatype'])) for c in columns)
    # Step names and defaults (Encoding=1252, QuoteStyle=QuoteStyle.None,
    # #"Promoted Headers" as the step name) match exactly what Power BI
    # Desktop itself generates for a CSV import, confirmed via direct
    # comparison against a working PBIP.
    return '\n'.join([
        'let',
        f'    Source = Csv.Document(File.Contents("{_m_path_literal(file_path)}"),[Delimiter="{delim}", '
        f'Columns={len(columns)}, Encoding=1252, QuoteStyle=QuoteStyle.None]),',
        '    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
        f'    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{{type_pairs}}})',
        'in',
        '    #"Changed Type"',
    ])


def _build_excel_backed_m_query(columns: list, file_path: Path) -> str:
    type_pairs = ', '.join(
        '{"%s", %s}' % (_m_str(c['name']), _m_type_literal(c['datatype'])) for c in columns)
    return '\n'.join([
        'let',
        f'    Source = Excel.Workbook(File.Contents("{_m_path_literal(file_path)}"), null, true),',
        '    Sheet0 = Source{0}[Data],',
        '    #"Promoted Headers" = Table.PromoteHeaders(Sheet0, [PromoteAllScalars=true]),',
        f'    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{{type_pairs}}})',
        'in',
        '    #"Changed Type"',
    ])


def _build_embedded_m_query(table_name: str, columns: list, records: list) -> str:
    """Self-contained M query embedding exact extracted rows (#table literal)."""
    NL = "\n"
    type_header = ', '.join(_m_col_name_type(c['name'], c['datatype']) for c in columns)
    row_strs = []
    for rec in records:
        vals = []
        for c in columns:
            v = rec.get(c['name'])
            vals.append(_m_literal(v, c['datatype']))
        row_strs.append('            {' + ', '.join(vals) + '}')
    body = (',' + NL).join(row_strs) if row_strs else ''
    return NL.join([
        'let',
        f'    /* {len(records)} row(s) extracted directly from the Cognos report output */',
        '    Source = #table(',
        '        type table [' + type_header + '],',
        '        {',
        body,
        '        }',
        '    )',
        'in',
        '    Source',
    ])


def _m_literal(value, datatype: str) -> str:
    if value is None or value == '':
        return 'null'
    s = str(value).strip()
    if datatype == 'double':
        cleaned = s.replace(',', '').replace('%', '').replace('$', '')
        try:
            return str(float(cleaned))
        except ValueError:
            return 'null'
    if datatype == 'int64':
        try:
            return str(int(float(s.replace(',', ''))))
        except ValueError:
            return 'null'
    if datatype == 'boolean':
        return 'true' if s.lower() in ('true', 'yes', '1') else 'false'
    if datatype == 'dateTime':
        m = re.match(r'^(\d{1,4})[-/](\d{1,2})[-/](\d{1,4})', s)
        if m:
            a, b, c = m.groups()
            a_i, b_i, c_i = int(a), int(b), int(c)
            if len(a) == 4:
                y, mo, d = a_i, b_i, c_i
            elif len(c) == 4:
                # Ambiguous DD-MM-YYYY vs MM-DD-YYYY. Whichever of the first
                # two segments is > 12 cannot be a month, so it must be the
                # day. If both are <= 12 the format is genuinely ambiguous;
                # default to day-first (DD-MM-YYYY), which is both the more
                # common convention outside the US and the format seen in
                # real Cognos exports (e.g. expressionLocale="en-gb").
                if a_i > 12 >= b_i:
                    d, mo, y = a_i, b_i, c_i
                elif b_i > 12 >= a_i:
                    mo, d, y = a_i, b_i, c_i
                else:
                    d, mo, y = a_i, b_i, c_i
            else:
                y, mo, d = a_i, b_i, c_i
            try:
                import datetime as _dt
                _dt.date(y, mo, d)   # raises ValueError for an impossible date
                return f'#datetime({y},{mo},{d},0,0,0)'
            except (ValueError, TypeError):
                return 'null'
        return 'null'
    return '"' + s.replace('"', '""') + '"'


def _build_synthetic_m_query(table_name: str, columns: list, num_rows: int = 8) -> str:
    NL = "\n"
    type_header = ', '.join(_m_col_name_type(c['name'], c['datatype']) for c in columns)
    rows = []
    for row_idx in range(num_rows):
        vals = [_m_sample_value(c['name'], c['datatype'], row_idx) for c in columns]
        rows.append('            {' + ', '.join(vals) + '}')
    body = (',' + NL).join(rows)
    return NL.join([
        'let',
        f'    /* {num_rows} synthetic sample rows — no exact source data was',
        f'       available for this table (bare report specification without',
        f'       embedded output). Replace this partition with a live query',
        f'       against the source system after import. */',
        '    Source = #table(',
        '        type table [' + type_header + '],',
        '        {',
        body,
        '        }',
        '    )',
        'in',
        '    Source',
    ])


def _materialize_table_csv(output_dir: Path, table_name: str, columns: list,
                           records: list = None, synthetic_rows: int = 8) -> Path:
    """
    Write an actual CSV file to disk for one table and return its path.

    This exists so every generated table is backed by a REAL, external data
    source (a file Power BI Desktop can see, track in Data Source Settings,
    and let the user swap out) instead of an in-memory #table() literal —
    Power BI only ever populates "Data Source Settings" for M queries that
    call a genuine data-source function like Csv.Document/File.Contents, so
    a literal-only model always shows that dialog as empty, by design.

    If `records` (exact extracted/embedded rows) are available they're used
    as-is; otherwise representative synthetic sample rows are generated so
    the file — and therefore the report — is never empty, and is trivially
    replaceable by the user afterwards.
    """
    import csv as _csv
    data_dir = output_dir / "data_sources"
    data_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r'[^A-Za-z0-9_-]', '_', table_name)[:80] or 'Table'
    csv_path = (data_dir / f"{safe_name}.csv").resolve()

    col_names = [c['name'] for c in columns]
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as fh:
        writer = _csv.writer(fh)
        writer.writerow(col_names)
        if records:
            for rec in records:
                writer.writerow([rec.get(c['name'], '') for c in columns])
        else:
            for row_idx in range(synthetic_rows):
                writer.writerow([_csv_sample_value(c['name'], c['datatype'], row_idx)
                                 for c in columns])
    return csv_path


def _csv_sample_value(col_name: str, datatype: str, row_idx: int):
    """Plain-Python synthetic value for one CSV cell (row_idx varies the
    value so the dummy dataset isn't just one row repeated)."""
    if datatype == 'double':
        return round(100.0 + row_idx * 37.5, 2)
    if datatype == 'int64':
        return 100 + row_idx * 7
    if datatype == 'boolean':
        return 'true' if row_idx % 2 == 0 else 'false'
    if datatype == 'dateTime':
        from datetime import date, timedelta
        return (date(2024, 1, 1) + timedelta(days=row_idx * 30)).isoformat()
    return f"{col_name} {row_idx + 1}"


# ─────────────────────────────────────────────────────────────────────────────
# TOM (Tabular Object Model) object construction — type-aware, not generic
# ─────────────────────────────────────────────────────────────────────────────
#
# Power BI Desktop's DataModelSchema is a strict TOM/TMSL JSON document.
# Different object *types* accept different property sets — most notably,
# "expression" is ONLY valid on a Column whose "type" is "calculated" (or on
# a Measure, which is a distinct object entirely). Writing "expression" onto
# a plain imported Column — which defaults to type "data" whenever "type" is
# omitted — produces exactly the "Unrecognized JSON property: expression"
# error Power BI Desktop raises. Every column/measure is therefore built
# through one of the constructors below (which set the correct "type"
# discriminator and only ever include properties valid for it), and
# additionally passed through _sanitize_tom_object() as a defensive final
# pass that strips anything that shouldn't be there before packaging.

# Properties allowed on each TOM object "kind". Anything not listed here is
# stripped by _sanitize_tom_object() as a last line of defense, regardless
# of which code path constructed the object.
_TOM_ALLOWED_PROPS = {
    'data_column': {
        'name', 'dataType', 'lineageTag', 'sourceColumn', 'isHidden', 'isKey',
        'isNullable', 'isUnique', 'summarizeBy', 'formatString', 'sortByColumn',
        'dataCategory', 'description', 'displayFolder', 'annotations',
        'extendedProperties', 'isDataTypeInferred', 'type', 'encoding', 'state',
    },
    'calculated_column': {
        'name', 'dataType', 'lineageTag', 'expression', 'isHidden', 'summarizeBy',
        'formatString', 'sortByColumn', 'dataCategory', 'description',
        'displayFolder', 'annotations', 'extendedProperties', 'isDataTypeInferred',
        'type', 'state',
    },
    'measure': {
        'name', 'lineageTag', 'expression', 'formatString', 'isHidden',
        'description', 'displayFolder', 'annotations', 'extendedProperties',
        'detailRowsExpression', 'kpi', 'state',
    },
    'table': {
        'name', 'lineageTag', 'columns', 'measures', 'partitions', 'annotations',
        'description', 'isHidden', 'isPrivate', 'hierarchies', 'calculationGroup',
    },
    'partition': {
        'name', 'mode', 'source', 'annotations', 'description', 'state',
    },
    'relationship': {
        'name', 'fromTable', 'fromColumn', 'toTable', 'toColumn',
        'crossFilteringBehavior', 'joinOnDateBehavior', 'isActive',
        'securityFilteringBehavior', 'fromCardinality', 'toCardinality',
    },
}


def _sanitize_tom_object(obj: dict, kind: str, context: str = '') -> dict:
    """
    Defensive final pass: strip any property not valid for this TOM object
    kind, logging exactly what was removed (and why) so a bad object never
    silently reaches the packaged .pbit.
    """
    allowed = _TOM_ALLOWED_PROPS.get(kind)
    if not allowed:
        return obj
    for prop in list(obj.keys()):
        if prop not in allowed:
            log('warn', f"Removing unsupported property '{prop}' from {kind.replace('_', ' ')} "
                        f"{context} — not valid on this TOM object type.")
            del obj[prop]
    return obj


def _build_data_column(name: str, data_type: str, source_column: str = None,
                       is_hidden: bool = False, format_string: str = None,
                       is_identifier: bool = False) -> dict:
    """An imported (non-calculated) column — TOM type 'data'. Must never
    carry an 'expression' property."""
    # Confirmed via a real Power BI Desktop-generated PBIP: an integer
    # identifier column (e.g. CustomerID) defaults to summarizeBy: count,
    # not none -- Desktop's own auto-summarization heuristic for ID-shaped
    # whole-number columns, distinct from its 'none' default for text.
    summarize_by = "count" if (is_identifier and data_type in ('int64', 'integer')) else "none"
    col = {
        "name": name,
        "lineageTag": _guid(),
        "dataType": data_type,
        "sourceColumn": source_column or name,
        "summarizeBy": summarize_by,
        "type": "data",
        "annotations": [{"name": "SummarizationSetBy", "value": "Automatic"}],
    }
    if is_hidden:
        col["isHidden"] = True
    if format_string:
        col["formatString"] = format_string
    geo_category = _guess_geo_data_category(name)
    if geo_category:
        col["dataCategory"] = geo_category
    return _sanitize_tom_object(col, 'data_column', name)


# ─────────────────────────────────────────────────────────────────────────────
# Fail-safe formula conversion support -- Step 3/4 of the migration policy:
# a Cognos formula that cannot be converted must NEVER stop the migration,
# never produce invalid TMDL/DAX, and must have its original source
# preserved as metadata (not silently discarded) alongside a placeholder
# value that keeps the semantic model loadable.
# ─────────────────────────────────────────────────────────────────────────────

def _placeholder_for_datatype(data_type: str) -> str:
    """A calculated column/measure that failed conversion still needs SOME
    valid DAX expression so the model stays loadable. BLANK() is always
    safe, but an empty string or zero is a more useful, still-always-safe
    default for text/numeric columns respectively -- exactly the STEP 3
    examples (BLANK() / "" / 0 depending on the expected data type)."""
    dt = (data_type or '').lower()
    if dt in ('string', 'text'):
        return '""'
    if dt in ('int64', 'integer', 'double', 'decimal', 'number', 'currency'):
        return '0'
    return 'BLANK()'   # dateTime, boolean, binary, or unknown -- no safe non-BLANK default


def _failure_annotations(original_expression: str) -> list:
    """The two metadata annotations Step 3 asks for, applied to a
    calculated column/measure whose Cognos expression could not be
    converted: the untouched original source (for manual re-authoring) and
    a short human-readable note. Values are metadata only -- never parsed
    as DAX or TMDL keywords by Power BI -- see _strip_tmdl_annotation_lines
    for why this is safe even though the original text legitimately
    contains CASE/WHEN/END."""
    return [
        {"name": "OriginalCognosExpression", "value": original_expression or ''},
        {"name": "MigrationComment",
         "value": "Automatic Cognos-to-DAX conversion failed; original expression "
                  "preserved above for manual review. A safe placeholder value is "
                  "used so the model remains loadable."},
    ]


def _build_expression_conversion_record(table_name: str, item_name: str, kind: str,
                                        original_expr: str, dax_expr: str, tr: dict) -> dict:
    """
    One row of the Step-4 migration report, in exactly the schema
    requested: Table Name, Column Name, Original Cognos Formula, Generated
    DAX, Conversion Status, Reason, Confidence, Manual Review Required,
    Unsupported Functions, Validation Errors. `tr` is a
    cognos_expr_to_dax()-shaped dict (or an equivalent hand-built one for
    the fast-path/no-expression cases that don't call it).
    """
    validation_errors = list(tr.get('validation_problems', []))
    warnings = list(tr.get('warnings', []))
    manual_review = tr.get('status') == 'Failed' or bool(validation_errors)
    reason = '; '.join(warnings) if warnings else (
        'Converted without issues.' if tr.get('status') == 'Converted' else '')
    return {
        'table': table_name, 'name': item_name, 'kind': kind,
        'original': original_expr, 'dax': dax_expr,
        'status': tr.get('status', 'Converted'),
        'validation': tr.get('validation', 'Passed'),
        'confidence': tr.get('confidence', 'high'),
        'reason': reason,
        'manual_review_required': manual_review,
        'unsupported_functions': list(tr.get('functions', [])),
        'validation_errors': validation_errors,
        'warnings': warnings + validation_errors,
    }


def _build_calculated_column(name: str, data_type: str, dax_expression: str,
                             extra_annotations: list = None) -> dict:
    """A calculated column — TOM type 'calculated'. Must carry 'expression'
    and must NOT carry 'sourceColumn' (it has no source; it's computed).

    extra_annotations: additional {'name', 'value'} annotation dicts appended
    after the standard SummarizationSetBy one -- used to preserve the
    original Cognos source expression (OriginalCognosExpression) and a
    human-readable note (MigrationComment) directly on the object whenever
    conversion could not be completed and the expression had to be replaced
    with a placeholder. Annotations are metadata only -- Power BI Desktop
    never evaluates them -- so this is a safe place to keep the source
    formula for manual review without affecting how the model loads.
    """
    col = {
        "name": name,
        "lineageTag": _guid(),
        "dataType": data_type,
        "isDataTypeInferred": True,
        "expression": dax_expression,
        "summarizeBy": "none",
        "type": "calculated",
        "annotations": [{"name": "SummarizationSetBy", "value": "Automatic"}]
                      + list(extra_annotations or []),
    }
    return _sanitize_tom_object(col, 'calculated_column', name)


def _build_measure(name: str, dax_expression: str, format_string: str = "#,0.00",
                   extra_annotations: list = None) -> dict:
    """A measure — always lives in the table's separate 'measures'
    collection, never in 'columns'. Only measures and calculated columns may
    carry 'expression'.

    extra_annotations: see _build_calculated_column -- same
    OriginalCognosExpression / MigrationComment metadata-preservation use.
    """
    m = {
        "name": name,
        "lineageTag": _guid(),
        "expression": dax_expression,
        "formatString": format_string,
    }
    if extra_annotations:
        m["annotations"] = list(extra_annotations)
    return _sanitize_tom_object(m, 'measure', name)


# ─────────────────────────────────────────────────────────────────────────────
# Logical table inference — turn generic Cognos report queries into a real,
# named semantic model instead of anonymous Query1/Query2/Query3 tables
# ─────────────────────────────────────────────────────────────────────────────
#
# A Cognos Report Studio query (<query name="Query1">) is usually just an
# internal alias for a flattened/joined SELECT — Report Studio assigns that
# generic name automatically whenever the author doesn't rename it. The
# REAL table identity lives one level deeper, in each data item's
# fully-qualified expression: [Namespace].[TableName].[ColumnName]. The
# second-to-last bracket segment is the underlying physical/query-subject
# table name (e.g. "Sales", "Customer") from the Framework Manager
# package/data module — that's what a Power BI developer would actually
# name the table, not the report-local query alias.

_GENERIC_QUERY_NAME_RE = re.compile(r'^(query|q|dsqr|ds|qry)\s*\d*$', re.I)


def _is_generic_query_name(name: str) -> bool:
    return bool(_GENERIC_QUERY_NAME_RE.match((name or '').strip()))


def resolve_report_item_to_framework_table(item: dict, fm_report: dict):
    """
    Resolve one report data item to its real Framework Manager table and
    column — THE ROOT-CAUSE FIX for report queries becoming orphan
    "Query1"/"Query2" tables instead of binding to the actual package.

    Tries, in order of reliability:

      1. The item's own Cognos expression (e.g.
         "[HR Enterprise Reporting].[Employee].[Employee ID]"), parsed
         into bracket segments. The second-to-last segment is normally a
         Presentation Layer folder name — what a report author actually
         sees and drags from in Report Studio — looked up against
         fm_report['_presentation_item_to_business'] (exact folder+item
         match, built directly from the model's own
         queryItemFolderRef/presentationQueryItem cross-references: the
         single most reliable signal available).
      2. If the folder resolves to a real table but this exact item name
         doesn't (a report-renamed alias), fall back to matching that
         same leaf segment against the resolved table's own item list.
      3. The second-to-last segment matched directly against a Business
         Layer table name — handles simpler/unlayered models with no
         separate Presentation Layer, or a report authored directly
         against Business Layer names.
      4. Last resort: match by item NAME ALONE against every table's
         items (the model's previous, sole strategy) — kept only for
         items with no usable expression at all (a purely report-local
         calculation, or an export shape this parser doesn't recognize).

    Returns (framework_table_name, framework_column_name). framework_column_name
    is None when the table resolved but no item of that exact name exists
    on it yet (the caller then adds this item to that table as a
    report-only field, rather than creating a whole new table for it).
    Returns (None, None) if nothing resolves at all.
    """
    expr = item.get('expression', '') or ''
    item_name = item.get('name', '') or ''
    segments = re.findall(r'\[([^\[\]]+)\]', expr)

    pres_item_map = fm_report.get('_presentation_item_to_business', {})
    pres_folder_map = fm_report.get('_presentation_folder_to_table', {})
    fm_tables_by_name = {q['name'].lower(): q for q in fm_report.get('queries', [])}

    if len(segments) >= 2:
        folder_candidate = segments[-2].lower()
        leaf_item = segments[-1].lower()

        hit = pres_item_map.get((folder_candidate, leaf_item))
        if hit:
            return hit

        table_from_folder = pres_folder_map.get(folder_candidate)
        if table_from_folder:
            fm_table = fm_tables_by_name.get(table_from_folder.lower())
            if fm_table:
                for fm_it in fm_table['items']:
                    if fm_it['name'].lower() == leaf_item:
                        return table_from_folder, fm_it['name']
                return table_from_folder, None

        fm_table = fm_tables_by_name.get(folder_candidate)
        if fm_table:
            for fm_it in fm_table['items']:
                if fm_it['name'].lower() == leaf_item:
                    return fm_table['name'], fm_it['name']
            return fm_table['name'], None

    if item_name:
        for fm_q in fm_report.get('queries', []):
            for fm_it in fm_q['items']:
                if fm_it['name'].lower() == item_name.lower():
                    return fm_q['name'], fm_it['name']

    return None, None


def _infer_source_table_for_item(expression: str):
    """Return the second-to-last bracket segment of a Cognos field
    expression — e.g. '[NS].[Sales].[Revenue]' -> 'Sales' — or None if the
    expression doesn't have enough qualification to infer a table."""
    segments = re.findall(r'\[([^\[\]]+)\]', expression or '')
    if len(segments) >= 2:
        return segments[-2]
    return None


_KEY_COLUMN_RE = re.compile(r'(id|key|code)$', re.I)


def _split_one_query(q: dict):
    """
    Pass 1 of query expansion: work out how one Cognos query's items group
    by inferred source table, which group is the primary/fact side, and
    which dimension groups need a foreign key promoted onto them. Returns
    (groups, primary_name, promoted_keys) — see _expand_queries_into_logical_tables.
    """
    plain_items = [it for it in q['items'] if not it['is_calculated'] and not it['aggregate']]
    other_items = [it for it in q['items'] if it not in plain_items]

    groups: dict = {}
    ungrouped = []
    for it in plain_items:
        src = _infer_source_table_for_item(it['expression'])
        if src and not _is_generic_query_name(src):
            groups.setdefault(src, []).append(it)
        else:
            ungrouped.append(it)

    if len(groups) <= 1:
        table_name = q['name']
        if groups and _is_generic_query_name(q['name']):
            table_name = next(iter(groups))
        return {table_name: list(q['items'])}, table_name, {}

    primary_name = max(groups, key=lambda k: len(groups[k]))
    groups[primary_name].extend(ungrouped)
    groups[primary_name].extend(other_items)

    # A flattened Cognos report query typically carries the join key only
    # once (on the fact/primary side) — e.g. "CustomerID" lives on Sales,
    # but there's no separate "Customer.CustomerID" in the flat result set
    # at all, since there was never a standalone dimension query to begin
    # with. Without a key column of its own, a dimension table can't be
    # related to anything, so: for every non-primary table, if the primary
    # table has a column shaped like "<DimensionName>ID"/"...Key"/"...Code",
    # promote (copy) that same data item onto the dimension table as its
    # own key column before finalizing the split.
    primary_cols = {it['name']: it for it in groups[primary_name]}
    promoted_keys = {}
    for tbl_name in list(groups.keys()):
        if tbl_name == primary_name:
            continue
        dim_cols = {it['name'] for it in groups[tbl_name]}
        if any(_KEY_COLUMN_RE.search(c) for c in dim_cols):
            continue
        key_pattern = re.compile(rf'^{re.escape(tbl_name)}[_ ]?(id|key|code)$', re.I)
        fk_item = next((it for name, it in primary_cols.items() if key_pattern.match(name)), None)
        if fk_item is not None:
            groups[tbl_name].append(dict(fk_item))
            promoted_keys[tbl_name] = fk_item['name']

    return groups, primary_name, promoted_keys


def _expand_queries_into_logical_tables(report: dict):
    """
    Turn every Cognos <query> into one or more "logical table" dicts (same
    shape as a query: name/items/filters/sorts) with real, meaningful names
    derived from the data — instead of the report's often-generic internal
    query alias — and infer relationships between them when a single query
    turns out to flatten more than one underlying source table together.

    Different queries often share a real dimension (e.g. a "Policy" query
    and a "Claims" query both referencing the same "Targets" lookup table).
    Splitting each query in isolation would create two separate,
    near-identical tables ("Targets" and "Targets_2") and — critically —
    would misroute relationships onto whichever one happened to be built
    last, since both raw-named "Targets" groups can't coexist under one
    name. That exact bug is what produces orphaned/duplicated dimension
    tables and mis-wired relationships, which is the most likely root
    cause behind "cyclic reference" style errors reported after this kind
    of split. So table merging happens GLOBALLY, across every query, by
    raw source-table name, BEFORE any final Power BI table names are
    assigned — a shared dimension always becomes exactly one table.

    Returns (logical_tables, inferred_relationships, item_table_by_query)
    where item_table_by_query maps original_query_name -> {cognos_item_name:
    logical_table_name}, which the layout/visual layer uses to find which
    split table a given visual's field actually landed on.
    """
    per_query = {}   # query_name -> (groups, primary_name, promoted_keys)
    for q in report['queries']:
        if not q['items']:
            continue
        per_query[q['name']] = _split_one_query(q)

    # Pass 2: merge every group sharing the same raw table name across ALL
    # queries into one combined item list (deduplicated by item name).
    merged_items: dict = {}     # raw_table_name -> {item_name: item}
    owning_query_for_table: dict = {}   # raw_table_name -> the one query whose
                                        # filters/sorts it should carry (its
                                        # own primary/fact table only)
    for q_name, (groups, primary_name, _promoted) in per_query.items():
        for raw_name, items in groups.items():
            bucket = merged_items.setdefault(raw_name, {})
            for it in items:
                bucket.setdefault(it['name'], it)
            if raw_name == primary_name:
                owning_query_for_table.setdefault(raw_name, q_name)

    logical_tables = []
    for raw_name, item_bucket in merged_items.items():
        owner_q = report_queries_by_name(report).get(owning_query_for_table.get(raw_name))
        logical_tables.append({
            'name': raw_name,
            'items': list(item_bucket.values()),
            'filters': owner_q['filters'] if owner_q else [],
            'sorts': owner_q['sorts'] if owner_q else [],
        })
        if len(per_query) and sum(1 for g, _, _ in per_query.values() if raw_name in g) > 1:
            log('info', f"Table '{raw_name}' is referenced by more than one Cognos query — "
                        f"modeled once as a shared table instead of being duplicated.")

    item_table_by_query: dict = {}
    for q_name, (groups, primary_name, _promoted) in per_query.items():
        item_table_by_query[q_name] = {}
        for raw_name, items in groups.items():
            for it in items:
                item_table_by_query[q_name][it['name']] = raw_name

    # Pass 3: relationships — prefer the promoted key columns (the common
    # case for a flattened single-query report), then fall back to any
    # column name shared verbatim, or key-naming-convention, between two of
    # one query's own groups.
    inferred_rels = []
    seen_pairs = set()
    for q_name, (groups, primary_name, promoted_keys) in per_query.items():
        if len(groups) <= 1:
            continue
        for tbl_name, key_col in promoted_keys.items():
            pair_key = (primary_name, key_col, tbl_name, key_col)
            if pair_key not in seen_pairs:
                seen_pairs.add(pair_key)
                inferred_rels.append({'fromTable': primary_name, 'fromColumn': key_col,
                                      'toTable': tbl_name, 'toColumn': key_col})
        table_names = list(groups.keys())
        for i, t1 in enumerate(table_names):
            cols1 = {it['name']: it for it in groups[t1]}
            for t2 in table_names[i + 1:]:
                already_promoted = (
                    (t1 == primary_name and t2 in promoted_keys) or
                    (t2 == primary_name and t1 in promoted_keys)
                )
                if already_promoted:
                    continue
                cols2 = {it['name']: it for it in groups[t2]}
                shared = set(cols1) & set(cols2)
                for col in shared:
                    many_tbl, one_tbl = (t1, t2) if len(groups[t1]) >= len(groups[t2]) else (t2, t1)
                    pair_key = (many_tbl, col, one_tbl, col)
                    if pair_key not in seen_pairs:
                        seen_pairs.add(pair_key)
                        inferred_rels.append({'fromTable': many_tbl, 'fromColumn': col,
                                              'toTable': one_tbl, 'toColumn': col})
                if not shared:
                    for c1 in cols1:
                        if re.match(rf'^{re.escape(t2)}[_ ]?(id|key|code)$', c1, re.I):
                            pk = next((c2 for c2 in cols2 if _KEY_COLUMN_RE.search(c2)), None)
                            if pk:
                                pair_key = (t1, c1, t2, pk)
                                if pair_key not in seen_pairs:
                                    seen_pairs.add(pair_key)
                                    inferred_rels.append({'fromTable': t1, 'fromColumn': c1,
                                                          'toTable': t2, 'toColumn': pk})
        log('info', f"Query '{q_name}' spans {len(groups)} source tables "
                    f"({', '.join(groups.keys())}) — split into separate related "
                    f"tables instead of one generic table.")

    return logical_tables, inferred_rels, item_table_by_query


def report_queries_by_name(report: dict) -> dict:
    return {q['name']: q for q in report['queries']}


def _find_one_relationship_cycle(rels: list):
    """DFS cycle detection over the directed fromTable->toTable graph of a
    relationship list. Returns a list of table names describing one cycle
    (e.g. ['Targets', 'Sales', 'Targets']), or None if the graph is a DAG."""
    graph: dict = {}
    nodes = set()
    for r in rels:
        graph.setdefault(r['fromTable'], []).append(r['toTable'])
        nodes.add(r['fromTable'])
        nodes.add(r['toTable'])

    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in nodes}
    path: list = []
    found: list = [None]

    def dfs(node):
        color[node] = GRAY
        path.append(node)
        for nxt in graph.get(node, []):
            if color.get(nxt) == GRAY:
                idx = path.index(nxt)
                found[0] = path[idx:] + [nxt]
                return True
            if color.get(nxt) == WHITE and dfs(nxt):
                return True
        path.pop()
        color[node] = BLACK
        return False

    for n in list(nodes):
        if color[n] == WHITE and dfs(n):
            return found[0]
    return None


def _detect_and_break_relationship_cycles(rels: list) -> list:
    """
    Validate that the relationship graph is a proper DAG before it's
    written into the model. A cycle here (direct A->A, or indirect
    A->B->A / A->B->C->A) is exactly the class of defect that produces
    Power BI's "A cyclic reference was encountered during evaluation"
    error, so every cycle is detected and automatically broken (by
    dropping the one edge that closes the loop) before packaging.
    """
    log('info', "Building query dependency graph...")
    log('info', "Checking query dependencies...")
    kept = list(rels)
    while True:
        cycle = _find_one_relationship_cycle(kept)
        if not cycle:
            break
        chain_str = "\n   ↓\n".join(cycle)
        log('warn', f"Cycle detected:\n{chain_str}")
        from_t, to_t = cycle[-2], cycle[-1]
        bad_rel = next((r for r in kept
                        if r['fromTable'] == from_t and r['toTable'] == to_t), None)
        if bad_rel is None:
            break   # defensive guard — shouldn't happen given how the cycle was found
        kept.remove(bad_rel)
        log('warn', f"Automatically resolved by removing relationship "
                    f"{bad_rel['fromTable']}.{bad_rel['fromColumn']} -> "
                    f"{bad_rel['toTable']}.{bad_rel['toColumn']}")
    if len(kept) == len(rels):
        log('info', "No cyclic references detected.")
    return kept


def build_data_model_schema(report: dict, embed_sample_data: bool = False,
                            source_data_folder=None, output_dir=None,
                            materialize_files: bool = True) -> dict:
    """
    Build a Power BI TOM/TMSL-compatible DataModelSchema from a parsed Cognos
    report, following the exact wrapper shape used by the Tableau engine
    (name / compatibilityLevel / model.{tables, relationships, annotations}).
    """
    wb_name = report['name']
    tables = []
    seen_table_names: set = set()
    seen_model_measure_names: set = set()
    audit = {'measures': 0, 'calc_columns': 0, 'low_confidence': 0, 'medium_confidence': 0}

    if report.get('_item_table_by_query_override') is not None:
        # Case 3 (Framework Manager model + report merged): report['queries']
        # already IS the final table list (FM tables, with any report-only
        # fields already appended to the matching table, plus any
        # genuinely-unmatched report query kept as its own table) — so the
        # star-schema splitting/inference pass that exists for flattened
        # report-only queries must NOT run again here; it would risk
        # re-fragmenting an already-correct Framework Manager table based on
        # a report-only calculated item's own namespace-qualified expression.
        logical_tables = report['queries']
        inferred_relationships = []
        item_table_by_query = report['_item_table_by_query_override']
        log('info', "Using the Framework Manager model's tables directly — "
                    "skipping star-schema re-inference for the merged report.")
    else:
        logical_tables, inferred_relationships, item_table_by_query = \
            _expand_queries_into_logical_tables(report)
    report['_item_table_by_query'] = item_table_by_query

    table_name_by_query: dict = {}
    raw_table_name_to_final: dict = {}   # each logical table's own raw name -> final PBI name
    report_filters: list = []   # Power BI report-filter JSON objects migrated from Cognos query filters
    fields_by_table: dict = {}   # table_name -> [{'name', 'is_measure', 'datatype'}]
    col_name_map_by_query: dict = {}   # query_name -> {cognos_item_name: pbi_col_name}

    for q in logical_tables:
        if not q['items']:
            continue
        table_name = _unique_name(_safe_pbi_name(q['name']), seen_table_names)
        raw_table_name_to_final[q['name']] = table_name

        seen_field_names: set = set()
        col_name_map: dict = {}     # Cognos item name -> final PBI column name
        pbi_columns, pbi_calc_columns, pbi_measures = [], [], []

        # Pass 1: register plain (non-aggregated) items as dimension columns
        # first so calculated-column / measure expressions can reference the
        # final, de-duplicated PBI column names.
        dimension_items = [it for it in q['items']
                            if not it['aggregate'] and (not it['is_calculated']
                                                         or _is_plain_field_ref(it['expression']))]
        calc_col_items = [it for it in q['items']
                          if not it['aggregate'] and it['is_calculated']
                          and not _is_plain_field_ref(it['expression'])]
        measure_items = [it for it in q['items'] if it['aggregate']]

        for it in dimension_items:
            col_name = _unique_name(it['name'], seen_field_names, case_insensitive=True)
            col_name_map[it['name']] = col_name
            pbi_dtype = it['datatype']
            entry = _build_data_column(
                col_name, pbi_dtype, source_column=col_name,
                format_string="General Date" if pbi_dtype == 'dateTime' else None,
                is_identifier=(it.get('usage') == 'identifier'))
            pbi_columns.append(entry)

        for it in calc_col_items:
            col_name = _unique_name(it['name'], seen_field_names, case_insensitive=True)
            col_name_map[it['name']] = col_name
            _ensure_referenced_fields_exist(it['expression'], col_name_map, seen_field_names, pbi_columns)
            # No valid_columns passed here: calculated columns are converted
            # before this table's measures exist yet, so a reference to a
            # measure defined later in the same query would be a false
            # "column not found" positive. Measures (processed last, once
            # every column/calc-column is already known) get the full check.
            tr = cognos_expr_to_dax(it['expression'], table_name, col_name_map, item_name=col_name)
            if tr['confidence'] == 'low':
                audit['low_confidence'] += 1
            elif tr['confidence'] == 'medium':
                audit['medium_confidence'] += 1
            audit['calc_columns'] += 1
            calc_col_datatype = it['datatype'] if it['datatype'] != 'string' else 'string'
            dax = tr['dax']
            extra_ann = None
            if tr['status'] == 'Failed':
                # Fail-safe policy: never write the raw Cognos source as the
                # expression itself (that's what produced the original bug)
                # -- use a type-appropriate placeholder instead, and keep
                # the original formula only as inert annotation metadata.
                dax = _placeholder_for_datatype(calc_col_datatype)
                extra_ann = _failure_annotations(it['expression'])
            pbi_calc_columns.append(_build_calculated_column(
                col_name, calc_col_datatype, dax, extra_annotations=extra_ann))
            if tr['warnings']:
                report['warnings'].extend(f"[{table_name}].[{col_name}]: {w}" for w in tr['warnings'])
            report.setdefault('_expression_conversions', []).append(
                _build_expression_conversion_record(
                    table_name, col_name, 'Calculated Column', it['expression'], dax, tr))

        table_measure_names: set = set()
        for it in measure_items:
            measure_name = it['name']
            agg_fn = _AGG_TO_DAX_FN.get((it['aggregate'] or '').lower())
            if agg_fn and _is_plain_field_ref(it['expression']):
                # Simple aggregate over a plain field, e.g. total([Revenue]).
                ref_item = re.findall(r'\[([^\[\]]+)\]', it['expression'])
                ref_name = ref_item[-1] if ref_item else measure_name
                ref_pbi_col = col_name_map.get(ref_name)
                if ref_pbi_col is None or ref_pbi_col in table_measure_names:
                    # Referenced column wasn't modeled as a dimension (it may
                    # be defined only inline here), or the name is already
                    # claimed by a measure — create it as a hidden numeric
                    # base column so the measure has something to sum.
                    ref_pbi_col = _unique_name(ref_name, seen_field_names, case_insensitive=True)
                    col_name_map[ref_name] = ref_pbi_col
                    pbi_columns.append(_build_data_column(
                        ref_pbi_col, "double", source_column=ref_pbi_col, is_hidden=True))
                dax = f"{agg_fn}('{table_name}'[{ref_pbi_col}])"
                confidence, m_warnings = 'high', []
                m_extra_ann = None
                fast_tr = {'status': 'Converted', 'validation': 'Passed', 'confidence': 'high',
                          'warnings': [], 'validation_problems': [], 'functions': []}
                report.setdefault('_expression_conversions', []).append(
                    _build_expression_conversion_record(
                        table_name, measure_name, 'Measure', it['expression'], dax, fast_tr))
            elif agg_fn and it['expression']:
                # Aggregate applied to a more complex expression.
                _ensure_referenced_fields_exist(it['expression'], col_name_map, seen_field_names, pbi_columns, table_measure_names)
                tr = cognos_expr_to_dax(it['expression'], table_name, col_name_map, item_name=measure_name, valid_columns={c['name'] for c in pbi_columns + pbi_calc_columns}, measure_names=table_measure_names)
                if tr['status'] == 'Failed':
                    dax = _placeholder_for_datatype(it.get('datatype') or 'double')
                    m_extra_ann = _failure_annotations(it['expression'])
                else:
                    m_extra_ann = None
                    if agg_fn.lower() in tr['dax'].lower():
                        dax = tr['dax']
                    else:
                        iter_fn = _AGG_TO_DAX_ITERATOR.get(agg_fn, agg_fn)
                        dax = f"{iter_fn}('{table_name}', {tr['dax']})" if iter_fn != agg_fn \
                            else f"{agg_fn}({tr['dax']})"
                confidence, m_warnings = tr['confidence'], tr['warnings']
                report.setdefault('_expression_conversions', []).append(
                    _build_expression_conversion_record(
                        table_name, measure_name, 'Measure', it['expression'], dax, tr))
            elif it['expression']:
                _ensure_referenced_fields_exist(it['expression'], col_name_map, seen_field_names, pbi_columns, table_measure_names)
                tr = cognos_expr_to_dax(it['expression'], table_name, col_name_map, item_name=measure_name, valid_columns={c['name'] for c in pbi_columns + pbi_calc_columns}, measure_names=table_measure_names)
                if tr['status'] == 'Failed':
                    dax = _placeholder_for_datatype(it.get('datatype') or 'double')
                    m_extra_ann = _failure_annotations(it['expression'])
                else:
                    dax = tr['dax']
                    m_extra_ann = None
                confidence, m_warnings = tr['confidence'], tr['warnings']
                report.setdefault('_expression_conversions', []).append(
                    _build_expression_conversion_record(
                        table_name, measure_name, 'Measure', it['expression'], dax, tr))
            else:
                dax = "BLANK()"
                m_extra_ann = None
                confidence, m_warnings = 'low', ['Measure has no expression to convert.']
                no_expr_tr = {'status': 'Converted', 'validation': 'Passed', 'confidence': 'low',
                             'warnings': m_warnings, 'validation_problems': [], 'functions': []}
                report.setdefault('_expression_conversions', []).append(
                    _build_expression_conversion_record(
                        table_name, measure_name, 'Measure', '', dax, no_expr_tr))

            if confidence == 'low':
                audit['low_confidence'] += 1
            elif confidence == 'medium':
                audit['medium_confidence'] += 1
            audit['measures'] += 1
            if m_warnings:
                report['warnings'].extend(f"[{table_name}].[{measure_name}]: {w}" for w in m_warnings)

            candidate = measure_name
            if (candidate.lower() in seen_model_measure_names
                    or candidate.lower() in seen_field_names):
                candidate = f"{measure_name} ({table_name})"
                if candidate.lower() in seen_model_measure_names or candidate.lower() in seen_field_names:
                    candidate = f"{measure_name} (Measure)"
            seen_model_measure_names.add(candidate.lower())
            seen_field_names.add(candidate.lower())
            # Deliberately does NOT overwrite an existing col_name_map entry
            # for this original name: if a hidden base column was already
            # created for it (e.g. this same fact-usage item's own simple
            # aggregate fast path), later expressions referencing it inline
            # — such as [Quantity] * [UnitPrice] — need to resolve to the
            # raw per-row COLUMN value, not this pre-aggregated measure, or
            # the generated DAX would silently compute the wrong number
            # instead of merely failing to compile.
            if measure_name not in col_name_map:
                col_name_map[measure_name] = candidate
            table_measure_names.add(candidate)
            pbi_measures.append(_build_measure(candidate, dax, extra_annotations=m_extra_ann))

        if not pbi_columns and not pbi_calc_columns:
            # A table with only measures still needs at least one physical
            # column for Power BI to load a valid partition.
            pbi_columns.append(_build_data_column("RowId", "int64", source_column="RowId",
                                                  is_hidden=True))

        all_source_columns = [{'name': c['name'], 'datatype': c['dataType']} for c in pbi_columns]
        records = report.get('sample_rows', {}).get(q['name'])
        src_kind, src_file = find_source_data_file(source_data_folder, table_name, q['name'])
        if src_kind == 'csv':
            log('info', f"Using live CSV/text data source for table '{table_name}': {src_file.name}")
            m_query = _build_csv_backed_m_query(all_source_columns, src_file)
        elif src_kind == 'excel':
            log('info', f"Using live Excel data source for table '{table_name}': {src_file.name}")
            m_query = _build_excel_backed_m_query(all_source_columns, src_file)
        elif materialize_files and output_dir:
            # No user-supplied source file — materialize a real, on-disk CSV
            # (using exact extracted rows when available, otherwise
            # synthetic rows) so Power BI still gets a genuine, trackable,
            # user-replaceable data source instead of an in-memory literal
            # that would leave Data Source Settings empty.
            if source_data_folder:
                log('warn', f"No matching data file found in '{source_data_folder}' for table "
                            f"'{table_name}' (looked for a file named '{table_name}' or "
                            f"'{q['name']}' with a .csv/.txt/.tsv/.xlsx/.xlsm/.xls extension) "
                            f"— generating a dummy CSV data source instead.")
            csv_path = _materialize_table_csv(output_dir, table_name, all_source_columns, records)
            kind_label = "exact extracted data" if records else "dummy sample data"
            log('info', f"Table '{table_name}' backed by generated CSV data source "
                        f"({kind_label}): {csv_path}")
            m_query = _build_csv_backed_m_query(all_source_columns, csv_path)
        elif records:
            # Fallback for calls that don't materialize files (e.g. pure
            # analysis) — exact extracted rows embedded in-memory.
            m_query = _build_embedded_m_query(table_name, all_source_columns, records)
        else:
            m_query = _build_synthetic_m_query(table_name, all_source_columns)

        data_table = {
            "name": table_name,
            "lineageTag": _guid(),
            "columns": pbi_columns + pbi_calc_columns,
            "measures": pbi_measures,
            "partitions": [_sanitize_tom_object({
                "name": table_name,
                "mode": "import",
                "source": {"type": "m", "expression": m_query.splitlines()},
            }, 'partition', table_name)],
            "annotations": [
                {"name": "PBI_ResultType", "value": "Table"},
                {"name": "PBI_SourceType", "value": "Cognos"},
            ],
        }

        fm_hierarchies = report.get('_fm_hierarchies', {}).get(q['name'])
        if fm_hierarchies:
            tom_hierarchies = _fm_build_tom_hierarchies(fm_hierarchies, col_name_map)
            if tom_hierarchies:
                data_table["hierarchies"] = tom_hierarchies
                log('info', f"Hierarchy detected on '{table_name}': "
                            f"{', '.join(h['name'] for h in fm_hierarchies)}")

        data_table = _sanitize_tom_object(data_table, 'table', table_name)
        tables.append(data_table)
        referencing_queries = [qn for qn, item_map in item_table_by_query.items()
                               if q['name'] in item_map.values()]
        for qn in referencing_queries:
            col_name_map_by_query.setdefault(qn, {}).update(col_name_map)

        for raw_filter_expr in q.get('filters', []):
            for condition in parse_filter_expression(raw_filter_expr):
                filter_json = build_pbi_filter_json(condition, table_name, col_name_map)
                if filter_json:
                    report_filters.append(filter_json)
                    log('info', f"Migrated report-level filter: {condition['field']} "
                                f"{condition['operator']} {condition['values']} (table '{table_name}')")
                else:
                    log('warn', f"Filter clause could not be converted and was not applied: "
                                f"{raw_filter_expr!r} (table '{table_name}')")

        fields_by_table[table_name] = (
            [{'name': c['name'], 'is_measure': False, 'datatype': c['dataType'],
              'data_category': c.get('dataCategory')}
             for c in pbi_columns + pbi_calc_columns if not c.get('isHidden')] +
            [{'name': m['name'], 'is_measure': True, 'datatype': 'double',
              'data_category': None}
             for m in pbi_measures]
        )

    if report.get('_item_table_by_query_override') is not None:
        # The merge override was built with each query subject's RAW name
        # (before _safe_pbi_name/_unique_name sanitization assigned the
        # table's final name in the loop above) — translate every value
        # through to the final name now that raw_table_name_to_final is
        # complete, or every visual referencing a merged table would
        # silently fail to resolve its fields (item_to_table.get(ref) would
        # never match fields_by_table's final-name keys) and fall back to
        # whatever field happened to be first in the table instead of the
        # one actually requested.
        item_table_by_query = {
            q_name: {item: raw_table_name_to_final.get(raw_tbl, _safe_pbi_name(raw_tbl))
                     for item, raw_tbl in item_map.items()}
            for q_name, item_map in item_table_by_query.items()
        }
        report['_item_table_by_query'] = item_table_by_query

    # Each original Cognos query's "primary" table (for layout objects that
    # reference the query directly rather than a specific split table) is
    # whichever table most of its items ended up on.
    for q_name, item_map in item_table_by_query.items():
        if not item_map:
            continue
        counts: dict = {}
        for raw_tbl in item_map.values():
            counts[raw_tbl] = counts.get(raw_tbl, 0) + 1
        primary_raw = max(counts, key=counts.get)
        table_name_by_query[q_name] = raw_table_name_to_final.get(
            primary_raw, _safe_pbi_name(primary_raw))

    # ── Relationships ──────────────────────────────────────────────────────
    pbi_model_rels = []
    seen_rels = set()

    def _resolve(raw_name):
        if raw_name in raw_table_name_to_final:
            return raw_table_name_to_final[raw_name]
        return table_name_by_query.get(raw_name, _safe_pbi_name(raw_name))

    all_relationships = list(report.get('relationships', [])) + inferred_relationships
    for rel in all_relationships:
        ft, tt = _resolve(rel['fromTable']), _resolve(rel['toTable'])
        fc, tc = rel['fromColumn'], rel['toColumn']
        if ft == tt or ft not in seen_table_names or tt not in seen_table_names:
            continue

        from_card = rel.get('fromCardinality')
        to_card = rel.get('toCardinality')

        # Power BI's TOM/TMDL relationship model requires the FROM end's
        # cardinality to be Many, unless the relationship is One-To-One
        # (Power BI Desktop rejects "From: One, To: Many" outright — this
        # is exactly the shape a Primary-Key -> Foreign-Key relationship
        # parses into when the Cognos/FM model lists the "one" (primary
        # key / lookup / dimension) side first, as ours does: Customers
        # (one) is the FM relationship's left/"from" side, Orders (many)
        # is the right/"to" side). The parser has no reason to know Power
        # BI's directional convention, so that orientation is normalized
        # here, at schema-generation time, by swapping ends whenever
        # cardinality says the FROM side is actually the One/lookup side.
        if from_card == 'one' and to_card == 'many':
            ft, tt = tt, ft
            fc, tc = tc, fc
            from_card, to_card = to_card, from_card

        key = (ft, fc, tt, tc)
        if key in seen_rels:
            continue

        # Defense in depth: if the relationship still isn't a valid Power
        # BI orientation after normalization (From must be Many, or both
        # sides One for a 1:1), don't write invalid TMDL — skip it and log
        # exactly why, so the failure is visible instead of silently
        # producing a package Power BI Desktop refuses to open.
        if from_card and to_card and from_card == 'one' and to_card != 'one':
            log('error', f"Relationship '{ft}'.[{fc}] -> '{tt}'.[{tc}] has an invalid "
                        f"cardinality orientation (From={from_card}, To={to_card}) even "
                        f"after normalization — Power BI requires the From end to be Many "
                        f"unless the relationship is One-To-One. Skipping this relationship "
                        f"rather than writing invalid TMDL.")
            continue

        seen_rels.add(key)
        # Auto-correction: a One-to-One relationship must cross-filter in
        # both directions. With oneDirection cardinality on a 1:1 pair,
        # filtering from the "wrong" side silently does nothing — usually
        # not a hard Power BI Desktop error, but it produces a model that
        # doesn't behave the way a 1:1 relationship is supposed to, and
        # Desktop's own relationship-editor UI defaults every 1:1 it
        # creates to Both for exactly this reason. Forced here regardless
        # of what the source Cognos relationship's direction hint said.
        is_one_to_one = from_card == 'one' and to_card == 'one'
        cross_filter = "bothDirections" if (is_one_to_one or rel.get('crossFilterDirection') == 'Both') \
            else "oneDirection"
        rel_obj = {
            "name": f"{ft}_{fc}_{tt}_{tc}",
            "fromTable": ft, "fromColumn": fc,
            "toTable": tt, "toColumn": tc,
            "crossFilteringBehavior": cross_filter,
            "joinOnDateBehavior": "datePartOnly",
            "isActive": rel.get('isActive', True),
        }
        if from_card:
            rel_obj["fromCardinality"] = from_card
        if to_card:
            rel_obj["toCardinality"] = to_card
        pbi_model_rels.append(_sanitize_tom_object(rel_obj, 'relationship', f"{ft}->{tt}"))

    report['_audit'] = audit
    report['_table_name_by_query'] = table_name_by_query
    report['_fields_by_table'] = fields_by_table
    report['_col_name_map_by_query'] = col_name_map_by_query
    report['_report_filters'] = report_filters

    pbi_model_rels = _detect_and_break_relationship_cycles(pbi_model_rels)

    return {
        "name": wb_name,
        "compatibilityLevel": 1600,
        "model": {
            "culture": "en-US",
            "dataAccessOptions": {"legacyRedirects": True, "returnErrorValuesAsNull": True},
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "sourceQueryCulture": "en-US",
            "tables": tables,
            "relationships": pbi_model_rels,
            "annotations": [
                {"name": "PBIDesktopVersion", "value": "2.128.952.0 (24.04)"},
                {"name": "PBI_QueryOrder", "value": json.dumps([t["name"] for t in tables])},
            ],
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Visualization conversion engine (VisualizationFactory)
# ─────────────────────────────────────────────────────────────────────────────
#
# Metadata-driven Cognos -> Power BI visual mapping, kept as a clearly
# delimited section inside this single file (per project structure
# requirements — no separate modules). Two stages:
#
#   Stage 1 (parse_cognos_visual)   Cognos layout object -> intermediate
#                                   VisualMetadata dict (category, measure,
#                                   legend, dimensions, tooltip fields).
#   Stage 2 (generate_powerbi_visual_json)  VisualMetadata -> real Power BI
#                                   visual JSON, looked up in a mapping
#                                   registry/dispatch table — never a
#                                   generic bar-chart fallback, and never
#                                   placeholder text for a supported type.
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Stage 1 support — tokenization + the visual mapping registry
# ─────────────────────────────────────────────────────────────────────────────

def _tokenize_visual_name(raw: str) -> set:
    """Tokenize a Cognos tag name or vizControl type string into whole-word
    tokens (handles 'HeatMap', 'com.ibm.vis.heatmap', '100%StackedBarChart',
    snake_case, etc.) so classification matches whole words rather than
    substring containment — substring matching previously misclassified
    'com.ibm.vis.heatmap' as a plain 'map' since 'map' is a substring of
    'heatmap'."""
    parts = re.split(r'[\s_\-./]+', raw or '')
    tokens = []
    for p in parts:
        tokens.extend(re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+', p))
    return {t.lower() for t in tokens if t}


# Single source of truth for every Cognos visual type this engine knows how
# to migrate. Adding support for a new one means adding a rule here (and,
# if it needs custom field roles, one builder registered in
# _CHART_VISUAL_DISPATCH near the bottom of this file) — nothing else
# needs to change. Ordered MOST-SPECIFIC-FIRST; a rule matches when ALL of
# its tokens are present (not substring containment).
_VISUAL_TYPE_RULES = [
    ({'network'}, 'network'),
    ({'radial'}, 'radial'),
    ({'sunburst'}, 'radial'),
    ({'waterfall'}, 'waterfall'),
    ({'slicer'}, 'slicer'),
    ({'prompt', 'control'}, 'slicer'),
    ({'select', 'value'}, 'slicer'),
    ({'value', 'prompt'}, 'slicer'),
    ({'heat', 'map'}, 'heatmap'),
    ({'heatmap'}, 'heatmap'),
    ({'quadrant'}, 'quadrant'),
    ({'bullet'}, 'bullet'),
    ({'packed', 'bubble'}, 'bubble'),
    ({'decomposition'}, 'decomposition_tree'),
    ({'chord'}, 'chord'),
    ({'sankey'}, 'sankey'),
    ({'radar'}, 'radar'),
    ({'ribbon'}, 'ribbon'),
    ({'funnel'}, 'funnel'),
    ({'bubble'}, 'bubble'),
    ({'100', 'stacked', 'bar'}, 'pct_stacked_bar'),
    ({'100', 'stacked', 'column'}, 'pct_stacked_column'),
    ({'stacked', 'bar'}, 'stacked_bar'),
    ({'stacked', 'column'}, 'stacked_column'),
    ({'stacked', 'area'}, 'area'),
    ({'floating', 'bar'}, 'bar'),
    ({'clustered', 'bar'}, 'bar'),
    ({'clustered', 'column'}, 'column'),
    ({'combination'}, 'combo'),
    ({'combo'}, 'combo'),
    ({'smooth', 'line'}, 'line'),
    ({'line'}, 'line'),
    ({'bar'}, 'bar'),
    ({'column'}, 'column'),
    ({'area'}, 'area'),
    ({'donut'}, 'donut'),
    ({'pie'}, 'pie'),
    ({'scatter'}, 'scatter'),
    ({'filled', 'map'}, 'filled_map'),
    ({'geo', 'map'}, 'map'),
    ({'map'}, 'map'),
    ({'treemap'}, 'treemap'),
    ({'radial', 'gauge'}, 'gauge'),
    ({'progress', 'gauge'}, 'gauge'),
    ({'gauge'}, 'gauge'),
    ({'kpi'}, 'card'),
]

# internal kind -> (PBI visualType, human label). Kinds not listed here are
# built by a dedicated composite/custom-visual builder registered in
# _CHART_VISUAL_DISPATCH instead of this plain visualType lookup.
VISUAL_KIND_TO_PBI_TYPE = {
    'bar': ('clusteredBarChart', 'Clustered Bar Chart'),
    'column': ('clusteredColumnChart', 'Clustered Column Chart'),
    'stacked_bar': ('barChart', 'Stacked Bar Chart'),
    'stacked_column': ('columnChart', 'Stacked Column Chart'),
    'pct_stacked_bar': ('hundredPercentStackedBarChart', '100% Stacked Bar Chart'),
    'pct_stacked_column': ('hundredPercentStackedColumnChart', '100% Stacked Column Chart'),
    'line': ('lineChart', 'Line Chart'),
    'area': ('areaChart', 'Area Chart'),
    'pie': ('pieChart', 'Pie Chart'),
    'donut': ('donutChart', 'Donut Chart'),
    'scatter': ('scatterChart', 'Scatter Chart'),
    'bubble': ('scatterChart', 'Scatter Chart (with Size)'),
    'treemap': ('treemap', 'Treemap'),
    'map': ('map', 'Map'),
    'filled_map': ('filledMap', 'Filled Map'),
    'gauge': ('gauge', 'Gauge'),
    'card': ('card', 'Card / KPI'),
    'combo': ('lineClusteredColumnComboChart', 'Line and Clustered Column Chart'),
    'ribbon': ('ribbonChart', 'Ribbon Chart'),
    'waterfall': ('waterfallChart', 'Waterfall Chart'),
    'funnel': ('funnel', 'Funnel'),
    'radar': ('lineChart', 'Line Chart (Radar approximation)'),
}

# Kinds that need a composite or custom-visual builder rather than the
# generic single-visualType chart shape.
COMPOSITE_VISUAL_KINDS = {'heatmap', 'quadrant', 'bullet', 'network', 'radial',
                          'decomposition_tree', 'chord', 'sankey'}


def map_visual_type(raw: str) -> str:
    """Classify a Cognos tag name or vizControl type string into one of our
    internal visual 'kind' keys. This is the single mapping matrix — see
    _VISUAL_TYPE_RULES above for the full Cognos -> Power BI table."""
    tokens = _tokenize_visual_name(raw)
    for required, kind in _VISUAL_TYPE_RULES:
        if required <= tokens:
            return kind
    return 'unsupported'


def recommended_pbi_label(kind: str) -> str:
    if kind in VISUAL_KIND_TO_PBI_TYPE:
        return VISUAL_KIND_TO_PBI_TYPE[kind][1]
    return {
        'heatmap': 'Matrix with Conditional Formatting',
        'quadrant': 'Scatter Chart with Constant Lines',
        'bullet': 'Clustered Bar Chart (actual vs. target)',
        'network': 'Network Navigator (Microsoft-certified custom visual)',
        'radial': 'Gauge or Donut Chart (closest native approximation)',
        'decomposition_tree': 'Decomposition Tree (certified custom visual)',
        'chord': 'Chord Diagram (certified custom visual)',
        'sankey': 'Sankey Diagram (certified custom visual)',
    }.get(kind, 'No Power BI equivalent available')


# ─────────────────────────────────────────────────────────────────────────────
# Stage 1 — parse Cognos visualization metadata into an intermediate model
# ─────────────────────────────────────────────────────────────────────────────

def apply_field_bindings(report: dict, obj: dict):
    """
    Resolve a layout object's Cognos item references to (primary_table,
    fields). Each field dict carries its own 'table' key — a single Cognos
    query can be split across several related Power BI tables (star-schema
    inference in cognos_pbi_server.py), so a visual's fields may not all
    live on the same table. Table/Matrix builders are multi-source-aware
    and use each field's own 'table'; every other builder uses a single
    table and the caller filters to primary_table first.
    """
    orig_query = obj.get('ref_query', '')
    item_to_table = report.get('_item_table_by_query', {}).get(orig_query, {})
    col_map = report.get('_col_name_map_by_query', {}).get(orig_query, {})
    fields_by_table = report.get('_fields_by_table', {})

    resolved = []
    if obj['item_refs']:
        for ref in obj['item_refs']:
            tbl = item_to_table.get(ref)
            if tbl is None:
                continue
            pbi_name = col_map.get(ref, ref)
            by_name = {f['name']: f for f in fields_by_table.get(tbl, [])}
            f = by_name.get(pbi_name) or by_name.get(ref)
            if f is None:
                # col_map may point at a hidden helper column sharing this
                # item's original name (columns take priority over measures
                # there so inline expressions resolve correctly) while the
                # actual measure got renamed to "<name> (<table>)" to avoid
                # that same collision — a visual asking for this item by
                # name wants the measure's aggregated value, not the hidden
                # raw column, so look for that renamed measure specifically.
                f = next((c for c in fields_by_table.get(tbl, [])
                         if c.get('is_measure') and c['name'].startswith(f"{ref} (")), None)
            if f:
                resolved.append({**f, 'table': tbl})

    if resolved:
        table_counts = {}
        for f in resolved:
            table_counts[f['table']] = table_counts.get(f['table'], 0) + 1
        primary_table = max(table_counts, key=table_counts.get)
        return primary_table, resolved

    primary_table = report.get('_table_name_by_query', {}).get(orig_query)
    if primary_table is None and report.get('_table_name_by_query'):
        primary_table = next(iter(report['_table_name_by_query'].values()))
    if primary_table is None:
        return None, []
    return primary_table, [{**f, 'table': primary_table}
                           for f in fields_by_table.get(primary_table, [])]


def parse_cognos_visual(obj: dict, report: dict) -> dict:
    """
    Stage 1 of the factory: turn one Cognos layout object into an
    intermediate VisualMetadata dict describing WHAT the visual is,
    independent of Power BI's JSON shape — e.g.:

        {"kind": "network", "title": "Offer Acceptance by Vehicle Class",
         "table": "Offers", "fields": [...], "category": {...},
         "measure": {...}, "legend": {...}, "tooltip": [...]}

    generate_powerbi_visual_json() (Stage 2) turns this into the actual
    Power BI visual container.
    """
    kind = obj.get('chart_type_kind')
    if kind is None:
        kind = map_visual_type(obj.get('chart_type', obj.get('kind', '')))
    table_name, fields = apply_field_bindings(report, obj)

    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')]
    category = dims[0] if dims else (fields[0] if fields else None)
    legend = dims[1] if len(dims) > 1 else None
    measure = msrs[0] if msrs else (fields[-1] if fields else None)
    tooltip_fields = fields[len(dims) + len(msrs):]

    local_filter_conditions = []
    for raw_expr in obj.get('local_filters', []):
        local_filter_conditions.extend(parse_filter_expression(raw_expr))
    col_name_map = report.get('_col_name_map_by_query', {}).get(obj.get('ref_query', ''), {})

    return {
        'kind': kind,
        'cognos_kind_raw': obj.get('chart_type', obj.get('kind', '')),
        'title': obj.get('name') or (obj.get('kind') or 'Visual').title(),
        'table': table_name,
        'fields': fields,
        'category': category,
        'legend': legend,
        'measure': measure,
        'measures': msrs,
        'dimensions': dims,
        'tooltip': tooltip_fields,
        'ref_query': obj.get('ref_query', ''),
        'obj_kind': obj.get('kind'),
        'text': obj.get('text', ''),
        'local_filters': local_filter_conditions,
        '_col_name_map': col_name_map,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Shared low-level JSON builders
# ─────────────────────────────────────────────────────────────────────────────

def _vc_layout(*args):
    # Backward-compatible with call sites that still pass a leading
    # vc_name (unused) positionally: _vc_layout(x,y,z,w,h) or
    # _vc_layout(name,x,y,z,w,h).
    x, y, z, width, height = args[-5:]
    return {"id": 0, "position": {"x": x, "y": y, "z": z, "width": width,
                                    "height": height, "tabOrder": z * 1000}}


def multi_source_from(fields: list, default_table: str):
    """Build the (alias_by_table, From-clause) pair for a prototypeQuery
    whose fields may come from more than one related table."""
    distinct_tables = []
    for f in fields:
        t = f.get('table', default_table)
        if t not in distinct_tables:
            distinct_tables.append(t)
    alias_by_table = {t: f"t{i}" for i, t in enumerate(distinct_tables)}
    from_clause = [{"Name": alias_by_table[t], "Entity": t, "Type": 0} for t in distinct_tables]
    return alias_by_table, from_clause


_multi_source_from = multi_source_from   # back-compat alias for the existing builder functions below


def make_textbox_visual(x, y, z, width, height, text, font_size=14, bold=False):
    vc_name = _guid()
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(x, y, z, width, height)],
        "singleVisual": {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": [{
                "textRuns": [{"value": text or '', "textStyle": {
                    "fontWeight": "bold" if bold else "normal", "fontSize": f"{font_size}pt"}}],
                "horizontalTextAlignment": "Center",
            }]}}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config, "filters": "[]"}


def make_placeholder_visual(x, y, z, width, height, title, cognos_type, reason):
    """
    The ONLY path that ever produces descriptive text instead of a real
    visual — reserved for the case where Power BI genuinely has no native
    or certified-custom-visual equivalent at all. Used by the legacy
    .pbit pipeline to document exactly what was migrated and why. The
    modern PBIP/PBIR writer (write_pbir_report) checks the '_is_placeholder'
    marker below and OMITS this visual entirely instead of writing it —
    a real PBIP report should never contain a fake "visual" that's
    actually just explanatory text standing in for one that couldn't be
    migrated; skipping it is strictly better than shipping a placeholder.
    """
    recommended = recommended_pbi_label(map_visual_type(cognos_type))
    text = (f"Could not migrate '{title}'.\n"
           f"Original Cognos visual type: {cognos_type}\n"
           f"Reason: {reason}\n"
           f"Recommended Power BI visual: {recommended}\n"
           f"Manual migration: recreate this visual in Power BI Desktop using the "
           f"fields listed for '{title}' in the migration documentation.")
    container = make_textbox_visual(x, y, z, width, height, text, font_size=9)
    container['_is_placeholder'] = True
    container['_placeholder_info'] = {
        'title': title, 'cognos_type': cognos_type, 'reason': reason,
        'recommended_pbi_visual': recommended,
    }
    return container


def apply_formatting(container, metadata: dict):
    """
    Stage 2 post-processing: make sure the generated container carries the
    visual's title (every builder already sets this at construction time;
    this is a defensive pass for any path that doesn't) and applies any
    Cognos filter embedded directly on this one visual (as opposed to a
    report-level filter from the query itself) to the visual's own
    'filters' property.
    """
    if not isinstance(container, dict) or 'config' not in container:
        return container
    local_conditions = metadata.get('local_filters') or []
    if local_conditions:
        table_name = metadata.get('table')
        col_map = metadata.get('_col_name_map', {})
        visual_filters = []
        for cond in local_conditions:
            fj = build_pbi_filter_json(cond, table_name, col_map) if table_name else None
            if fj:
                visual_filters.append(fj)
        if visual_filters:
            container['filters'] = _jmin(visual_filters)
            log('info', f"Applied {len(visual_filters)} visual-level filter(s) to "
                        f"'{metadata.get('title')}'.")
    try:
        cfg = json.loads(container['config'])
        sv = cfg.get('singleVisual', {})
        vc_objects = sv.setdefault('vcObjects', {}) if isinstance(sv, dict) else None
        if vc_objects is not None and 'title' not in vc_objects and metadata.get('title'):
            vc_objects['title'] = [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(metadata['title'])}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]
        container['config'] = _jmin(cfg)
    except Exception:
        pass
    return container



def _make_table_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    fields = fields[:20] or [{'name': 'RowId', 'is_measure': False, 'datatype': 'int64',
                              'table': table_name}]
    # One query-source alias per distinct table actually referenced — a
    # table/list visual's columns can now come from more than one related
    # table (e.g. Sales + Customer together) after splitting a flattened
    # Cognos query into a proper star-schema model.
    distinct_tables = []
    for f in fields:
        t = f.get('table', table_name)
        if t not in distinct_tables:
            distinct_tables.append(t)
    alias_by_table = {t: f"t{i}" for i, t in enumerate(distinct_tables)}

    def _select(f):
        t = f.get('table', table_name)
        key = "Measure" if f['is_measure'] else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_select(f) for f in fields]
    proto_query = {"Version": 2,
                    "From": [{"Name": alias_by_table[t], "Entity": t, "Type": 0} for t in distinct_tables],
                    "Select": proto_select, "OrderBy": []}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
            "DataReduction": {"DataVolume": 4, "Primary": {"Window": {"Count": 1000}}},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {"Values": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True}
                              for f in fields]}
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "tableEx",
            "projections": projections,
            "prototypeQuery": proto_query,
            "drillFilterOtherVisuals": True,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    data_transforms = _jmin({
        "selects": [{
            "displayName": f['name'], "queryName": f"{f.get('table', table_name)}.{f['name']}",
            "roles": {"Values": True},
            "type": {"category": None, "underlyingType": 259 if f['is_measure'] else 1},
        } for f in fields],
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0",
            "dataTransforms": data_transforms, "filters": "[]"}



def _make_matrix_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """Crosstab -> pivot-style matrix visual (rows = dimensions, values = measures)."""
    dims = [f for f in fields if not f['is_measure']][:4] or fields[:1]
    msrs = [f for f in fields if f['is_measure']][:4] or fields[1:2]
    if not dims and not msrs:
        return _make_table_visual(vc_name, x, y, z, width, height, table_name, fields, title)

    distinct_tables = []
    for f in dims + msrs:
        t = f.get('table', table_name)
        if t not in distinct_tables:
            distinct_tables.append(t)
    alias_by_table = {t: f"t{i}" for i, t in enumerate(distinct_tables)}

    def _row_sel(f):
        t = f.get('table', table_name)
        return {"Column": {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    def _val_sel(f):
        t = f.get('table', table_name)
        return {"Measure": {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_row_sel(f) for f in dims] + [_val_sel(f) for f in msrs]
    proto_query = {"Version": 2,
                    "From": [{"Name": alias_by_table[t], "Entity": t, "Type": 0} for t in distinct_tables],
                    "Select": proto_select}
    row_idx = list(range(len(dims)))
    val_idx = list(range(len(dims), len(proto_select)))
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": row_idx + val_idx, "Subtotal": 1}]},
            "DataReduction": {"DataVolume": 4, "Primary": {"Window": {"Count": 500}}},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Rows": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True} for f in dims],
        "Values": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}"} for f in msrs],
    }
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "pivotTable",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_chart_visual(vc_name, x, y, z, width, height, table_name, fields,
                       title, visual_type='columnChart'):
    dims = [f for f in fields if not f['is_measure']][:1]
    msrs = [f for f in fields if f['is_measure']][:4]
    if not msrs:
        # A chart needs at least one numeric value; promote a dimension.
        msrs = fields[1:2] if len(fields) > 1 else fields[:1]
    if not dims:
        dims = fields[:1]

    alias_by_table, from_clause = _multi_source_from(dims + msrs, table_name)

    def _cat_sel(f):
        t = f.get('table', table_name)
        return {"Column": {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    def _val_sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f['is_measure'] else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_cat_sel(f) for f in dims] + [_val_sel(f) for f in msrs]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
            "DataReduction": {"DataVolume": 4, "Primary": {"Sample": {}}},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Category": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True} for f in dims],
        "Y": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}"} for f in msrs],
    }
    if visual_type in ('pieChart', 'donutChart'):
        projections = {
            "Category": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True} for f in dims],
            "Y": [{"queryRef": f"{msrs[0].get('table', table_name)}.{msrs[0]['name']}"}] if msrs else [],
        }
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": visual_type,
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_gauge_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    msrs = [f for f in fields if f['is_measure']] or fields[:1]
    value_field = msrs[0] if msrs else {'name': 'RowId', 'is_measure': False}
    vt = value_field.get('table', table_name)
    key = "Measure" if value_field['is_measure'] else "Column"
    proto_select = [{key: {"Expression": {"SourceRef": {"Source": "t"}}, "Property": value_field['name']},
                      "Name": f"{vt}.{value_field['name']}"}]
    proto_query = {"Version": 2, "From": [{"Name": "t", "Entity": vt, "Type": 0}],
                    "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": [0]}]}, "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {"Y": [{"queryRef": f"{vt}.{value_field['name']}", "active": True}]}
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "gauge",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_scatter_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    msrs = [f for f in fields if f['is_measure']]
    dims = [f for f in fields if not f['is_measure']]
    # Scatter needs an X and a Y measure; fall back gracefully if the source
    # data doesn't naturally provide two numeric fields.
    x_field = msrs[0] if len(msrs) >= 1 else (fields[1] if len(fields) > 1 else fields[0])
    y_field = msrs[1] if len(msrs) >= 2 else (msrs[0] if msrs else (fields[0]))
    cat_field = dims[0] if dims else fields[0]
    # A third distinct measure becomes bubble Size — this is what turns a
    # plain scatter into a genuine bubble chart.
    size_field = next((m for m in msrs[2:3]), None)

    sel_fields = [cat_field, x_field, y_field] + ([size_field] if size_field else [])
    alias_by_table, from_clause = _multi_source_from(sel_fields, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in sel_fields]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
            "DataReduction": {"DataVolume": 4, "Primary": {"Sample": {}}},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Category": [{"queryRef": f"{cat_field.get('table', table_name)}.{cat_field['name']}", "active": True}],
        "X": [{"queryRef": f"{x_field.get('table', table_name)}.{x_field['name']}"}],
        "Y": [{"queryRef": f"{y_field.get('table', table_name)}.{y_field['name']}"}],
    }
    if size_field:
        projections["Size"] = [{"queryRef": f"{size_field.get('table', table_name)}.{size_field['name']}"}]
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "scatterChart",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_treemap_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    dims = [f for f in fields if not f['is_measure']][:1] or fields[:1]
    msrs = [f for f in fields if f['is_measure']][:1] or fields[1:2] or fields[:1]

    alias_by_table, from_clause = _multi_source_from(dims + msrs, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in dims] + [_sel(f) for f in msrs]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Group": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True} for f in dims],
        "Values": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}"} for f in msrs],
    }
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "treemap",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_waterfall_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """Native Power BI Waterfall: Category (+ optional Breakdown) + Values."""
    dims = [f for f in fields if not f['is_measure']]
    msrs = [f for f in fields if f['is_measure']] or fields[1:2] or fields[:1]
    category = dims[0] if dims else fields[0]
    breakdown = dims[1] if len(dims) > 1 else None
    value_field = msrs[0] if msrs else fields[-1]

    sel_fields = [category] + ([breakdown] if breakdown else []) + [value_field]
    alias_by_table, from_clause = _multi_source_from(sel_fields, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in sel_fields]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
                   "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Category": [{"queryRef": f"{category.get('table', table_name)}.{category['name']}", "active": True}],
        "Y": [{"queryRef": f"{value_field.get('table', table_name)}.{value_field['name']}"}],
    }
    if breakdown:
        projections["Breakdown"] = [
            {"queryRef": f"{breakdown.get('table', table_name)}.{breakdown['name']}"}]
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "waterfallChart",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_funnel_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """Native Power BI Funnel: Category + Values."""
    dims = [f for f in fields if not f['is_measure']][:1] or fields[:1]
    msrs = [f for f in fields if f['is_measure']][:1] or fields[1:2] or fields[:1]
    alias_by_table, from_clause = _multi_source_from(dims + msrs, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in dims] + [_sel(f) for f in msrs]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
                   "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Category": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": True} for f in dims],
        "Values": [{"queryRef": f"{f.get('table', table_name)}.{f['name']}"} for f in msrs],
    }
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "funnel",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_ribbon_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """Native Power BI Ribbon Chart: Category (axis) + Series (rank group) + Value."""
    dims = [f for f in fields if not f['is_measure']]
    msrs = [f for f in fields if f['is_measure']][:1] or fields[-1:]
    category = dims[0] if dims else fields[0]
    series = dims[1] if len(dims) > 1 else None
    value_field = msrs[0] if msrs else fields[-1]

    sel_fields = [category] + ([series] if series else []) + [value_field]
    alias_by_table, from_clause = _multi_source_from(sel_fields, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in sel_fields]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
                   "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {
        "Category": [{"queryRef": f"{category.get('table', table_name)}.{category['name']}", "active": True}],
        "Value": [{"queryRef": f"{value_field.get('table', table_name)}.{value_field['name']}"}],
    }
    if series:
        projections["Series"] = [{"queryRef": f"{series.get('table', table_name)}.{series['name']}"}]
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "ribbonChart",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_heatmap_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos Heat Map -> Power BI Matrix with a background-color conditional
    formatting rule (3-color gradient) applied to the value cells — the
    closest native equivalent, per the requested mapping.
    """
    dims = [f for f in fields if not f['is_measure']][:2] or fields[:1]
    msrs = [f for f in fields if f['is_measure']][:1] or fields[-1:]
    value_field = msrs[0] if msrs else fields[-1]

    base = _make_matrix_visual(vc_name, x, y, z, width, height, table_name, dims + [value_field], title)
    try:
        cfg = json.loads(base['config'])
        vt = value_field.get('table', table_name)
        color_rule = {
            "backgroundColor": {
                "solid": {"color": {"expr": {"FillRule": {
                    "Input": {"Measure" if value_field.get('is_measure') else "Column": {
                        "Expression": {"SourceRef": {"Source": "t"}}, "Property": value_field['name']}},
                    "FillRule": {"linearGradient3": {
                        "min": {"color": {"expr": {"Literal": {"Value": "'#FFFFFF'"}}}},
                        "mid": {"color": {"expr": {"Literal": {"Value": "'#FFC000'"}}}},
                        "max": {"color": {"expr": {"Literal": {"Value": "'#C00000'"}}}},
                    }},
                }}}}
            }
        }
        cfg['singleVisual'].setdefault('objects', {})['values'] = [
            {"properties": color_rule, "selector": {"metadata": f"{vt}.{value_field['name']}"}}]
        base['config'] = _jmin(cfg)
    except Exception as exc:
        log('warn', f"Heat map conditional formatting could not be applied to '{title}' "
                    f"(the underlying Matrix visual itself is unaffected): {exc}")
    return base


def _make_bullet_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos Bullet Chart -> Power BI has no native bullet visual, so this
    approximates it with a Clustered Bar Chart comparing the actual value
    against a target/comparison measure side by side, which is the closest
    faithful native rendering (a documented approximation, not a text
    placeholder — the visual itself is fully real and interactive).
    """
    msrs = [f for f in fields if f['is_measure']]
    dims = [f for f in fields if not f['is_measure']]
    category = dims[0] if dims else fields[0]
    value_fields = (msrs[:2] if len(msrs) >= 2 else msrs[:1]) or fields[-1:]
    return _make_chart_visual(vc_name, x, y, z, width, height, table_name,
                              [category] + value_fields, title, visual_type='clusteredBarChart')


def _make_quadrant_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos Quadrant Chart -> a real Power BI Scatter Chart (X/Y/Size/
    Category) plus four small corner labels (I/II/III/IV) overlaid as
    textboxes, since Power BI's scatter visual has no native quadrant-label
    feature. Returns a LIST of visual containers (the scatter plus its
    corner labels) rather than a single one.
    """
    scatter = _make_scatter_visual(vc_name, x, y, z, width, height, table_name, fields, title)
    try:
        cfg = json.loads(scatter['config'])
        cfg['singleVisual'].setdefault('objects', {})['referenceLine'] = [
            {"properties": {
                "show": {"expr": {"Literal": {"Value": "true"}}},
                "lineColor": {"solid": {"color": {"expr": {"Literal": {"Value": "'#666666'"}}}}},
                "style": {"expr": {"Literal": {"Value": "'dashed'"}}},
            }}]
        scatter['config'] = _jmin(cfg)
    except Exception:
        pass

    label_w, label_h = 24, 18
    pad = 4
    corners = [
        ("I", x + width - label_w - pad, y + pad),
        ("II", x + pad, y + pad),
        ("III", x + pad, y + height - label_h - pad),
        ("IV", x + width - label_w - pad, y + height - label_h - pad),
    ]
    labels = [_make_textbox_visual(f"{vc_name}_{roman}", lx, ly, z + 1, label_w, label_h,
                                   roman, font_size=9, bold=True)
             for roman, lx, ly in corners]
    return [scatter] + labels


def _make_map_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos geographic/filled/bubble map -> the correct Power BI Map or
    Filled Map, chosen from the fields' geographic dataCategory (see
    _guess_geo_data_category / _build_data_column):

      - Latitude AND Longitude fields both present -> native "map" visual
        with those bound explicitly to the Latitude/Longitude roles (exact
        point plotting, not name-based geocoding).
      - A recognized place-name field (Country/State/City/County/
        PostalCode) -> "filledMap", bound to Category so Power BI's
        geocoding engine resolves it by name.
      - Neither -> best-effort fallback (a plain dimension bound to
        Category), flagged as needing manual verification since fidelity
        then depends on the field actually containing place names.
    """
    lat_field = next((f for f in fields if f.get('data_category') == 'Latitude'), None)
    lon_field = next((f for f in fields if f.get('data_category') == 'Longitude'), None)
    geo_field = next((f for f in fields if f.get('data_category') in
                      ('Country', 'StateOrProvince', 'City', 'County', 'PostalCode',
                       'Continent')), None)
    msrs = [f for f in fields if f.get('is_measure')]
    size_field = msrs[0] if msrs else None

    if lat_field and lon_field:
        visual_type = 'map'
        role_fields = {'Latitude': [lat_field], 'Longitude': [lon_field]}
        if size_field:
            role_fields['Size'] = [size_field]
        legend_field = next((f for f in fields if not f.get('is_measure')
                             and f not in (lat_field, lon_field)), None)
        if legend_field:
            role_fields['Category'] = [legend_field]
    elif geo_field:
        visual_type = 'filledMap'
        role_fields = {'Category': [geo_field]}
        if size_field:
            role_fields['Color saturation' if False else 'Size'] = [size_field]
    else:
        log('warn', f"Map visual '{title}' has no recognizable Latitude/Longitude or named "
                    f"location field (Country/State/City/PostalCode) — falling back to a "
                    f"best-effort category binding; verify this field actually contains "
                    f"place names for Power BI's geocoding to work.")
        visual_type = 'map'
        dims = [f for f in fields if not f.get('is_measure')][:1] or fields[:1]
        role_fields = {'Category': dims}
        if size_field:
            role_fields['Size'] = [size_field]

    all_fields = [f for role in role_fields.values() for f in role]
    alias_by_table, from_clause = _multi_source_from(all_fields, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in all_fields]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {
            "Primary": {"Groupings": [{"Projections": list(range(len(proto_select))), "Subtotal": 1}]},
            "Version": 1,
        },
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {role: [{"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": i == 0}
                          for i, f in enumerate(fs)]
                  for role, fs in role_fields.items()}
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": visual_type,
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_card_visual(vc_name, x, y, z, width, height, table_name, field, title):
    ft = field.get('table', table_name)
    key = "Measure" if field['is_measure'] else "Column"
    proto_select = [{key: {"Expression": {"SourceRef": {"Source": "t"}}, "Property": field['name']},
                      "Name": f"{ft}.{field['name']}"}]
    proto_query = {"Version": 2, "From": [{"Name": "t", "Entity": ft, "Type": 0}],
                    "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": [0]}]}, "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {"Values": [{"queryRef": f"{ft}.{field['name']}", "active": True}]}
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "card",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


def _make_textbox_visual(vc_name, x, y, z, width, height, text, font_size=14, bold=False):
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": [{
                "textRuns": [{"value": text or '', "textStyle": {
                    "fontWeight": "bold" if bold else "normal", "fontSize": f"{font_size}pt"}}],
                "horizontalTextAlignment": "Center",
            }]}}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config, "filters": "[]"}


# ─────────────────────────────────────────────────────────────────────────────
# Visual factory dispatch — maps a resolved chart_type (a plain PBI
# visualType string for the common cases, or one of the composite-kind
# strings for heatmap/quadrant/bullet) to the builder function that creates
# it. Anything not listed here falls through to the generic
# Category/Y _make_chart_visual(), which already covers every simple
# single-shape chart type (bar/column/line/area/pie/donut/combo/ribbon/
# waterfall/funnel all use the same Category+Y projection shape and only
# differ by their visualType string). This is the "factory" the
# visualization generator is built around: adding a new Cognos visual type
# in the future means adding one _VISUAL_TYPE_RULES entry plus, only if it
# needs custom field roles, one entry here — no other dispatch code changes.
def _make_custom_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                        visual_type_guid, visual_display_name, data_role_map):
    """
    Generic Microsoft-certified custom-visual scaffold. Custom visuals are
    identified in report JSON by a visualType GUID (assigned by the
    marketplace/AppSource at publish time) rather than a built-in name like
    'barChart'. If the exact visual isn't installed locally, Power BI
    Desktop shows a "Get it now" prompt linking to that GUID on
    AppSource — it does not corrupt the file or block opening the report.

    data_role_map: {role_name: field_dict_or_list_of_field_dicts} — the
    custom visual's own named data roles (these vary per visual; the
    common ones used here are documented on each caller).
    """
    all_fields = []
    for v in data_role_map.values():
        all_fields.extend(v if isinstance(v, list) else [v])
    alias_by_table, from_clause = multi_source_from(all_fields, table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(f) for f in all_fields]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": list(range(len(proto_select)))}]},
                   "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {}
    idx = 0
    for role, v in data_role_map.items():
        items = v if isinstance(v, list) else [v]
        role_refs = []
        for f in items:
            role_refs.append({"queryRef": f"{f.get('table', table_name)}.{f['name']}", "active": idx == 0})
            idx += 1
        projections[role] = role_refs
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(x, y, z, width, height)],
        "singleVisual": {
            "visualType": visual_type_guid,
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]",
            "_custom_visual": {"guid": visual_type_guid, "displayName": visual_display_name}}


# Microsoft-certified custom visuals used as the closest equivalent for
# Cognos visual types Power BI has no native visual for. The GUID strings
# below are AppSource-assigned identifiers reconstructed from public
# documentation, not fetched live — verify them against the current
# AppSource/marketplace listing before relying on exact byte-for-byte
# resolution, since a marketplace re-publish can change the suffix. If a
# GUID here is stale, Power BI Desktop still opens the report normally and
# simply prompts to fetch the visual from AppSource by name.
CUSTOM_VISUAL_REGISTRY = {
    'network': {
        'guid': 'NetworkNavigatorChart1449170457764',
        'display_name': 'Network Navigator Chart',
        'roles': ('Source', 'Target', 'Weight'),
    },
    'chord': {
        'guid': 'chordSNAPPETVisual1445472000000',
        'display_name': 'Chord Diagram',
        'roles': ('Source', 'Target', 'Values'),
    },
    'sankey': {
        'guid': 'Sankey1444199122834',
        'display_name': 'Sankey Diagram',
        'roles': ('Source', 'Destination', 'Weight'),
    },
    'decomposition_tree': {
        'guid': 'decompositionTree',   # ships built into modern Power BI Desktop
        'display_name': 'Decomposition Tree',
        'roles': ('Analyze', 'Explain By'),
    },
}


def _make_network_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos Network visualization (force-directed node/edge graph) -> the
    Microsoft-certified "Network Navigator Chart" custom visual, the
    closest available equivalent (Power BI has no built-in graph visual).
    Maps: Category/first dimension -> Source node, Legend/second dimension
    (or repeats Source if there's only one) -> Target node, measure -> edge
    Weight — matching Cognos's node/edge/weight semantics.
    """
    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')]
    source = dims[0] if dims else (fields[0] if fields else {'name': 'RowId', 'is_measure': False})
    target = dims[1] if len(dims) > 1 else source
    weight = msrs[0] if msrs else (fields[-1] if fields else source)
    reg = CUSTOM_VISUAL_REGISTRY['network']
    return _make_custom_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                               reg['guid'], reg['display_name'],
                               {'Source': source, 'Target': target, 'Weight': weight})


def _make_radial_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos Radial visualization (concentric multi-ring chart) -> the
    closest NATIVE Power BI visual, chosen from the metadata shape per the
    requested preference order:
      - a single category + single measure (one ring of proportions) ->
        Donut Chart, the closest native ring-shaped visual.
      - a single overall measure with no meaningful category (a KPI-style
        ratio/progress ring) -> Gauge.
    A true multi-ring/sunburst rendering has no native Power BI equivalent;
    if that fidelity is required, use a certified Sunburst custom visual
    instead (see CUSTOM_VISUAL_REGISTRY for the scaffold pattern).
    """
    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')]
    if not dims and len(msrs) <= 1:
        return _make_gauge_visual(vc_name, x, y, z, width, height, table_name, fields, title)
    return _make_chart_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                              visual_type='donutChart')


def _make_decomposition_tree_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')] or fields[-1:]
    reg = CUSTOM_VISUAL_REGISTRY['decomposition_tree']
    return _make_custom_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                               reg['guid'], reg['display_name'],
                               {'Analyze': msrs[:1], 'Explain By': dims})


def _make_chord_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')] or fields[-1:]
    source = dims[0] if dims else fields[0]
    target = dims[1] if len(dims) > 1 else source
    reg = CUSTOM_VISUAL_REGISTRY['chord']
    return _make_custom_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                               reg['guid'], reg['display_name'],
                               {'Source': source, 'Target': target, 'Values': msrs[:1]})


def _make_sankey_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    dims = [f for f in fields if not f.get('is_measure')]
    msrs = [f for f in fields if f.get('is_measure')] or fields[-1:]
    source = dims[0] if dims else fields[0]
    dest = dims[1] if len(dims) > 1 else source
    reg = CUSTOM_VISUAL_REGISTRY['sankey']
    return _make_custom_visual(vc_name, x, y, z, width, height, table_name, fields, title,
                               reg['guid'], reg['display_name'],
                               {'Source': source, 'Destination': dest, 'Weight': msrs[:1]})


def _make_slicer_visual(vc_name, x, y, z, width, height, table_name, fields, title):
    """
    Cognos prompt control / value-selection UI -> a native Power BI Slicer,
    bound to the same field the Cognos prompt filtered on.
    """
    field = next((f for f in fields if not f.get('is_measure')), fields[0] if fields else
                {'name': 'Value', 'is_measure': False})
    alias_by_table, from_clause = _multi_source_from([field], table_name)

    def _sel(f):
        t = f.get('table', table_name)
        key = "Measure" if f.get('is_measure') else "Column"
        return {key: {"Expression": {"SourceRef": {"Source": alias_by_table[t]}}, "Property": f['name']},
                "Name": f"{t}.{f['name']}"}

    proto_select = [_sel(field)]
    proto_query = {"Version": 2, "From": from_clause, "Select": proto_select}
    query = {"Commands": [{"SemanticQueryDataShapeCommand": {
        "Query": proto_query,
        "Binding": {"Primary": {"Groupings": [{"Projections": [0]}]}, "Version": 1},
        "ExecutionMetricsKind": 1,
    }}]}
    projections = {"Values": [{"queryRef": f"{field.get('table', table_name)}.{field['name']}", "active": True}]}
    config = _jmin({
        "name": vc_name,
        "layouts": [_vc_layout(vc_name, x, y, z, width, height)],
        "singleVisual": {
            "visualType": "slicer",
            "projections": projections,
            "prototypeQuery": proto_query,
            "objects": {"data": [{"properties": {"mode": {"expr": {"Literal": {"Value": "'Basic'"}}}}}]},
            "vcObjects": {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": f"'{_m_str(title)}'"}}},
                "show": {"expr": {"Literal": {"Value": "true"}}},
            }}]},
        },
    })
    return {"id": abs(hash(vc_name)) % (2 ** 31), "x": x, "y": y, "z": z,
            "width": width, "height": height, "config": config,
            "query": _jmin(query), "queryHash": "0", "filters": "[]"}


_CHART_VISUAL_DISPATCH = {
    'gauge': _make_gauge_visual,
    'scatter': _make_scatter_visual,
    'bubble': _make_scatter_visual,
    'treemap': _make_treemap_visual,
    'map': _make_map_visual,
    'filled_map': _make_map_visual,
    'waterfall': _make_waterfall_visual,
    'funnel': _make_funnel_visual,
    'ribbon': _make_ribbon_visual,
    'heatmap': _make_heatmap_visual,
    'quadrant': _make_quadrant_visual,
    'bullet': _make_bullet_visual,
    'network': _make_network_visual,
    'radial': _make_radial_visual,
    'decomposition_tree': _make_decomposition_tree_visual,
    'chord': _make_chord_visual,
    'sankey': _make_sankey_visual,
    'slicer': _make_slicer_visual,
}




# ─────────────────────────────────────────────────────────────────────────────
# Stage 2 — the Visualization Factory
# ─────────────────────────────────────────────────────────────────────────────

def generate_powerbi_visual_json(metadata: dict, x, y, z, width, height):
    """
    The factory entry point: VisualMetadata -> Power BI visual JSON.

    Looks up metadata['kind'] in the mapping registry/dispatch table and
    builds the corresponding visual — a real one whenever Power BI has a
    native or certified-custom-visual equivalent. A generic Bar/Column
    chart, or descriptive placeholder text, is used ONLY as an absolute
    last resort when metadata['kind'] is 'unsupported' (no rule in
    _VISUAL_TYPE_RULES matched at all) — never as a default for a
    recognized-but-not-yet-specially-handled type.

    Returns a single visual container dict, or a list of them for
    composite visuals (e.g. Quadrant, which also places corner labels).
    """
    obj_kind = metadata.get('obj_kind')
    table_name = metadata.get('table')
    fields = metadata.get('fields', [])
    title = metadata.get('title', 'Visual')
    vc_name = _guid()

    if table_name is None and obj_kind not in ('text', 'image'):
        container = make_textbox_visual(
            x, y, z, width, height,
            f"[{title}] could not be linked to a converted query — "
            f"see migration documentation for details.", font_size=10)
        container['_is_placeholder'] = True
        container['_placeholder_info'] = {
            'title': title, 'cognos_type': metadata.get('cognos_kind_raw', obj_kind or 'unknown'),
            'reason': "Visual could not be linked to a converted query/table.",
            'recommended_pbi_visual': 'n/a',
        }
        return container

    if obj_kind == 'crosstab':
        result = _make_matrix_visual(vc_name, x, y, z, width, height, table_name, fields, title)
    elif obj_kind == 'chart':
        kind = metadata['kind']
        builder = _CHART_VISUAL_DISPATCH.get(kind)
        if builder is not None:
            result = builder(vc_name, x, y, z, width, height, table_name, fields, title)
        elif kind in VISUAL_KIND_TO_PBI_TYPE:
            pbi_type = VISUAL_KIND_TO_PBI_TYPE[kind][0]
            result = _make_chart_visual(vc_name, x, y, z, width, height, table_name, fields,
                                        title, visual_type=pbi_type)
        else:
            # Genuinely no rule matched this Cognos visual type at all —
            # the ONLY case that produces descriptive placeholder text
            # instead of a real visual.
            log('warn', f"No Power BI equivalent found for Cognos visual type "
                        f"'{metadata.get('cognos_kind_raw')}' on '{title}' — generating a "
                        f"documented placeholder instead of guessing.")
            return make_placeholder_visual(x, y, z, width, height, title,
                                           metadata.get('cognos_kind_raw', 'unknown'),
                                           "No native or certified-custom-visual Power BI "
                                           "equivalent is registered for this Cognos visual type.")
    elif obj_kind == 'singleton':
        f = fields[0] if fields else {'name': 'RowId', 'is_measure': False}
        result = _make_card_visual(vc_name, x, y, z, width, height, table_name, f, title)
    elif obj_kind == 'text':
        return make_textbox_visual(x, y, z, width, height, metadata.get('text') or title)
    elif obj_kind == 'image':
        container = make_textbox_visual(
            x, y, z, width, height,
            f"[Image: {title}] — static images are not migrated; "
            f"re-add this asset manually in Power BI.", font_size=10)
        container['_is_placeholder'] = True
        container['_placeholder_info'] = {
            'title': title, 'cognos_type': 'image',
            'reason': "Static images are not migrated.",
            'recommended_pbi_visual': 'n/a (re-add manually)',
        }
        return container
    else:   # 'list' / 'table' / default
        result = _make_table_visual(vc_name, x, y, z, width, height, table_name, fields, title)

    if isinstance(result, list):
        return [apply_formatting(r, metadata) for r in result]
    return apply_formatting(result, metadata)


# ─────────────────────────────────────────────────────────────────────────────
# Power BI Report/Layout builder
# ─────────────────────────────────────────────────────────────────────────────

def build_report_layout(report: dict) -> dict:
    """
    Build the PBI Report/Layout section, one PBI page per Cognos page.

    Visual generation itself is delegated entirely to visual_converter.py:
    each Cognos layout object is parsed into an intermediate VisualMetadata
    dict (parse_cognos_visual) and then handed to the visualization
    factory (generate_powerbi_visual_json), which looks up the closest
    Power BI equivalent and builds real visual JSON — never a generic
    chart substitution, and never placeholder text for a visual type this
    engine actually knows how to migrate.
    """
    pages = report.get('pages') or [{'name': report['name'], 'objects': []}]
    sections = []
    PAGE_W, PAGE_H = 1280, 720
    custom_visuals_used: dict = {}   # guid -> displayName, collected across the whole report

    for page_idx, page in enumerate(pages):
        objects = page.get('objects', [])
        visual_containers = [make_textbox_visual(
            24, 12, 0, PAGE_W - 48, 40,
            page.get('name', f'Page {page_idx + 1}'), font_size=16, bold=True)]

        if not objects:
            visual_containers.append(make_textbox_visual(
                24, 70, 1, PAGE_W - 48, 60,
                "No convertible Cognos layout objects were found on this page. "
                "The underlying query/data was still migrated into the data model.",
                font_size=11))
        else:
            cols, rows = 2, (len(objects) + 1) // 2
            cell_w = (PAGE_W - 48) // cols
            cell_h = max(220, (PAGE_H - 100) // max(rows, 1))
            primary_visual_count = 0
            for obj_idx, obj in enumerate(objects):
                col = obj_idx % cols
                row = obj_idx // cols
                x = 24 + col * cell_w
                y = 70 + row * cell_h
                w = cell_w - 12
                h = cell_h - 12
                title = obj.get('name') or obj['kind'].title()
                z = obj_idx + 1
                primary_visual_count += 1
                try:
                    metadata = parse_cognos_visual(obj, report)
                    if metadata.get('obj_kind') == 'chart' and not metadata.get('fields'):
                        log('warn', f"Visual '{title}' ({metadata.get('cognos_kind_raw')}) has no "
                                    f"resolvable fields — it will render as an empty container; "
                                    f"check that its Cognos query and data items were extracted correctly.")
                    result = generate_powerbi_visual_json(metadata, x, y, z, w, h)
                    result_list = result if isinstance(result, list) else [result]
                    for container in result_list:
                        cv = container.pop('_custom_visual', None)
                        if cv:
                            custom_visuals_used[cv['guid']] = cv['displayName']
                    visual_containers.extend(result_list)
                except Exception as exc:
                    log('warn', f"Visual build failed for '{title}' ({obj['kind']}): {exc}")
                    orig_type = obj.get('chart_type', obj['kind'])
                    visual_containers.append(make_placeholder_visual(
                        x, y, z, w, h, title, orig_type, str(exc)))

        # Validation: the number of Power BI visuals generated for this page
        # must exactly match the number of Cognos layout objects found for
        # it — one Power BI visual PER COGNOS OBJECT, never more (the page
        # title textbox and the "no objects" placeholder are UI scaffolding,
        # not report visuals; composite visuals like Quadrant legitimately
        # add a few decorative corner-label textboxes alongside their one
        # real chart, which is expected, not a defect).
        if objects and primary_visual_count != len(objects):
            log('warn', f"Page '{page.get('name')}': expected {len(objects)} visual(s) "
                        f"from the Cognos layout but processed {primary_visual_count} — "
                        f"investigate before relying on this page.")
        elif objects:
            log('info', f"Page '{page.get('name')}': {len(objects)} Cognos visual(s) -> "
                        f"{primary_visual_count} Power BI visual(s) (exact match; "
                        f"{len(visual_containers) - 1} total container(s) placed, including "
                        f"decorative elements such as quadrant corner labels).")

        sections.append({
            "id": page_idx,
            "name": re.sub(r'[^A-Za-z0-9_]', '_', page.get('name', f'Page{page_idx + 1}')),
            "displayName": page.get('name', f'Page {page_idx + 1}'),
            "objectId": _guid(),
            "displayOption": 1,
            "ordinal": page_idx,
            "width": float(PAGE_W),
            "height": float(PAGE_H),
            "config": _jmin({"relationships": [], "objects": {"section": [{"properties": {
                "verticalAlignment": {"expr": {"Literal": {"Value": "'Top'"}}}}}]}}),
            "filters": "[]",
            "visualContainers": visual_containers,
        })

    config = _jmin({
        "version": "5.70",
        "themeCollection": {"baseTheme": {"name": "CY26SU02", "type": 2,
                             "version": {"visual": "2.6.0", "report": "3.1.0", "page": "2.3.0"}}},
        "activeSectionIndex": 0,
        "defaultDrillFilterOtherVisuals": True,
        "linguisticSchemaSyncVersion": 2,
        "settings": {
            "useNewFilterPaneExperience": True, "useStylableVisualContainerHeader": True,
            "useEnhancedTooltips": True, "allowChangeFilterTypes": True,
            "queryLimitOption": 6, "exportDataMode": 1, "useDefaultAggregateDisplayName": True,
        },
        "objects": {"section": [{"properties": {
            "verticalAlignment": {"expr": {"Literal": {"Value": "'Top'"}}}}}]},
    })

    public_custom_visuals = [
        {"guid": guid, "displayName": name} for guid, name in custom_visuals_used.items()
    ]
    if public_custom_visuals:
        log('info', f"Report references {len(public_custom_visuals)} certified custom visual(s) "
                    f"not built into Power BI Desktop: "
                    f"{', '.join(v['displayName'] for v in public_custom_visuals)}. "
                    f"Power BI Desktop will prompt to install them from AppSource on first open.")

    report_filters = report.get('_report_filters', [])
    if report_filters:
        log('info', f"Applying {len(report_filters)} migrated report-level filter(s).")

    return {
        "id": 0,
        "resourcePackages": [{"resourcePackage": {
            "name": "SharedResources", "type": 2,
            "items": [{"type": 202, "path": "BaseThemes/CY26SU02.json", "name": "CY26SU02"}],
            "disabled": False,
        }}],
        "sections": sections,
        "pods": [],
        "config": config,
        "reportId": _guid(),
        "filters": _jmin(report_filters),
        "layoutOptimization": 0,
        "publicCustomVisuals": [v['guid'] for v in public_custom_visuals],
    }


def build_diagram_layout(report: dict) -> dict:
    """Build the DataModelSchema's companion DiagramLayout (table positions
    in the Power BI 'Model' relationship-diagram view)."""
    diagrams_nodes = []
    x, y = 40, 40
    for i, table_name in enumerate(report.get('_table_name_by_query', {}).values()):
        diagrams_nodes.append({
            "location": {"x": x, "y": y}, "nodeIndex": table_name,
            "nodeLineageTag": _guid(), "size": {"height": 240, "width": 280},
            "zIndex": i,
        })
        x += 320
        if x > 1600:
            x = 40
            y += 280
    return {
        "version": "1.1.0",
        "diagrams": [{
            "ordinal": 0, "scrollPosition": {"x": 0, "y": 0}, "nodes": diagrams_nodes,
            "name": "All tables", "zoomValue": 100, "pinKeyFieldsToTop": False,
            "showExtraHeaderInfo": False, "hideKeyFieldsWhenCollapsed": False,
            "tablesLocked": False,
        }],
        "selectedDiagram": "All tables", "defaultDiagram": "All tables",
    }


# ─────────────────────────────────────────────────────────────────────────────
# PBIT writer, with mandatory package validation + self-healing rebuild loop
# ─────────────────────────────────────────────────────────────────────────────
#
# HIGHEST PRIORITY REQUIREMENT: the generated .pbit must never trigger
# Power BI Desktop's "file is corrupted"/"file is encrypted" errors. Every
# structural rule below is copied verbatim from the confirmed-working
# encoding rules in tableau_pbi_server.py's write_pbit(), because those
# rules were derived from real PBIX/PBIT byte-level analysis:
#
#   [Content_Types].xml   -> UTF-8 XML
#   Version                -> UTF-16LE, no BOM (plain string)
#   Metadata                -> UTF-16LE, no BOM (JSON)
#   Settings                -> UTF-16LE, no BOM (JSON)
#   DataModelSchema         -> UTF-16LE, no BOM (JSON)
#   DiagramLayout           -> UTF-16LE, no BOM (JSON)
#   Report/Layout           -> UTF-16LE, no BOM (JSON)
#   Report/StaticResources/.../CY26SU02.json -> UTF-8 JSON
#
# In addition to matching those encoding rules, every generated package goes
# through validate_pbit_bytes() before being accepted; on any failure the
# model/report/diagram are rebuilt (with a fresh regeneration pass — new
# GUIDs, re-sanitised JSON, table/measure name collisions re-resolved) and
# validated again, up to _MAX_BUILD_ATTEMPTS times.

_CY26SU02_BASE = {"name": "CY26SU02", "dataColors": [
    "#118DFF", "#12239E", "#E66C37", "#6B007B", "#E044A7", "#744EC2", "#D9B300",
    "#D64550", "#197278", "#1AAB40"],
    "foreground": "#252423", "foregroundNeutralSecondary": "#605E5C",
    "foregroundNeutralTertiary": "#B3B0AD", "background": "#FFFFFF",
    "backgroundLight": "#F3F2F1", "backgroundNeutral": "#C8C6C4",
    "tableAccent": "#118DFF", "good": "#1AAB40", "neutral": "#D9B300", "bad": "#D64554",
    "maximum": "#118DFF", "center": "#D9B300", "minimum": "#DEEFFF", "null": "#FF7F48",
    "hyperlink": "#0078d4", "visitedHyperlink": "#0078d4",
    "textClasses": {
        "callout": {"fontSize": 45, "fontFace": "DIN", "color": {"inherited": True}},
        "title": {"fontSize": 12, "fontFace": "DIN", "color": {"inherited": True}},
        "header": {"fontSize": 12, "fontFace": "Segoe UI", "color": {"inherited": True}},
        "label": {"fontSize": 10, "fontFace": "Segoe UI", "color": {"inherited": True}},
    },
    "visualStyles": {"*": {"*": {
        "*": [{"properties": {"fontSize": {"value": 10}, "fontFamily": {"value": "Segoe UI"}}}],
        "background": [{"properties": {"show": {"value": False}}}],
        "plotArea": [{"properties": {"transparency": {"value": 0}}}],
    }}},
}

_COGNOS_10_PALETTE = ['#5B8FF9', '#61DDAA', '#65789B', '#F6BD16', '#7262FD',
                      '#78D3F8', '#9661BC', '#F6903D', '#008685', '#F08BB4']

_THEME_PATH = 'Report/StaticResources/SharedResources/BaseThemes/CY26SU02.json'
_MAX_BUILD_ATTEMPTS = 3


def _content_types_xml() -> bytes:
    xml = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="json" ContentType=""/>'
        '<Default Extension="xml" ContentType="application/vnd.openxmlformats-officedocument.custom-properties+xml"/>'
        '<Override PartName="/Version" ContentType=""/>'
        '<Override PartName="/DataModelSchema" ContentType=""/>'
        '<Override PartName="/DiagramLayout" ContentType=""/>'
        '<Override PartName="/Report/Layout" ContentType=""/>'
        '<Override PartName="/Settings" ContentType="application/json"/>'
        '<Override PartName="/Metadata" ContentType="application/json"/>'
        f'<Override PartName="/{_THEME_PATH}" ContentType="application/json"/>'
        '</Types>'
    )
    return xml.encode('utf-8')


def _build_pbit_entries(report: dict, embed_sample_data: bool, source_data_folder=None,
                        output_dir=None) -> dict:
    """Build every ZIP-entry payload for one PBIT package (bytes, keyed by
    archive path). Kept separate from write_pbit() so the self-validation
    loop can call it repeatedly with a clean slate on each rebuild attempt."""
    schema = build_data_model_schema(report, embed_sample_data=embed_sample_data,
                                     source_data_folder=source_data_folder,
                                     output_dir=output_dir, materialize_files=True)
    layout = build_report_layout(report)
    diagram = build_diagram_layout(report)

    theme_json = {**_CY26SU02_BASE, 'dataColors': report.get('data_colors') or _COGNOS_10_PALETTE}
    theme_bytes = json.dumps(theme_json, separators=(',', ':')).encode('utf-8')

    metadata = _jstr({
        "Version": 5, "AutoCreatedRelationships": [],
        "CreatedFrom": "Cognos Migration Utility", "CreatedFromRelease": "IBM Cognos Analytics",
    })
    settings = _jstr({
        "Version": 4, "ReportSettings": {},
        "QueriesSettings": {"TypeDetectionEnabled": True, "RelationshipImportEnabled": True,
                            "Version": "2.128.952.0"},
    })

    return {
        '[Content_Types].xml': _content_types_xml(),
        'Version': "1.21".encode('utf-16-le'),
        'Metadata': metadata.encode('utf-16-le'),
        'Settings': settings.encode('utf-16-le'),
        'DataModelSchema': _sanitise_json(_jstr(schema)).encode('utf-16-le'),
        'DiagramLayout': _sanitise_json(_jstr(diagram)).encode('utf-16-le'),
        'Report/Layout': _sanitise_json(_jstr(layout)).encode('utf-16-le'),
        _THEME_PATH: theme_bytes,
    }


_REQUIRED_ENTRIES = ('[Content_Types].xml', 'Version', 'Metadata', 'Settings',
                     'DataModelSchema', 'DiagramLayout', 'Report/Layout', _THEME_PATH)
_UTF16_JSON_ENTRIES = ('Metadata', 'Settings', 'DataModelSchema', 'DiagramLayout', 'Report/Layout')


def _validate_tom_schema(model: dict) -> list:
    """
    Validate every table/column/measure/relationship/partition in a parsed
    DataModelSchema against the allowed TOM property sets for its object
    type, logging each step. This is what actually prevents Power BI
    Desktop's "Unrecognized JSON property" error: a column carrying
    'expression' without type == 'calculated' (or any other property not
    valid for its object kind) is caught and reported here, with the exact
    table/column/property identified, before the package is ever written.
    """
    problems = []
    log('info', "Validating DataModelSchema...")
    tables = model.get('model', {}).get('tables', [])

    log('info', "Checking imported columns...")
    log('info', "Checking calculated columns...")
    for t_idx, t in enumerate(tables):
        t_name = t.get('name', f'table[{t_idx}]')
        for c_idx, c in enumerate(t.get('columns', [])):
            c_name = c.get('name', f'columns[{c_idx}]')
            col_type = c.get('type', 'data')
            kind = 'calculated_column' if col_type == 'calculated' else 'data_column'
            allowed = _TOM_ALLOWED_PROPS[kind]
            for prop in c.keys():
                if prop not in allowed:
                    problems.append(
                        f"model.tables[{t_idx}].columns[{c_idx}].{prop} — unsupported "
                        f"property '{prop}' on {kind.replace('_', ' ')} "
                        f"'{t_name}'.'{c_name}'.")
            if kind == 'data_column' and 'expression' in c:
                problems.append(
                    f"model.tables[{t_idx}].columns[{c_idx}].expression — imported column "
                    f"'{t_name}'.'{c_name}' must not have an 'expression' property "
                    f"(only calculated columns may); it is also missing type='calculated'.")
            if kind == 'calculated_column' and 'sourceColumn' in c:
                problems.append(
                    f"model.tables[{t_idx}].columns[{c_idx}].sourceColumn — calculated column "
                    f"'{t_name}'.'{c_name}' must not have a 'sourceColumn' property.")
            if kind == 'calculated_column' and 'expression' not in c:
                problems.append(
                    f"model.tables[{t_idx}].columns[{c_idx}] — calculated column "
                    f"'{t_name}'.'{c_name}' is missing its required 'expression' property.")

    log('info', "Checking measures...")
    for t_idx, t in enumerate(tables):
        t_name = t.get('name', f'table[{t_idx}]')
        for m_idx, m in enumerate(t.get('measures', [])):
            m_name = m.get('name', f'measures[{m_idx}]')
            for prop in m.keys():
                if prop not in _TOM_ALLOWED_PROPS['measure']:
                    problems.append(
                        f"model.tables[{t_idx}].measures[{m_idx}].{prop} — unsupported "
                        f"property '{prop}' on measure '{t_name}'.'{m_name}'.")
            if 'expression' not in m:
                problems.append(
                    f"model.tables[{t_idx}].measures[{m_idx}] — measure "
                    f"'{t_name}'.'{m_name}' is missing its required 'expression' property.")

    for t_idx, t in enumerate(tables):
        t_name = t.get('name', f'table[{t_idx}]')
        for p_idx, p in enumerate(t.get('partitions', [])):
            for prop in p.keys():
                if prop not in _TOM_ALLOWED_PROPS['partition']:
                    problems.append(
                        f"model.tables[{t_idx}].partitions[{p_idx}].{prop} — unsupported "
                        f"property on partition for table '{t_name}'.")

    for r_idx, rel in enumerate(model.get('model', {}).get('relationships', [])):
        for prop in rel.keys():
            if prop not in _TOM_ALLOWED_PROPS['relationship']:
                problems.append(
                    f"model.relationships[{r_idx}].{prop} — unsupported property on relationship.")

    log('info', "Validating TOM schema...")
    if problems:
        for p in problems:
            log('warn', f"TOM validation issue: {p}")
    else:
        log('info', "DataModelSchema validation completed successfully.")
    return problems


def validate_pbit_entries(entries: dict) -> list:
    """
    Mandatory package validation, run before every .pbit is accepted.
    Returns a list of human-readable problems (empty list == valid).
    """
    problems = []

    for name in _REQUIRED_ENTRIES:
        if name not in entries:
            problems.append(f"Missing required package part: {name}")

    if '[Content_Types].xml' in entries:
        try:
            ET.fromstring(entries['[Content_Types].xml'].decode('utf-8'))
        except Exception as exc:
            problems.append(f"[Content_Types].xml is not well-formed XML: {exc}")

    for name in _UTF16_JSON_ENTRIES:
        if name not in entries:
            continue
        raw = entries[name]
        if b'\x00\x00' in raw[:2] or len(raw) % 2 != 0:
            # UTF-16LE text should decode cleanly; catch obvious corruption.
            pass
        try:
            text = raw.decode('utf-16-le')
        except UnicodeDecodeError as exc:
            problems.append(f"{name} is not valid UTF-16LE: {exc}")
            continue
        if '\x00' in text:
            problems.append(f"{name} contains embedded NUL characters.")
        # Illegal XML/JSON control characters (Power BI's XMLA layer rejects
        # C0 controls other than TAB/LF/CR).
        if re.search(r'[\x01-\x08\x0b\x0c\x0e-\x1f]', text):
            problems.append(f"{name} contains illegal control characters.")
        try:
            json.loads(text)
        except json.JSONDecodeError as exc:
            problems.append(f"{name} is not valid JSON: {exc}")

    if 'DataModelSchema' in entries and not any(
            p.startswith('DataModelSchema') for p in problems):
        try:
            model = json.loads(entries['DataModelSchema'].decode('utf-16-le'))
            tables = model.get('model', {}).get('tables', [])
            if not tables:
                problems.append("DataModelSchema has zero tables — nothing was migrated.")
            table_names = [t['name'] for t in tables]
            if len(table_names) != len(set(n.lower() for n in table_names)):
                problems.append("DataModelSchema has duplicate table names.")
            lineage_tags = []
            for t in tables:
                lineage_tags.append(t.get('lineageTag'))
                for c in t.get('columns', []):
                    lineage_tags.append(c.get('lineageTag'))
                for m in t.get('measures', []):
                    lineage_tags.append(m.get('lineageTag'))
            lineage_tags = [t for t in lineage_tags if t]
            if len(lineage_tags) != len(set(lineage_tags)):
                problems.append("DataModelSchema has duplicate lineageTag GUIDs.")
            valid_names = set(table_names)
            for t in tables:
                field_names = ([c['name'].lower() for c in t.get('columns', [])] +
                              [m['name'].lower() for m in t.get('measures', [])])
                if len(field_names) != len(set(field_names)):
                    problems.append(
                        f"Table '{t['name']}' has a column/measure name collision "
                        f"(columns and measures share one namespace per table).")
            for rel in model.get('model', {}).get('relationships', []):
                if rel.get('fromTable') not in valid_names or rel.get('toTable') not in valid_names:
                    problems.append(
                        f"Relationship references a table not present in the model: "
                        f"{rel.get('fromTable')} -> {rel.get('toTable')}")
            cycle = _find_one_relationship_cycle(model.get('model', {}).get('relationships', []))
            if cycle:
                problems.append(
                    "Relationship graph contains a cycle (would cause Power BI's "
                    "\"A cyclic reference was encountered\" error): " + " -> ".join(cycle))
        except Exception as exc:
            problems.append(f"DataModelSchema structural validation failed: {exc}")

    # ── Cross-check: every visual's table/field references must resolve
    # against the actual data model — this is exactly the class of defect
    # (a visual pointing at a table/column/measure that doesn't exist) that
    # produces Power BI's "Something's wrong with one or more fields" error.
    if ('DataModelSchema' in entries and 'Report/Layout' in entries
            and not any(p.startswith('DataModelSchema') or p.startswith('Report/Layout')
                       for p in problems)):
        try:
            model = json.loads(entries['DataModelSchema'].decode('utf-16-le'))
            layout = json.loads(entries['Report/Layout'].decode('utf-16-le'))
            tables_by_name = {t['name']: t for t in model.get('model', {}).get('tables', [])}
            for section in layout.get('sections', []):
                for vc in section.get('visualContainers', []):
                    try:
                        cfg = json.loads(vc.get('config', '{}'))
                    except json.JSONDecodeError:
                        continue
                    proto = cfg.get('singleVisual', {}).get('prototypeQuery')
                    if not proto:
                        continue
                    for frm in proto.get('From', []):
                        entity = frm.get('Entity')
                        if entity and entity not in tables_by_name:
                            problems.append(
                                f"Visual '{cfg.get('name', '?')}' on page "
                                f"'{section.get('displayName', '?')}' references "
                                f"table '{entity}', which does not exist in the "
                                f"data model.")
                    field_names = set()
                    for t in tables_by_name.values():
                        field_names.update(c['name'] for c in t.get('columns', []))
                        field_names.update(m['name'] for m in t.get('measures', []))
                    for sel in proto.get('Select', []):
                        prop = (sel.get('Column') or sel.get('Measure') or {}).get('Property')
                        if prop and prop not in field_names:
                            problems.append(
                                f"Visual '{cfg.get('name', '?')}' on page "
                                f"'{section.get('displayName', '?')}' references "
                                f"field '{prop}', which does not exist in the "
                                f"data model.")
        except Exception as exc:
            problems.append(f"Visual/field reference cross-validation failed: {exc}")

    return problems


# ═══════════════════════════════════════════════════════════════════════════
# TMDL (Tabular Model Definition Language) semantic-model writer
# ═══════════════════════════════════════════════════════════════════════════
#
# Re-serializes the SAME already-built, already-validated TOM schema dict
# (build_data_model_schema's return value) that write_pbit uses -- into the
# newer .pbip project's TMDL text format instead of the legacy zipped
# DataModelSchema JSON blob. No new extraction or conversion logic here;
# only the output serialization differs.


# ═══════════════════════════════════════════════════════════════════════════
# PBIP output validation layer — every file below is validated immediately
# before it touches disk. A file that fails validation is never written;
# the caller gets a clear log of exactly what was wrong and where, instead
# of a "Object reference not set to an instance of an object." from Power
# BI Desktop with no indication of which file or property caused it.
# ═══════════════════════════════════════════════════════════════════════════

_GUID_RE = re.compile(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')


def _validate_json_serializable(obj, label: str) -> list:
    """Confirm an object can actually be serialized to valid JSON at all
    (catches NaN/Infinity floats, non-string dict keys after transformation,
    circular references, etc. — anything that would otherwise only surface
    as a write-time crash or a file Power BI Desktop can't parse)."""
    try:
        text = json.dumps(obj, allow_nan=False)
    except (TypeError, ValueError) as exc:
        return [f"{label}: object is not valid JSON — {exc}"]
    try:
        json.loads(text)
    except json.JSONDecodeError as exc:
        return [f"{label}: round-trip JSON parse failed — {exc}"]
    return []


def _validate_tmdl_identifier_quoting(text: str, label: str) -> list:
    """
    Structural TMDL sanity check: every identifier this writer emits after
    a 'table'/'column'/'measure'/'relationship'/'hierarchy'/'level'/
    'partition'/'ref table' keyword, and every value after a
    'sourceColumn:'/'fromColumn:'/'toColumn:' property, must either be a
    bare [A-Za-z_][A-Za-z0-9_]* identifier or a properly single-quoted one
    — exactly the rule _tmdl_quote_name() itself enforces. A bare
    identifier containing a space or other special character is invalid
    TMDL that fails to deserialize in Power BI Desktop (this is precisely
    the class of bug that previously broke relationship/column loading).
    """
    problems = []
    keyword_re = re.compile(
        r"^(?:table|column|measure|relationship|hierarchy|level|partition|ref table)\s+(.+?)"
        r"(?:\s*=.*)?$")
    prop_re = re.compile(r"^\s*(?:sourceColumn|fromColumn|toColumn)\s*:\s*(.+?)\s*$")

    def _is_properly_quoted_or_bare(token: str) -> bool:
        token = token.strip()
        if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', token):
            return True
        if token.startswith("'") and token.endswith("'") and len(token) >= 2:
            return True
        return False

    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip('\t')
        m = keyword_re.match(line)
        if m:
            ident = m.group(1).strip()
            if not _is_properly_quoted_or_bare(ident):
                problems.append(f"{label}: line {line_no}: identifier {ident!r} contains "
                                f"special characters but is not single-quoted — invalid TMDL.")
            continue
        m = prop_re.match(line)
        if m:
            value = m.group(1).strip()
            # A qualified reference like Table.'Column Name' or 'Table'.Column
            # is valid — check each dotted segment independently rather than
            # the value as a whole.
            for seg in value.split('.'):
                if not _is_properly_quoted_or_bare(seg):
                    problems.append(f"{label}: line {line_no}: reference segment {seg!r} in "
                                    f"{value!r} contains special characters but is not "
                                    f"single-quoted — invalid TMDL.")
    return problems


def _validate_relationship_bindings(relationships: list, tables: list) -> list:
    """Every relationship's fromTable/toTable must exist in the model,
    fromColumn/toColumn must exist as a real column on that table, and its
    cardinality orientation must be valid for Power BI's TOM/TMDL model:
    the From end's cardinality must be Many, unless the relationship is
    One-To-One (Power BI Desktop rejects "From: One, To: Many" outright —
    it insists the many/foreign-key side be the From end). An invalid
    reference or orientation here is exactly what produces a null/rejected
    relationship object when Power BI Desktop tries to load it."""
    problems = []
    columns_by_table = {t['name']: {c['name'] for c in t.get('columns', [])} for t in tables}
    table_names = set(columns_by_table.keys())
    for idx, rel in enumerate(relationships):
        from_t, to_t = rel.get('fromTable'), rel.get('toTable')
        from_c, to_c = rel.get('fromColumn'), rel.get('toColumn')
        if from_t not in table_names:
            problems.append(f"relationships[{idx}]: fromTable '{from_t}' does not exist in the model.")
        elif from_c not in columns_by_table.get(from_t, set()):
            problems.append(f"relationships[{idx}]: fromColumn '{from_c}' does not exist on table '{from_t}'.")
        if to_t not in table_names:
            problems.append(f"relationships[{idx}]: toTable '{to_t}' does not exist in the model.")
        elif to_c not in columns_by_table.get(to_t, set()):
            problems.append(f"relationships[{idx}]: toColumn '{to_c}' does not exist on table '{to_t}'.")

        from_card, to_card = rel.get('fromCardinality'), rel.get('toCardinality')
        if from_card == 'one' and to_card and to_card != 'one':
            problems.append(
                f"relationships[{idx}]: '{rel.get('name', f'{from_t}->{to_t}')}' has From "
                f"end cardinality 'one' (From='{from_t}'[{from_c}], To='{to_t}'[{to_c}], "
                f"To cardinality='{to_card}') — Power BI requires the From end to be Many "
                f"unless the relationship is One-To-One. The Many/foreign-key side "
                f"('{to_t}') must be the From end; swap fromTable/fromColumn with "
                f"toTable/toColumn.")
    return problems


def _validate_visual_json(visual_obj: dict, fields_by_table: dict, label: str) -> list:
    """
    Validate one PBIR visual.json object before it's written:
      - required top-level shape (name, position, visual.visualType) present
      - position coordinates are numeric and width/height are positive
      - every field projection in query.queryState resolves to a real
        column or measure on a real table in the semantic model — an
        unresolvable Entity/Property reference is exactly what produces a
        null field binding when Power BI Desktop loads the report.
    fields_by_table: {table_name: {field_name, ...}} covering both columns
    and measures.
    """
    problems = []
    name = visual_obj.get('name')
    if not name or not isinstance(name, str):
        problems.append(f"{label}: visual is missing a required 'name'.")

    position = visual_obj.get('position')
    if not isinstance(position, dict):
        problems.append(f"{label}: visual is missing a required 'position' object.")
    else:
        for key in ('x', 'y', 'width', 'height'):
            val = position.get(key)
            if not isinstance(val, (int, float)) or isinstance(val, bool):
                problems.append(f"{label}: position.{key} is missing or not numeric ({val!r}).")
        for key in ('width', 'height'):
            val = position.get(key)
            if isinstance(val, (int, float)) and not isinstance(val, bool) and val <= 0:
                problems.append(f"{label}: position.{key} must be greater than 0 (got {val!r}).")

    visual = visual_obj.get('visual')
    if not isinstance(visual, dict) or not visual.get('visualType'):
        problems.append(f"{label}: visual.visualType is missing.")
        return problems  # nothing further to check without a visual type

    query_state = (visual.get('query') or {}).get('queryState') or {}
    if not isinstance(query_state, dict):
        problems.append(f"{label}: visual.query.queryState must be an object.")
        return problems

    for role, role_obj in query_state.items():
        projections = (role_obj or {}).get('projections') or []
        for p_idx, proj in enumerate(projections):
            field = proj.get('field') or {}
            for kind in ('Column', 'Measure'):
                if kind not in field:
                    continue
                entity = field[kind].get('Expression', {}).get('SourceRef', {}).get('Entity')
                prop = field[kind].get('Property')
                if not entity or not prop:
                    problems.append(f"{label}: query.queryState.{role}.projections[{p_idx}] "
                                    f"is missing Entity/Property on its {kind} field.")
                    continue
                if entity not in fields_by_table:
                    problems.append(f"{label}: query.queryState.{role}.projections[{p_idx}] "
                                    f"references table '{entity}', which does not exist in "
                                    f"the semantic model.")
                elif prop not in fields_by_table.get(entity, set()):
                    problems.append(f"{label}: query.queryState.{role}.projections[{p_idx}] "
                                    f"references '{entity}.{prop}', which does not exist as a "
                                    f"column or measure on table '{entity}'.")
    return problems


# Visual types that are legitimately allowed to have an empty queryState —
# pure decoration/text/navigation, never bound to data.
_TEXT_ONLY_VISUAL_TYPES = {'textbox', 'image', 'actionButton', 'basicShape', 'shape'}


def _validate_visual_not_empty(visual_obj: dict, label: str) -> list:
    """
    A data-bound visual (table, chart, matrix, card, etc.) with ZERO field
    projections in every role is technically well-formed JSON but is a
    useless visual that shows nothing — and in practice is exactly the
    kind of "visual" that should never have been generated in the first
    place rather than being written and silently failing to render.
    Text/image/shape visuals are exempt since they're never data-bound.
    """
    visual = visual_obj.get('visual') or {}
    visual_type = visual.get('visualType', '')
    if visual_type in _TEXT_ONLY_VISUAL_TYPES:
        return []
    query_state = (visual.get('query') or {}).get('queryState') or {}
    total_projections = sum(len((role_obj or {}).get('projections') or [])
                            for role_obj in query_state.values())
    if total_projections == 0:
        return [f"{label}: visual type '{visual_type}' has no field bindings at all "
               f"(empty queryState) — would render as a blank/broken visual."]
    return []


def _log_file_validation(filename: str, ok: bool, problems: list, warnings: list = None) -> None:
    """
    One consistent structured log entry per generated file, covering
    exactly what the PBIP generation policy requires visibility into:
    file name, validation result, every error found, every warning, and
    an overall Power BI compatibility verdict.
    """
    warnings = warnings or []
    status = "PASSED — Power BI Desktop compatible" if ok else \
        "FAILED — NOT written (would break Power BI Desktop)"
    log('info' if ok else 'error',
        f"[validate] {filename}: {status} | errors: {len(problems)} | warnings: {len(warnings)}")
    for p in problems:
        log('error', f"[validate] {filename}: ERROR — {p}")
    for w in warnings:
        log('warn', f"[validate] {filename}: WARNING — {w}")


def _validate_and_write_json(path: Path, obj: dict, label: str, extra_problems: list = None) -> bool:
    """
    Validate then write one JSON file. Returns True if written, False if
    validation failed (in which case the file is NOT written and every
    problem is logged as an error) — "if a required object is missing or
    invalid, do not write the invalid file" applied uniformly to every
    JSON part of the PBIP/PBIR output.
    """
    problems = list(extra_problems or [])
    problems += _validate_json_serializable(obj, label)
    ok = not problems
    _log_file_validation(path.name, ok, problems)
    if not ok:
        return False
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')
    return True


def _strip_tmdl_annotation_lines(text: str) -> str:
    """Return text with every 'annotation NAME = VALUE' line blanked out.
    Annotations are opaque metadata -- TMDL/Power BI never parses their
    value as DAX or as a TMDL keyword -- so a deliberately-preserved
    OriginalCognosExpression annotation (which legitimately contains
    CASE/WHEN/END, by design, per the fail-safe formula-conversion policy)
    must not trip the raw-Cognos-syntax scan the way a real, evaluated
    column/measure expression must."""
    return '\n'.join(
        '' if line.strip().startswith('annotation ') else line
        for line in text.splitlines())


def _validate_and_write_tmdl(path: Path, text: str, label: str, extra_problems: list = None) -> bool:
    """Validate then write one TMDL file. Same do-not-write-if-invalid
    contract as _validate_and_write_json, using TMDL-specific checks
    (identifier quoting) instead of JSON serializability.

    Validation 4 (model-wide, pre-write scan): also runs
    validate_no_cognos_syntax() against the FULLY RENDERED file text
    (annotation lines excluded -- see _strip_tmdl_annotation_lines), not
    just the individual expressions that fed into it. This is the single
    chokepoint every generated .tmdl file passes through — database.tmdl,
    model.tmdl, cultures/en-US.tmdl, relationships.tmdl, and every table
    file — so it catches a raw Cognos CASE/WHEN/END (or any other
    untranslated construct) reaching disk *as a live expression* regardless
    of which code path put it there, including any future call site that
    builds a calculated column or measure without going through
    cognos_expr_to_dax at all — while still allowing the fail-safe
    formula-conversion policy to legitimately preserve the original Cognos
    source text as OriginalCognosExpression/MigrationComment annotation
    metadata for manual review, per the migration spec.
    """
    problems = list(extra_problems or [])
    problems += _validate_tmdl_identifier_quoting(text, label)
    cognos_syntax_problems = validate_no_cognos_syntax(_strip_tmdl_annotation_lines(text))
    if cognos_syntax_problems:
        problems += [f"{label}: {p}" for p in cognos_syntax_problems]
    ok = not problems
    _log_file_validation(path.name, ok, problems)
    if not ok:
        return False
    path.write_text(text, encoding='utf-8')
    return True


def _validate_no_duplicate_ids(ids: list, kind: str) -> list:
    """Flag any duplicate visual/page/table identifier — a duplicate GUID
    or name is exactly what makes Power BI Desktop resolve a reference to
    the wrong (or a null) object at load time."""
    seen, dupes = set(), set()
    for i in ids:
        if i in seen:
            dupes.add(i)
        seen.add(i)
    return [f"duplicate {kind} id: {d!r}" for d in sorted(dupes)]


def _tmdl_quote_name(name: str) -> str:
    """TMDL identifiers containing anything other than letters/digits/
    underscore must be single-quoted, matching DAX's own quoting rule."""
    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', name or ''):
        return name
    return "'" + (name or '').replace("'", "''") + "'"


def _tmdl_indent(text: str, levels: int) -> str:
    prefix = '\t' * levels
    return '\n'.join((prefix + line if line.strip() else '') for line in text.splitlines())


def _tmdl_column_block(col: dict) -> str:
    lines = [f"column {_tmdl_quote_name(col['name'])}"]
    if col.get('type') == 'calculated':
        lines[0] += f" = {col['expression']}"
    lines.append(f"\tdataType: {col.get('dataType', 'string')}")
    if col.get('formatString'):
        lines.append(f"\tformatString: {col['formatString']}")
    lines.append(f"\tlineageTag: {col.get('lineageTag', _guid())}")
    if col.get('isHidden'):
        lines.append("\tisHidden")
    summarize_by = col.get('summarizeBy', 'none')
    lines.append(f"\tsummarizeBy: {summarize_by}")
    if col.get('dataCategory'):
        lines.append(f"\tdataCategory: {col['dataCategory']}")
    if col.get('displayFolder'):
        lines.append(f"\tdisplayFolder: {_tmdl_quote_name(col['displayFolder'])}")
    if col.get('type') != 'calculated':
        lines.append(f"\tsourceColumn: {_tmdl_quote_name(col.get('sourceColumn', col['name']))}")
    body = lines[0] + '\n' + '\n'.join(l if l.startswith('\t') else '\t' + l for l in lines[1:])
    # Annotations sit in their own block, separated from the properties
    # above by a blank line -- confirmed via a real Desktop-generated file.
    ann_lines = [f"\tannotation {ann['name']} = {_tmdl_annotation_safe_value(ann['value'])}" for ann in col.get('annotations', [])]
    if ann_lines:
        body += '\n\n' + '\n'.join(ann_lines)
    return body


def _tmdl_annotation_safe_value(text: str) -> str:
    """TMDL is line-oriented: a property/annotation value must be a single
    physical line. Collapse any newlines/runs of whitespace in an
    annotation value (e.g. a multi-line Cognos CASE expression being
    preserved as OriginalCognosExpression metadata) down to single spaces
    so it can never break the file's line structure."""
    return re.sub(r'\s+', ' ', text or '').strip()


def _tmdl_measure_block(m: dict) -> str:
    lines = [f"measure {_tmdl_quote_name(m['name'])} = {m['expression']}"]
    lines.append(f"\tlineageTag: {m.get('lineageTag', _guid())}")
    if m.get('formatString'):
        lines.append(f"\tformatString: {m['formatString']}")
    if m.get('displayFolder'):
        lines.append(f"\tdisplayFolder: {_tmdl_quote_name(m['displayFolder'])}")
    if m.get('isHidden'):
        lines.append("\tisHidden")
    body = '\n'.join(lines)
    # Annotations sit in their own block after a blank line, at the same
    # indentation as the measure's own property lines -- same convention
    # already used for columns in _tmdl_column_block.
    ann_lines = [f"\tannotation {ann['name']} = {_tmdl_annotation_safe_value(ann['value'])}"
                for ann in m.get('annotations', [])]
    if ann_lines:
        body += '\n\n' + '\n'.join(ann_lines)
    return body


def _tmdl_hierarchy_block(h: dict) -> str:
    lines = [f"hierarchy {_tmdl_quote_name(h['name'])}", f"\tlineageTag: {h.get('lineageTag', _guid())}", ""]
    for lvl in h.get('levels', []):
        lines.append(f"\tlevel {_tmdl_quote_name(lvl['name'])}")
        lines.append(f"\t\tlineageTag: {lvl.get('lineageTag', _guid())}")
        lines.append(f"\t\tcolumn: {_tmdl_quote_name(lvl['column'])}")
        lines.append("")
    return '\n'.join(lines).rstrip()


def _tmdl_partition_block(table_name: str, partition: dict) -> str:
    src = partition.get('source', {})
    m_lines = src.get('expression', [])
    if isinstance(m_lines, str):
        m_lines = m_lines.splitlines()
    m_text = '\n'.join(m_lines)
    # M-code body indentation confirmed via byte-level inspection of a real
    # Desktop-generated file: 4 tabs total (1 from the table-level wrap this
    # block gets passed through + 3 added here), not 3 total as previously coded.
    lines = [f"partition {_tmdl_quote_name(table_name)} = m",
            f"\tmode: {partition.get('mode', 'import')}",
            "\tsource =",
            _tmdl_indent(m_text, 3)]
    return '\n'.join(lines)


def _tmdl_table_file(table: dict) -> str:
    parts = [f"table {_tmdl_quote_name(table['name'])}",
             f"\tlineageTag: {table.get('lineageTag', _guid())}"]
    if table.get('isHidden'):
        parts.append("\tisHidden")
    parts.append("")
    for col in table.get('columns', []):
        parts.append(_tmdl_indent(_tmdl_column_block(col), 1))
        parts.append("")
    for m in table.get('measures', []):
        parts.append(_tmdl_indent(_tmdl_measure_block(m), 1))
        parts.append("")
    for h in table.get('hierarchies', []):
        parts.append(_tmdl_indent(_tmdl_hierarchy_block(h), 1))
        parts.append("")
    for p in table.get('partitions', []):
        parts.append(_tmdl_indent(_tmdl_partition_block(table['name'], p), 1))
        parts.append("")
    # Table-level annotations sit at the same indentation as column/
    # partition lines (one tab) -- confirmed via precise byte-level
    # inspection of a real Desktop-generated file.
    annotations = list(table.get('annotations', []))
    if table.get('partitions') and not any(a['name'] == 'PBI_ResultType' for a in annotations):
        # Desktop always records this for any table backed by a partition.
        annotations.append({'name': 'PBI_ResultType', 'value': 'Table'})
    for ann in annotations:
        parts.append(f"\tannotation {ann['name']} = {ann['value']}")
    return '\n'.join(parts).rstrip() + '\n'


def _tmdl_relationships_file(relationships: list) -> str:
    blocks = []
    for rel in relationships:
        rel_id = rel.get('name') or _guid()
        # The relationship's own identifier must be quoted exactly like
        # every other TMDL identifier in this file (table/column names)
        # whenever it contains anything beyond letters/digits/underscore.
        # Relationship names here are built from column names (e.g.
        # "Customer ID"), so they almost always contain spaces — emitting
        # that as a bare identifier produces invalid TMDL that fails to
        # deserialize in Power BI Desktop (this was previously the one
        # identifier in the whole TMDL writer NOT run through
        # _tmdl_quote_name, and it silently broke every relationship whose
        # join columns had a space or other special character in their name).
        lines = [f"relationship {_tmdl_quote_name(rel_id)}"]
        if not rel.get('isActive', True):
            lines.append("\tisActive: false")
        if rel.get('crossFilteringBehavior') == 'bothDirections':
            lines.append("\tcrossFilteringBehavior: bothDirections")
        lines.append(f"\tfromColumn: {_tmdl_quote_name(rel['fromTable'])}.{_tmdl_quote_name(rel['fromColumn'])}")
        lines.append(f"\ttoColumn: {_tmdl_quote_name(rel['toTable'])}.{_tmdl_quote_name(rel['toColumn'])}")
        if rel.get('fromCardinality'):
            lines.append(f"\tfromCardinality: {rel['fromCardinality']}")
        if rel.get('toCardinality'):
            lines.append(f"\ttoCardinality: {rel['toCardinality']}")
        blocks.append('\n'.join(lines))
    return '\n\n'.join(blocks) + ('\n' if blocks else '')


def _tmdl_model_file(schema: dict) -> str:
    # Confirmed via a real Power BI Desktop-generated PBIP:
    #  - annotations are top-level, unindented, each separated by a blank
    #    line (NOT indented as properties of 'model' as previously written)
    #  - a dataAccessOptions block with legacyRedirects/returnErrorValuesAsNull
    #    is present under model
    #  - __PBI_TimeIntelligenceEnabled and PBI_ProTooling annotations are
    #    present (previously missing entirely)
    #  - the culture reference is 'ref cultureInfo en-US', not a path-style
    #    'ref cultures/en-US' (which is not valid TMDL -- 'ref' takes an
    #    object type and name, not a folder path)
    lines = [
        "model Model",
        "\tculture: en-US",
        "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
        "\tsourceQueryCulture: en-US",
        "\tdataAccessOptions",
        "\t\tlegacyRedirects",
        "\t\treturnErrorValuesAsNull",
        "",
        "annotation __PBI_TimeIntelligenceEnabled = 1",
        "",
        "annotation PBI_QueryOrder = " + json.dumps([t['name'] for t in schema['model']['tables']]),
        "",
        "annotation PBI_ProTooling = [\"DevMode\"]",
        "",
    ]
    for t in schema['model']['tables']:
        lines.append(f"ref table {_tmdl_quote_name(t['name'])}")
    lines.append("")
    lines.append("ref cultureInfo en-US")
    return '\n'.join(lines) + '\n'


def _tmdl_database_file(schema: dict) -> str:
    # Confirmed via a real Power BI Desktop-generated PBIP: the database
    # object is unnamed (bare 'database' line, no name after it) and the
    # compatibility level is 1600 -- both differ from what this previously
    # generated (a quoted name, and compatibilityLevel 1550).
    return f"database\n\tcompatibilityLevel: {schema.get('compatibilityLevel', 1600)}\n"


def _tmdl_culture_file(culture: str = 'en-US') -> str:
    # Confirmed via a real Power BI Desktop-generated PBIP: this file is
    # plain TMDL syntax (a bare cultureInfo object declaration), NOT JSON.
    # Writing JSON here (the previous behavior) produced a .tmdl file that
    # cannot be parsed by Power BI Desktop's TMDL loader.
    return f"cultureInfo {culture}\n\n"


def write_tmdl_semantic_model(schema: dict, semantic_model_dir: Path) -> bool:
    """
    Write a complete <name>.SemanticModel/definition/ folder from an
    already-built TOM schema dict — database.tmdl, model.tmdl, one
    tables/<name>.tmdl per table, and relationships.tmdl. Every file is
    validated immediately before it's written; a file that fails
    validation is skipped (and logged) rather than written broken.
    Returns True only if every file wrote successfully.
    """
    definition_dir = semantic_model_dir / "definition"
    tables_dir = definition_dir / "tables"
    cultures_dir = definition_dir / "cultures"
    tables_dir.mkdir(parents=True, exist_ok=True)
    cultures_dir.mkdir(parents=True, exist_ok=True)

    tables = schema['model']['tables']
    all_ok = True

    lineage_tags = [t.get('lineageTag') for t in tables if t.get('lineageTag')]
    for t in tables:
        for c in t.get('columns', []) + t.get('measures', []):
            if c.get('lineageTag'):
                lineage_tags.append(c['lineageTag'])
    dup_problems = _validate_no_duplicate_ids(lineage_tags, 'lineageTag')
    for p in dup_problems:
        log('error', f"Validation failed — model: {p}")
    all_ok = all_ok and not dup_problems

    all_ok &= _validate_and_write_tmdl(
        definition_dir / "database.tmdl", _tmdl_database_file(schema), "database.tmdl")
    all_ok &= _validate_and_write_tmdl(
        definition_dir / "model.tmdl", _tmdl_model_file(schema), "model.tmdl")
    all_ok &= _validate_and_write_tmdl(
        cultures_dir / "en-US.tmdl", _tmdl_culture_file(), "cultures/en-US.tmdl")

    for t in tables:
        safe_name = re.sub(r'[\\/:*?"<>|]', '_', t['name'])
        all_ok &= _validate_and_write_tmdl(
            tables_dir / f"{safe_name}.tmdl", _tmdl_table_file(t), f"tables/{safe_name}.tmdl")

    relationships = schema['model'].get('relationships') or []
    if relationships:
        rel_problems = _validate_relationship_bindings(relationships, tables)
        all_ok &= _validate_and_write_tmdl(
            definition_dir / "relationships.tmdl",
            _tmdl_relationships_file(relationships), "relationships.tmdl",
            extra_problems=rel_problems)

    all_ok &= _validate_and_write_json(
        semantic_model_dir / "definition.pbism",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
         "version": "4.2", "settings": {}}, "definition.pbism")

    all_ok &= _validate_and_write_json(
        semantic_model_dir / ".platform",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
         "metadata": {"type": "SemanticModel", "displayName": schema.get('name', 'Model')},
         "config": {"version": "2.0", "logicalId": _guid()}},
        "SemanticModel/.platform")

    return all_ok


def _write_pbip_manifest(project_dir: Path, project_name: str, has_report: bool) -> bool:
    """Write the top-level <name>.pbip manifest that Power BI Desktop opens
    directly — it just points at the semantic model (and report, if
    present) sub-folders by relative path. Validated like every other
    output file before being written."""
    artifacts = [{"report": {"path": f"{project_name}.Report"}}] if has_report else \
        [{"semanticModel": {"path": f"{project_name}.SemanticModel"}}]
    manifest = {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
        "version": "1.0",
        "artifacts": artifacts,
        "settings": {"enableAutoRecovery": True},
    }
    return _validate_and_write_json(
        project_dir / f"{project_name}.pbip", manifest, f"{project_name}.pbip")


def write_pbip_semantic_model_only(report: dict, output_dir: Path,
                                   embed_sample_data: bool = False,
                                   source_data_folder=None) -> Path:
    """
    Case 2 — a Framework Manager model with no accompanying report: build
    the full semantic model (reusing build_data_model_schema exactly as
    write_pbit does) and package it as a complete .pbip project containing
    ONLY a <name>.SemanticModel folder — no report pages, per the
    "semantic-model-only" workflow.

    Returns the path to the generated .pbip manifest file.
    """
    project_name = _safe_pbi_name(report.get('name') or 'Model')
    project_dir = output_dir / project_name
    project_dir.mkdir(parents=True, exist_ok=True)

    log('info', "Extracting Semantic Model...")
    schema = build_data_model_schema(report, embed_sample_data=embed_sample_data,
                                     source_data_folder=source_data_folder,
                                     output_dir=project_dir, materialize_files=True)

    tom_problems = _validate_tom_schema(schema)
    if tom_problems:
        for p in tom_problems:
            log('warn', f"Semantic model validation: {p}")

    log('info', "Building Power BI Semantic Model...")
    semantic_model_dir = project_dir / f"{project_name}.SemanticModel"
    model_ok = write_tmdl_semantic_model(schema, semantic_model_dir)

    log('info', "Generating Power BI Project...")
    manifest_ok = _write_pbip_manifest(project_dir, project_name, has_report=False)

    if not (model_ok and manifest_ok):
        raise RuntimeError(
            "PBIP generation aborted — one or more semantic model files failed pre-write "
            "validation (see the error log above for exactly which file and property).")

    log('info', f"Migration Completed Successfully. -> {project_dir / (project_name + '.pbip')}")
    return project_dir / f"{project_name}.pbip"


def merge_framework_manager_with_report(fm_report: dict, report_report: dict) -> dict:
    """
    Case 3 — both a Framework Manager model AND a report specification were
    uploaded together: the FM model is the authoritative semantic model
    (its tables, columns, relationships, hierarchies win), and every one of
    the report's OWN query items is resolved against it via
    resolve_report_item_to_framework_table() instead of building separate
    "Query1"/"Query2"/... tables — so the generated report binds directly
    to the Framework Manager-derived model with no orphan tables and no
    manual relationship/field re-mapping needed after opening the project.

    Matching strategy, per item (delegated to
    resolve_report_item_to_framework_table -- see there for the full
    priority order): a report data item's own Cognos EXPRESSION
    ("[HR Enterprise Reporting].[Employee].[Employee ID]") is resolved
    against the Framework Manager model's Presentation Layer folder/item
    structure, which is what a report author actually drags fields from in
    Report Studio — NOT the report query's own often-generic internal name
    ("Query1"), and not a name-only guess. A report ITEM name is only ever
    used as a last resort, for the rare item with no usable expression at
    all (a purely report-local calculation with no package ancestry).

    A report query is only ever kept as its own standalone table if
    LITERALLY NONE of its items resolve to the Framework Manager model —
    even a single resolved field is enough to prove the query is
    package-bound, at which point every field (resolved or not) is routed
    onto the Framework Manager table(s) its data actually belongs to,
    never flattened into a new table of its own. This is what "a report
    query referencing multiple Framework Manager tables must bind each
    field to its real table, not become one new flattened table" means in
    practice — relationships between those real tables already exist in
    the semantic model, so Power BI resolves the cross-table binding
    automatically once every field points at its real home.
    """
    merged = _new_report_skeleton(report_report.get('name', fm_report.get('name', 'Model')))
    merged['name'] = report_report.get('name') or fm_report.get('name')
    merged['_artifact_type'] = 'merged'
    merged['warnings'] = list(fm_report.get('warnings', []))
    merged['relationships'] = list(fm_report.get('relationships', []))
    merged['pages'] = report_report.get('pages', [])
    merged['parameters'] = report_report.get('parameters', [])

    merged['queries'] = [dict(q, items=list(q['items'])) for q in fm_report.get('queries', [])]
    queries_by_name = {q['name'].lower(): q for q in merged['queries']}
    # Tracks which item names each FM table already carries, kept up to
    # date as report-only fields get appended, so the SAME report-only
    # field referenced by two different report queries is only ever added
    # to its target table once.
    existing_item_names_by_table = {
        q['name'].lower(): {it['name'].lower() for it in q['items']} for q in merged['queries']
    }

    item_table_by_query: dict = {}
    unmatched_report_queries = 0

    for rq in report_report.get('queries', []):
        item_table_by_query[rq['name']] = {}
        table_hit_counts: dict = {}
        truly_unresolved = []

        for it in rq['items']:
            fw_table, fw_col = resolve_report_item_to_framework_table(it, fm_report)
            if fw_table is None:
                truly_unresolved.append(it)
                continue

            table_hit_counts[fw_table] = table_hit_counts.get(fw_table, 0) + 1
            item_table_by_query[rq['name']][it['name']] = fw_table

            existing = existing_item_names_by_table.setdefault(fw_table.lower(), set())
            already_present = fw_col and fw_col.lower() in existing
            if already_present:
                continue
            # Either the folder/table resolved but no column of this exact
            # name exists yet (fw_col is None -- e.g. a report-renamed
            # alias), or this is a genuine report-only field under a real
            # FM table: add it once, keyed by whichever name it'll actually
            # be written under.
            add_key = (fw_col or it['name']).lower()
            if add_key in existing:
                continue
            existing.add(add_key)
            queries_by_name[fw_table.lower()]['items'].append(it)
            log('info', f"Report-only field '{it['name']}' from query '{rq['name']}' added to "
                        f"table '{fw_table}' (resolved via its Cognos expression; not present "
                        f"verbatim in the Framework Manager model).")

        if not table_hit_counts:
            # Genuinely no relationship to the FM model at all -- keep as
            # its own table (graceful fallback, same as Case 1 behaviour),
            # rather than silently dropping data that has nowhere else to go.
            merged['queries'].append(rq)
            item_table_by_query[rq['name']] = {it['name']: rq['name'] for it in rq['items']}
            unmatched_report_queries += 1
            log('warn', f"Report query '{rq['name']}' has no field that resolves to the "
                        f"Framework Manager model — migrated as its own separate table.")
            continue

        if truly_unresolved:
            primary_table = max(table_hit_counts, key=table_hit_counts.get)
            for it in truly_unresolved:
                item_table_by_query[rq['name']][it['name']] = primary_table
                existing = existing_item_names_by_table.setdefault(primary_table.lower(), set())
                if it['name'].lower() in existing:
                    continue
                existing.add(it['name'].lower())
                queries_by_name[primary_table.lower()]['items'].append(it)
                log('info', f"Report-only field '{it['name']}' from query '{rq['name']}' added "
                            f"to table '{primary_table}' (no Framework Manager match found for "
                            f"this specific field).")

        if len(table_hit_counts) > 1:
            tables_touched = sorted(table_hit_counts)
            log('info', f"Report query '{rq['name']}' is a flattened query spanning "
                        f"{len(tables_touched)} Framework Manager table(s) "
                        f"({', '.join(tables_touched)}) — each field was bound to its own real "
                        f"table instead of being migrated as one new flattened table.")

    merged['_item_table_by_query_override'] = item_table_by_query
    if unmatched_report_queries == 0:
        log('info', "Every report query's fields resolved to the Framework Manager model via "
                    "their own Cognos expressions — the report will bind directly to it with no "
                    "orphan query tables (no 'Query1'/'Query2'/...) and no manual field mapping "
                    "required.")
    return merged


# ═══════════════════════════════════════════════════════════════════════════
# PBIR (Power BI Report definition) writer — the modern per-file report
# format used inside a .pbip project's <name>.Report folder.
# ═══════════════════════════════════════════════════════════════════════════
#
# HONESTY NOTE: this is the lowest-confidence piece of the whole PBIP
# pipeline. The legacy Report/Layout blob (used for .pbit, generated by
# build_report_layout above) has been tested against real Cognos XML
# throughout this project. The newer per-file PBIR format used here is
# reconstructed from documentation/training knowledge, not verified against
# a real Power BI Desktop "open" — the exact property names may need a
# follow-up fix once tried against real Desktop. It is NOT fabricated
# placeholder content though: every visual's type, position, and field
# bindings come directly from the same already-working
# parse_cognos_visual()/build_report_layout() extraction used for .pbit.

def _pbir_queryref_to_field(query_ref: str, select_by_name: dict, alias_to_entity: dict) -> dict:
    """
    Reconstruct a full PBIR field expression for one queryRef (e.g.
    "SalesQuery.Revenue") from the legacy visual's own prototypeQuery.Select
    entry — which already carries the correct Column-vs-Measure kind and
    Entity/Property, just using the legacy "SourceRef.Source" alias
    convention instead of PBIR's "SourceRef.Entity" convention. Falls back
    to a best-effort Column guess (splitting "Table.Field") if no matching
    Select entry is found, rather than emitting nothing.
    """
    sel = select_by_name.get(query_ref)
    if sel is not None:
        for kind in ("Column", "Measure"):
            if kind in sel:
                alias = sel[kind].get("Expression", {}).get("SourceRef", {}).get("Source")
                entity = alias_to_entity.get(alias, alias)
                prop = sel[kind].get("Property")
                return {kind: {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}
    if "." in query_ref:
        entity, prop = query_ref.split(".", 1)
        return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}
    return {"Column": {"Expression": {"SourceRef": {"Entity": ""}}, "Property": query_ref}}


def _pbir_query_state(single_visual: dict) -> dict:
    """
    Build a real PBIR queryState object from the legacy visual's
    projections + prototypeQuery — every role (Category/Y/Values/...) maps
    to {"projections": [...]}, NOT directly to a bare list of refs (that
    was the actual bug behind visuals opening with no fields bound: Power
    BI Desktop doesn't recognize a role pointing straight at an array, so
    every binding was silently ignored even though the container, position,
    and visual type all rendered correctly).
    """
    proto = single_visual.get('prototypeQuery', {})
    select_by_name = {s.get('Name'): s for s in proto.get('Select', [])}
    alias_to_entity = {f.get('Name'): f.get('Entity') for f in proto.get('From', [])}

    query_state = {}
    for role, refs in (single_visual.get('projections') or {}).items():
        projections = []
        for i, ref in enumerate(refs):
            query_ref = ref.get('queryRef', '')
            field = _pbir_queryref_to_field(query_ref, select_by_name, alias_to_entity)
            native_ref = query_ref.split('.', 1)[-1] if '.' in query_ref else query_ref
            projections.append({
                "field": field,
                "queryRef": query_ref,
                "nativeQueryRef": native_ref,
                "active": ref.get('active', i == 0),
            })
        if projections:
            query_state[role] = {"projections": projections}
    return query_state


_LEGACY_TO_PBIR_VISUAL_TYPE = {
    # Confirmed via Microsoft's own PBIR authoring guidance: the legacy
    # Layout-blob visualType "card" (used by the .pbit format) is "cardVisual"
    # in PBIR, with its field role renamed from "Values" to "Data" to match.
    'card': ('cardVisual', {'Values': 'Data'}),
}


def _pbir_visual_json(container: dict, metadata: dict) -> dict:
    """Convert one already-built legacy visualContainer (from
    build_report_layout) into a PBIR visual.json object, reusing its
    config (visualType/projections/objects) rather than re-deriving it."""
    try:
        cfg = json.loads(container['config'])
        single = cfg.get('singleVisual', {})
    except Exception:
        single = {}

    legacy_type = single.get('visualType', 'textbox')
    query_state = _pbir_query_state(single)
    pbir_type, role_renames = _LEGACY_TO_PBIR_VISUAL_TYPE.get(legacy_type, (legacy_type, {}))
    if role_renames:
        query_state = {role_renames.get(role, role): v for role, v in query_state.items()}

    return {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.10.0/schema.json",
        "name": _guid(),
        "position": {
            "x": container.get('x', 0), "y": container.get('y', 0), "z": container.get('z', 0),
            "width": container.get('width', 200), "height": container.get('height', 150),
            "tabOrder": container.get('z', 0),
        },
        "visual": {
            "visualType": pbir_type,
            "query": {"queryState": query_state},
            "objects": single.get('objects', {}),
            # PBIR (modern .pbip schema) calls this "visualContainerObjects",
            # not "vcObjects" -- that name is specific to the legacy
            # Layout-blob config format single/vcObjects was read from above.
            "visualContainerObjects": single.get('vcObjects', {}),
        },
    }


# Exact byte-for-byte content of Power BI Desktop's built-in 'CY26SU05'
# base theme, confirmed via a real Desktop-generated PBIP -- report.json's
# resourcePackages entry below references this theme by name/path, so the
# actual StaticResources file must exist alongside it or that reference
# would dangle.
_PBI_BASE_THEME_CY26SU05_JSON = '{"name": "CY26SU05", "dataColors": ["#118DFF", "#12239E", "#E66C37", "#6B007B", "#E044A7", "#744EC2", "#D9B300", "#D64550", "#197278", "#1AAB40", "#15C6F4", "#4092FF", "#FFA058", "#BE5DC9", "#F472D0", "#B5A1FF", "#C4A200", "#FF8080", "#00DBBC", "#5BD667", "#0091D5", "#4668C5", "#FF6300", "#99008A", "#EC008C", "#533285", "#99700A", "#FF4141", "#1F9A85", "#25891C", "#0057A2", "#002050", "#C94F0F", "#450F54", "#B60064", "#34124F", "#6A5A29", "#1AAB40", "#BA141A", "#0C3D37", "#0B511F"], "foreground": "#252423", "foregroundNeutralSecondary": "#605E5C", "foregroundNeutralTertiary": "#B3B0AD", "background": "#FFFFFF", "backgroundLight": "#F3F2F1", "backgroundNeutral": "#C8C6C4", "tableAccent": "#118DFF", "good": "#1AAB40", "neutral": "#D9B300", "bad": "#D64554", "maximum": "#118DFF", "center": "#D9B300", "minimum": "#DEEFFF", "null": "#FF7F48", "hyperlink": "#0078d4", "visitedHyperlink": "#0078d4", "textClasses": {"callout": {"fontSize": 24, "fontFace": "DIN", "color": "#252423"}, "title": {"fontSize": 12, "fontFace": "DIN", "color": "#252423"}, "header": {"fontSize": 12, "fontFace": "Segoe UI Semibold", "color": "#252423"}, "label": {"fontSize": 10, "fontFace": "Segoe UI", "color": "#252423"}}, "visualStyles": {"*": {"*": {"*": [{"wordWrap": true}], "line": [{"transparency": 0}], "outline": [{"transparency": 0}], "plotArea": [{"transparency": 0}], "categoryAxis": [{"showAxisTitle": true, "gridlineStyle": "dotted", "concatenateLabels": false}], "valueAxis": [{"showAxisTitle": true, "gridlineStyle": "dotted"}], "y2Axis": [{"show": true}], "title": [{"titleWrap": true}], "lineStyles": [{"strokeWidth": 3}], "wordWrap": [{"show": true}], "background": [{"show": true, "transparency": 0}], "border": [{"width": 1}], "outspacePane": [{"backgroundColor": {"solid": {"color": "#ffffff"}}, "transparency": 0, "border": true, "borderColor": {"solid": {"color": "#B3B0AD"}}}], "filterCard": [{"$id": "Applied", "transparency": 0, "foregroundColor": {"solid": {"color": "#252423"}}, "border": true}, {"$id": "Available", "transparency": 0, "foregroundColor": {"solid": {"color": "#252423"}}, "border": true}]}}, "scatterChart": {"*": {"bubbles": [{"bubbleSize": -10, "markerRangeType": "auto"}], "general": [{"responsive": true}], "fillPoint": [{"show": true}], "legend": [{"showGradientLegend": true}]}}, "lineChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "forecast": [{"matchSeriesInterpolation": true}], "seriesLabels": [{"enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "map": {"*": {"bubbles": [{"bubbleSize": -10, "markerRangeType": "auto"}]}}, "azureMap": {"*": {"bubbleLayer": [{"bubbleRadius": 8, "minBubbleRadius": 8, "maxRadius": 40}], "barChart": [{"barHeight": 3, "thickness": 3}]}}, "pieChart": {"*": {"legend": [{"show": true, "position": "RightCenter"}], "labels": [{"labelStyle": "Data value, percent of total"}]}}, "donutChart": {"*": {"legend": [{"show": true, "position": "RightCenter"}], "labels": [{"labelStyle": "Data value, percent of total"}]}}, "pivotTable": {"*": {"rowHeaders": [{"showExpandCollapseButtons": true, "legacyStyleDisabled": true}]}}, "multiRowCard": {"*": {"card": [{"outlineWeight": 2, "barShow": true, "barWeight": 2}]}}, "kpi": {"*": {"trendline": [{"transparency": 20}]}}, "cardVisual": {"*": {"layout": [{"maxTiles": 3}, {"$id": "default", "cellPadding": 12, "paddingIndividual": false, "paddingUniform": 12, "backgroundShow": true}], "overflow": [{"type": 0}], "image": [{"$id": "default", "position": "Left", "imageAreaSize": 20, "padding": 12, "rectangleRoundedCurve": 4, "fit": "Normal", "fixedSize": false}], "referenceLabel": [{"$id": "default", "backgroundColor": {"solid": {"color": "backgroundLight"}}, "paddingUniform": 12, "rectangleRoundedCurveCustomStyle": true, "rectangleRoundedCurveLeftBottom": 4, "rectangleRoundedCurveRightBottom": 4}], "referenceLabelDetail": [{"$id": "default", "detailBackgroundColor": {"solid": {"color": "foreground"}}, "detailFontColor": {"solid": {"color": "background"}}}], "referenceLabelTitle": [{"$id": "default", "titleFontColor": {"solid": {"color": "foregroundNeutralSecondary"}}}], "referenceLabelValue": [{"$id": "default", "valueFontFamily": "\'Segoe UI Semibold\', wf_segoe-ui_semibold, helvetica, arial, sans-serif", "fontColor": {"solid": {"color": "foreground"}}}], "value": [{"$id": "default", "fontFamily": "\'Segoe UI Semibold\', wf_segoe-ui_semibold, helvetica, arial, sans-serif"}], "label": [{"$id": "default", "position": "belowValue", "fontColor": {"solid": {"color": "foregroundNeutralSecondary"}}}], "spacing": [{"$id": "default", "verticalSpacing": 2}], "outline": [{"$id": "default", "lineColor": {"solid": {"color": "backgroundLight"}}}], "divider": [{"$id": "default", "dividerColor": {"solid": {"color": "backgroundLight"}}}], "shapeCustomRectangle": [{"$id": "default", "tileShape": "rectangleRoundedByPixel", "rectangleRoundedCurve": 4}], "smallMultiplesOuterShape": [{"$id": "default", "rectangleRoundedCurveCustomStyle": false, "rectangleRoundedCurve": 4}], "smallMultiplesHeader": [{"$id": "default", "paddingIndividual": false, "paddingUniform": 12, "backgroundColor": {"solid": {"color": "backgroundLight"}}}], "smallMultiplesLayout": [{"style": "Table", "cellPadding": 12, "rowCount": 3, "orientation": 1, "titleOrientation": 1, "headerPosition": "Top"}], "smallMultiplesGrid": [{"gridlineColor": {"solid": {"color": "foregroundNeutralTertiary"}}}], "smallMultiplesBorder": [{"$id": "default", "gridlineColor": {"solid": {"color": "foregroundNeutralTertiary"}}}], "padding": [{"$id": "default", "paddingUniform": 12, "paddingIndividual": false}]}}, "advancedSlicerVisual": {"*": {"layout": [{"maxTiles": 3}], "shapeCustomRectangle": [{"$id": "default", "tileShape": "rectangleRoundedByPixel", "rectangleRoundedCurve": 4}], "selectionIcon": [{"$id": "default", "size": 12}], "value": [{"$id": "default", "fontFamily": "\'\'\'Segoe UI Semibold\'\', wf_segoe-ui_semibold, helvetica, arial, sans-serif\'"}]}}, "listSlicer": {"*": {"layout": [{"showFixedSize": true}]}}, "slicer": {"*": {"general": [{"responsive": true}], "date": [{"hideDatePickerButton": false}], "items": [{"padding": 4, "accessibilityContrastProperties": true}]}}, "waterfallChart": {"*": {"general": [{"responsive": true}]}}, "columnChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "clusteredColumnChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "hundredPercentStackedColumnChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "barChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "clusteredBarChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "hundredPercentStackedBarChart": {"*": {"general": [{"responsive": true}], "legend": [{"showGradientLegend": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}]}}, "areaChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "seriesLabels": [{"enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "stackedAreaChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "seriesLabels": [{"enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "lineClusteredColumnComboChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "seriesLabels": [{"backgroundTransparency": 0.9, "enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "lineStackedColumnComboChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "seriesLabels": [{"backgroundTransparency": 0.9, "enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "ribbonChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "valueAxis": [{"show": true}]}}, "hundredPercentStackedAreaChart": {"*": {"general": [{"responsive": true}], "smallMultiplesLayout": [{"backgroundTransparency": 0, "gridLineType": "inner"}], "seriesLabels": [{"enableBackground": true, "leaderLines": true, "seriesMatchColor": true}]}}, "group": {"*": {"background": [{"show": false}]}}, "basicShape": {"*": {"background": [{"show": false}], "general": [{"keepLayerOrder": true}], "visualHeader": [{"show": false}]}}, "shape": {"*": {"background": [{"show": false}], "general": [{"keepLayerOrder": true}], "visualHeader": [{"show": false}]}}, "image": {"*": {"background": [{"show": false}], "general": [{"keepLayerOrder": true}], "visualHeader": [{"show": false}], "padding": [{"left": 0, "top": 0, "right": 0, "bottom": 0}]}}, "actionButton": {"*": {"background": [{"show": false}], "visualHeader": [{"show": false}]}}, "pageNavigator": {"*": {"background": [{"show": false}], "visualHeader": [{"show": false}]}}, "bookmarkNavigator": {"*": {"background": [{"show": false}], "visualHeader": [{"show": false}]}}, "textbox": {"*": {"general": [{"keepLayerOrder": true}], "visualHeader": [{"show": false}]}}, "page": {"*": {"outspace": [{"color": {"solid": {"color": "#FFFFFF"}}}], "background": [{"transparency": 100}]}}}}'


def write_pbir_report(report: dict, report_dir: Path, semantic_model_relative_path: str,
                      schema: dict = None) -> bool:
    """
    Write a <name>.Report/ folder in the modern PBIR format, reusing the
    exact same visual-generation pipeline already proven for .pbit
    (build_report_layout) and re-serializing its output into PBIR's
    per-page/per-visual file layout instead of one big legacy Layout blob.

    Every file is validated immediately before it's written. When schema
    (the semantic model's already-built TOM schema dict) is supplied, each
    visual's field bindings are checked against the real table/column/
    measure list — a binding that references a table or field that
    doesn't actually exist in the model is exactly what produces a null
    field reference when Power BI Desktop opens the report, so that visual
    is skipped (and logged) rather than written with a dangling reference.
    Returns True only if every file wrote successfully.
    """
    fields_by_table = {}
    if schema:
        for t in schema.get('model', {}).get('tables', []):
            fields_by_table[t['name']] = (
                {c['name'] for c in t.get('columns', [])} |
                {m['name'] for m in t.get('measures', [])})

    legacy_layout = build_report_layout(report)
    definition_dir = report_dir / "definition"
    pages_dir = definition_dir / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    all_ok = True

    all_ok &= _validate_and_write_json(
        report_dir / "definition.pbir",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
         "version": "4.0",
         "datasetReference": {"byPath": {"path": semantic_model_relative_path}}},
        "definition.pbir")

    all_ok &= _validate_and_write_json(
        report_dir / ".platform",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
         "metadata": {"type": "Report", "displayName": report.get('name', 'Report')},
         "config": {"version": "2.0", "logicalId": _guid()}},
        "Report/.platform")

    all_ok &= _validate_and_write_json(
        definition_dir / "report.json",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json",
         "themeCollection": {
             "baseTheme": {
                 "name": "CY26SU05",
                 "reportVersionAtImport": {"visual": "2.9.0", "report": "3.3.0", "page": "2.3.1"},
                 "type": "SharedResources",
             },
         },
         "objects": {
             "section": [{"properties": {"verticalAlignment": {"expr": {"Literal": {"Value": "'Top'"}}}}}],
         },
         "resourcePackages": [
             {"name": "SharedResources", "type": "SharedResources",
              "items": [{"name": "CY26SU05", "path": "BaseThemes/CY26SU05.json", "type": "BaseTheme"}]},
         ],
         "settings": {
             "useStylableVisualContainerHeader": True,
             "exportDataMode": "AllowSummarized",
             "defaultDrillFilterOtherVisuals": True,
             "allowChangeFilterTypes": True,
             "useEnhancedTooltips": True,
             "useDefaultAggregateDisplayName": True,
         }},
        "report.json")

    # The theme referenced by resourcePackages above must actually exist at
    # this exact path, or that reference dangles. Content is Power BI
    # Desktop's own built-in "CY26SU05" theme, byte-for-byte, confirmed via
    # a real Desktop-generated PBIP.
    theme_dir = report_dir / "StaticResources" / "SharedResources" / "BaseThemes"
    theme_dir.mkdir(parents=True, exist_ok=True)
    all_ok &= _validate_and_write_json(
        theme_dir / "CY26SU05.json", json.loads(_PBI_BASE_THEME_CY26SU05_JSON), "CY26SU05.json")

    # version.json — required by the PBIR format, sitting alongside
    # report.json/pages/reportExtensions.json in definition/. Content
    # confirmed exact via direct side-by-side comparison against a real
    # Power BI Desktop-generated PBIP.
    all_ok &= _validate_and_write_json(
        definition_dir / "version.json",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",
         "version": "2.0.0"},
        "version.json")

    page_ids = []
    all_visual_ids = []
    for section in legacy_layout.get('sections', []):
        page_id = section.get('name') or _guid()
        page_ids.append(page_id)
        page_dir = pages_dir / page_id
        visuals_dir = page_dir / "visuals"
        visuals_dir.mkdir(parents=True, exist_ok=True)

        page_obj = {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json",
            "name": page_id,
            "displayName": section.get('displayName', page_id),
            "width": section.get('width', 1280),
            "height": section.get('height', 720),
            "displayOption": "FitToPage",
        }
        page_problems = []
        if not isinstance(page_obj['width'], (int, float)) or page_obj['width'] <= 0:
            page_problems.append(f"page {page_id}: width must be a positive number.")
        if not isinstance(page_obj['height'], (int, float)) or page_obj['height'] <= 0:
            page_problems.append(f"page {page_id}: height must be a positive number.")
        all_ok &= _validate_and_write_json(
            page_dir / "page.json", page_obj, f"pages/{page_id}/page.json",
            extra_problems=page_problems)

        for container in section.get('visualContainers', []):
            visual_id = _guid()
            visual_label = f"pages/{page_id}/visuals/{visual_id}/visual.json"

            if container.get('_is_placeholder'):
                info = container.get('_placeholder_info', {})
                _log_file_validation(
                    visual_label, ok=False,
                    problems=[f"no valid Power BI equivalent for Cognos visual "
                             f"'{info.get('title', '?')}' (type: "
                             f"{info.get('cognos_type', 'unknown')}). Reason: "
                             f"{info.get('reason', 'unsupported visual type')}. Recommended: "
                             f"{info.get('recommended_pbi_visual', 'n/a')}. Visual omitted — "
                             f"no placeholder written."])
                continue

            visual_json = _pbir_visual_json(container, {})
            visual_json['name'] = visual_id

            visual_problems = _validate_visual_json(visual_json, fields_by_table, visual_label) \
                if fields_by_table else []
            visual_problems += _validate_visual_not_empty(visual_json, visual_label)
            if visual_problems:
                _log_file_validation(visual_label, ok=False, problems=visual_problems)
                continue

            all_visual_ids.append(visual_id)
            visual_dir = visuals_dir / visual_id
            visual_dir.mkdir(parents=True, exist_ok=True)
            all_ok &= _validate_and_write_json(
                visual_dir / "visual.json", visual_json, visual_label)

    dup_page_problems = _validate_no_duplicate_ids(page_ids, 'page')
    dup_visual_problems = _validate_no_duplicate_ids(all_visual_ids, 'visual')
    for p in dup_page_problems + dup_visual_problems:
        log('error', f"Validation failed — {p}")
    all_ok = all_ok and not dup_page_problems and not dup_visual_problems

    all_ok &= _validate_and_write_json(
        pages_dir / "pages.json",
        {"$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json",
         "pageOrder": page_ids,
         "activePageName": page_ids[0] if page_ids else ""},
        "pages.json")

    return all_ok


def write_pbip_full_project(merged_report: dict, output_dir: Path,
                            embed_sample_data: bool = False,
                            source_data_folder=None) -> Path:
    """
    Case 3 — Framework Manager model + report specification merged: build
    ONE semantic model from the merge (merge_framework_manager_with_report's
    output) and a report bound to it, packaged as a single .pbip project
    containing both a <name>.SemanticModel and a <name>.Report folder.
    Returns the path to the generated .pbip manifest.
    """
    project_name = _safe_pbi_name(merged_report.get('name') or 'Model')
    project_dir = output_dir / project_name
    project_dir.mkdir(parents=True, exist_ok=True)

    log('info', "Extracting Complete Semantic Model...")
    schema = build_data_model_schema(merged_report, embed_sample_data=embed_sample_data,
                                     source_data_folder=source_data_folder,
                                     output_dir=project_dir, materialize_files=True)
    tom_problems = _validate_tom_schema(schema)
    for p in tom_problems:
        log('warn', f"Semantic model validation: {p}")

    log('info', "Building Power BI Semantic Model...")
    semantic_model_dir = project_dir / f"{project_name}.SemanticModel"
    model_ok = write_tmdl_semantic_model(schema, semantic_model_dir)

    log('info', "Generating Report Pages...")
    log('info', "Generating Visuals...")
    report_dir = project_dir / f"{project_name}.Report"
    report_ok = write_pbir_report(merged_report, report_dir, f"../{project_name}.SemanticModel",
                                  schema=schema)

    log('info', "Generating Power BI Project...")
    manifest_ok = _write_pbip_manifest(project_dir, project_name, has_report=True)

    if not (model_ok and report_ok and manifest_ok):
        raise RuntimeError(
            "PBIP generation aborted — one or more files failed pre-write validation (see "
            "the error log above for exactly which file and property).")

    log('info', f"Migration Completed Successfully. -> {project_dir / (project_name + '.pbip')}")
    return project_dir / f"{project_name}.pbip"




def write_pbit(report: dict, output_path: Path, embed_sample_data: bool = False,
               source_data_folder=None):
    """
    Write a valid .pbit file from a parsed Cognos report, running the
    mandatory self-validation pipeline (build -> validate -> rebuild on
    failure) before the file is ever placed at output_path.

    If source_data_folder is given, tables are bound to a matching CSV/Excel
    file in that folder (a live, refreshable data source) instead of
    synthetic or embedded sample data wherever a match is found — see
    find_source_data_file(). Any table without a match still gets a real,
    on-disk CSV data source (materialized under output_path.parent /
    "data_sources") rather than an in-memory literal, so Power BI's Data
    Source Settings is never empty and the source is always user-replaceable.
    """
    output_dir = output_path.parent
    last_problems = []
    entries = None
    for attempt in range(1, _MAX_BUILD_ATTEMPTS + 1):
        log('info', f"Building Power BI package (attempt {attempt}/{_MAX_BUILD_ATTEMPTS})…")
        entries = _build_pbit_entries(report, embed_sample_data=embed_sample_data,
                                      source_data_folder=source_data_folder,
                                      output_dir=output_dir)

        # Write the generated DataModelSchema to a temporary JSON file and
        # validate it there BEFORE it's packaged into the .pbit — this is
        # deliberate: it means a bad schema can be inspected on disk exactly
        # as Power BI Desktop would see it, and the validation failure
        # points at the precise table/column/property (e.g.
        # "model.tables[10].columns[5].expression") rather than only
        # surfacing once Power BI itself rejects the file.
        schema_problems = []
        if 'DataModelSchema' in entries:
            import tempfile as _tempfile
            try:
                schema_text = entries['DataModelSchema'].decode('utf-16-le')
                tmp_fd, tmp_schema_path = _tempfile.mkstemp(
                    suffix='.DataModelSchema.json', prefix='cognos_pbi_')
                with os.fdopen(tmp_fd, 'w', encoding='utf-8') as fh:
                    fh.write(schema_text)
                log('info', f"Wrote DataModelSchema to temporary file for pre-package "
                            f"validation: {tmp_schema_path}")
                schema_model = json.loads(schema_text)
                schema_problems = _validate_tom_schema(schema_model)
                os.unlink(tmp_schema_path)
            except Exception as exc:
                schema_problems = [f"Could not validate temporary DataModelSchema file: {exc}"]

        problems = validate_pbit_entries(entries) + schema_problems
        if not problems:
            log('info', "Package validation passed — no corruption risk detected.")
            break
        last_problems = problems
        for p in problems:
            log('warn', f"Validation issue (attempt {attempt}): {p}")
        if attempt < _MAX_BUILD_ATTEMPTS:
            log('info', "Regenerating package metadata/GUIDs and rebuilding…")
    else:
        pass

    if last_problems and entries is not None:
        final_problems = validate_pbit_entries(entries)
        if final_problems:
            log('error',
                "Package still failed validation after "
                f"{_MAX_BUILD_ATTEMPTS} attempts — writing best-effort output "
                "and flagging for manual review: " + "; ".join(final_problems))

    import tempfile
    tmp_fd, tmp_path = tempfile.mkstemp(suffix='.pbit.tmp', dir=output_path.parent)
    try:
        os.close(tmp_fd)
        with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for name, data in entries.items():
                zf.writestr(name, data)
        try:
            os.replace(tmp_path, output_path)
        except PermissionError:
            raise PermissionError(
                f"Cannot overwrite '{output_path.name}' — close it in "
                f"Power BI Desktop first, then retry.")
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise

    # Final on-disk verification: re-open the written ZIP and re-run
    # validation against exactly the bytes that were persisted, to catch any
    # corruption introduced during the ZIP write itself.
    try:
        with zipfile.ZipFile(output_path) as zf:
            on_disk = {n: zf.read(n) for n in zf.namelist()}
        disk_problems = validate_pbit_entries(on_disk)
        if disk_problems:
            log('error', "Post-write validation found issues: " + "; ".join(disk_problems))
        else:
            log('info', "Post-write validation confirmed the package is structurally sound.")
    except zipfile.BadZipFile as exc:
        log('error', f"Post-write validation failed — ZIP could not be reopened: {exc}")
        raise


# ─────────────────────────────────────────────────────────────────────────────
# Analysis engine + migration documentation (DOCX)
# ─────────────────────────────────────────────────────────────────────────────

def analyze_report(path: Path) -> dict:
    """Parse a Cognos file and return a structured analysis summary."""
    report = parse_cognos_report(path)
    # Build the data model once purely for reporting purposes (per-table/
    # measure/DAX-confidence stats); the real conversion re-runs this fresh
    # during write_pbit() so analysis never affects the actual output file.
    if report['queries']:
        build_data_model_schema(report, embed_sample_data=False)

    total_items = sum(len(q['items']) for q in report['queries'])
    total_measures = sum(1 for q in report['queries'] for it in q['items'] if it['aggregate'])
    total_calc = sum(1 for q in report['queries'] for it in q['items']
                     if it['is_calculated'] and not it['aggregate'])
    total_visuals = sum(len(p.get('objects', [])) for p in report['pages'])

    return {
        'file': path.name,
        'report_name': report['name'],
        'summary': {
            'total_queries': len(report['queries']),
            'total_data_items': total_items,
            'total_measures': total_measures,
            'total_calculated_fields': total_calc,
            'total_pages': len(report['pages']),
            'total_visuals': total_visuals,
            'total_relationships': len(report['relationships']),
            'total_parameters': len(report['parameters']),
        },
        'queries': report['queries'],
        'pages': report['pages'],
        'relationships': report['relationships'],
        'warnings': report['warnings'],
        'audit': report.get('_audit', {}),
        'expression_conversions': report.get('_expression_conversions', []),
        'fm_object_log': report.get('_fm_object_log', []),
    }


def write_migration_docx(analysis: dict, output_path: Path):
    """
    Write migration documentation covering: report summary, migration
    summary, converted visuals, unsupported Cognos features, DAX
    conversions, relationships, filters, parameters, warnings, assumptions,
    and conversion statistics — as required by the Cognos → Power BI
    migration deliverable spec.
    """
    if not _DOCX_OK:
        _write_migration_txt(analysis, output_path.with_suffix('.txt'))
        return

    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()
    title = doc.add_heading(f"Cognos → Power BI Migration Report: {analysis['report_name']}", level=0)

    doc.add_heading("Report Summary", level=1)
    s = analysis['summary']
    table = doc.add_table(rows=0, cols=2)
    table.style = 'Light Grid Accent 1'
    for label, value in [
        ("Source file", analysis['file']),
        ("Queries / tables", s['total_queries']),
        ("Total data items", s['total_data_items']),
        ("Measures", s['total_measures']),
        ("Calculated fields", s['total_calculated_fields']),
        ("Report pages", s['total_pages']),
        ("Layout visuals found", s['total_visuals']),
        ("Relationships", s['total_relationships']),
        ("Parameters / prompts", s['total_parameters']),
    ]:
        row = table.add_row().cells
        row[0].text, row[1].text = str(label), str(value)

    doc.add_heading("Migration Summary", level=1)
    audit = analysis.get('audit', {})
    p = doc.add_paragraph()
    p.add_run(
        f"{audit.get('measures', 0)} measure(s) and {audit.get('calc_columns', 0)} "
        f"calculated column(s) were translated to DAX. "
        f"{audit.get('medium_confidence', 0)} translation(s) partially converted and "
        f"should be spot-checked; {audit.get('low_confidence', 0)} translation(s) could "
        f"not be fully resolved. For those, the original Cognos formula is preserved as "
        f"an OriginalCognosExpression annotation on the object itself (never written "
        f"into the DAX expression, which would break TMDL) alongside a safe placeholder "
        f"value — see the Expression Conversions table below for exactly which ones."
    )

    doc.add_heading("Queries and Data Items", level=1)
    for q in analysis['queries']:
        doc.add_heading(q['name'], level=2)
        t = doc.add_table(rows=1, cols=4)
        t.style = 'Light List Accent 1'
        hdr = t.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = (
            'Data Item', 'Type', 'Aggregate', 'Expression')
        for it in q['items']:
            row = t.add_row().cells
            row[0].text = it['name']
            row[1].text = it['datatype']
            row[2].text = it['aggregate'] or ('calculated' if it['is_calculated'] else '')
            row[3].text = (it['expression'] or '')[:200]
        if q['filters']:
            doc.add_paragraph("Filters:")
            for f in q['filters']:
                doc.add_paragraph(f, style='List Bullet')

    if analysis.get('fm_object_log'):
        doc.add_heading("Framework Manager Model Migration Report", level=1)
        doc.add_paragraph(
            "Every Query Subject and Relationship found in the Framework Manager model, "
            "the Power BI object it became, and its migration outcome.")
        t = doc.add_table(rows=1, cols=6)
        t.style = 'Light List Accent 1'
        hdr = t.rows[0].cells
        for i, h in enumerate(['Original Cognos Object', 'Power BI Object', 'Migration Status',
                               'Warnings', 'Errors', 'Manual Intervention Required']):
            hdr[i].text = h
        for rec in analysis['fm_object_log']:
            row = t.add_row().cells
            row[0].text = rec['original']
            row[1].text = rec['pbi_object']
            row[2].text = rec['status']
            row[3].text = "; ".join(rec.get('warnings', []))
            row[4].text = "; ".join(rec.get('errors', []))
            row[5].text = rec.get('manual_intervention', '') or '—'

    if analysis['relationships']:
        doc.add_heading("Relationships", level=1)
        t = doc.add_table(rows=1, cols=4)
        t.style = 'Light List Accent 1'
        hdr = t.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = (
            'From Table', 'From Column', 'To Table', 'To Column')
        for rel in analysis['relationships']:
            row = t.add_row().cells
            row[0].text, row[1].text = rel['fromTable'], rel['fromColumn']
            row[2].text, row[3].text = rel['toTable'], rel['toColumn']

    if analysis.get('expression_conversions'):
        doc.add_heading("Expression Conversions — Cognos to DAX", level=1)
        doc.add_paragraph(
            "Every calculated column and measure found in the report specification, "
            "with its original Cognos expression, the generated DAX, and the outcome "
            "of automatic syntax validation. A calculation that could not be fully "
            "converted is never written as invalid DAX or left out of the model — its "
            "original Cognos formula is preserved as an OriginalCognosExpression "
            "annotation on the object itself (visible in Power BI Desktop's model view) "
            "and a safe placeholder value is used so the model still loads; "
            "\"Manual Review Required\" flags exactly which ones need attention.")
        t = doc.add_table(rows=1, cols=10)
        t.style = 'Light List Accent 1'
        hdr = t.rows[0].cells
        headers = ['Table Name', 'Column/Measure Name', 'Original Cognos Formula',
                  'Generated DAX', 'Conversion Status', 'Reason', 'Confidence',
                  'Manual Review Required', 'Unsupported Functions', 'Validation Errors']
        for i, h in enumerate(headers):
            hdr[i].text = h
        for rec in analysis['expression_conversions']:
            row = t.add_row().cells
            row[0].text = rec['table']
            row[1].text = rec['name']
            row[2].text = (rec['original'] or '')[:180]
            row[3].text = (rec['dax'] or '')[:180]
            row[4].text = rec['status']
            row[5].text = (rec.get('reason') or '')[:200]
            row[6].text = rec.get('confidence', '')
            row[7].text = 'Yes' if rec.get('manual_review_required') else 'No'
            row[8].text = ', '.join(rec.get('unsupported_functions', [])) or '—'
            row[9].text = '; '.join(rec.get('validation_errors', []))[:200] or '—'
        failed = [r for r in analysis['expression_conversions'] if r['status'] == 'Failed']
        warned = [r for r in analysis['expression_conversions']
                 if r['status'] == 'Converted with warnings']
        doc.add_paragraph(
            f"{len(analysis['expression_conversions'])} expression(s) processed — "
            f"{len(analysis['expression_conversions']) - len(failed) - len(warned)} converted cleanly, "
            f"{len(warned)} converted with warnings requiring a quick review, "
            f"{len(failed)} could not be automatically translated (original formula "
            f"preserved as annotation metadata; placeholder value written in its place) "
            f"and need manual DAX authoring.")

    doc.add_heading("Report Pages and Converted Visuals", level=1)
    for pg in analysis['pages']:
        doc.add_heading(pg['name'], level=2)
        if not pg['objects']:
            doc.add_paragraph("No convertible layout objects were detected on this page.")
            continue
        t = doc.add_table(rows=1, cols=3)
        t.style = 'Light List Accent 1'
        hdr = t.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text = 'Object', 'Kind', 'Source Query'
        for obj in pg['objects']:
            row = t.add_row().cells
            row[0].text = obj.get('name', '')
            row[1].text = obj.get('kind', '')
            row[2].text = obj.get('ref_query', '') or '(unresolved)'

    doc.add_heading("Unsupported Features / Warnings", level=1)
    if analysis['warnings']:
        for w in analysis['warnings']:
            doc.add_paragraph(w, style='List Bullet')
    else:
        doc.add_paragraph("No unsupported features were flagged during conversion.")

    doc.add_heading("Assumptions", level=1)
    for a in [
        "Data types not explicitly declared in the report specification were "
        "inferred from aggregate rules, column-name heuristics, and (when "
        "available) sample values extracted from rendered report output.",
        "Where an exact Cognos → DAX translation could not be derived "
        "automatically, the generated measure/column is annotated with a "
        "comment and a BLANK() placeholder rather than a guessed value.",
        "Static images and Cognos-specific formatting/themes are not "
        "migrated and must be reproduced manually in Power BI.",
        "When no exact source data could be extracted (e.g. a bare report "
        "specification with no embedded output), representative sample data "
        "was generated so the model and visuals can be validated structurally; "
        "replace the partitions with a live data source before production use.",
    ]:
        doc.add_paragraph(a, style='List Bullet')

    doc.save(str(output_path))


def _write_migration_txt(analysis: dict, output_path: Path):
    """Fallback plain-text documentation if python-docx is unavailable."""
    lines = [f"Cognos -> Power BI Migration Report: {analysis['report_name']}", ""]
    lines.append("Report Summary")
    for k, v in analysis['summary'].items():
        lines.append(f"  {k}: {v}")
    lines.append("")
    lines.append("Warnings")
    lines.extend(f"  - {w}" for w in analysis['warnings']) or lines.append("  (none)")
    output_path.write_text("\n".join(lines), encoding='utf-8')


# ─────────────────────────────────────────────────────────────────────────────
# Job tracking + conversion pipeline (mirrors tableau_pbi_server.py exactly)
# ─────────────────────────────────────────────────────────────────────────────

def _update_job(filename: str, status: str, message: str):
    now = datetime.now().strftime("%H:%M:%S")
    if filename not in conversion_state["jobs"]:
        conversion_state["jobs"][filename] = {"started": now}
    job = conversion_state["jobs"][filename]
    job["status"] = status
    job["message"] = message
    if status in ("done", "error"):
        job["finished"] = now
    broadcast("job_update", {"filename": filename, "status": status,
                              "message": message, "ts": now})


def analyze_file(cognos_path: Path, target_dir: Path):
    """
    Analyze a Cognos report/spec/package and write migration documentation.

    Output is always placed in:  target_dir / "analysis" / <stem>_analysis.docx
    (falling back to .txt if python-docx could not be installed).
    """
    filename = cognos_path.name
    analysis_dir = target_dir / "analysis"
    out_name = cognos_path.stem + "_analysis.docx"
    out_path = analysis_dir / out_name

    try:
        _update_job(filename, "running", "Reading Cognos report…")
        log("info", f"Reading {filename}", filename)
        log("info", "Extracting XML…" if cognos_path.suffix.lower() in
            ('.xml', '.spec', '.report') else "Extracting report content…", filename)

        analysis = analyze_report(cognos_path)
        s = analysis['summary']
        _update_job(filename, "running",
                    f"Extracted: {s['total_queries']} quer(y/ies), "
                    f"{s['total_data_items']} data item(s), {s['total_pages']} page(s)")
        log("info",
            f"  -> {s['total_queries']} quer(y/ies), {s['total_measures']} measure(s), "
            f"{s['total_calculated_fields']} calculated field(s)", filename)
        for w in analysis['warnings'][:20]:
            log("warn", w, filename)

        _update_job(filename, "running", f"Writing {out_name}…")
        analysis_dir.mkdir(parents=True, exist_ok=True)
        write_migration_docx(analysis, out_path)
        if not out_path.exists():
            out_path = out_path.with_suffix('.txt')

        size_kb = max(1, out_path.stat().st_size // 1024)
        _update_job(filename, "done",
                    f"Analysis saved -> analysis/{out_path.name} ({size_kb} KB)")
        log("info", f"Analysis written -> {out_path} ({size_kb} KB)", filename)

    except Exception as exc:
        tb = traceback.format_exc()
        _update_job(filename, "error", f"Analysis failed: {exc}")
        log("error", f"Analysis failed: {exc}", filename)
        log("error", tb, filename)


def convert_file(cognos_path: Path, target_dir: Path, embed_sample_data: bool = False,
                 source_data_folder=None):
    filename = cognos_path.name

    try:
        _update_job(filename, "running", "Parsing Cognos artifact…")
        log("info", f"Parsing {filename}", filename)

        report = parse_cognos_report(cognos_path)

        for w in report['warnings']:
            log("warn", w, filename)

        _update_job(filename, "running",
                    f"Parsed: {len(report['queries'])} quer(y/ies), "
                    f"{len(report['pages'])} page(s)")
        log("info",
            f"  -> {len(report['queries'])} quer(y/ies)/table(s), "
            f"{len(report['pages'])} report page(s)", filename)

        if not report['queries']:
            raise ValueError(
                "No queries, data items, or extractable tables were found in "
                "this file — nothing to convert.")

        if report.get('_artifact_type') == 'framework_manager':
            # Case 2 — Framework Manager model only: complete Power BI
            # Project (.pbip) with a semantic model and no report pages.
            log("info", "Converting expressions to DAX…", filename)
            _update_job(filename, "running", "Building Power BI Semantic Model…")
            target_dir.mkdir(parents=True, exist_ok=True)
            pbip_path = write_pbip_semantic_model_only(
                report, target_dir, embed_sample_data=embed_sample_data,
                source_data_folder=source_data_folder)
            size_kb = sum(f.stat().st_size for f in pbip_path.parent.rglob('*') if f.is_file()) // 1024
            _update_job(filename, "done", f"Created {pbip_path.name} ({size_kb} KB)")
            log("info", f"Conversion completed successfully -> {pbip_path} ({size_kb} KB)", filename)
            return

        # Case 1 — report specification only: Power BI Template (.pbit),
        # exactly the existing, unchanged workflow.
        out_name = cognos_path.stem + ".pbit"
        out_path = target_dir / out_name

        log("info", "Converting SQL/expressions to DAX…", filename)
        log("info", "Generating Power BI model…", filename)
        if source_data_folder:
            log("info", f"Live data source folder set: {source_data_folder} "
                        f"(tables are matched by name; unmatched tables fall "
                        f"back to sample data)", filename)
        _update_job(filename, "running", "Building Power BI data model…")

        log("info", "Generating report layout…", filename)
        _update_job(filename, "running", "Building report layout…")

        log("info", "Creating DataModelSchema…", filename)
        log("info", "Generating PBIT…", filename)

        mode_label = " [sample data]" if embed_sample_data else ""
        _update_job(filename, "running", f"Writing {out_name}{mode_label}…")

        target_dir.mkdir(parents=True, exist_ok=True)
        log("info", "Validating package…", filename)
        log("info", "Checking internal references…", filename)
        log("info", "Packaging outputs…", filename)
        write_pbit(report, out_path, embed_sample_data=embed_sample_data,
                  source_data_folder=source_data_folder)

        size_kb = out_path.stat().st_size // 1024
        _update_job(filename, "done", f"Created {out_name}{mode_label} ({size_kb} KB)")
        log("info", f"Conversion completed successfully -> {out_path} ({size_kb} KB)", filename)

    except Exception as exc:
        tb = traceback.format_exc()
        _update_job(filename, "error", f"{exc}")
        log("error", f"Conversion failed: {exc}", filename)
        log("error", tb, filename)


def _count_report_visuals(report: dict) -> int:
    """
    Count real visual objects (list/crosstab/chart/table/gauge/map/etc.)
    across every page of an already-parsed report, excluding plain
    text/textbox/image/rectangle chrome. Used only for the "visual count"
    detection summary surfaced to the UI — not part of the actual
    conversion logic, which already handles every object individually.
    """
    non_visual_kinds = {'text', 'textbox', 'image', 'rectangle'}
    count = 0
    for page in report.get('pages', []):
        for obj in page.get('objects', []):
            if obj.get('kind') not in non_visual_kinds:
                count += 1
    return count


_COGNOS_REPO_IGNORED_DIR_NAMES = {
    'logs', 'log', 'temp', 'tmp', 'backup', 'backups', '__pycache__', 'node_modules',
}


def detect_cognos_repository(root_folder) -> dict:
    """
    Auto-detect a Cognos Analytics On-Premise repository's layout inside
    root_folder, searching RECURSIVELY and supporting every folder
    convention Cognos environments commonly use:

        Structure 1 (documented convention):
            <root>/model/model.xml, <root>/content_store/report.xml,
            <root>/sample_data/*.csv

        Structure 2 (renamed folders):
            <root>/model/, <root>/reports/, <root>/data/

        Structure 3 (flat — no subfolders at all):
            <root>/model.xml, <root>/report.xml, <root>/*.csv

        Structure 4 (nested repositories — any of the above one level
            deeper inside an extra wrapper folder)

    Every .xml/.spec/.report file found anywhere under root_folder is
    classified by its actual content (via detect_cognos_artifact_type),
    not by folder name — so renamed or nested folders are still detected
    correctly. Skips any 'logs', 'temp', 'backup', '__pycache__', or
    hidden (dot-prefixed) folder while walking.

    If multiple model.xml candidates are found, the one closest to
    root_folder (fewest path segments below it) wins; a tie is broken in
    favor of one that actually sits under a folder named "model". If
    multiple report.xml candidates are found, one sitting under a folder
    named "content_store" is preferred first, then the closest to root.

    Returns:
        {
            "project_root": str,
            "model_xml": str | None,
            "report_xml": str | None,
            "sample_data": [str, ...],
        }
    """
    root = Path(root_folder)
    result = {"project_root": str(root), "model_xml": None, "report_xml": None, "sample_data": []}
    if not root.is_dir():
        log('error', f"Input folder not found: {root}")
        return result

    log('info', "Scanning Cognos Repository...")

    def _is_ignored(path: Path) -> bool:
        # Only the directory segments matter here, not the file name itself.
        for part in path.relative_to(root).parts[:-1]:
            if part.startswith('.') or part.lower() in _COGNOS_REPO_IGNORED_DIR_NAMES:
                return True
        return False

    xml_like, data_files = [], []
    for p in root.rglob('*'):
        if not p.is_file() or _is_ignored(p):
            continue
        suffix = p.suffix.lower()
        if suffix in ('.xml', '.spec', '.report'):
            xml_like.append(p)
        elif suffix in ('.csv', '.tsv', '.txt', '.xlsx', '.xlsm', '.xls'):
            data_files.append(p)

    fm_candidates, report_candidates = [], []
    for p in xml_like:
        try:
            root_el = ET.fromstring(p.read_text(encoding='utf-8', errors='replace'))
            kind = detect_cognos_artifact_type(root_el)
        except ET.ParseError:
            kind = 'report'
        (fm_candidates if kind == 'framework_manager' else report_candidates).append(p)

    if fm_candidates:
        def _fm_sort_key(p: Path):
            depth = len(p.relative_to(root).parts)
            in_model_folder = 0 if 'model' in {s.lower() for s in p.parts} else 1
            return (depth, in_model_folder, str(p))
        fm_candidates.sort(key=_fm_sort_key)
        result['model_xml'] = str(fm_candidates[0])
        log('info', "Model XML found.")
    else:
        log('warn', "Framework Manager model.xml not found.")

    if report_candidates:
        def _report_sort_key(p: Path):
            in_content_store = 0 if 'content_store' in {s.lower() for s in p.parts} else 1
            depth = len(p.relative_to(root).parts)
            return (in_content_store, depth, str(p))
        report_candidates.sort(key=_report_sort_key)
        result['report_xml'] = str(report_candidates[0])
        log('info', "Report XML found.")
    else:
        log('warn', "Report XML not found.")

    if data_files:
        preferred_folder = None
        for p in data_files:
            parts_lower = {s.lower() for s in p.parts}
            if 'sample_data' in parts_lower or 'data' in parts_lower:
                preferred_folder = p.parent
                break
        if preferred_folder is None:
            folder_counts: dict = {}
            for p in data_files:
                folder_counts[p.parent] = folder_counts.get(p.parent, 0) + 1
            preferred_folder = max(folder_counts, key=folder_counts.get)
        result['sample_data'] = [str(p) for p in data_files if p.parent == preferred_folder]
        log('info', "Sample Data detected.")

    if result['model_xml'] or result['report_xml']:
        log('info', "Repository detected.")

    return result


def _discover_fm_project_layout(root_dir: Path) -> dict:
    """
    Backward-compatible wrapper around detect_cognos_repository(), kept
    for the existing conversion_worker/convert_file_pair call sites that
    expect this older return shape (Path objects instead of strings, and
    fm_path/report_paths/csv_folder/csv_files instead of
    model_xml/report_xml/sample_data).
    """
    repo = detect_cognos_repository(root_dir)
    result = {'fm_path': None, 'extra_fm_paths': [], 'report_paths': [],
             'csv_folder': None, 'csv_files': []}
    if repo['model_xml']:
        result['fm_path'] = Path(repo['model_xml'])
    if repo['report_xml']:
        result['report_paths'] = [Path(repo['report_xml'])]
    if repo['sample_data']:
        csv_paths = [Path(p) for p in repo['sample_data']]
        result['csv_files'] = csv_paths
        result['csv_folder'] = csv_paths[0].parent
    return result


def convert_file_pair(fm_path: Path, report_path: Path, target_dir: Path,
                      embed_sample_data: bool = False, source_data_folder=None):
    """
    Case 3 — a Framework Manager model AND a report specification uploaded
    together: merge them (the FM model is the authoritative semantic
    model; the report's queries resolve against it by name) and produce
    ONE complete Power BI Project (.pbip) containing both a bound semantic
    model and report pages. See merge_framework_manager_with_report() and
    write_pbip_full_project() for the actual merge/packaging logic.
    """
    filename = f"{fm_path.name} + {report_path.name}"
    try:
        _update_job(filename, "running", "Parsing Framework Manager model and report…")
        fm_report = parse_cognos_report(fm_path)
        report_report = parse_cognos_report(report_path)
        for w in fm_report['warnings'] + report_report['warnings']:
            log("warn", w, filename)

        log("info", "Store Metadata Repository...", filename)
        log("info", "Load Report Specification XML...", filename)
        log("info", "Match Report Queries...", filename)
        merged = merge_framework_manager_with_report(fm_report, report_report)
        for w in merged['warnings'][len(fm_report['warnings']):]:
            log("warn", w, filename)

        table_count = len(merged.get('queries', []))
        relationship_count = len(merged.get('relationships', []))
        visual_count = _count_report_visuals(report_report)
        log("info", f"Detected model: {table_count} table(s), {relationship_count} "
                    f"relationship(s), {visual_count} visual(s).", filename)
        broadcast("cognos_detect", {
            "model_xml": fm_path.name, "report_xml": report_path.name,
            "table_count": table_count, "relationship_count": relationship_count,
            "visual_count": visual_count,
        })

        _update_job(filename, "running", "Building merged Power BI Project…")
        target_dir.mkdir(parents=True, exist_ok=True)
        pbip_path = write_pbip_full_project(
            merged, target_dir, embed_sample_data=embed_sample_data,
            source_data_folder=source_data_folder)

        size_kb = sum(f.stat().st_size for f in pbip_path.parent.rglob('*') if f.is_file()) // 1024
        _update_job(filename, "done", f"Created {pbip_path.name} ({size_kb} KB)")
        log("info", f"Conversion completed successfully -> {pbip_path} ({size_kb} KB)", filename)

    except Exception as exc:
        tb = traceback.format_exc()
        _update_job(filename, "error", f"{exc}")
        log("error", f"Conversion failed: {exc}", filename)
        log("error", tb, filename)


def process_file(cognos_path: Path, target_dir: Path,
                 embed_sample_data: bool = False, mode: str = 'migrate',
                 pbix_params: dict = None, source_data_folder=None):
    """
    Route a Cognos file through the selected processing mode, then
    optionally convert the resulting PBIT to PBIX (reusing the Tableau
    engine's generic, format-agnostic PBIT -> PBIX helpers).

    mode options:
      'migrate'          - Convert to PBIT only
      'analyze'          - Migration documentation only
      'analyze_migrate'  - Both documentation AND PBIT

    source_data_folder (optional): a folder containing CSV/Excel files, one
    per table, named to match either the converted Power BI table name or
    the original Cognos query name (e.g. "qMain.csv"). Any table with a
    matching file is bound to that file as a live, refreshable Power BI
    data source instead of synthetic/embedded sample data; tables without a
    match keep the previous fallback behavior unchanged.
    """
    if mode == 'analyze':
        analyze_file(cognos_path, target_dir)
        return

    if mode == 'analyze_migrate':
        analyze_file(cognos_path, target_dir)

    convert_file(cognos_path, target_dir, embed_sample_data, source_data_folder)

    if pbix_params and pbix_params.get('method') not in (None, '', 'none'):
        pbit_path = target_dir / (cognos_path.stem + ".pbit")
        method = pbix_params['method']
        if pbit_path.exists():
            if method == 'desktop':
                _pbix_via_desktop(
                    pbit_path, target_dir,
                    pbi_exe=pbix_params.get('pbi_exe', ''),
                    timeout=int(pbix_params.get('timeout', 90)))
            elif method == 'api':
                _pbix_via_api(
                    pbit_path, target_dir,
                    tenant_id=pbix_params.get('tenant_id', ''),
                    client_id=pbix_params.get('client_id', ''),
                    client_secret=pbix_params.get('client_secret', ''),
                    workspace_id=pbix_params.get('workspace_id', ''))
        else:
            log("warn", f"PBIX conversion skipped — PBIT not found: {pbit_path.name}",
                cognos_path.name)


def _quick_classify_artifact(path: Path) -> str:
    """Lightweight classification used only by the folder watcher to decide
    whether newly-arrived files should be paired (Case 3) — full parsing
    still happens exactly once, inside convert_file/convert_file_pair."""
    if path.suffix.lower() not in ('.xml', '.spec', '.report'):
        return 'report'   # non-XML formats are always report-style inputs
    try:
        root = ET.fromstring(path.read_text(encoding='utf-8', errors='replace'))
        return detect_cognos_artifact_type(root)
    except ET.ParseError:
        return 'report'


def conversion_worker(source_dir: str, target_dir: str,
                      embed_sample_data: bool = False, mode: str = 'migrate',
                      pbix_params: dict = None, source_data_folder=None):
    src = Path(source_dir).resolve()
    tgt = Path(target_dir).resolve()
    seen: set = set()

    log("info", f"Watching {src}  ->  {tgt}  [mode: {mode}]"
                + (f"  [live data source: {source_data_folder}]" if source_data_folder else ""))
    broadcast("status", {"running": True, "source": str(src), "target": str(tgt)})

    while conversion_state["running"]:
        try:
            # ── Nested project-folder auto-detection ────────────────────────
            # In addition to the flat top-level scan below (unchanged, for
            # backward compatibility with single-file/legacy uploads), also
            # look for the IBM Cognos Analytics On-Premise project layout
            # (model/model.xml, content_store/report.xml, sample_data/*.csv)
            # anywhere under the watched folder — the shape produced by
            # exporting a Framework Manager package + report + sample data
            # together as one folder upload.
            layout = _discover_fm_project_layout(src)
            if layout['fm_path'] is not None:
                fm_key = f"PROJECT_FM:{layout['fm_path'].resolve()}:{layout['fm_path'].stat().st_mtime}"
                if fm_key not in seen:
                    seen.add(fm_key)
                    # Also claim this file's flat-top-level-scan key so the
                    # unchanged flat scan just below never re-processes the
                    # same physical file a second time under Structure 3
                    # (no subfolders at all, where both code paths would
                    # otherwise see the exact same model.xml/report.xml).
                    seen.add(f"{layout['fm_path'].name}:{layout['fm_path'].stat().st_mtime}")
                    effective_data_folder = source_data_folder or (
                        str(layout['csv_folder']) if layout['csv_folder'] else None)
                    log("info", f"Detected project folder layout under {src}: "
                                f"model.xml -> {layout['fm_path'].name}; "
                                f"{len(layout['report_paths'])} report file(s); "
                                f"{len(layout['csv_files'])} CSV/Excel file(s) in "
                                f"{layout['csv_folder'].name if layout['csv_folder'] else 'n/a'}.")
                    def _rel(p):
                        try:
                            return str(p.relative_to(src))
                        except ValueError:
                            return p.name
                    broadcast("cognos_detect", {
                        "project_root": src.name,
                        "model_xml": layout['fm_path'].name,
                        "model_xml_relative": _rel(layout['fm_path']),
                        "report_xml": [p.name for p in layout['report_paths']],
                        "report_xml_relative": [_rel(p) for p in layout['report_paths']],
                        "csv_files": [p.name for p in layout['csv_files']],
                        "csv_count": len(layout['csv_files']),
                        "csv_folder": str(layout['csv_folder']) if layout['csv_folder'] else None,
                    })
                    if layout['report_paths']:
                        for report_path in layout['report_paths']:
                            rp_key = f"PROJECT_REPORT:{report_path.resolve()}:{report_path.stat().st_mtime}"
                            seen.add(rp_key)
                            seen.add(f"{report_path.name}:{report_path.stat().st_mtime}")
                            log("info", "Migration started.")
                            threading.Thread(
                                target=convert_file_pair,
                                args=(layout['fm_path'], report_path, tgt,
                                      embed_sample_data, effective_data_folder),
                                daemon=True).start()
                    else:
                        log("warn", f"Project folder model.xml detected but no report "
                                    f"specification was found alongside it — converting the "
                                    f"Framework Manager model on its own.")
                        threading.Thread(
                            target=process_file,
                            args=(layout['fm_path'], tgt, embed_sample_data, mode,
                                  pbix_params, effective_data_folder),
                            daemon=True).start()
                    for extra_fm in layout['extra_fm_paths']:
                        extra_key = f"PROJECT_FM:{extra_fm.resolve()}:{extra_fm.stat().st_mtime}"
                        if extra_key not in seen:
                            seen.add(extra_key)
                            seen.add(f"{extra_fm.name}:{extra_fm.stat().st_mtime}")
                            threading.Thread(
                                target=process_file,
                                args=(extra_fm, tgt, embed_sample_data, mode,
                                      pbix_params, effective_data_folder),
                                daemon=True).start()

            # ── Flat top-level scan (original behavior, unchanged) ─────────
            cognos_files = []
            for ext in SUPPORTED_EXTENSIONS:
                cognos_files.extend(src.glob(f"*{ext}"))
            new_files = []
            for cf in cognos_files:
                key = f"{cf.name}:{cf.stat().st_mtime}"
                if key not in seen:
                    seen.add(key)
                    new_files.append(cf)

            if new_files:
                # Automatic Case-3 detection: when a Framework Manager model
                # and a report specification both arrive together, merge and
                # process them as one paired migration instead of two
                # independent ones — "the application should automatically
                # detect the uploaded file type(s) [and] merge the semantic
                # model with the report when both are provided."
                classified = [(cf, _quick_classify_artifact(cf)) for cf in new_files]
                fm_files = [cf for cf, kind in classified if kind == 'framework_manager']
                report_files = [cf for cf, kind in classified if kind == 'report']

                if fm_files and report_files:
                    fm_path = fm_files[0]
                    for report_path in report_files:
                        log("info", f"Detected Artifact: Framework Manager Model + Report "
                                    f"Specification ({fm_path.name} + {report_path.name}) — "
                                    f"merging into one Power BI Project.")
                        threading.Thread(
                            target=convert_file_pair,
                            args=(fm_path, report_path, tgt, embed_sample_data, source_data_folder),
                            daemon=True).start()
                    for extra_fm in fm_files[1:]:
                        threading.Thread(
                            target=process_file,
                            args=(extra_fm, tgt, embed_sample_data, mode, pbix_params, source_data_folder),
                            daemon=True).start()
                else:
                    for cf in new_files:
                        threading.Thread(
                            target=process_file,
                            args=(cf, tgt, embed_sample_data, mode, pbix_params, source_data_folder),
                            daemon=True).start()
        except Exception as e:
            log("error", f"Watcher error: {e}")
        time.sleep(2)

    broadcast("status", {"running": False})
    log("info", "Watcher stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# Standalone CLI entry point (for local testing only — normally this module
# is imported in-process by report_migration_tool.py, exactly like the
# Tableau engine).
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="IBM Cognos Analytics -> Power BI Migration Engine (standalone test mode)")
    parser.add_argument("--source", default="./cognos_source")
    parser.add_argument("--target", default="./cognos_target")
    parser.add_argument("--mode", default="analyze_migrate",
                        choices=["migrate", "analyze", "analyze_migrate"])
    parser.add_argument("--embed-sample-data", action="store_true")
    parser.add_argument("--source-data-folder", default=None,
                        help="Optional folder of CSV/Excel files (one per table, named to "
                             "match the table) to use as a live data source instead of "
                             "sample data.")
    args = parser.parse_args()

    os.makedirs(args.source, exist_ok=True)
    os.makedirs(args.target, exist_ok=True)
    conversion_state.update(running=True, source=args.source, target=args.target, jobs={})
    print(f"[cognos] Watching {args.source} -> {args.target}  [mode: {args.mode}]  (Ctrl+C to stop)")
    try:
        conversion_worker(args.source, args.target, args.embed_sample_data, args.mode, {},
                          args.source_data_folder)
    except KeyboardInterrupt:
        conversion_state["running"] = False
        print("\n[cognos] Stopped.")